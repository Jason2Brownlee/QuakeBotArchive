------------------------------------------------------------
Grappling Hook QuakeC Mod v2.2			10/9/96
Compiled with the new Quake v1.06 source code
By: Perecli Manole AKA: Bort
------------------------------------------------------------

This version of the grappling hook is the most playable.
It allows usage with just one key, while allowing your
undisturbed use of weapons at all times.


Description
-----------
Grapplig hook is a rotating iron shaft with claws, thrown by
a chain and used for grasping, drawing and holding. Can be
used for getting out of tight spots, getting to unreachable
places and even grabbing your enemy, inflicting great pain.
Grappling hook does not use any ammunition.

Usage
-----
   impulse 98      to throw, hook, and pull
   impulse 97      to let go 

I recommend binding your keys like this. In your autoexec.cfg
add these lines:

   // grappling hook
   alias +hook "impulse 98"
   alias -hook "impulse 97"
   bind [Your desired key] +hook

This will ensure better playability since you can control
the grappling hook with just one key.


Installation
------------
In your Quake directory parallel to the id1 directory make
a new directory called "hook". In this directory, put the
pak0.pak file supplied and your autoexec.cfg with the above
lines added. From within the quake directory start Quake with
this command line:

quake -game hook


If you need help or have any comments or suggestions regarding this
mod, here is my address: Perecli@ix.netcom.com

Special thanks to:
Mike (Last name unknown) for the hook model.