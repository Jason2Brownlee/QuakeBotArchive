================
= Best Of Void =
================

Best of Void was written from scratch with gameplay, weapon balance, and ease of use in mind.
The sheer variety of Best Void is its strength.  It caters to an entire army of different tastes and preferences, so that you can set up your deathmatch or CTF game however you please.  Deathmatch, Teamplay, Capture the Flag, and even Single Player are all a brand new world.  BestVoid is meant to be a Deathmatch and CTF mod, though Single Player is possible (but not recommended).


=============

Installation

=============
Please note that you will need Quake v.1.08 or higher, or GL Quake to use gamecfg variables.  If you have a lower version than that, simply find quake.zip in your bestvoid folder after installing and extract the quake.exe into your quake folder.


Extract the zip into a new folder named "bestvoid" in your Quake directory.  For example:
C:\quake\bestvoid\

If you are upgrading from an old version, delete the old version first.

Run Quake with the parameter -game bestvoid
For example:
quake -game bestvoid
glquake -game bestvoid
winquake -game bestvoid

Then simply start a multiplayer game and spawn some bots or get your friends to join!



=============
=Weapon List=
=============

1.	Blaster
2.	Nailgun
3.	Rapid Fire Canister Rifle
4.	Explosive Shell Shotgun
5.	Namek Machine Gun
6.	Particle Cannon (press again for Napalm)
7.	Rocket Launcher
8.	Hyper Blaster


==========
=Impulses=
==========
An autoexec.cfg is included with BestVoid to create these aliases.  Make sure you don't erase it. An autoexec.cfg allows players to set up commands they want used when the game starts (such as +mlook or autoswitchoff), so go ahead and use those

=Common Use Commands=
Commands you should bind to a key:
impulse	 command		action
--------------
10	cyclewep		Cycle Weapon Command
11	cyclerev		Cycle Weapon Reverse Command
12	lb or laserbomb		Set laser bomb (above all other impulses, bind this to a handy key!)

14	+hook			Use your offhand grappling hook (if enabled with gamecfg)

15	dropflag		Drop the CTF flag(s) you are carrying in a ctf game

=Lower Priority Commands=
Less important or one-time use commands:
impulse	 command		action
--------------
30	gamemenu		Opens game options menu.  You can set gamecfg, temp1 and other game options with it.

13	killprobe		Dispose probe (not really needed)

50	autoswitchoff		Turn off auto weapon switching.  Won't switch weapons when you pick up weapons or ammo.
51	autoswitchon		Turn auto weapon switching back on again.

20	useturret		Use the controllable turret you are looking at

100	addbot			Add a Frikbot
101	addteambot		Add a Frikbot to other team (teamplay)
102	killbot			Remove a Frikbot
103	botcam			Player Cam - watch from another player/bot's eyes


==================
= Other Commands =
==================

deathmatch 3 or higher will activate CTF.  Values higher than 3 will activate different ctf variations.  Please see CTF section below for more info.

noexit 2 works like noexit 1, in that it will disallow players to exit the level; but it won't gib them the way noexit 1 does

gamecfg x	Activates gamecfg options, where x is the combined values of all gamecfg options you want activated.
(note: see below for info on gamecfg & other gameplay option variables)

temp1 x		Activates temp1 options.

nomonsters x	When using the random gamecfg option, nomonsters can be used to define which gamecfgs you want to select from, if you don't want it to select from the whole list.

savedgamecfg x	Sets the gamecfg's that will always be active if random gamecfg options is set.  This option will be saved in your config.cfg, so be sure to set it to 0 or a new value next time you use random gamecfg's, or the old values will still be there.


==============
=Game Options=
==============
Gamecfg and temp1 variables are the main feature of Best of Void.  They allow you to customize your deathmatch game to however you want it.  You can increase player's health, double amount of damage done, start with all weapons, respawn with 3 seconds of invulnerability, or even make the level almost completely dark!  As the server, it's your call.
These variables affect everyone - you can't just give yourself 800 health and 8x damage :)  Also, only the server can directly change the gamecfg/temp1, and only the first (longest playing) player can use the menu.

Enabling game options is easy.  Just go to the console and type "gamemenu" without the quotes.

===================
Navigating the Menu
===================

The menu is simple to use.  Simply note the number next to the option you want and press it.  At any time you can press 0 to Quit or 9 to back up to the previous menu.  When you quit the menu, the gameconfig is reprinted to you so you can review it over to make sure it's correct.  See the sections below for a listing of Gamecfg and Temp1 values and descriptions.  Only the server or the first (longest playing) player can use the menu.
Following are descriptions of the different menus you can use:

*	Main Menu
The main menu you'll be dealing with.  Use it to access the other menus and perform other actions.
1. Gamecfg Options 	- Toggle Gamecfg options on and off.
2. Temp1 Options		- Toggle Temp1 options on and off.
3. Random Variables	- Toggle the options involved with randomly selected variables
4. Deactivate All Options	- Turn off all options and start fresh
5. Reload Level		- Reloads the level so that certain options can take effect

*Gamecfg Options
The gamecfgs are split into 3 groups because there are so many of them.
1. Gamecfg Part I		- First set of gamecfg options
2. Gamecfg Part II		- Second set of gamecfg options
3. Gamecfg Part III	- Third set of gamecfg options

*Temp1 Options
The temp1s are split into 3 groups because there are many of them, and there are several groups.
1. Temp1 Part I		- General/Misc temp1 options
2. Temp1 Part II		- Start With Weapon optons
3. Temp1 Part III		- Ban Weapon options

*Gamecfg Part I-III
Simply press numbers 1-8 to toggle the options you want on and off.

*Gamecfg Part I-III
Simply press numbers 1-8 to toggle the options you want on and off.

*Random Variables
Gamecfgs can be selected randomly when each level loads.  Using this menu you can enable this option and control what options will be selected from and what options will always be active.  Sorry, temp1 options cannot be randomly selected from, only gamecfg.
1. Enable/Disable Random Gamecfgs - Toggle random gamecfg selection on or off.  If the "Random List" and "Static List" aren't set, the options are just selected from the full list of gamecfgs.
2. Copy current gamecfg to Random list - The random list is the list of options you want the random gamecfgs to be selected from.  This option will set this list to whatever the current gamecfg is now.  So, just go back and choose the options you want to have in the list, and then use this to set the Random List.
3. Copy to list of Static Variables - Same as copy to random list (above), but the Static List is the gamecfg options that will *always* be enabled, no matter what other options are selected.
4. Clear Random list	- Clears the Random List so that the random variables are selected from the full list
5. Clear Static list	- Clears the Static List so that no gamecfg's will always be on.


Remember:
Some options will require that you either die or restart the map before they take effect.
The options aren't done yet.  Those without numbers in front of them aren't yet available.

============================================
Using Gamecfg & Temp1 on a dedicated server:
============================================

Because the menu isn't available to a dedicated server console, you'll have to edit the variables directly.

Add the numbers of the options below that you want together (better break out the ol' calculator) and at the console type:
gamecfg x
replacing x with the combined total of numbers of the options you wanted (look at your calculator screen.  LOW BATTERY is not a valid gamecfg :P ).  For example,
gamecfg 290
will give the player 300 health (starting 100 + 200 more) and double the amount of damage they do and the amount that health boxes heal (gamecfg's 2 + 32 + 256).

Temp1's the same way.  For example,
temp1 12
will scale the impact shock of attacks and the amount of damage that must be done for a gib, if one of the gamecfg variables is making the damage real high (so you won't fly across the map when you're hit by a nail and you won't gib with just any attack).



-----------
The Options
-----------

The numbers next to the options are only used for editing the configs directly, most people won't need to worry about them.

****************

Gamecfg

****************



===Damage Modifiers, can be combined for 2x, 4x, or 8x damage.  Quad Damage Powerup will increase this even more.

1	Realistic Falling Damage

2	Super Damage - 2x

4	Mega Damage - 4x

8	Instant kill deathmatch mode


===Health modifiers, combined for desired amount of health.  Capped at 999 - not even megahealths will exceed this.

16	+100 health

32	+200 health

64	+300 health

128	+400 health


===Health box modifiers, can be combined for 2x, 4x, or 8x healing.

256	Super Health Boxes - 2x healing

512	Mega Health Boxes - 4x

1024	Health Boxes take you above your starting health

8192	Health Boxes do not take you above 100 health (overrides above option)

524288	Super Armor - Lasts 2x as long

1048576	Mega Armor - Lasts 4x as long


===Misc Options

2048	Invincible for 3 seconds on respawn

4096	Grappling Hook (see impulse commands)

32768	All Weapons

16384	Start without ammo

65536	Start with Full Ammo

131072	Night Hunters (whole level is dark)

262144	Players glow - easier to see in dark places

2097152	Random Weapon upgrade - Some weapon becomes permanently superpowerful to contend with RL & Hyperblaster



****************

Temp1

****************

===Disablers - Disables a certain feature, weapon, etc

64	No turrets

128	No Gibbing

32768	Weapon #2 is banned
65536	Weapon #3 is banned
131072	Weapon #4 is banned
262144	Weapon #5 is banned
524288	Weapon #6 is banned
1048576	Weapon #7 is banned
2097152	Weapon #8 is banned

===Start with weapons - player will always have weapon #1 & #2:

512	Weapon #3
1024	Weapon #4
2048	Weapon #5
4096	Weapon #6
8192	Weapon #7
16384	Weapon #8



===Misc Options

4	Scale gib damage to match damage upgrades

8	Scale impact shock to match damage upgrades (so you don't fly 'cross the room when hit with a single nail)

256	No Powerups

2	Don't allow observers (bots and turrets ignore players named "observer", this will just change their name back to "player")

16	Remove all weapons from level

4194304	Don't print list of active options to players - make them guess :)

1	Random gamecfg options when level starts. "nomonsters" stores the gamecfg options to be randomly selected from (set nomonsters the same way you would gamecfg), and savedgamecfg is what gamecfg's you want to always be present (not randomly selected). Only gamecfg options can be randomly selected.
	Example: To randomly select from Realistic Falling Damage, +100 Health, and Grappling Hook, and to have 3 second invulnerability always on, type at the console:
temp1 1
nomonsters 4113
savedgamecfg 2048
	Then the next level I played would have some combination of those 3 gamecfg's, and always have 3 second invulnerability.  The 3 randomized gamecfg's would change each time the level changed or was reloaded.



==================
=Capture The Flag=
==================

Capture the Flag is a classic game in which players aspire to steal the enemy flag from its base and capture it by taking it to their own flag.  BestVoid adds to this with several new variations of CTF:

Three-Team CTF - This variation introduces a third team, which tries to steal the flag from the other two teams and capture it on its own flag, which may be in another area, a separate base, or directly between the two oppowing bases, depending on the map.

Rob The Nest - In Rob The Nest, two teams struggle to obtain the Egg, a special flag which can be found nestled in a room somewhere in the map (the Nest).  Players must find and steal the Egg from the Nest before the other team does, and then get it back to their own base to capture it.  Capturing the enemy flag yields only one point, though you can steal their flag to keep them from obtaining a capture (they need their flag to be at their base to capture the Egg).  On some maps players must capture the Egg in the enemy base.

Protect The Nest - Protect The Nest is similar to Rob The Nest, except instead of stealing the Egg, you must steal the enemy flag and take it to the Egg to make a capture.  Teams must not only defend their own flag, but they must defend the Nest from the other team and keep them from capturing there.  Depending on the map, a team's flag may or may not start out in their own base, but rather, in the enemy base.

Offensive-Defensive CTF - ODCTF is different from all the other CTF games.  In Offensive-Defensive, Red team's goal is to steal Blue (defensive) team's flag from their base and capture it.  While Offensive Team's base is entirely utilitarian and generally quite small, Defensive Team's base is large, complex, and well-defended.  However, Defensive Team can neither steal nor capture Offensive Team's flag, and Offensive team gains no points for kills while everyone on Defensive Team gains a kill for each time one of its members gets a kill (the person who made the kill gets extra points).  The game ends when the fraglimit or the time limit is reached (the fraglimit may even be as low as one capture).  Choose your team based on your personal preference.  Offensive-Defensive CTF is the most map-specific, as most CTF maps would be relatively less exciting to play on.


To set the CTF game type you want to play, set the deathmatch variable to corresponding value:
var	description
1	Regular Deathmatch
2	DM with some odd rules (don't look at me, ID1 created it)
3	Regular CTF
4	Three-Team CTF
5	Rob The Nest
6	Protect The Nest
7	Offensive-Defensive CTF (works better on maps built for ODCTF)

So, instead of typing deathmatch 1 like normal, type deathmatch 5 for Rob The Nest.  Most CTF games will not work unless played on a map that was created for them, and CTF won't work at all unless there's flags on the map you're playing on.


========
=Probes=
========

When you find a probe you're in luck.  A probe will follow you around and fire at the enemies you point at.  In addition, it also provides a flashlight and lasertarget.  Although the bullets it fires are not extremely strong, it has a lot of them so you'll never need to worry about refills.  A probe by your side can allow you to focus your attention on dodging enemy fire fire, and can greatly add to the damage done to the enemies you're attacking.  Probes will only attack living things, which excludes laserbombs, turrets, etc.  Probes will only target enemies when you are attacking and pointing at an enemy.
There are 4 different weapons the probe may have when you pick it up.  The type of probe can be determined by the color.  You can only have one probe at a time.  Probes do not carry over to other weapons and may have a time limit.
Probe Weapons
-------------
1: Duel Nailgun
2: Machine Gun
3: Tri-Laser
4: Spreadshot

Probe Impulses
--------------
13	Dispose of probe.  Probe will fall to ground and dissapear, allowing you to pick up a different one.  Be careful, you won't get it back.


==========
=Frikbots=
==========

Frikbots are your computer-controlled opponents for when you don't have any or enough human players to play against. They know how to use all the weapons, including laserbombs, and can be pretty malicious fighers no matter what weapon they weild.  All in all they're pretty decent opponents, although water and lava seem to be their downfall (this is due to the fact that they're more like real players than monsters, and unlike monsters, players can fall right off cliffs.  Bots have an aweful time avoiding this...  And water is just hard for them to get out of and navigate sometimes).  Try to avoid maps with lots of exposed lava and water higher than ankle or knee-deep.
To make a bot join use impulse 100.
However, before adding bots it is recommended that you run around the map for a minute or two, because this teaches the bots how to navigate it once they do join the game.  If you don't like that, you can download previosly made waypoints for popular maps at the Frikbot Waypoint Depot, www.botepidemic.com/fwd/ .  The waypoints there are actually better than anything that would be made by running around the map a little, so I highly recommend a visit.  The waypoint list includes such maps as dm1-6, selected single player maps, and numerous custom maps like the Electric Fish series (efdm1-8) by Mr.Fribbles.  The waypoints for dm1-dm6 are already included with the mod.





=========
= Story =
=========
Best of Void has no story.  Nada.  The closest it comes is the weapon descriptions, which I just wrote one day when I was in a weird mood...




=======================
= Weapon Descriptions =
=======================
Neocron Tech provides background and specs on some of the more popular weapons they sell to various governments.  Remember this information as you may be equipped with such weaponry on various missions; or, more likely, will have to face enemies using them against you.


Na'mek-40375 (Nailgun):
The sole spoil from a lengthy excavation of Mar Sarah, the city of an advanced civilization that existed almost three millenia ago.  The Na'mek technology takes any small metal object, partially converts it to energy which heats the remaining metal to glowing hot, then propells it in a given direction.  Because of its high efficiency, it has become standard issue with many of the world's milita since its discovery; and because it works so well with nails, the na'mek has come to be known simply as the "Nailgun".  Unfortunately, standard uniform has since been modified to partially negate the strength of the bullets.
---------------------------------------------
Ammo Type:		Nails
Ammo Used:		1
# Fired:		1
Reload Rate:		High
Damage Scale:		Low
Projectile Speed:	Medium
Attack Type:		Rapid


Blaster:
Avaliable at all times to any soldier.  The blaster is a fairly weak and slow but infinite use weapon, used only when the Na'mek and all other ammunition is depleted.  Found to be devastating to undead.
---------------------------------------------
Ammo Type:		--
Ammo Used:		--
# Fired:		1
Reload Rate:		Medium
Damage Scale:		Low
Projectile Speed:	Low
Attack Type:		Single


Rapid Fire Canister Rifle:
Originally developed as a last resort to mob suppression in third world countries, the Canister Rifle has since been modified to cause devastating bone-breaking damage to whomever it is used on.  Its only disadvantage is the large amount of ammunition it consumes in a short time.
---------------------------------------------
Ammo Type:		Shells
Ammo Used:		1
# Fired:		1
Reload Rate:		High
Damage Scale:		Medium
Projectile Speed:	Very Fast
Attack Type:		Rapid Explosive


Explosive Shell Shotgun:
Hunting enthusiast Richard M. Farling developed this weapon as "a light, all purpose hunting rifle, mainly for use on large, slow moving prey at medium range."  He liked to hunt squirrels with it.
It has since become a popular weapon for army gurillas and millita working for large, warring governments.  The shotgun's tremendous power far outweighs its high-range inaccuracy.
---------------------------------------------
Ammo Type:		Shells
Ammo Used:		2
# Fired:		2
Reload Rate:		Low
Damage Scale:		High
Projectile Speed:	Very Fast
Attack Type:		Multiple Explosive


Na'mek Upgrade 8192-07 (Machine Gun):
Once the Na'mek had been developed into an efficient weapon, many of Earth's leading governments began to look for ways to expand on the technology.  After much trial and error, and many, many explosions, the northernmost continent succeeded in creating a weapon which could deal a large amount of damage without overheating, exploding, and destroying everything in a 3 kilometer radius, including its user.  It was named after an ancient weapon called the "machinegun", which in its time must have been considered a very safe and non-explosive weapon.
Further development of this technology as a large-scale bomb is also being discussed.
---------------------------------------------
Ammo Type:		Nails
Ammo Used:		1
# Fired:		1
Reload Rate:		Very High
Damage Scale:		Medium
Projectile Speed:	Medium
Attack Type:		Rapid


Plasma Rifle:
One of the latest energy weapons in development, the Plasma Rifle delivers devastating firepower at a relatively low ammunition cost.  It fires a rapid barrage of energy at enemies and causes large amounts of damage.
The Particle Cannon's manufacturer not only boasts of its power and efficiency, but also of its compadability.  The ability to use either cells or rockets for two different attack types has literally made the particle cannon an overnight success.
The secondary attack mode fires a powerful napalm grenade that explodes in a fury of flame and heat.  Any enemies close or on the ground within the blast range will take damage.  Wreaks absolute havok in a firestorm.  Also effectively blocks or impaires passage through narrow areas for a very short time.
---------------------------------------------
Ammo Type:		Cells	Rockets
Ammo Used:		4	1
# Fired:		10	8
Reload Rate:		Medium	Low
Damage Scale:		High	High
Projectile Speed:	High	Medium
Attack Type:		Cluster


Grenade Launcher:
***production discontinued*** reason: uneconomical
The grenade has been used for centuries without many changes.  Its explosive power has been tweaked over time to maximize the economical efficiency of their mass production, but for the most part the grenade has withstood the test of time.  However, its use in the future has recently been cast into shadow by the exponential development of energy-based weaponry.  Latest word is no new models are being produced, and we've received no new shipments.
---------------------------------------------
Ammo Type:		Rockets
Ammo Used:		1
# Fired:		1
Reload Rate:		Low
Damage Scale:		Very High
Projectile Speed:	Slow
Attack Type:		Ballistic


Rocket Launcher:
Considered the ultimate weapon since its creation, the Rocket Launcher is the most widely used heavyweight weapon on the planet.  It fires a powerful unguided warhead a high speed and demolishes whatever it hits.  Because of the extensive cost of producing reliable launchers and ammunition, like all heavy weaponry, the use of rocket launchers has been limited to professional soldiers in key government battles.  Because of the high weight and instability of rockets, soldiers can carry a maximum of 15 rockets at a time.
There have been some reports of certain governments dilluting their packets of ammunition to make it last longer.  While this may increase the amount of ammunition a government can delegate to its soldiers, such a practice is highly impractical as it greatly reduces the power of the weapon.  We do not promote such actions and cannot create your ammunition contray to manufacturer standards.
---------------------------------------------
Ammo Type:		Rockets
Ammo Used:		1
# Fired:		1
Reload Rate:		Low
Damage Scale:		Very High
Projectile Speed:	Medium
Attack Type:		Single Explosive


Hyperblaster:
The first stable energy weapon ever to be disclosed, the hyperblaster can melt its way through even the most powerful of opponents, mechanical or otherwise.  However, it consumes a tremendous amount of power, which causes difficulties in keeping any mobile unit properly charged.  Because of this, hyperblasters are very rarely used by human milita.
---------------------------------------------
Ammo Type:		Cells
Ammo Used:		1
# Fired:		1
Reload Rate:		High
Damage Scale:		High
Projectile Speed:	Fast
Attack Type:		Rapid


Laser Cannon:
***production discontinued*** reason: unreliable
At first the Laser Cannon was showing some great potential and promised to replace the recently discontinued Plasma Cannon, but it was recently pulled from the market because of its fickle tendency to go off suddenly and without warning, particularly when pointed at its owner's buddies.  Its manufacturer apologises to those involved and promises to absolutely, positively have it fixed in the next 3-6 decades or so.
However, while personal hand-held models are out of production, larger-scale laser cannons are still widely produced and do not seem to be affected by the problem.  Please contact our special orders department for more information.
---------------------------------------------
Ammo Type:		Cells
Ammo Used:		12
# Fired:		1
Reload Rate:		Low
Damage Scale:		Very High
Projectile Speed:	--
Attack Type:		Beam


Plasma Cannon:
***production discontinued*** reason unknown
A newer energy weapon just released into the market and making all of its creators very wealthy indeed.  The Plasma Cannon fires an energy packet that explodes on impact and irradiates the whole area.  A direct hit pierces right through armor of any type or thickness, and even the outer radius of the explosion has a fairly detrimental effect on body armor.  Its creation has already threatened the long-standing dominance of armored tanks and airships because a single hit will kill the pilot and crew.  Some scientists are opposed to its use because, admittedly, it was created mostly by accident and no one knows quite how it works or what its long term effects could be.
Update: Suddenly pulled from the market and all buyers given full refunds.  If you still have a model please return it immediately, health risks may be involved.  No word on why this was done or who was responsible for the recall.  Large-scale models for turrets and armored vehicles have not been recalled and are still in production, though at an even higher price than before.
---------------------------------------------
Ammo Type:		Cells
Ammo Used:		2
# Fired:		1
Reload Rate:		Medium
Damage Scale:		High
Projectile Speed:	Medium
Attack Type:		Single


Laserbombs:
Laserbombs have made jungle warefare an absolute nightmare for foot soldiers, and in part led to the accelerated industry of armored tanks and mechs.  Properly placed they can be completely invisible until it's too late.  The bomb is set on a solid surface, and when something crosses its laser, it explodes for a large amount of damage.
---------------------------------------------
Ammo Type:		laserbombs
# Ammo Used:		1
# Shots Fired:		1
Reload Rate:		High
Damage Scale:		Very High
Projectile Speed:	-
Attack Type:		Stationary Bomb


*Some things to remember while using our services
-------------------------------------------------
We at Neocron Tech are not responsible for any harm that may come to you while using the products we supply.  Please remember that we do not make these products, we only market them, so we cannot fulfill special orders or provide detailed technical information.  Please contact the govt. or company involved for further information on these products.

We are not responsible for lost or ruined articles caused by the misuse of our weaponry.  Many guns have a lot of moving parts on them and so items such as dirt, fingers, wedding rings, candy, and flammables should not be placed in their way.  So stop calling.

We are also not responsible for damage caused to the weapons themselves through misuse.  Please do not try to dissasemble your weapon, remove parts, or add your own special power modifications, you will probably ruin it. Also, many weapons can be deadly when their innards are exposed; energy weapons are exceptionally dangerous and any tampering will probably result in your death, if not everyone around you too.

Personal orders are not available.  Our products are only sold, in bulk, to superior commanders and high-ranking officials or nation leaders, and are normally far out of the price-range of the average soldier anyway.  Please contact your superior for information on what weapons may be available to you through them.  And no, it's not our fault if you get yelled at.

No, we cannot custom-build the perfect gun for you.  We're sorry.

We normally do not provide tanks, turrets and other armored vehicles except by special delivery or rare auctions to the highest bidder.  In the former case, a varying service charge may be given, as well as additional expenses such as shipping, preassembly, and storage.

Please be aware that some models have been recalled from the market.  While you may be resistant to giving up the weapons that are keeping your country from being overridden, we encourage you to return them to their manufacturer within the 6 month deadline, or that manufacturer *will* enter your country and *will* take their products away by force.  This is obviously quite self-defeating, unless, of course, you are already at war with them.

We do not know why so many energy weapons have been recalled, nor do we know why the Hyperblaster, the oldest of them all, is still in commission.  All such information has been held from us in the highest of secrecy.

We do not provide frequent customer discounts, as most of our customers are anomynous buyers.

Remember that this is a free market and thus you are free to purchase weapons of any make or origin.  Do not declare war on us for using or marketing your opponent's products.  We are not saying this out of fear or as a threat, but as an act of good will - If you declare war, we will win.  Remember, we have the weapons to do it with!



============================
=Other li'l tidbits of info=
============================

laserbombs are useless if the enemy passes the laser when he's far away from the bomb.  Put them in hallways to make sure the enemy has to cross close to the bomb and take lots of damage.

laserbombs can often be jumped over.  If that won't work, they can also be shot, although doing so makes them explode, which can hurt you a lot if you're close.

When you pick up a probe it will follow you as best as it can.  If you lose it somewhere, it may take a second or 2 to reappear by your side.

The probe's nailgun is twice as powerful as the machine gun, but the machine gun is instant hit and guaranteed to do its damage.

The Napalm is more powerful in small areas, especially corners.  It's most useful when running backwards, away from an enemy; you can simply drop one right in their path every time they turn a corner.  If it doesn't kill them, at least it will slow them down so you're set up for another attack.  A direct hit right in front of an enemy is also extremely effective, as they'll take blast damage and walk into the flame.


============
=Known Bugs=
============

Players & bots can get stuck on their laserbombs if they stand next to them for several seconds after setting them.  Be sure to take a step back when you set them.  Bots don't understand this concept, so they get stuck a lot.  It's a very annoying problem.  Minus an engine mod there's really no way to fix this.


=========
=Credits=
=========

Mod Concept - me!

Weapons - me!

Probes & custents - me!

Turrets - me!

Mod Coding - me me me!

Models - me! Ummm.. though very few of mine are worth mentioning...
	Laser target model for probe is from Team Fortress.
	Laserbomb model & Plasma Rifle sound is from Fiend Hunter (a very cool TC in my opinion: link? Adam Armstrong, xoltan@telefragged.com)
	Hyperblaster & blaster models & sounds from Quake2
	Grappling Hook code and model by Perecli Manole AKA Bort

	Thanks to LTH for his suggestions on how some weapons should look and act, and for the Namek fire sound.

Beta Testing - Again, thanks to LTH.  He told me right out what needed to be changed, and the mod improved greatly from his input.  Special thanks to Anton Jackson for his testing and keen interest in the mod.

Frikbots - How can I not credit Frika-c?  frika-c@earthling.net  I owe a lot to these lil' bots of his... www.inside3d.com/frikbot/  He's got some real nice mods & such there.



=========
=Contact=
=========

My e-mail is static_void@hotmail.com.  I can also be found on the forums of Inside3d.com, come and visit us!


============================================
=  Copyright and Distribution Permissions  =
============================================
Ok, the basic legal stuff:

Authors MAY use these modifications as a basis for other
publicly available work.  Please send me any modifications
you make.

If you have used part of this mod (code, model or sound) in
your own mod, please give credits to the authors who have made
them - including myself. Thank you.

You may distribute this Quake modification in any electronic
format as long as this description file remains intact and unmodified
and is retained along with all of the files in the archive.
You are not allowed to sell this mod for money without permission.
