=======================================================================

			   Rogue Bot
			  ..for Quake..
			   By Electro

=======================================================================

Title    : The Rogue Bot
Filename : Rogue04.zip
Version  : Beta 0.4
Date     : 14/05/99
Author   : Benjamin Darling (Electro)
Email    : ELECTRO_BEN@hotmail.com
Credits  : id software  - making Quake
	   Steven Polge - making the Reaper Bot
	   Alan Kivlin - Bot Rankings Stuff
	   Lee Smith - ProQCC
	   ALL the guys at inside3d for the tutorials, thanx!
           www.inside3d.com
	   
Build time: 13 hours (so far...)

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no  


Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no, what is this anyway?
context diff  : no, ?
.qc files     : no, maybe released later on....
progs.dat     : yes


Bot enhancements by Electro
- - - - --- - - - - - --  -

*Bot now talks. (it's crappy, but better than nothing)
*You can call for help from fellow team-mates (impulse 217)
*Bots appear on scoreboard (must use -listen to have more than 3 bots)
*Weapon Steal Bug fixed.
*Random Skin for bot teams in Teamplay + Deathmatch
*Route Overflow Bug Fixed.
*Packet Overflow occurance reduced.
*Bots can now be "bounced around" with a well placed rocket/grenade.
*Thud reduction


Comming Soon.....
- - -- - - -  -- -  --  - -

*Demos of me (maybe others) kicking the bots ass, or the other way
 around :)
*This "modified" Reaper bot in a new weapons patch.
*Norse Movement Functions
*Bots will be able to hide in the dark.
*Bots won't see you if you are hiding in the dark.


Bugs
-- -  -- -  - --  - - -- -

I tryed to fix all of them that i know of. Any more? Contact me.
Bot still MAY have trouble with LOTS broken ground in one area
e.g. Rocket Launcher area in Start. Norse Movement will fix this.

============================================================
The screenshot is at the end of a game, me VS. A skill 2.
Just wait till' Norse is put in, it'll be a WAY closer game.
============================================================

Legal Notes
-- - - -- -- -- - - - - -
= The original Reaper Bot code & mod are copyright Steven Polge.
= Quake is copyright - id software.
= This mod is copyright Electro 1999.
= Alan Kilvins' code is for the public, and i give credit to him.
= Any code or advise used from www.inside3d.com is credited to the 
  staff at Inside 3D.

I CANNOT BE HELD LIABLE FOR ANY DAMAGES CAUSED TO YOU, 
YOUR COMPUTER, OR SOFTWARE ON THE COMPUTER SYSTEM. If however you are
experiencing problems running this mod, or some features in the actual
game, feel free to email me.


-Enjoy
ELECTRO_BEN@hotmail.com