Title    : GYPObot - A Deathmatch and Teamplay bot base code
Filename : gypobot.zip
Version  : v0.9
Date     : 13/7/00
Author   : Stephen Dobbs, creator of the DOBBSbot
Website  : http://www.dobbsnet.co.uk
Email    : stephen.dobbs@btinternet.com
Credits  : The creator of the Tutor Bot and Bot-player
	   Great praise goes out to Coffee for his
	   tutorials and tutor bot.

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no


Format of QuakeC
----------------
unified diff  : no
context diff  : no
.qc files     : yes
progs.dat     : yes

Contents
--------
1. Overview
2. Installation
3. How to use the bot
4. Bugs
5. Copyright
6. Availabilty

Overview
--------
After making the DOBBSbot, i decided to make an acceptable bot which
could be used as a base for someone who wants to make their on bot.
It is essentially a cut down version of the DOBBSbot, or a souped
up version of the Tutor bot with some of my own code. However, where 
as the tutor bot was made to plug-in into deathmatch mods, the 
GYPObot is designed to be a good base for anyone who wants to make a
bot. It has been designed as simply as possible, making the progs.dat
file on 47k bigger than the normal progs.dat!


Installation
------------
Extract the zip file with Winzip into a subdirectory inside the Quake
directory called 'gypobot' (ie. c:\quake\gypobot). Make shortcuts
to the files dm.bat (deathmatch) and tp.bat (teamplay)and double-click
on them to run the required mode of game.

How to use the bot
------------------
The controls are very simple.
PRESS B to create a bot -In teamplay this will create a team-mate,
			 but in Deathmatch will create an enemy bot.
PRESS N to create a bot on the opposite team -Teamplay only.


Bugs
----
THERE ARE NO MAJOR GAMEPLAY BUGS, but...
+ Bots can't travel in the water very well at all.
+ Bots will not always die in lava.
+ Bots very occasionally get stuck.

							
Copyright and Distribution Permissions
--------------------------------------

Authors MAY use these modifications as a basis for other
publically available work (that's the idea of the bot!)
as long as you mention my name and include this text file.


Availability
------------

This modification is available from the following places:

FTP   : -none-
WWW   : http://www.dobbsnet.co.uk/quake.htm
