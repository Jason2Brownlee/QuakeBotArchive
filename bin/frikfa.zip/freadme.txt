Title    : FrikBot in Final Arena
Filename : frikpk.zip
Version  : 0.08
Date     : 9-28-99
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Alan Kivlin for his rankings.qc and step movement
Frog for releasing the Frogbot code and giving me a good goal
to shoot for.

Additional thanks to Wazat, Asdf and MaNiAc who helped immensly with suggestions, code snipplets and ideas.

Big thanks to David 'crt' Wright, author of Final Arena, for putting out the code and for making a pretty cool mod (I say that about all of 'em, don't I?)


Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : no
progs.dat     : yes



Description of the Modification
-------------------------------

Okay there are tons of Rocket Arena bots out there. Seems the thing to do nowadays, this one is just one more. It's really a pretty unmodified frikbot (I removed fov and some other things to make it more adapted to the arena concept) It's a good deal of fun, the FrikBot isn't the best fighter in the world, and it shows in this mod, but it's worth a try at least.
                          
How to Install the Modification
-------------------------------

You must have the original Final Arena files to use this mod. You can download them at http://www.planetquake.com/arena/

Copy all included files into your arena directory, DO NOT OVERWRITE ANY PAK FILES, then start quake -game arena -listen 8, have fun!



Impulses
===========
100 Add a bot or add a bot to your team in a team game
101 Add a bot to an enemy team
102 Remove a bot
103 Bot Cam cycle. Cycles through the view of all bots & players currently on the server
104 Dump Waypoint data to console


Technical Details
-----------------

Known Bugs
==========
* Bots don't fight very well

For general FrikBot bugs, finger frika-c@mdqnet.net or visit the Dept 187 webpage


Availability
------------

This modification is available from the following places:

Department 187 at http://www.mdqnet.net/dept187/



