October 15, 2008
----------------

FBCA 0.99 Y - A modification of Paraboil's FBCA 0.92KT
Modified by Baker
=========================================================================
Instructions:

1. Extract to quake\frogbots
2. Command line:  c:\quake\glquake.exe -game frogbots -listen 8 +map dm6

=========================================================================
This is the older NQ version of Paraboil's FBCA modification
that I updated with Trinca's waypoints with a few minor changes
including a CAx style motd for Clan Arena.

Type:

"maps" for the list of supported maps
"arena" to switch to clan arena mode
"addbot" or "removebot" to remove bots

Type "skill 0" for skill 0 bots, "skill 10" for skill 10 bots etc.

In game, type "commands" for help and "rules" for the rules.  

The common commands like "reset", "ready" and so forth apply, as do
setting "deathmatch 1" or "deathmatch 3" and the "fraglimit 50"
and so on.

I may end up making more modifications to this as time goes on and
if so those would be located at http://www.quakeone.com and I may
end up putting up a bots page with this and other types of bots
made available.

Paraboil's Frogbots probably rank in the top 3-4 of highly sophisticated
Quake mods out there.  The work Trinca did to waypoint so very many
maps is admirable.  I don't how someone could have the time and
patience to do such a Herculean effort and his taste in DM maps is 
really amazing.  Thanks Trinca!

----------------------------------------------------------------
Compiling:

If you want to compile, use the fteqccgui.exe included.  Not a newer
version unless you want to figure out why it doesn't compile with
a newer version, heheh!

And turn on EVERY optimization by pressing O3 and then checking the 
single unchecked optimization in the left pane.  It needs them all!