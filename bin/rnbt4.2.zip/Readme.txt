=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
  Chuck Parsons                                        07/11/00
  pentm450@earthlink.net
             
                           RNBT-4.2

 
               http://www.home.earthlink.net/~pentm450  
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

                        A short readme.

Make sure the included Autoexec.cfg is in the same directory as this mod.
You can customize some settings there.



Start with -game rnbt4.2 -listen 8 
  

Impulses
200 spawns a bot
201 spawns a teammate (untested).
202 removes a bot.
Read the Frikbot readme for more impulses.


The admin passcode is 555555.

On most maps the bots will enter the game on their own.  On some maps,
 "start" for example, you will need to follow the steps below.

To add a bot you have to be in admin-mode and ride them and put them
into the game.  

You cant kick bots from admin menu. :P

Replaced Morter with a railgun.  Press 7 twice to access it.
Replaced Flash Grenade with a Gas Grenade.  Stay out of the cloud!
Press 6 twice to access that.

Added Kascam.  
join the game and enter impulse 250. 
You are now a chasecam.
Impulse 166+ switches players.
Impulse 201 toggles chase mode.
Sit back and enjoy the movie!

Modified the bots' code a bit this go around.


READ THE DOCS THAT I HAVE INCLUDED WITH THIS MOD.  
THEY SHOULD ANSWER MOST ANY QUESTION YOU MIGHT HAVE ABOUT PLAYING IT!!!!

     DO NOT USE THE SWITCH RUNE TO SWITCH PLACES WITH A BOT!!!!
             THE GAME WILL IMMEDIATLY CRASH!!!!!! 
        
             Rarely crashes, but don't be surprised when it does.
         
                  
                    USE AT YOUR OWN RISK!!!!!
                             AND
                      Have a nice day!!!!
                 
                          Chuck
  