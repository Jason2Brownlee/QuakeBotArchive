FAKE CLIENT QUAKEWORLD SERVER MODIFICATION
------------------------------------------
AUTHOR:            Rich Whitehouse
CONTACT:           thefatal@telefragged.com
HOMEPAGE:          http://www.telefragged.com/thefatal/
RELEASE NUMBER:    1

The source code for this binary distribution is available
from my homepage.

Before you use this, you will need to get version 0.12 of
Frogbot, currently available at:

http://www.telefragged.com/metro/

After you get it, install it, and replace the qwprogs.dat
with the one in this file's zip (you may want to back up the
original first, as the qwprogs.dat in this package cannot be
used with any server other than the qwsvfrog.exe in this
file's zip). Next place the qwsvfrog.exe file from this
file's zip in your main Quake folder. Run it with gamedir
frogbot on the command line. An example would be:

c:\quake\qwsvfrog.exe +gamedir frogbot +map dm6

Then connect to yourself (you may want to use Priority or
something else) and add a Frogbot as usual. For information
on how to do that and everything else, you can see the
Frogbot documenation. Also, before you start, make sure the
server.cfg file from this file's zip is also in your Frogbot
folder, and that the botinfo.txt file from this file's zip
is in your main Quake folder with qwsvfrog.exe.

Things that are changed from the original Frogbot version:

Bots now get their information from the botinfo.txt file.
The "skill" setting is now a serverinfo variable.
The obvious, being that bots are now treated as clients.

There are a variety of advantages that come from having the
bot treated as a real client, such as being able to issue
actual stuffcmd commands to it and other things. None of
that is really used with the Frogbot in its current state,
however, which is why you're encouraged to use this in
creating Frogbot mods.

Anyway, you can mess with it and do whatever you want. Have
fun.

-Rich