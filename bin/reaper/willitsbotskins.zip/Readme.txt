Willits Bot Skin Pack
=====================

This is a modified player.mdl and h_player.mdl for use with the
reaperbots or any other bots that use multiskin models.

It is based on the Willits skin (by Tim Willits, aka GOD).
Why this skin? Because I think it is the best quake skin ever. Unlike
most, it is well made, has colour support, and isn't a cheap novelty
that grows tiresome after 5 minutes.

The player.mdl contains 16 different coloured variants of the skin.
Skins 1-8 use the best looking (as seldom more than 8 bots would be used),
and most distinctive skins (ie: "I'll kill that red bastard"). Skins 9-14
use thecolours that are boring, repetitive and/or just don't look that good.
Skin 15 is the default colours, and skin 16 uses the colours I use on this
skin in QuakeWorld. If you use a combination of bots and humans you should
modify the mdl so that skin 15 becomes skin 1.

The h_player.mdl (by me) contains 16 coloured gibbed
helmets to match the colours of the bots they were blown off of.

For The Uninitiated
-------------------
Put both the files in a progs directory in your bot folder (eg.
C:\Quake\HipReaper\Progs) and run your bots normally.
Better yet, use PakExplorer to put the models in your pak#.pak files.

Credits
-------
All I did was make the skin into different colour variants (plus the
gibbed heads) the real credit goes to:

id (duh), in particular Tim Willits.
The makers of Quake Model Editor and PakExplorer.
Steve Polge for some damn fine bots.
You for reading this (and hopefully using the skins).


I would just like to say that this is the best multiskin pack for Q1
 that I've seen. Honest.

If you would like a armor.mdl to match the skin (or just to let me
know that someone is actually using it) then send mail to...

grimlock@one.net.au
