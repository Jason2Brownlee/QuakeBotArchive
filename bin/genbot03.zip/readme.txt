GENEBOT QUAKEWORLD SERVER MODIFICATION
--------------------------------------
AUTHOR:            Rich Whitehouse
CONTACT:           thefatal@telefragged.com
HOMEPAGE:          http://www.telefragged.com/thefatal/
RELEASE NUMBER:    3

RELEASE HISTORY
---------------
3:
Full waypoint system added, with in-game waypoint editing.

Better teamplay AI.

Support for moving platforms.

Added an additional AI thinking state so that the bot can
perform multiple activities at the same time.

Server-side management commands added.

Client-side waypoint placement commands added.
---
2:
AI improved in general, better navigation system.
---
1:
First release.

SERVER COMMANDS
---------------
These commands should be typed into the server window or
used by a client with rcon.

addbot - Adds a bot.

rembot - Removes a bot.

wp_edit - Enables/disables waypoint edit mode.

wp_write - Writes waypoints to a file, so they can be used
later.

CLIENT COMMANDS
---------------
These commands must be issued from a client. Use cmd before
any of them when typing from the client console. Example:

cmd makewp

All client commands are waypoint-related, and the server
must have waypoint edit mode on in order for any of them
to work.

makewp - Creates a waypoint, if the server has waypoint edit
mode on (blood particle patches are waypoints).

remwp - Removes the last created waypoint.

makewp_plat - The bot will only move to this waypoint if there
is an entity under the point. Be careful with placing these.

GWD FILES
---------
GWD (Genebot Waypoint Data) files are files which contain
waypoint data for the bot to navigate levels. When you create
a waypoint data file, it will be saved in a folder called
"Genebot Waypoint Data" under the directory for the mod you
are currently playing. For example, if your Quake folder is
c:\quake and you are playing Rocket Arena and decided to save
a waypoint file for the map arenax, the file would then be:

c:\quake\arena\Genebot Waypoint Data\arenax.gwd

To waypoint a level, all you need to do is turn waypoint edit
mode on (on the server) and connect with a client, then use
the client commands listed above to place waypoints.

--------------------------------------------------------------
The source code for this binary distribution is available
from my homepage.

Usage of this program is fairly simple. Extract it to your
main Quake folder (you should already have the QuakeWorld
server executable, which is qwsv.exe in most cases) WITH
directory structure (so the files go where they should).
After that, you'll have a file called botinfo.txt and a file
called qwsv_bot.exe in your main Quake folder. Just run
qwsv_bot instead of qwsv to run your server (see
http://www.quakeworld.net for info on running a QW server),
and then type addbot in the console to add a bot into the
game no matter what mod you're using. You can then use
rembot to remove bots as well. After you add a bot, it will
continue to be carried across level changes and such as
well, so you don't have to worry about that. If you want
to make the bots more custom to fit your needs, just edit
the botinfo.txt file (it's somewhat self-explanitory).

Make sure you extract with directory structure, so that the
skins included in the zip will extract to the correct place
(they are used by a couple bots by default in the botinfo.txt
file) and so the waypoint files that I've already created
will be put in their proper folders.

After you get the server set up, run priority.exe (which
is included in the priority.zip file which was in the zip
this file was in). I didn't write the program, but you'll
need to use it with the server or the bots will seem to
float around and lag badly.

Priority was written by Alan 'Strider' Kivlin, and all the
files from his original distribution are included in the
priority.zip file. Note that if you're running on an OS
which allows you to set program priority levels that you
won't need to run priority.exe, and you can just force
qwsv_bot.exe's priority level up manually to avoid any
problems.

Note that there are probably bugs and such in this because
I haven't had much time to tweak it out myself. If there's
something you don't like, go download the source code and
fix it yourself.

The AI for the existing bots is fairly simple as well, but
I'm looking forward to seeing if anyone changes that.
Although, the existing bots do play a very good game of
Rocket Arena. Especially on arenax.

Happy murdering.

-Rich
