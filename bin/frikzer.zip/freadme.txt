Title    : FrikBot in Zerstorer: Testament of the Destroyer
Filename : frikzer.zip
Version  : 0.09
Date     : 2-26-00
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Alan Kivlin for his rankings.qc and step movement
Frog for releasing the Frogbot code and giving me a good goal
to shoot for.

Additional thanks to Wazat, Asdf and MaNiAc who helped immensly with suggestions, code snipplets and ideas.

Thanks to the Zerstorer team for creating the mod originally

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : no
progs.dat     : yes


Description of the Modification
-------------------------------

Zerstorer is/was a great free mission pack, and it comes with some mighty fine deathmatch maps, of course, if you have no one to play with, you can't fully appreciate them! Well through the magic of FrikBot, now you can enjoy this TC fully. Keep checking the FrikBot page for updates on this bot mod.
                          
How to Install the Modification
-------------------------------

You must have the Zeroster patch to use the included files. Zerstorer may be found at ftp://ftp.cdrom.com/pub/idgames2/partial_conversions/zerstoerer/zer.zip

Copy all files into your Zerstorer directory, it might be a good idea to back up your original progs.dat in case there are problems. DO NOT OVERWRITE ANY PAK FILES.



Impulses
===========
100 Add a bot or add a bot to your team in a team game
101 Add a bot to an enemy team
102 Remove a bot
103 Bot Cam cycle. Cycles through the view of all bots & players currently on the server
104 Dump Waypoint data to console


Technical Details
-----------------

Known Bugs
==========
None known specific to this mod.

For general FrikBot bugs, finger frika-c@mdqnet.net or visit the FrikBot homepage.


Availability
------------

This modification is available from the following places:

FrikBot homepage at http://www.mdqnet.net/frikbot/


