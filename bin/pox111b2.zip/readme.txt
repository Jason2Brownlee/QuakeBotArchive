Paroxysm v1.11b2 - QuakeWorld Server Patch
<http://www.planetquake.com/paroxysm/>
<pox@planetquake.com>


INSTALLATION:

Replace the 'pak1.pak' in your 'quake/pox/' directory with the one supplied in this archive.


CHANGES:

Addressed several bugs related to Last Man Standing mode:
- Fixed a bug that caused the game to lose track of how many players were active.
- Suiciding your frag count below 1 will now count that player out
- Last Man Standing Observers can no longer suicide


Enhanced Last Man Standing Observer Controls:
- Added zoom in [1] & zoom out [2] impulses out to QW LMS observer mode
- Added control instructions for QW LMS observer (auto displayed when kicked to observer mode)
- Fixed Target ID overiding centerprints, added frag count to Target ID
- Observers can now use teleporters
