Title    : FrikBot in Rhino's Ultimate Quake
Filename : frikruq.zip
Version  : 0.04
Date     : 6-1-99
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Roscoe A. Sincero (legion) for DoomBot movement code (norse_movetogoal)
Alan Kivlin for his rankings.qc
Coffee (http://www.planetquake.com/minion/) for the inspiration
All the people who helped me test this bot and made suggestions!

Rhino of course :)

Type of Mod
-----------
Quake C  : yes
Sound    : yes (silent thud and splash sounds)
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : yes 
progs.dat     : yes


Description of the Modification
-------------------------------

This bot takes a unique approach. Unlike all other bots I've seen, FrikBot actually pretends to be a player. When he fires his weapon, it's the same function that the player uses. It is all done through his button flags. In other words, the bot fakes all client functions, he looks like a Quake client not only to the people in the game, but also to the Quake C. So why did I make him fake client behavior? Well with him using all the player code, he automatically works with hundreds of mods with a few short lines of code added or changed. This bot will play by the game rules of nearly every mod out there. (though he doesn't always know the rules however)
                          
How to Install the Modification
-------------------------------

You must have the RUQ patch to use the included files. RUQ may be found at http://www.geocities.com/SiliconValley/Network/7212/

Copy all files into your RUQ directory, it might be a good idea to back up your original progs.dat in case there are problems. DO NOT OVERWRITE ANY PAK FILES.


Impulses
===========
100 Add a bot or add a bot to your team in a team game
102 Remove a bot


Technical Details
-----------------

Known Bugs
==========
* Bot colors don't appear in GL Quake.
* Bots occasionally over exaggerate their out-of-water jumping (though it's cool to watch). 
* Bots really hate ledges.
* Bots can cause serious slow down on large levels.

More? Email me with your bug finds at frika-c@earthling.net


Availability
------------

This modification is available from the following places:

Department 187 at http://www.mdqnet.net/dept187/


