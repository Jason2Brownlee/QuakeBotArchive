/*
**  stack instantiation BULL SHIT (I shouldn't have to do this!!!!)
**
*/


#include "m_stack.h"
#include "vector.h"

template m_stack< class vector >;
template m_stack< class m_BSPnode * >;
