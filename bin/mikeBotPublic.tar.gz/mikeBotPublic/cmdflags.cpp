

#include "defines.h"
#include "cmdflags.h"

#include <string.h>
#include <stdio.h>

/*
**  parseCommandLine : returns a cmdFlags struct filled with tons o' valuable
**			info. (see qpstruct.h)
**
*/

cmdFlags::cmdFlags( int argc, char **argv )
{

  int i, j;

  filename=0;
  port=0;
  address=0;
  pakpath=new char[ Q_MAX_STRING ];
  configfile = new char[ Q_MAX_STRING ];
  
  strcpy( configfile, CONFIG_FNAME );
  strcpy( pakpath, "C:\\quake\\id1\\" );

  for( i=1; i < argc; i++ )
    {
      if( *argv[i] == '-' )
	for( j=1; j < (int)strlen( argv[i] )-1; j++ )
	  switch( argv[i][j] )
	    {
	    case 'r':
	      filename = new char[ Q_MAX_STRING ];
	      strcpy( filename, &argv[i][j+1] );
	      j = 10000;	// strange way to exit switch, but hey :)
	      break;

	    case 'p':
	      port = atoi( &argv[i][j+1] );
	      j = 10000;
	      break;

		case 'c':
			strcpy( configfile, &argv[i][j+1] );
			printf("cmdflags::cmdflags(): using config file `%s'\n",configfile);
			j = 10000;
			break;

		case 'f':
			strcpy( pakpath, &argv[i][j+1] );
			printf("cmdflags::cmdflags(): using PAK path `%s'\n", pakpath);
			j=10000;
			break;
	      
	    default:
	      fprintf(stderr, "parseCommandLine(): unknown flag `%c'\n", argv[i][j]);
	      break;
	    }
      else
	{
	  address = new char[ Q_MAX_STRING ];
	  strcpy( address, argv[i] );
	}
    }

}

