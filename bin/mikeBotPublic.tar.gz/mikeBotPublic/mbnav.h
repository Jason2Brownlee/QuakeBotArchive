/*
**
**  MBNAV class 
**
**  (c) 1997, mike warren
**  mikeBot
**
**  ROAM version
**
**  handles navigation : has complete control over idealSpeeds, which are
**  changed to actual speeds after facing is determined (by mbfire). Also 
**  controls jumping. (unused, basically)
**
** TODO : pretty much everything :)
**
*/

#ifndef _MBNAV_H_
#define _MBNAV_H_

#include "mbfire.h"
#include "stack.h"
#include "m_list.h"

class mbnav : public mbfire
{
protected:

  vector mbn_facing;		// where nav system wants to go
  double mbn_velocity;		// target speed
  int mbn_jump;				// turned off after send
  
							// qcs::mbn_target
  int mbn_oldTarget;		// previous target

  int aimAt( vector & );
  void updateRatings();
  void aquireTarget();

				//
				//  behaviours : listed in order of precedence
				//

  void b_avoidlava();
  
  void jump() { if( mbn_jump == 10) mbn_jump = 9; }

public:

  mbnav();
  ~mbnav() { }
  
  void forceJump() { jump(); }
  void mbn_printTarget() { if( mbn_target != -1 ) printf("`%s'", modeltable[ entities[mbn_target].index ]); else printf("`none'"); }

  void update();
  int cmd( char * );

};





#endif

