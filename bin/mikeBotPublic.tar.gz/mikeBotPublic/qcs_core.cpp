/*
**
**  QCS handles client-server communications
**
**  (c) mike warren, 1997
**  mikeBot
**
**  ``core'' functions; connect, disconnect, etc.
**
*/



#include "defines.h"
#include "qcs.h"

#if !WIN32
#include <sys/types.h>
#include <sys/time.h>
#endif

#if WIN32
#include <sys/types.h>
#include <sys/timeb.h>
#endif

/*
**  reinit : deletes everything, then calls ctor
**
*/

void qcs::reinit()
{

  if( recording() )
    stopDemo();
  if( connected() )
	  disconnect();

  if( info.name )
    delete[] info.name;
  info.name = (char *)0;
  if( info.level )
    delete[] info.level;
  info.level = (char *)0;
  if( info.address )
    delete[] info.address;
  info.address = (char *)0;

  fragments->reset();

  outgoingReliable = 0;
  outgoingUnreliable = 0;
  incomingReliable = 0;
  incomingUnreliable = 0;

  haveConnection = 0;
  newTimestamp = (float)0.0;
  oldTimestamp = (float)0.0;
  signonLevel = 0;

  myEntityNumber = 0;

  int i;
  for( i=0; i < QCS_MAX_ENTITIES; i++ )
    {
      entities[i].origin.set((float)0,(float)0,(float)0);
      entities[i].velocity.set((float)0,(float)0,(float)0);
      entities[i].facing.set((float)0,(float)0,(float)0);
      entities[i].index = 0;
      entities[i].default_index = 0;
      entities[i].frame = 0;
      entities[i].skin = 0;
      entities[i].lastTime = (float)0.0;
      entities[i].rate = (float)0;
	  entities[i].rateMultiplier = (float)1.0;
    }

  for( i=0; i < QCS_MAX_PLAYERS; i++ )
    {
      players[i].hate = 0;
      players[i].index = 0;
      players[i].frags=0;
      players[i].name = 0;
      players[i].shirt = 0;
      players[i].pants = 0;
    }

  deleteTables();
  initTables();			// make all entries NULL

  inPacket.reset();
  outPacket.reset();
  prespawns1.reset();
  prespawns2.reset();
  prespawns3.reset();

  ackQueue.clear();

  for( i=0; i < QCS_MAX_PLAYERS; i++ )
    {
      if( players[i].name )
		delete[] players[i].name;
      players[i].name = (char *)0;
    }

#if DEBUG & DQCS
  printf("qcs::reinit(): reinitialized\n");
#endif


}


/*
**  ctor : simply inits variables
*/

qcs::qcs()
{
  qcs_lastrule = 0;
  qcs_message[0] = 0;
  demoPauseState = FALSE;

  chEntity=0;
  chFrame=0;
  chQEntity.frame = 0;
  chQEntity.skin = 0;
  chIsVisible = FALSE;
  
  currentServerIP[0]=0;

  sock = (qsocket *)0; 
  demoFP = (FILE *)0;
  
#if QPROXY
  proxy = new qproxy( QX_MAX_CLIENTS, 26000 );
#endif
  info.name = (char *)0;
  info.level = (char *)0;
  info.address = (char *)0;
  result = (char *)0;

  fragments = new qpacket( QCS_FRAGMENT_BUFFER );

  outgoingReliable = 0;
  outgoingUnreliable = 0;
  incomingReliable = 0;
  incomingUnreliable = 0;

  haveConnection = 0;
  newTimestamp = (float)0.0;
  oldTimestamp = (float)0.0;
  signonLevel = 0;

  myEntityNumber = 0;

  int i;
  for( i=0; i < QCS_MAX_ENTITIES; i++ )
    {
      entities[i].origin.set((float)0,(float)0,(float)0);
      entities[i].velocity.set((float)0,(float)0,(float)0);
      entities[i].facing.set((float)0,(float)0,(float)0);
      entities[i].index = 0;
      entities[i].default_index = 0;
      entities[i].frame = 0;
      entities[i].skin = 0;
      entities[i].lastTime = (float)0.0;
      entities[i].rate = (float)0;
	  entities[i].rateMultiplier = (float)1.0;
    }

  for( i=0; i < QCS_MAX_PLAYERS; i++ )
    {
      players[i].hate = 0;
      players[i].index = 0;
      players[i].frags=0;
      players[i].name = 0;
      players[i].shirt = 0;
      players[i].pants = 0;
    }

  name( QCS_BOT_NAME );
  pants( QCS_BOT_PANTS );
  shirt( QCS_BOT_SHIRT );

  initTables();			// make all entries NULL

  ackQueue.setTimeout( QACK_MAX_TIMEOUT );

}


/*
**  recordDemo
**
**  Opens the filename passed, writes the header (<cd track>\n)
**  and all subsequent update()'s write to the file.
**
*/

int qcs::recordDemo( char * filename )
{
  if ( recording() )		// already recording
    {
      printf("qcs::recordDemo(): already recording\n");
      return FALSE;		
    }

  if( !connected() || signonLevel < 3 )
  {
	  printf("qcs::record(): Please fully connect first\n");
  }

  char temp[ 1024 ];

  strcpy( temp, "c:\\quake\\id1\\" );
  strcat( temp, filename );

  demoFP = fopen( temp, "wb" );

  if( !demoFP )			// open failed
    {
      fprintf(stderr, "qcs::recordDemo(): couldn't open `%s'\n", temp);
      return FALSE;
    }
  else
    printf("opened `%s' for writing\n", temp);

			// write "header", such as it is (cd track; -1=none)

  char h[3];
  
  h[0] = 0x2d;
  h[1] = 0x31;
  h[2] = 0x0A;

  fwrite( h, 1, 3, demoFP );

  vector tv;
  if( connected() )
    {
      prespawns1.write( demoFP, 0, tv );
      prespawns2.write( demoFP, 0, tv );
      prespawns3.write( demoFP, 0, tv );
    }
	  
  return TRUE;
}

/*
 **  stopDemo : stops recording demo ( if any ) and closes file. TRUE if succes
 **
 */

int qcs::stopDemo()
{
  if( !recording() )
    {
      printf("qcs::stopDemo(): not recording\n");
      return FALSE;
    }

  char t[ 17 ];
  int i=0;
  for( i=0; i < 16; i++ )
    t[i]=0;

#ifdef QBIG_ENDIAN
  t[0] = 1;
#else
  t[4] = 1;
#endif

  t[16] = SC_DISCONNECT;

  fwrite( t, 1, 17, demoFP );

  fclose( demoFP );
  demoFP = (FILE *)0;
  
  return TRUE;
}


/*
 **  Server : releases (if any) the current socket, and obtains a new one, 
 **	      pointed at the specified ip. returns FALSE on error
 **
 */


int qcs::server( char * ip, int port )
{
  
  if( connected() )
    disconnect();	
  
  if (sock)
    {
      delete sock;
      sock = (qsocket *)0;
    }

/*  for( int i=0; i < 10; i++ )
    if( !strcmp( ip, servers[i] ) )
      {
	printf("qcs::server(): using `%s' for `%s'\n", address[i],ip);
	ip = address[i];
	break;
      }
*/

#if QTHROW
  try
    {
      sock = new qsocket( ip, port );
    }
  catch( char * err )
    {
      printf("qcs::server(): `%s'\n", err );
      sock = (qsocket *)0;
      return FALSE;
    }
#else
      sock = new qsocket( ip, port );
#endif

  strcpy( currentServerIP, ip );
  outgoingReliable=0;
  incomingReliable=0;
  outgoingUnreliable=0;
  incomingUnreliable=0;
  newTimestamp=(float)0.0;
  oldTimestamp=(float)0.0;

  return TRUE;
}


/*
 **  update : call this ONLY WHEN THERE IS DATA TO BE READ FROM THE SOCKET 
 **	      all decoding, etc, is then handled
 **	     
 */

int qcs::update()
{	
	int r = sock->receive( inPacket );

	if ( r <= 0 )
    {
#if UNIX
      if( errno != EWOULDBLOCK )
#else
	  if( WSAGetLastError() != WSAEWOULDBLOCK )
#endif
        fprintf(stderr,"qcs::update(): read error\n");

#if WIN32
	  sock->winError();
#endif

      return FALSE;
    }

	if( r > 0 )
	{
		inPacket.init();			// updates type, size from header
		decodeQPacket( inPacket );		// decodes it
	}


  ackQueue.resend( sock );		// update the acknowledge queue

  if( signonLevel == 3 )
    sendMovement();

  //  _ftime( &thisPacketTime );

  //qcs_ping = (((float)lastPacketTime.time * (float)100.0)+(float)lastPacketTime.millitm) - 
  //		(((float)thisPacketTime.time * (float)100.0)+(float)lastPacketTime.millitm);


#if QPROXY
  proxy->update();
#endif

  return TRUE;

}

/*
 **  connect : returns (char *)0 if connect was successful, else returns the
 **	      reject string. (i.e. "Server is full.\n")
 **
 */

char * qcs::connect()
{

  if( !sock )
    {
      fprintf( stderr,"qcs::connect(): no valid socket\n");
      return "Invalid socket.";
    }

  if( result )
    delete[] result;
  result = new char[ Q_MAX_STRING ];
  strcpy( result, "No responce.\n" );

  outPacket.reset();	
  outPacket.addByte( (char)0x01 );
  outPacket.addString( "QUAKE" );
  outPacket.addByte( (char)0x03 );
  outPacket.changeType( qpacket::control );
  send( outPacket );

  int i=0;

  while( i++ < QCS_MAX_TIMEOUTS )
  {
    printf("qcs::connect(): trying...\n");
    if( !waitForPacket() )
      {
	printf( result );
	send( outPacket );
      }
    else if ( connected() )
      break;
  }

  if( connected() )
    return (char *)0;
  else
    return result;

}

/*
 **  disconnect : deallocs qsocket, sends disconnect
 */

void qcs::disconnect()
{
  
  printf("qcs::disconnect(): disconnecting...\n");

  if( connected() )		// send 3 times 'cause itt
  {
    sendDisconnect();
    sendDisconnect();
    sendDisconnect();
  }
  if( recording() )
    stopDemo();
  
  haveConnection = 0;

  reinit();

  delete sock;
  sock = (qsocket *)0;		// yes, this *is* important
  server( currentServerIP, 26000 ); // aquire new socket

}

/*
**  waitForPacket : waits to receive a packet; return TRUE if one received, 
**		    FALSE on timeout. NOTE that update() *IS* CALLED!
**
**	!!!->	    this is meant to be used to wait for control packets (only)
**
*/

int qcs::waitForPacket()
{

  fd_set a;
  struct timeval tv;

  tv.tv_sec = QCS_MAX_WAIT;
  tv.tv_usec = QCS_MAX_WAIT * 1000;

  FD_ZERO( &a );
  FD_SET( sock->getFD(), &a );

  if ( (select( sock->getFD()+1, &a, NULL, NULL, &tv )) == -1 )
    {
      perror("qcs::waitForPacket(): select()");
      return FALSE;
    }

#if DEBUG & DQCS
  printf("qcs::waitForPacket(): %s data\n", FD_ISSET(sock->getFD(),&a)?"got some":"no");
#endif

  
  if( FD_ISSET( sock->getFD(), &a ) )
    update();
  else
    return FALSE;

  return TRUE;
  
}



/*
**  initTables : makes each entry in modeltable, soundtable == (char *)0
**
*/

void qcs::initTables()
{
	int i=0;

	for(i=0; i < QCS_MAX_MODELS; i++ )
	  modeltable[ i ] = (char *)0;
	
	for(i=0; i < QCS_MAX_SOUNDS; i++ )
	  soundtable[ i ] = (char *)0;

}

/*
**  deleteTables : deletes each entry in soundtable, modeltable (if they are
**		   not already NULL)
**
*/

void qcs::deleteTables()
{
	int i=0;

	for(i=0; i < QCS_MAX_MODELS; i++)
	  if( modeltable[i] ) 
	    delete[] modeltable[i];

	for(i=0; i < QCS_MAX_SOUNDS; i++)
	  if( soundtable[i] )
	    delete[] soundtable[i];

	initTables();
}


/*
**  updateTableTypes : slow function which determines what "modeltype" each
**                     of the table entries is.
**
*/

void qcs::updateTableTypes()
{

  int i;

  for( i=1; i < QCS_MAX_MODELS; i++ )
    if( modeltable[i] )
      {
	if( !strncmp( modeltable[i], "progs/g_", 8 ) )
	  {
	    m_modeltypes[ i ] = ET_WEAPON;
	    if( !strcmp( modeltable[i], "progs/g_shot.mdl" ) )
	      {
		modeltypes[i] = ET_W_SSG;
	      }
	    else if ( !strcmp( modeltable[i], "progs/g_rock.mdl" ))
	      {
		modeltypes[i] = ET_W_GL;
	      }
	    else if ( !strcmp( modeltable[i], "progs/g_rock2.mdl" ))
	      {
		modeltypes[i] = ET_W_RL;
	      }
	    else if ( !strcmp( modeltable[i], "progs/g_nail.mdl" ))
	      {
		modeltypes[i] = ET_W_NG;
	      }
	    else if ( !strcmp( modeltable[i], "progs/g_nail2.mdl" ))
	      {
		modeltypes[i] = ET_W_SNG;
	      }
	    else if ( !strcmp( modeltable[i], "progs/g_light.mdl" ))
	      {
		modeltypes[i] = ET_W_LG;
	      }
	  }
	else if ( !strcmp( modeltable[i], "progs/missile.mdl" ) )
	  {
	    modeltypes[i] = ET_P_MISSILE;
	    m_modeltypes[i] = ET_PROJECTILE;
	  }
	else if ( !strcmp( modeltable[i], "progs/grenade.mdl" ) )
	  {
	    modeltypes[i] = ET_P_GRENADE;
	    m_modeltypes[i] = ET_PROJECTILE;
	  }
	else if ( !strcmp( modeltable[i], "progs/s_spike.mdl" ) )
	  {
	    modeltypes[i] = ET_P_SNG_NAIL;
	    m_modeltypes[i] = ET_PROJECTILE;
	  }
	else if ( !strcmp( modeltable[i], "progs/spike.mdl" ) )
	  {
	    modeltypes[i] = ET_P_NG_NAIL;
	    m_modeltypes[i] = ET_PROJECTILE;
	  }
//	else if ( !strcmp( modeltable[i], "progs/v_spike.mdl" ) )
//	  modeltypes[i] = ET_PROJECTILE | ET_P_NAIL;
	else if ( !strncmp( modeltable[i], "maps/b_bh", 9 ) )
	  {
	    m_modeltypes[i] = ET_HEALTH;
	    if( !strcmp( modeltable[i], "maps/b_bh100.bsp"))
	      {
		modeltypes[i] = ET_H_100;
	      }
	    else if( !strcmp( modeltable[i], "maps/b_bh25.bsp"))
	      {
		modeltypes[i] = ET_H_25;
	      }
	    else if( !strcmp( modeltable[i], "maps/b_bh10.bsp"))
	      {
		modeltypes[i] = ET_H_15;
	      }
	  }
	else if ( !strcmp( modeltable[i], "progs/armor.mdl" ) )
	  {
	    m_modeltypes[i] = ET_ARMOR;
	    modeltypes[i]= ET_A_GREEN;
	  }
	else if ( !strncmp( modeltable[i], "maps/b", 6 ) )
	  {
	    m_modeltypes[i] = ET_AMMO;
	    if( !strncmp( modeltable[i], "maps/b_shell", 12 ) )
	      modeltypes[i] = ET_A_SHELLS;
	    else if( !strncmp( modeltable[i], "maps/b_batt", 11 ) )
	      modeltypes[i] = ET_A_CELLS;
	    else if( !strncmp( modeltable[i], "maps/b_rock", 11 ) )
	      modeltypes[i] = ET_A_ROCKETS;
	    else if( !strncmp( modeltable[i], "maps/b_nail", 11 ) )
	      modeltypes[i] = ET_A_NAILS;
	  }
	else if ( !strncmp( modeltable[i], "progs/v_", 8 ) )
	  {
	    m_modeltypes[i] = ET_VIEWMODEL;
	    if( !strcmp( modeltable[i], "progs/v_shot.mdl" ) )
	      modeltypes[i] = ET_V_SG;
	    if( !strcmp( modeltable[i], "progs/v_shot2.mdl" ) )
	      modeltypes[i] = ET_V_SSG;
	    if( !strcmp( modeltable[i], "progs/v_nail.mdl" ) )
	      modeltypes[i] = ET_V_NG;
	    if( !strcmp( modeltable[i], "progs/v_nail2.mdl" ) )
	      modeltypes[i] = ET_V_SNG;
	    if( !strcmp( modeltable[i], "progs/v_light.mdl" ) )
	      modeltypes[i] = ET_V_LG;
	    if( !strcmp( modeltable[i], "progs/v_rock.mdl" ) )
	      modeltypes[i] = ET_V_GL;
	    if( !strcmp( modeltable[i], "progs/v_rock2.mdl" ) )
	      modeltypes[i] = ET_V_RL;
	    if( !strcmp( modeltable[i], "progs/v_axe.mdl" ) )
	      modeltypes[i] = ET_V_AXE;
	  }
	else 
	  {
	    m_modeltypes[i] = ET_MISC;
	    if ( !strncmp( modeltable[i], "progs/gib", 9))
	      modeltypes[i] = ET_M_BODY;
	    else if ( !strcmp( modeltable[i], "progs/h_player.mdl" ))
	      modeltypes[i] = ET_M_BODY;
	    else if ( *modeltable[i]=='*' )
	      modeltypes[i] = ET_M_ENTITY;
	    else if ( !strcmp( modeltable[i], "progs/backpack.mdl" ))
	      {
		modeltypes[i] = ET_I_BACKPACK;
		m_modeltypes[i] = ET_ITEM;
	      }
	    else if ( !strcmp( modeltable[i], "progs/quaddama.mdl" ))
	      {
		modeltypes[i] = ET_I_QUAD;
		m_modeltypes[i] = ET_ITEM;
	      }
	    else if ( !strcmp( modeltable[i], "progs/invisibl.mdl" ))
	      {
		modeltypes[i] = ET_I_RING;
		m_modeltypes[i] = ET_ITEM;
	      }
	    else if ( !strcmp( modeltable[i], "progs/invulner.mdl" ))
	      {
		modeltypes[i] = ET_I_POP;
		m_modeltypes[i] = ET_ITEM;
	      }
	    else if ( !strcmp( modeltable[i], "progs/suit.mdl" ))
	      {
		modeltypes[i] = ET_I_BIOSUIT;
		m_modeltypes[i] = ET_ITEM;
	      }
	    else
	      {
		printf(" `%s' is unknown\n", modeltable[i] );
		m_modeltypes[i]=0;
		modeltypes[i]=0;
	      }

	  }

      }


				// 
				// TODO : do this for sounds, too
				// 

      
}


/*
**  addBaseline : adds a new spawnbaseline message (for the crosshairs) returns
**                the entity number.
**
*/

int qcs::addBaseline( qentity & qe, char * mdlName )
{
	//
	// add model to model table
	//

	int i=1;
	while( modeltable[ i ] && i < 450 )
		i++;

	if( i < 450 )
	{
		i--;
		modeltable[ i ] = new char[ Q_MAX_STRING ];
		strncpy( modeltable[i], mdlName, Q_MAX_STRING );
		modeltable[ i+1 ] = 0;
		qe.default_index = i;
		qe.index = i;
	}

	//
	// add the spawnbaseline message to the fragment packets.
	//

	prespawns2.ffwd();		// go to the end of the packet
	prespawns2.setReadPos( prespawns2.getWritePos() - 6 );

	if( prespawns2.readByte() != SC_SIGNON )
	{
		printf("qcs::addBaseline(): end of prespawn2 not SIGNON\n");
		return 0;
	}

	prespawns2.setWritePos( prespawns2.getReadPos() - 1 );

	int r = findFreeEntity();
	if( r == -1 )
	{
		printf("qcs::addBaseline(): no free entities\n");
		return 0;
	}

	prespawns2.addByte( SC_SPAWNBASELINE );
	prespawns2.addLEshort( (short)r );			 // entity number
	prespawns2.addByte( (char)qe.default_index );// modelindex
	prespawns2.addByte( (char)qe.frame );		 // frame
	prespawns2.addByte( (char)0 );				 // colormap
	prespawns2.addByte( (char)qe.skin );		 // skin
	for( int j=0; j < 9; j++ )
		prespawns2.addByte( (char) 0 );			 // coords, angle (0's)

	prespawns2.addByte( SC_SIGNON );			// add signon 2 back
	prespawns2.addByte( (char)2 );

	prespawns2.truncate();

				//
				// re-build first prespawn packet (with model, soundtables)
				//

	prespawns1.reset();
	prespawns1.setWritePos( 0 );
	prespawns1.addByte( SC_PRINT );
	prespawns1.addString( "recorded by mikeBot version 0.30\n\nwww.planetquake.com/mikeBot\n(c)1997 mike warren\nmbwarren@acs.ucalgary.ca\n");

	prespawns1.addByte( SC_SERVERINFO );
	prespawns1.addLEint( 0x0F );
	prespawns1.addByte( (char)info.maxPlayers );
	prespawns1.addByte( (char)1 );
	prespawns1.addString( info.level );
	for( i=1; modeltable[ i ]; i++ )
	{
		prespawns1.addString( modeltable[i] );
	}
	prespawns1.addString( "" ); // FIXME FIXME (to do with addBaseline())
	printf("qcs::addBaseline(): added %d modeltable entries\n", i );
	for( i=1; soundtable[ i ]; i++ )
	{
		prespawns1.addString( soundtable[i] );
	}

	prespawns1.addByte( SC_SETVIEW );
	prespawns1.addLEshort( (short)myEntityNumber );

	prespawns1.addByte( SC_SIGNON );
	prespawns1.addByte( (char)1 );

	qe.spawned = TRUE;

	return r;
}


/*
**  findFreeEntity : finds an entity number not spawnbaseline'd
**
*/

int qcs::findFreeEntity()
{
	for( int i=0; i < 450; i++ )
		if( entities[ i ].spawned == FALSE )
			return i;
	return -1;
}


/*
**  cmd
**
**  performs user commands. New to version 0.40. Return TRUE iff some command
**  was performed.
**
*/

int qcs::cmd( char * in )
{
	char * sp;
	char temp[ 100 ];

	switch( in[0] )
	{
	case 'i':
		printf("Info\n");
		printInfo();
		printAllPlayers();
		return TRUE;
		break;

	case 'r':
		printf("Record demo `%s'...", &in[2] );
		fflush( stdout );
		if( !connected() )
		{
			printf(" not connected\n" );
			return TRUE;
		}
		if( !recordDemo( &in[2] ) )
		{
			perror( &in[2] );
		}
		else
		{
			printf("OK\n");
		}
		return TRUE;
		break;

	case 'R':
		printf("stop Recording\n");
		stopDemo();
		return TRUE;
		break;

	case 'l':
		printLevel();
		return TRUE;
		break;

	case 'q':
		if( connected() )
		{
			printf("disconnecting...\n");
			disconnect();
			return TRUE;
		}
		break;

	case 'p':
		if( connected() )
		{
			rankings();
			return TRUE;
		}
		break;

	case 'z':
		if( connected() )
		{
			printf("Ping: ");
			printPing();
			return TRUE;
		}
		break;

	case 'm':
		printf("Change port %d\n", atoi( &in[2] ) );
		changePort( atoi( &in[2] ) );
		return TRUE;
		break;

	case 'c':
		if( !connected() )
		{
			printf( "Connect\n" );
			sp = connect();
			if( !sp )
				printf("Connection accepted\n");
			else
				printf("Connection Rejected: %s\n", sp );
		}
		else
		{
			printf( "Console: %s\n", &in[2] );
			sendConsole( &in[2] );
		}
		return TRUE;
		break;

	case 's':
		if( connected() )
		{
			sprintf( temp, "say %s\n", &in[2] );
			printf( temp );
			sendConsole( temp );
		}
		else
		{
			printf( "Server `%s'\n", &in[2] );
			server( &in[2] );
		}
		return TRUE;
		break;

	case 'n':
		printf("Name: `%s'\n", &in[2] );
		name( &in[ 2 ] );
		return TRUE;
		break;

	case 'P':
		printf("Pants: %d\n", atoi(&in[2]) );
		pants( atoi( &in[2] ) );
		return TRUE;
		break;

	case 'S':
		printf("Shirt: %d\n", atoi( &in[2] ) );
		shirt( atoi( &in[2] ) );
		return TRUE;
		break;
	}

	return FALSE;
}
			




/*
**  dumpHash
**
**  Prints all hash-table values and strings to the file specified
**
*/

void qcs::dumpHash( FILE * fp )
{
	if( fp )
		opts.dumpToFile( fp );
}
