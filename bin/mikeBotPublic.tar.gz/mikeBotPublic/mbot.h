/*
**
**  MBOT class, derived from MBFIRE and MBNAV and MBTALK and MBEARS
**
**  (c) 1997, mike warren
**  mikeBot
**
*/

#ifndef _MBOT_H_
#define _MBOT_H_

#include "mbnav.h"

class mbot : public mbnav
{
protected:

  int respawn;			// > 0 iff bot is dead. and should fire
  int verticleSpeed;	// these are the massaged speeds 
  int forwardSpeed;		// after accounting for idealSpeeds
  int strafeSpeed;		// from mbnav and facing from mbfire

  int sendMovement();		// overrideds QCS::SENDMOVEMENT()

public:
  
  mbot();
  ~mbot(){  }

  void reinit() { mbotbase::reinit(); }

  void update();		// only function which needs to be called
						// calls qcs::update(), mbfire::update(), etc.
  int setOptsFromFile( char * );// initializes MBOT options from a file
  void changeHate( int i, int x ) { players[i].hate = x; }

  void disconnect() { qcs::disconnect(); }

  int cmd( char * );

};





#endif

