/*
**  m_line
**  mike warren 1997
**
**  Simple line class for BSP stuff
**
*/


#ifndef _M_LINE_H_
#define _M_LINE_H_

#include "vector.h"


class m_line
{
private:
	vector * m_first;
	vector * m_second;

public:
	m_line() { m_first = 0; m_second = 0; }
	~m_line(){}

	void first( vector * x ) { m_first = x; }
	void second( vector * x ) { m_second = x; }

	vector first() const { return *m_first; }
	vector second() const { return *m_second; }

	vector * pFirst() { return m_first; }
	vector * pSecond() { return m_second; }

};


#endif