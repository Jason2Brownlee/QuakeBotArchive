
=====================================================
  E D B O T   R E A D M E             Version 0.04
=====================================================

http://www.planetquake.com/hotcakes/edbot/


*** USE THIS MOD AT YOUR OWN RISK. ***

THE AUTHOR ACCEPTS NO RESPONSIBILITY FOR ANY DAMAGE
INCURRED TO THE USER'S COMPUTER OR PERSONAL WELL-
BEING AS A RESULT OF USING THE FILES IN THIS ARCHIVE. 
That said, to the best of the Author's knowledge, no
dangerous or malicious content is to be found in this
archive.

To install this mod, extract all files to your Quake
directory MAKING SURE YOU PRESERVE DIRECTORY 
STRUCTURE.


For more information, see manual.htm.

Thanks,

Edd/HotCakes
