#ifndef ENTITYOBJ_H
#define ENTITYOBJ_H

#include "QuakeBot.h"
#include <float.h>
#include <math.h>
#include <stdio.h>

class EntityObj {

public:

	int Attacker;
	unsigned char Visible, Dormant; 
	float OldAngle[3], OldLocation[3], OldVelocity[3];

	// These are Quake Variables
	float Angle[3], Location[3], Velocity[3];

	unsigned char ModelIndex, Frame, ColorMap, Skin, 
		AttackState;
	
	unsigned char OldModelIndex, OldFrame, OldColorMap, 
		OldSkin, OldAttackState;
	

	float Distance(EntityObj *);
	float Distance(float, float, float);
	void DisplayAll();
	void Reset();
	void SaveOldValues();

	EntityObj() {

		int i;

		for(i=0; i<3; i++) {
			Location[i] = (float)0.0;
			Angle[i] = (float)0.0;
			Velocity[i] = (float)0.0;
		}
		ModelIndex = 0;
		ColorMap = 0;
		Frame = 0;
		AttackState = 0;
		Skin = 0;
		Dormant = 1;
		Attacker = 0;
		Visible = 1;
	}


};




#endif
