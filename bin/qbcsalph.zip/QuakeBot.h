#ifndef QUAKEBOT_H
#define QUAKEBOT_H

#pragma warning( disable : 4514 4201 ) 


#include <stdlib.h>
#include <stdio.h>

#ifndef __unix__
	#include <winsock.h>
	#include <crtdbg.h>
#else
	
	#define strnicmp strncmp
	#define stricmp strcmp
	#define _timeb timeb
	#define _ftime ftime

#endif

struct CoordStruct{
	float X, Y, Z, Distance;
	int Index;
};

typedef struct CoordStruct GameCoord;

struct AddressStruct{
	char * IPAddress;
	int Port;
};

 typedef struct AddressStruct Address;

enum Booleans {True = 1, False = 0};

typedef enum Booleans Boolean;


enum EventDestinations {edBroadcast, edConsole, edServer, edIBCServer, 
	edAI, edProxyServer}; // Event Destinations

typedef enum EventDestinations EventDest;

enum ObjectEvents {oeConsoleParse, oeConsolePrint, oeAIOn, oeAIOff,
oeServerOnline, oeServerOffline, oeServerConnect, oeRespawn,
oeServerDisconnect, oeSendRuntimePacket, oeSendSay, oeSendRaw,
oeImpulseReceived, oeProxyPrint, oeAICommand}; // Object events

typedef enum ObjectEvents ObjectEvent;

#endif

