#include "H.h"
#include "NavObj.h"

int NavObj::Mapping() {

	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];
	BotCoord.X = Bot->Location[0];
	BotCoord.Y = Bot->Location[1];
	BotCoord.Z = Bot->Location[2];
	BotCoord.Distance = FLT_MAX;

	if(Traveling) {
		if(Stalled(BotCoord)) {
//			_RPT0(_CRT_WARN, "Bot is STALLED\n"); 
			InsertBlockedWaypoint(EndCoord);
			InsertWaypoint(BotCoord);
			Bot->CommandInlineSpeed = 0x00;
			EndCoord.Distance = (float) MAX_RANGE;
			Traveling = 0;
		} else if(AtDestination(BotCoord)) {
//			_RPT0(_CRT_WARN, "Bot has reached destination\n"); 

/*			if(!InsertWaypoint(EndCoord))
			_RPT0(_CRT_WARN, "Insert Failed\n"); 
			else
			_RPT0(_CRT_WARN, "Insert Successfull\n"); 
*/
			EndCoord.Distance = (float) MAX_RANGE;
			Bot->CommandInlineSpeed = 0x00;
			Traveling = 0;
		} else
			return 1;
	} 
	
	if(WaypointSync(BotCoord)) { // I can map to somewhere

		// save the start position
		StartCoord.X = Bot->Location[0];
		StartCoord.Y = Bot->Location[1];
		StartCoord.Z = Bot->Location[2];

		do {
			EndCoord.X = Bot->Location[0];
			EndCoord.Y = Bot->Location[1];
			EndCoord.Z = Bot->Location[2];

			Data->NextEntity(&EndCoord);

		// While destination already tried or nowhere else to try
		} while(IsAttached(EndCoord) && EndCoord.Index != -1);
					
		if(EndCoord.Index != -1 ) {

//			_RPT1(_CRT_WARN, "Entity is %d\n", EndCoord.Index);
//			if(Bot->Aim(EndCoord) == FLT_MAX)
//				_RPT0(_CRT_WARN, "Cannot AIM!!!!\n");
			SetDestination(EndCoord);
			Bot->CommandInlineSpeed = 0x20;
			Traveling = 1;
			StallCount = 0;
			return 1;
		} else {
//			_RPT0(_CRT_WARN, "Nowhere else to try!!!\n");
			return 0;
		}
	}
	return 0;
}

void NavObj::RandomMove() {
//	Console.DisplayString("Moveing Randomly\n");
}

// ************************************************
// *
// * Checks to see if at a known location
// * If yes, the location is saved for next action
// *
// ************************************************
int NavObj::WaypointSync(GameCoord Coord ){

	int i;
//	_RPT0(_CRT_WARN, "Syncing Waypoint....\n");

	for(i = 0; i < MAX_DEATHMATCH_STARTS; i++) {
		if(GraphEntry[i] != NULL) {

			CurrentWaypoint = FindWaypoint(GraphEntry[i], Coord.X, Coord.Y, Coord.Z);
			if(CurrentWaypoint != NULL) {
				return 1;
			}
		}
	}

//	_RPT3(_CRT_WARN, "****Cannot Sync Location (%f, %f, %f)\n", Coord.X, Coord.Y, Coord.Z);
	DisplayGraph();
	return 0;
}


// ************************************************
// *
// * This inserts a new entrypoint into the graph
// * if the current Waypoint does not exist.  It is for
// * dealing with disjoint starts like respawn
// *
// ************************************************

void NavObj::InsertEntryPoint(GameCoord Coord) {
	int i;
	for(i = 0; i < MAX_DEATHMATCH_STARTS; i++) {
		if(GraphEntry[i] == NULL) {  // No Waypoint for this entry

//			_RPT3(_CRT_WARN, "******New Entrypoint Created at (%f, %f, %f)\n", Coord.X, Coord.Y, Coord.Z);

			GraphEntry[i] = new WaypointObj(Coord.X, Coord.Y, Coord.Z);
			CurrentWaypoint = GraphEntry[i];
//			Console.DisplayString("Current Waypoint=%x\n", CurrentWaypoint);
			return;
		} else if(GraphEntry[i]->WithinRange(Coord.X, Coord.Y, Coord.Z)) {

//			_RPT3(_CRT_WARN, "******Waypoint Exists at (%f, %f, %f)\n", Coord.X, Coord.Y, Coord.Z);

			CurrentWaypoint = GraphEntry[i];
			return;
		}
	}
//	_RPT0(_CRT_WARN, "******No room for entry point\n");
}


// ************************************************
// *
// * This inserts a new waypoint  into the graph
// * if the current Waypoint does not exist.  
// *
// ************************************************

int NavObj::InsertWaypoint(GameCoord Coord) {
	int i;
	WaypointObj *NewWaypoint;

	if(FindWaypoint(CurrentWaypoint, Coord.X, Coord.Y, Coord.Z) != NULL)
		return 0;

	i = VacantConnection();
	if(i != -1) {
		NewWaypoint = new WaypointObj(Coord.X, Coord.Y, Coord.Z);
		CurrentWaypoint->Attach(NewWaypoint);
		CurrentWaypoint = NewWaypoint; // I am here now
		return 1;
	} else
		return 0;
}


// ************************************************
// *
// * This inserts a new waypoint  into the graph
// * if the current Waypoint does not exist.
// * Set blocked flag so path will not be chosen again  
// *
// ************************************************

void NavObj::InsertBlockedWaypoint(GameCoord Coord) {
	int i;
	WaypointObj *NewWaypoint;

	if(FindWaypoint(CurrentWaypoint, Coord.X, Coord.Y, Coord.Z) != NULL) {
//		Console.DisplayString("Waypoint Exists at (%f, %f, %f). Skipping Insertion\n", Coord.X, Coord.Y, Coord.Z);
		return;
	}

	i = VacantConnection();
	if(i != -1) {
		NewWaypoint = new WaypointObj(Coord.X, Coord.Y, Coord.Z);
		CurrentWaypoint->Block(NewWaypoint);
#ifdef DEBUG
		// Console.DisplayString("******Blocked Waypoint Inserted and attached. Graph Sync'ed.\n");
#endif
		
	} else {
#ifdef DEBUG
		// Console.DisplayString("******No room for entry point\n");
#endif
	}
}
// ************************************************
// *
// * Check for the existance of a waypoint at the 
// * location.
// *
// ************************************************
int NavObj::IsAttached(GameCoord Coord) {

	int i;
	for(i = 0; i < MAX_CONNECTIONS; i++) {
		if(CurrentWaypoint->Connection[i] != NULL) {  // No Waypoint for this entry
			if(CurrentWaypoint->Connection[i]->WithinRange(Coord.X, Coord.Y, Coord.Z)){
//				Console.DisplayString("******Location Already Attached(%f, %f, %f)\n", Coord.X, Coord.Y, Coord.Z);
				return 1;
			}
		}
	}
	return 0;

}


// ************************************************
// *
// * Check to see if progress is being made toward the
// * destination.
// *
// ************************************************

int NavObj::Stalled(GameCoord Coord) {

	float Result;

//	Console.DisplayString("Stall Check. Current Waypoint=%x\n", CurrentWaypoint);
	Result = DistanceFromDestination(Coord.X, Coord.Y, Coord.Z);

	if((Result + 1) < PreviousDistance){

		StallCount = 0; // Reset Stallcount
//		Console.DisplayString("******Moving (Distance = %f)\n", Result);
		PreviousDistance = Result;  // Save for next check
		return 0;
	} else {
		if(++StallCount >= MaxStallCount) {
//			_RPT1(_CRT_WARN, "******Stalled (Distance = %f)\n", Result);
			PreviousDistance = Result;  // Save for next check
			return 1;
		} else
			return 0;
	}
}

float NavObj::DistanceFromDestination(float X, float Y, float Z) {
	float XOffset, YOffset, ZOffset;	

	XOffset = DestinationX - X;
	YOffset = DestinationY - Y;
	ZOffset = DestinationZ - Z;

	return (float) sqrt(pow(ZOffset, (float)2.0) + pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));

}

// ************************************************
// *
// * Traverses graph recursively to see if coords 
// * are represented by any Waypoints
// *
// ************************************************

WaypointObj *NavObj::FindWaypoint(WaypointObj *Start, float X, float Y, float Z){

	int i;
	WaypointObj *ReturnNode;

	if(Start->Visited) // If I have been here before
		return NULL;

	if(Start->WithinRange(X, Y, Z))  // If the right node
		return Start;

	for(i = 0; i < MAX_CONNECTIONS; i++){ // recurse
		if(Start->Connection[i] != NULL) {
			ReturnNode = FindWaypoint(Start->Connection[i], X, Y, Z);	
			if(ReturnNode != NULL) {
				Start->Visited = 0;
				return ReturnNode;
			}
		}
	}

	Start->Visited = 0; // dead end
	return 0;
}

// ************************************************
// *
// * Prints out a graph 
// *
// ************************************************

void NavObj::DisplayGraph(){
	int i;

	for(i = 0; i < MAX_DEATHMATCH_STARTS; i++) {
		if(GraphEntry[i] != NULL) {

			DisplayWaypoint(GraphEntry[i]);
		}
	}

}

// ************************************************
// *
// * Traverses graph recursively prints it out 
// *
// ************************************************

void NavObj::DisplayWaypoint(WaypointObj *Start){

	int i;

	if(Start->Visited) // If I have been here before
		return;

//	_RPT4(_CRT_WARN, "Node(%x) = %f, %f, %f\n", Start, Start->X, Start->Y, Start->Z);
	for(i = 0; i < MAX_CONNECTIONS; i++){ // recurse
		if(Start->Connection[i] != NULL) {
			DisplayWaypoint(Start->Connection[i]);	
		}
	}

	Start->Visited = 0; // dead end
	return;
}

// ************************************************
// *
// * Checks for a vacant connection in the Waypoint
// *
// ************************************************

int NavObj::VacantConnection() {
	int i;

	if(CurrentWaypoint != NULL) {
		for(i = 0; i < MAX_CONNECTIONS; i++) {
		if(CurrentWaypoint->Connection[i] == NULL)
			return i;

		}
#ifdef DEBUG
		// Console.DisplayString("Connections are full!!\n");
#endif
	}

	// Console.DisplayString("Player is Desynched from NavObj\n");
	return -1;
}

// ************************************************
// *
// * Set the destination for a mapping move
// *
// ************************************************
void NavObj::SetDestination(GameCoord Coord) {

	DestinationX = Coord.X;
	DestinationY = Coord.Y;
	DestinationZ = Coord.Z;
//	Console.DisplayString("Current Waypoint=%x\n", CurrentWaypoint);

	PreviousDistance = FLT_MAX;
#ifdef DEBUG
	// Console.DisplayString("Destination (%f, %f, %f) (%f) is set\n", Coord.X, Coord.Y, Coord.Z, Coord.Distance);
#endif

}

// ************************************************
// *
// * Set the destination for a mapping move
// *
// ************************************************
int NavObj::AtDestination(GameCoord Coord) {

	float Residue;

	Residue = (float) (fabs(DestinationX - Coord.X) + fabs(DestinationY - Coord.Y) +
		fabs(DestinationZ - Coord.Z));

	if(Residue <= (float)MAX_RANGE)
		return 1;
	else
		return 0;

}


void NavObj::AttachWaypoint(){
#ifdef DEBUG
	// Console.DisplayString("Attaching Waypoint\n");
#endif
}

