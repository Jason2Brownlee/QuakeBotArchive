#ifndef SERVEROBJ_H
#define SERVEROBJ_H

#include "QuakeBot.h"
#include "Quake.h"

#include <sys/types.h>
#include <sys/timeb.h>
#include <limits.h>
#include <float.h>
#include <ctype.h>

#include "EventObj.h"
#include "ScktObj.h"
#include "PcktObj.h"
#include "DataObj.h"

const char QuitString[] = "no bots";

enum QuakeServerModes { smSetup, smQuery, smGetRules, smConnect, smGameInit, smIdle, smRuntime };

typedef enum QuakeServerModes QuakeServerMode;

enum QuakeSocketModes { skIdle, skWaiting };

typedef enum QuakeSocketModes QuakeSocketMode;


class ServerObj: virtual public EventHandlerObj {

private:

	// ***************************************************
	//
	//  Server Timeout routine. Uses Console instead of printf
	//
	// ***************************************************

	static void ServerTimeoutHandler(void) {

		printf("Server: Receive timed out!!!!\n");

	}


	Boolean Connected;
	EventTableObj *EventTable;
//	time_t ClientStartTime;
	int GameMode;
	Boolean GetServerStartTime; // Flag to get the first start time
	QuakeServerMode ServerMode;
	QuakeSocketMode SocketMode;
	int SocketEventID;
	DataObj *Data;
	PlayerObj *Bot;

	timeval ShortTimeout; // This is for extra data

	void DEMServerInfo();
	void DEMSpawnStatic();
	void DEMTempEntity(int);
	void DEMUpdateClientData();
	void DEMUpdatePlayerName(int);
	void DEMUpdatePlayerColor(int);
	void DEMUpdatePlayerState(int);
	void DEMUpdatePlayerFrags(int);
	void DEMSpawnBaseline(int);
	void DEMCDTrack();
	void DEMServerShutdown();
	void DEMSetView(int);
	void DEMSound();
	void DEMLightStyle(int);

public:

	PacketObj ServerPacket;

	char Initialized;

	// Registered callbacks
	
	void CycleEvent(void *);
	void ExitEvent(void *); 
	void RecvEvent(void *);
	void MessageEvent(ObjectEvent, void *);
	
	// Member Functions
	ServerObj(EventTableObj *, DataObj *);
	void DecodePacket();
	void DecodeServerPacket();
	void SendGoodbye();
	void SetServer(char *, int);
	void QueryServer();
	void GetRules();
	void SendRuntimePacket(PlayerObj *);
	void SendBroadcastMessage(char *);
	void SendCommand(char *);
	void ConnectServer();
	void GameInit();
	void Respawn();
	void SendClientParms(), SendBegin(), SendNoOp();
	void SendPrespawn();
	void BombOut(char *);
	void DecodeAccept();
	void DecodeReject();
	void DecodeRule();
	void DecodeQuery();
	void IsMemNuked();

	EntityObj *CheckPointer;



};


#endif
