#ifndef DATAOBJ_H
#define DATAOBJ_H


#include "PlayrObj.h"
#include "QuakeBot.h"
#include "Quake.h"

#include <limits.h>
#include <float.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAX_MODELS 255
#define MAX_SOUNDS 255

#define MAX_BASELINE_ENTITIES 450
#define MAX_STATIC_ENTITIES 128
#define GAME_STATE_PRESPAWN 1
#define GAME_STATE_LIGHTING 2
#define GAME_STATE_RENDER 3

class DataObj {

private:

	int GameMode;

public:

	// These are server parameters
	int sv_gravity, sv_friction, sv_maxspeed, noexit;
	int teamplay, fraglimit, timelimit;
	int NumModels, NumSounds;
	int StaticEntityCount;
	int EntityIndex;
	char *PrecacheModel[255], *PrecacheSound[255];
	int NumberOfPlayers, MaxPlayers, MaxClients, Multi, BotID;
	int BotEntityIndex;

	EntityObj *BaselineEntity[MAX_BASELINE_ENTITIES];
	EntityObj *StaticEntity[MAX_STATIC_ENTITIES];
	int UpdatedEntity[MAX_BASELINE_ENTITIES];

	char *LightStyle[MAX_STATIC_ENTITIES];

	char *BotName, *ServerName, *ServerIP, *MapName, *ProxyHostName;
	int BotShirtColor, BotPantColor;
	long ServerVersion;
	int ProtocolVersion;
	char Initialized;
	void ResetGameVariables();
	float ServerTimeStamp, ClientTimeStamp;

	_timeb ServerTime;

	Boolean RespawnMode;

//	float ServerStartTime;

	
	// Member Functions
	DataObj();
	~DataObj();
	int WhatIsAt(float, float, float);
	void FreeEntities(), FreePrecache(), FreeMisc();
	int NearestPlayerByVector();
	int NearestEnemyByVector();
	int NearestEntityByVector(float, float, float);
	void SetServerName(char *);
	void SetMapName(char *);
	void SetServerIP(char *);
	void SetBotName(char *);
	void SetProxyHostName(char *);
	void SetLightStyle(int, char *);
	void FreeGameData();
	int LastUpdatedEntity;

	GameCoord *NextEntity(GameCoord *);

};


#endif
