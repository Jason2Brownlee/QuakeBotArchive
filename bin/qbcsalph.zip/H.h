//
// This file is included in each *.cpp, after the <system> header files,
// but before any other "qudproxy" header file.
//

#ifndef H_H
#define H_H

#ifdef __unix__

#include <errno.h>

#if !defined(__FreeBSD__) && !defined(__NetBSD__) && \
    !defined(__bsdi__) && !defined(__alpha) && !defined(__GLIBC__)
extern char *sys_errlist[];
#endif

#endif // __unix__

#if 0

-----BEGIN PGP SIGNED MESSAGE-----

 The following part is donated by Carlo Wood from his package 'libr':
 (C) Copyright 1996-1997

 Author:

 1024/624ACAD5 1997/01/26 Carlo Wood, Run on IRC <carlo@runaway.xs4all.nl>
 Key fingerprint = 32 EC A7 B6 AC DB 65 A6  F6 F6 55 DD 1C DC FF 61
 Get key from pgp-public-keys server or
 finger carlo@runaway.xs4all.nl for public key (dialin, try at 21-22h GMT).

#endif // BEGIN PGP SIGNED MESSAGE

#define UNUSED(x)

// GNU CC improvements: We can only use this if we have a g++ compiler
#ifdef __GNUC__

# if (__GNUC__ < 2) || (__GNUC__ == 2 && __GNUC_MINOR__ < 7)
#  define NO_ATTRIBUTE
# endif

#else // !__GNUC__

// No attributes if we don't have gcc-2.7 or higher
# define NO_ATTRIBUTE

#endif // !__GNUC__

#ifdef NO_ATTRIBUTE
# define __attribute__(x)
#endif

#define RCSTAG_CC(string) \
    static char rcs_ident[] __attribute__ ((unused)) = string;

#if 0

-----BEGIN PGP SIGNATURE-----
Version: PGPfreeware 5.0i for non-commercial use
Charset: noconv

iQCVAwUBND5Wsm/Sxh1iSsrVAQEmhQP7BgX66yc+Perrea72zg2VjOI7wopmTWp+
cuQlfz33XxYt/JiLhUlZB/x7bcGZTKUs62YQlwBoEsmf056ZEGf56841iYZpXQbU
nOHpXIxE24mZH+X4XQKftnWbSLjcxt6YQng/v73jcMAtY9QSG84mOkkaJkfbqBf+
p3biYjVUZAo=
=b2IU
-----END PGP SIGNATURE-----

#endif // PGP SIGNATURE

#endif // H_H
