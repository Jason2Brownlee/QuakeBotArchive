#ifndef PROXYSERVEROBJ_H
#define PROXYSERVEROBJ_H

#include "QuakeBot.h"
#include "Quake.h"
#include "ScktObj.h"
#include "PcktObj.h"
#include "SrvrObj.h"
#include "EventObj.h"
#include "DataObj.h"



#include <limits.h>
#include <float.h>
#include <time.h>

#ifdef __unix__
 #define strnicmp strncmp
 #define stricmp strcmp
 #define Sleep sleep
 #define TRUE 1
 #define FALSE 0
#endif

const int WatchdogCounterMax = 200;

enum ProxyServerModes { pmIdle, pmASCIIPacket, pmBinaryPacket, pmLightingPacket, pmRuntimePacket };

typedef enum ProxyServerModes ProxyServerMode;

//enum ProxySocketModes { skIdle, skWaiting };

//typedef enum ProxySocketModes ProxySocketMode;


class ProxyServerObj : EventHandlerObj {


private:

	EventTableObj *EventTable;

	QuakeSocketMode SocketMode;
	ProxyServerMode ProxyMode;

	int SocketEventID, WatchdogCounter;

//	void Logon();

	// ***************************************************
	//
	//  Server Timeout routine. Uses Console instead of printf
	//
	// ***************************************************


	static void TimeoutHandler(void) {

//		Console.DisplayString("Receive timed out!!!!\n");
		printf("Proxy: Receive timed out!!!!\n");

	}
	void RespondQuery();
	void RespondRule();
	void RespondConnect();
	void SendASCIIPacket();
	void SendBinaryPacket();
	void SendLightingPacket();
	void SendRuntimePacket();
	void SendNoOp();
	void GameInit();

	int InitClientPort();
	void DecodeFinal();
	void DecodeUpdate();
	void ClientShutdown();
	void SendGoodbye();
	void SendBroadcastMessage(char *);

	DataObj *Data;
	Boolean ServerConnected, ClientConnected;
	PacketObj ProxyInitPacket;
	PacketObj ClientPacket;

public:

	// Server Parameters
	long ClientVersion;
	char Initialized;
	ProxyServerObj(EventTableObj *, DataObj *, int);

	// Registered Callbacks
	void RecvEvent(void *);
	void CycleEvent(void *);
	void MessageEvent(ObjectEvent, void *);
	void ExitEvent(void *);


	// Member Functions
	void DecodeInitPacket();
	void DecodeClientPacket();
	void InitServerPort(char *);

	void DEMPrintString(char *);
	void DEMSendEntityUpdate(int );

	time_t ClientStartTime;

};


#endif
