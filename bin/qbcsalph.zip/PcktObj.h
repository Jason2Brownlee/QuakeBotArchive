#ifndef PACKETOBJ_H
#define PACKETOBJ_H

#include "ScktObj.h"

// These are message types for packets
#define MESSAGE_TYPE_UNDEFINED 0
#define MESSAGE_TYPE_CONTROL 1
#define MESSAGE_TYPE_UPDATE 2
#define MESSAGE_TYPE_PARTIAL 3
#define MESSAGE_TYPE_FINAL 4
#define MESSAGE_TYPE_ACK 5
#define MESSAGE_TYPE_CLIENT 6


#define HEXDUMP_INPUT_BUFFER 0
#define HEXDUMP_OUTPUT_BUFFER 1

#define SEQUENCE_UPDATE 0
#define SEQUENCE_FINAL 1
#define SEQUENCE_ACK 2
#define SEQUENCE_MAX 2


// This is the Data object for the Packet
class PacketObj {

private:

	int Count;

	char *OutputPacket, *InputPacket;
	char StringBuffer[0x800];
	short NShort(short);
	long NLong(long);
	void SetPacketSequence(long Data);
	long GetPacketSequence();


public:
	
	SocketObj Socket;
	int IncomingPacketSequence[3];
	int OutgoingPacketSequence[3];
	int i, InputLength, OutputLength;
	char *OutputBuffer, *InputBuffer;
	int InputOffset, OutputOffset, IncomingRejected;
	void SendMessage(), HexDump(int), HexDump(int, int), SendAck();
	int GetMessage();
	unsigned char ReadByte();
	char ReadChar();
	float ReadAngle(), ReadCoord(), ReadFloat(), ReadNFloat();
	short ReadShort(), ReadNShort();
	long ReadLong(), ReadNLong();
	char *ReadString();
	void SaveString(char *);
	void SaveChar(char);
	void SaveByte(unsigned char);
	void SaveAngle(float Data);
	void SaveCoord(float Data);
	void SaveShort(short Data);
	void SetHeader(int Type);
	int GetInputHeader();
	int GetOutputHeader();
	int GetHeader(unsigned char *);
	void SaveLong(long Data);
	void SaveFloat(float Data), SaveNFloat(float Data);
	void SaveNLong(long Data);
	void SetOutputLength(short Data);
	unsigned char End();
	PacketObj();
	void Reset();
	void ResetPacket();

	
};



#endif

