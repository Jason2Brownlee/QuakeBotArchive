#include <math.h>
#include <ctype.h>
#include "H.h"
#include "AIObj.h"

extern char VERSION[];

//AI Constructor
AIObj::AIObj(EventTableObj *Event, DataObj *ServerData)
{
	EventTable = Event;
	OwnerID = edAI;
	Enabled = False;
	Data = ServerData;
	LastTimeStamp = 0.0f;
	Rotation = -1.0f;
	Delay = .5f;
	Speed = 0x80;

	AIMode = INIT;
	Msg = True;

	StartCoord.X = StartCoord.Y = StartCoord.Z = 0.0f;

	// Register the AI Callback
	EventTable->RegisterCallback((EventHandlerObj *)this, (void *)NULL, etCycleEvent);
	EventTable->RegisterCallback((EventHandlerObj *)this, (void *)NULL, etMessageEvent);

}


void AIObj::Print(char *Data, ...)
{
	va_list Marker;
	va_start(Marker, Data);
	char Buffer[0xff];
	char Temp[0xff];

	strcpy(Temp, "AI: ");
	strcat(Temp, Data);

	vsprintf(Buffer, Temp, Marker); // printf it to a Buffer

	if (Msg)
		EventTable->Print(Buffer); // Generate event
}

/*int AIObj::AttackPlayer(int TargetPlayer) {

	float Distance;

	PlayerObj *MyBot, *Target;

	MyBot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];
	Target = (PlayerObj *)Data->BaselineEntity[TargetPlayer+1];
	if(TargetPlayer == -1) 
		return 0;
	if(Target->Dead()) 
		return 0;
	
	// Aim at Player
	Distance = MyBot->Aim(Target);

	if(Distance <= (float)300.0 && Distance > (float) 10.0){
		MyBot->SelectSafeWeapon(); 
		MyBot->CommandActions |= KEY_ACTION_FIRE;
		MyBot->CommandInlineSpeed = 0x1FF;
		return 1;
	} else if (Distance <= (float)10.0) {
		MyBot->CommandImpulse = SELECT_WEAPON_AXE;
		MyBot->CommandActions |= KEY_ACTION_FIRE;
		MyBot->CommandInlineSpeed = 0;
		return 1;
	}
	return 0;
}*/


/*void AIObj::Chatter(int MyCount) {

	char Buffer[50];
	if(MyCount == 50) {
		sprintf(Buffer, "QuakeBot C/S(c) %s", VERSION);
		EventTable->SendMessage(edServer, oeSendSay, (void *)Buffer);
	}

	if(MyCount == 100)
		EventTable->SendMessage(edServer, oeSendSay, (void *)"jfrorie@uncc.edu");

}*/

/*void AIObj::DisplayMode(int Mode) {

	switch(Mode) {
	case AI_MODE_IDLE:
		EventTable->Print("Bot is IDLE\n");
		break;
	case AI_MODE_ATTACK:
		EventTable->Print("Bot is ATTACKING\n");
		break;
	case AI_MODE_TARGET:
		EventTable->Print("Bot is TARGETING\n");
		break;
	case AI_MODE_EVADE:
		EventTable->Print("Bot is EVADING\n");
		break;
	case AI_MODE_MAP:
		EventTable->Print("Bot is MAPPING\n");
		break;
	case AI_MODE_RETRACE:
		EventTable->Print("Bot is RETRACING\n");
		break;
	case AI_MODE_DEAD:
		EventTable->Print("Bot is DEAD\n");
		break;
	case AI_MODE_STALLED:
		EventTable->Print("Bot is STALLED\n");
		break;
	case AI_MODE_MOVING:
		EventTable->Print("Bot is MOVING\n");
		break;
	case AI_MODE_REACHED:
		EventTable->Print("Bot has found WAYPOINT\n");
		break;
	case AI_MODE_RESPAWNED:
		EventTable->Print("Bot has RESPAWNED\n");
		break;
	default:
		EventTable->Print("Bot is SCREWED UP!!!\n");
	}
}*/

//*********************************
//
// This function hits once per event cycle
//
//*********************************

void AIObj::CycleEvent(void *Unused) {

	float	TimeStampInterval, Slope, DistanceOffCourse, ActualRotation;
	GameCoord	DistanceMoved, Predicted;
	PlayerObj *Bot;

	if (!Enabled) // AI was turned off
		return;

	// Update who I am for this pass
	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];

	//Check to see if this is the first pass though ai cycle event
	if (AIMode == INIT)
	{
		LastTimeStamp = Data->ServerTimeStamp;
		BotCoord.X = Bot->Location[0];
		BotCoord.Y = Bot->Location[1];
		BotCoord.Z = Bot->Location[2];

		//Store Start Coord.
		StartCoord.X = Bot->Location[0];
		StartCoord.Y = Bot->Location[1];
		StartCoord.Z = Bot->Location[2];

		LastCoord.X = Bot->Location[0];
		LastCoord.Y = Bot->Location[1];
		LastCoord.Z = Bot->Location[2];

		AIMode = IDLE;
		return;
	}


	//Check for death
	if(Bot->Health <= 0)  // I am dead, deal with it	
	{
		//EventTable->SendMessage(edAI, oeAIOff, (void *)NULL); // Turn off AI
//		while (Bot->Health <= 0)
		Data->RespawnMode = True;
//		EventTable->SendMessage(edServer, oeRespawn, (void *)NULL);

		StartCoord.X = Bot->Location[0];
		StartCoord.Y = Bot->Location[1];
		StartCoord.Z = Bot->Location[2];

		LastCoord.X = Bot->Location[0];
		LastCoord.Y = Bot->Location[1];
		LastCoord.Z = Bot->Location[2];
		
		return;
	}

	//Calc time interval
	TimeStampInterval = Data->ServerTimeStamp - LastTimeStamp;

	// check if bot on course
	if ((Bot->CommandRotation == 90.0f) || (Bot->CommandRotation == 270))
	{
		Slope = Bot->CommandRotation == 90.0f ? 0.0f : -0.0f;
		Predicted.X = StartCoord.X;
		Predicted.Y = Bot->Location[1];
		Predicted.Z = 0.0f;
	}
	else 
	{
		Slope = (float)tan(3.14 * Bot->CommandRotation / 180);
		Predicted.Y = Slope * (Bot->Location[0]) + (StartCoord.Y - Slope * StartCoord.X);
		Predicted.X = Bot->Location[0];
		Predicted.Z = 0.0f;
	}

	if (TimeStampInterval < Delay) // wait for something to happen
	{
		if ((TimeStampInterval / Delay) > 2)
		{
			LastCoord.X = Bot->Location[0];
			LastCoord.Y = Bot->Location[1];
			LastCoord.Z = Bot->Location[2];
		}
		return;
	}

	LastTimeStamp = Data->ServerTimeStamp;
/*
//	EventTable->Print("AI: Start Position -     (%f, %f, %f)\n", StartCoord.X, StartCoord.Y, StartCoord.Z);
	Print("Current Position -   (%f, %f, %f)\n", Bot->Location[0], Bot->Location[1], Bot->Location[2] );
	Print("Predicted Position - (%f, %f, %f)\n", Predicted.X, Predicted.Y, Predicted.Z);
//	EventTable->Print("AI: Predicted Slope - %f\n", Slope);
//	EventTable->Print("AI: Actual Slope - %f\n", (StartCoord.Y - Bot->Location[1])/(StartCoord.X - Bot->Location[0]));
	Print("Predicted Rotation - %f\n", Bot->CommandRotation);
*/	ActualRotation = (float)(180.0f / 3.14f * (float)atan2((Bot->Location[1] - LastCoord.Y), (Bot->Location[0] - LastCoord.X)));

	if (ActualRotation < 0)
		ActualRotation += 360;
//	Print("Actual Rotation - %f\n", ActualRotation);
	
	

	//calc distance moved
	DistanceMoved.X = Bot->Location[0] - BotCoord.X;
	DistanceMoved.Y = Bot->Location[1] - BotCoord.Y;
	DistanceMoved.Z = Bot->Location[2] - BotCoord.Z;
	
	//Update position
	BotCoord.X = Bot->Location[0];
	BotCoord.Y = Bot->Location[1];
	BotCoord.Z = Bot->Location[2];

	DistanceOffCourse = (float) sqrt(pow(Bot->Location[0] - Predicted.X, (float)2.0) + pow(Bot->Location[1] - Predicted.Y, (float)2.0));

//	Print("DistanceOffCourse %f\n", DistanceOffCourse);

	//check to see if bot is stuck
	if ((fabs(DistanceMoved.X) > 0)||(fabs(DistanceMoved.Y) > 0)||(fabs(DistanceMoved.Z) > 0 ))
	{
//		EventTable->Print("AI: Distance Moved %f %f %f\n", DistanceMoved.X, DistanceMoved.Y, DistanceMoved.Z);

		//Check to make sure bot is where we think it is
		if ((fabs(DistanceOffCourse) < 10) && (LastTimeStamp != 0.0))
			return;	
		else
		{
			ActualRotation = (float)(180.0f / 3.14f * (float)atan2((Bot->Location[1] - LastCoord.Y), (Bot->Location[0] - LastCoord.X)));
			if (ActualRotation < 0)
				ActualRotation += 360;
			Bot->CommandRotation = ActualRotation;
		}
	}
	else
		// we are stuck or off predicted course pick new direction 
		Bot->CommandRotation = (float)floor(255.0f * ((float)rand() / (float)RAND_MAX));

	Bot->CommandActions = KEY_ACTION_NONE;
	Bot->CommandImpulse = 0x0;
	Bot->CommandLateralSpeed = 0x0; // speed side to side
	Bot->CommandInlineSpeed = Speed; // Speed in forward/reverse
    Bot->CommandVerticalSpeed = 0x0; // ???

	

	/*if (Rotation == -1.0f)
		Rotation = 0.0f;
	else if (Rotation == 0.0f)
		Rotation = 90.0f;
	else if (Rotation == 90.0f)
		Rotation = 180.0f;
	else if (Rotation == 180.0f)
		Rotation = 270.0f;
	else if (Rotation == 270.f)
		Rotation = 0.0f;

	Bot->CommandRotation = Rotation;*/

//	Print("Bot Rotation %f******************\n", Bot->CommandRotation);

	//Store Start Coord.
	StartCoord.X = Bot->Location[0];
	StartCoord.Y = Bot->Location[1];
	StartCoord.Z = Bot->Location[2];

	LastCoord.X = Bot->Location[0];
	LastCoord.Y = Bot->Location[1];
	LastCoord.Z = Bot->Location[2];

//	EventTable->SendMessage(edServer, oeSendRuntimePacket, (void *)Bot);
	Unused = NULL;

}


//Handles Impulse commands from the console
//just toggles ai->enabled right now
void AIObj::ProcessImpulse() {
	Print("Processing Impulse\n");
	EventTable->SendMessage(edServer, oeSendSay, (void *)"Impulse Received\n");

	if (Enabled)
	{
		Enabled = False;
		EventTable->SendMessage(edServer, oeSendSay, (void *)"AI Disabled\n");
	}
	else
	{
		Enabled = True;
		EventTable->SendMessage(edServer, oeSendSay, (void*)"AI Enabled\n");
	}
}

//Process commands from console to AI
void AIObj::ProcessCommand(char *Cmd)
{
	char *Temp;
	PlayerObj *Bot;

	// Update who I am for this pass
	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];

	if (Cmd == NULL)
	{
		Print("No command found\n");
		return;
	}

	Print("Processing Command (%s)\n", Cmd);
#ifdef __unix__
       for (char *p = Cmd; *p; ++p)
               *p = toupper(*p);
#else
	strupr(Cmd);
#endif
	Temp = strtok(Cmd, "=");

	if (Temp == NULL)
		Print("NULL Token\n");

	if (strcmp(Temp, "SPEED")==0)
	{
		Print("Processing Speed Command\n");
		Temp = strtok(NULL,"");
		if (Temp == NULL)
			Print("NULL Token\n");
		else
		{
			Speed = (short)strtol(Temp,NULL,16);
			Print("New Speed %d\n", Speed);
		}
	}
	else if (strcmp(Temp, "ANGLE")==0)
	{
		Print("Processing Angle Command\n");
		Temp = strtok(NULL,"");
		if (Temp == NULL)
			Print("NULL Token\n");
		else
		{
			Bot->CommandRotation = (float)strtod(Temp,NULL);
			Bot->CommandActions = KEY_ACTION_NONE;
			Bot->CommandImpulse = 0x0;
			Bot->CommandLateralSpeed = 0x0; // speed side to side
			Bot->CommandVerticalSpeed = 0x0; // ???

			EventTable->SendMessage(edServer, oeSendRuntimePacket, (void *)Bot);
		}

	}
	else if (strcmp(Temp, "DELAY")==0)
	{
		Print("Processing Delay Command\n");
		Temp = strtok(NULL,"");
		if (Temp == NULL)
			Print("NULL Token\n");
		else
		{
			Delay = (float)strtod(Temp,NULL);
			Print("New Delay %f\n", Delay);
		}
	}
	else if (strcmp(Temp, "MSG")==0)
	{
		Print("Processing Msg Command\n");
		Temp=strtok(NULL,"");
		if (Temp == NULL)
			Print("NULL Token\n");
		else
		{
			if (strcmp(Temp, "ON")==0)
				Msg = True;
			else if (strcmp(Temp, "OFF")==0)
				Msg = False;
			else
				Print("Unknown Value\n");
		}
	}
	else if (strcmp(Temp, "MOVE")==0)
	{
		Print("Processing Move Command\n");
		Temp=strtok(NULL,",");

		if (Temp == NULL)
			Print("NULL Token\n");
		else
		{
			Bot->CommandRotation = (float)strtod(Temp,NULL);
			Temp = strtok(NULL,"");
			if (Temp == NULL)
				Print("NULL Token\n");
			else
				Bot->CommandInlineSpeed = (short)strtol(Temp,NULL,16);

		}

		Bot->CommandActions = KEY_ACTION_NONE;
		Bot->CommandImpulse = 0x0;
		Bot->CommandLateralSpeed = 0x0; // speed side to side
		Bot->CommandVerticalSpeed = 0x0; // ???

		EventTable->SendMessage(edServer, oeSendRuntimePacket, (void *)Bot);
	}
	else if (strcmp(Temp, "STOP")==0)
	{
		Temp = strtok(NULL,"");
		Bot->CommandInlineSpeed = 0x0;
		Bot->CommandActions = KEY_ACTION_NONE;
		Bot->CommandImpulse = 0x0;
		Bot->CommandLateralSpeed = 0x0; // speed side to side
		Bot->CommandVerticalSpeed = 0x0; // ???

		EventTable->SendMessage(edServer, oeSendRuntimePacket, (void *)Bot);
			
	}
	else if (strcmp(Temp,"SHOWPOS")==0)
	{
		Print("Current Position -   (%f, %f, %f)\n", Bot->Location[0], Bot->Location[1], Bot->Location[2] );
		Print("Current Rotation - %f %f %f\n", Bot->Angle[0], Bot->Angle[1], Bot->Angle[2]);
	}
	else if (strcmp(Temp,"HELP")==0)
	{
		Print("Speed=Hex Value    - Changes speed at which AI moves bot\n");
		Print("Angle=float        - Changes Bots current rotational angle in degrees\n");
		Print("Delay=float        - Changes how often AI checks bot's progress\n");
		Print("Msg=On/Off         - Turns AI Messages On and Off\n");
		Print("Move=Angle, Speed  - Moves bot along the vector specified\n");
		Print("Stop               - Stops motion of bot\n");
		Print("ShowPos            - Displays Bot's current position and Rotational angle\n");
	}
	else
		Print("Unknown Command\n");
}


//Processes Message Events from other objects
void AIObj::MessageEvent(ObjectEvent Event, void *Data) {

	switch(Event) {
	case oeAIOff: // Turn off AI
		Print("Disabled\n");
		Enabled = False;
		break;
	case oeAIOn: // Turn on AI
		Print("Enabled\n");
		Enabled = True;
		break;
	case oeImpulseReceived: // Impulse command from quake proxy client
		Print("Impulse Received\n");
		ProcessImpulse();
		break;
	case oeAICommand:	//Process command from quakebot console
		Print("Raw Command Sent\n");
		ProcessCommand((char*)Data);
        break;
    case oeProxyPrint:
    case oeSendRaw:
    case oeSendSay:
    case oeSendRuntimePacket:
    case oeServerDisconnect:
    case oeRespawn:
    case oeServerConnect:
    case oeServerOffline:
    case oeServerOnline:
    case oeConsolePrint:
    case oeConsoleParse:
		break;
	}	

}
