//*******************************************
//
//			SocketObj.h
//
//			V1.0 beta
//
//			by: Jim Rorie
//			Email: jfrorie@uncc.edu
//
// This is a Socket object.  Its keeps track of I/O, closing, opening, etc.
// It is general purpose and should work for anything
//
//*******************************************

#ifndef SOCKETOBJ_H
#define SOCKETOBJ_H

#include <stdio.h>
#include <stdlib.h>
#include "QuakeBot.h"

#ifdef __unix__
	#include <string.h>
	#include <unistd.h>
	#include <netdb.h>
	#include <sys/time.h>
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	typedef int SOCKET;
	typedef sockaddr *LPSOCKADDR;
	typedef sockaddr_in SOCKADDR_IN;
	#define INVALID_SOCKET -1
	#define FAR
#else
	#include <winsock.h>
	#include <stdio.h>
#endif


#define HOSTNAME_LEN 30

#define BUFLEN 1200

#define MaxOutputData 1032


class SocketObj {

	SOCKADDR_IN RecvAddress; // Last Receive Address
public:

	void ServerListen();
	void SetDestinationToPacketSource();
	void SetDestination(char *);

	void SetTimeoutHandler(long, void (*Handler)(void));

	char InputBuffer[BUFLEN]; // Input packet buffer
	char OutputBuffer[BUFLEN]; // Output packet buffer
	char RemoteIP[18];			// Remote System's IP
	int RemotePort;				// its port

	char LocalIP[18];			// My IP
	int LocalPort;				// MY local Port

	void SendPacket(char *Data, int DataLen);  // Sends a raw packet
	int GetPacket();							// Get s raw packet
	int IsData(timeval);

	friend class PacketObj;			// Lets my packetobj talk

	void ResetSocket();
	
	SocketObj() {
		LocalPort = 0;
		RemotePort = 0;
#ifndef __unix__
		CheckVersion();				// Check winsock version
#endif
		MakeSocket();				// create a socket
	}
	
	void Init(char *HostName = NULL){
		InitSocket(HostName); // does a bind
		SetTimeoutHandler(3000, DefaultTimeoutHandler);
	}

	SOCKET GetSocket(){
		return SocketID;
	}
	
	~SocketObj() {					// shut down

		shutdown(SocketID, 2);
#ifndef __unix__
		closesocket(SocketID);
  		WSACleanup();
#else
		close(SocketID);
#endif

	}


private:

	SOCKET SocketID;					// System socket for object
										// All functions reference this	long RecvTimeout;
	timeval RecvTimeout;
#ifndef __unix__
	void CheckVersion();		
#endif
	void MakeSocket();
#ifndef __unix__
	void EvaluateStartupError(int);		// error routines
#endif
	void EvaluateError();
	void InitSocket(char *Hostname);
	void InitSocket() {
		InitSocket(NULL);
	}

	void (*TimeoutHandler) (void);				//  Routine that handles 
												// Receive timeouts

	static void DefaultTimeoutHandler(void) {

		printf("Socket: Receive timed out!!!!\n");

	}
	
};


#endif
