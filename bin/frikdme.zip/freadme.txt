Title    : FrikBot in Deathmatch Essentials
Filename : frikdme.zip
Version  : 0.09
Date     : 2-26-00
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Alan Kivlin for his rankings.qc and step movement
Frog for releasing the Frogbot code and giving me a good goal
to shoot for.

Additional thanks to Wazat, Asdf and MaNiAc who helped immensly with suggestions, code snipplets and ideas.

Thanks to the whole team that is RAzOR entertainment for creating a seemingly very popular mod.

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : no
progs.dat     : yes


Description of the Modification
-------------------------------

Deathmatch Essentials was suggested numerous times by many people as a potential source for ideas for the Frogbot. Just to show off (heh) I made FrikBot play the original (it is basically just regular deathmatch, so it wasn't that big a deal, 5 mins is all it took), unfortunately though, I didn't put in any AI to make use of the crouch feature.. If you want to do that, you can, just add FrikBot to the source folder and follow the bot.qc instructions, add the crouch AI and you're all set. Even without crouch though, it's still pretty fun. The visible weapons and footsteps are really kinda neat...
                          
How to Install the Modification
-------------------------------

As Deathmatch essentials is very difficult to locate, the original package is include with this file, place all files in this archive into a subfolder of your quake directory, run the game with the command line "quake -game dme -listen 8"


Impulses
===========
Note: As the original DME uses impulses 100 - 102 for crouching, I moved the FrikBot impulses down to the funky groovy seventies.
 
70 Add a bot or add a bot to your team in a team game
71 Add a bot to an enemy team
72 Remove a bot
73 Cycle through the view of all players in the game (clients & bots)
74 Dump waypoint information

Technical Details
-----------------

Known Bugs
==========
* Bots do not make use of the crouch feature

For general Frikbot bugs, please finger frika-c@mdqnet.net or visit the FrikBot homepage.


Availability
------------

This modification is available from the following places:

FrikBot homepage at http://www.mdqnet.net/frikbot/


