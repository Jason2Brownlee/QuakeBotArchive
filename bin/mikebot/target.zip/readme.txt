+---------------------------------------------
|  TARGET.MDL                             ---
+------------------------------------------

	This is a new quake model made by Mike Warren for
mikeBot version 0.30 and above. mikeBot is a client-side quake-bot
(NOT Quake-C) see:

	Http://www.planetquake.com/mikebot

for more information.

Unzip this model into the directory:

	C:\Quake\id1\progs\

before playing any mikeBot .DEMos from version 0.30 or above.

Also, if anyone can whip up a better model (well, shouldn't be hard ;) )
and would like to send it along to me at:

	mbwarren@acs.ucalgary.ca

I would be happy to include it instead (and give credit, of course).
Feel free to make it animated, too :)

Thanks to qME author for qME, with which I made the model.

	