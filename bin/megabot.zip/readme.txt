=================
| MegaBot v 0.1 |
=================

This is the first version of MegaBot. Please, if you find bugs post message on AI 
Cafe (http://www.planetquake.com/minion/) Msg Board.
MegaBot is based on Tutor Bot and tutorials posted at AI Cafe.

Here's the list of features:
- Bots support deathmatch, teamplay modes.
- Bots can swim.
- Bots can ride platforms.
- Bots support specific team colors.
- Bots support custom names.
- Bots support all weapons (including Axe).
- Bots support all maps.
- Bots can do rocket jumps.
- Bots can chase enemy, etc.
- Bots can jump to items and in combat mode.
- Bots can talk.
- Bots can talk to teammates.
- Bots have colored shirts and pants in GL mode.

Use this commands to add bots of specific color:
addwhite
addbrown
addbblue
addgreen
addred
addolive
addorange
addpeech
addpurple
addmajenta
addgrey 
addaqua
addyellow
addblue
addrandom

You can specify bot's name. Use this command : usename. Bot spawned after you typed
this command will have your name. Here's the example:

usename
name Kick_ass
addrandom
name your_previous_name

Now you can create a bot config file such as ones in Frogbot.

Author: Vic. E-mail: vic@captured.com.