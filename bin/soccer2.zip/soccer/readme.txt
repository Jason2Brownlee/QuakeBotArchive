========================================
	::Quake Soccer::
Author: Orion (rfalcetti@gmail.com)
Editors used: Quark, QCIDE, QME
Build time: 2 days, because I had to do all the tests, etc
========================================


Type of mod:
==========
QC files: yes
Models: yes
Sounds: yes
=========


Description of the Modification:
It's a soccer mod for Quake. But it's clean soccer. No weapons, you can't kill anyone, jumping is now re-implemented.
You enter the game on blue team by default. But you can change your team by typing 'impulse 150' at the console, and there you go.
The mod now comes with 2 maps, which were specially made to run this mod. I'll show you the name of the entities used in it below, if you want to make a map.


Entities:

info_ball_spot: There should be ONLY ONE in a map. Place it on the midfield. This entity is where the ball will be spawned when starting the map, or, when scoring a goal, or when kicking the ball out of bounds.

trigger_goal: The goal. When the ball touches that trigger, a team will score and the ball will teleport to the midfield.
MUST HAVE THESE FIELDS:
*team_no 1 or 2, 1 for blue and 2 for red team. NOTE: If the ball enters the team 1's goal, red will score; and vice-versa.
*real_origin: As triggers don't have an origin at all, and if you set an origin field your game will be bugged, set real_origin the same as the center of the trigger's polyhedron. Why? It's because of the bots, so ther will go for the correct goal, not the midfield.

trigger_out: Used to teleport the ball back to the midfield when kicked there. No additional fields needed, just set the proper size.

info_player_teamspawn: The team spawn spots.
MUST HAVE THIS FIELD:
team_no 1 or 2, if 1 blue players will spawn on there, if 2 red players will spawn on there.


Rules:

The objective is to kick the ball to the enemy team's goal. E.g: If you're on blue team, you should kick the ball to the red goal, DO NOT kick the ball to the blue goal, or you'll get a free score for the other team. :)
When someone kicks to the goal, an announcer voice will tell which team scored, and at your top left of your screen, the score will be displayed.
When you get close to the ball, the ball will be kicked in the direction you're facing. So if the ball is in your back, it won't go backwards, but will go forward.
The mod can be played with bots to offer offline play. They know how to score, so watch out.


Commands:

Impulse 100: Add a bot on blue team.
Impulse 101: Add a bot on red team.
Impulse 102: Add two bots on both teams.
Impulse 150: Change team.
Impulse 200: Toggle speed boost on or off (I recommend binding it to a key).

Changelog:

Re-implemented jumping: You can now jump, but higher than usual, and it takes out some stamina.
Stamina system: At the bottom center of your screen, the amount of stamina you have is displayed. Jumping takes out 20 stamina at one and the speed boost takes about 15 stamina points per second. Maximum stamina is 100. It slightly regenerates if you're not jumping or using the speed boost.
Speed boost: Makes you run faster. Press the key you bound to impulse 200 and you'll run faster, and consuming your stamina. If your stamina goes to zero, the boost automatically turns off, and then when you get some stamina, you can turn it on again by presing that key.
Goalkeepers: Bots which are spawned in front of the goal when the map is loaded, they try to keep the ball far away from it. It's now a bit harder to score a goal, but not impossible.


Have fun!





