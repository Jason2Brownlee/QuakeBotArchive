Ultimate Deathmatch
(c)2002-2004  Alex Shadowalker
Version 2.00,   Release Date:  April 21, 2004

Designed and written by alex_&^shado&^walker&^@&^yah&^oo.com
  Remove &^ to use
Do not post this email anywhere without my permission!
Design time:  Since 9/01/01
Beta testing: myself

Looking for mappers, graphic designers, and model makers. Will give you credit in exchange for your work. Looking for copies of changes for versions 1.4 of UD and earlier. If you have, email me.

  http://www.planetquake.com/ud/   development info and patches

  It is acceptable to distribute this mod over the Internet and BBS systems for free. It is also not acceptable to charge for this mod in any way or charge for distribution of this mod. This includes CD-ROM/DVD/floppy disk collections of all types, including magazines. All files must be included and unaltered. It's copyright license is for free download only. UD may not be altered, modified, or decompiled by anyone but Alex Shadowalker. UDC and UD files must remain in the same zip.


   IMPORTANT NOTES: Map level designers assume shockwave=8 for rocket jumping. Shamblers are immune to explosions. Fiends are immune to plasma and fire. Soldiers and Enforcers are immune to energy grenades and plasma based attacks. Fiends cut right through rune shield. You should read the file on configuration before you start. Levels with no deathmatch spawnpoints like bnt and many others can be converted to deathmatch levels easily, even gmsp3!  Bots use both the skill and AIspeed cvar.

   If you, as a game author, want to use my ideas, such as the energy grenade. Email me and give me credit as I have for others. If you make a map specific to my mod, please tell me!

Install info:
   Requires winquake files and engine support for cvar_string and cvar_create. Delete old ultdet directory. Unzip all files into c:\quake\ultdet. Make sure you uncheck "use folder names". Then move the shortcuts into the c:\quake directory. Anything in () means it's my config keys file. If you want to use my game config file, rename "mykeys.cfg" to "config.cfg".  An autoexec.cfg is built into it, so don't use another. If you want to add a player skin file, you'll need a pak explorer. Put the "player.mdl" file into the progs directory. Make sure you set "numskins" in the cfg files to the correct number of skins. Also, i'v included some wallpaper for your desktop.


Changes version 2.00:
   Vengance Rune model changed. Renamed config var shotgundamage and lightningdamage. Weapon mode barbarian now allows you grab cells for rune shield. AIspeed cvar and voreball fine tuned. Rune shield is immune to voreballs. Recoil impulses deleted. Recoil cvars are now varible. Flamethrower recoil cvar added. Report of system vars formating cleaned up. Improved game and menu eye candy. Mapper/player values toggle removed from menu. Net performance enhanced for shotgun and gatling gun. Added "War of the Gods" config script.

Bug fixes:
   Start rune cvar conflict
   Map item_weapon
   Recoil conflict with firing weapon

Recommended levels:
   Scorn, Moonlite Assault, The Crawling Chaos, Oblivion, Could have been, Nastrond, GMSP3, and scorn.

Recommended episodes:
   Bridges and Towers(bnt, bnt2), Ikstart, The Insurrection, prodigy special edition, Coagula contest #1.

   For qblack, put pak0.pak into your UD directory(remove when done). For Beyond Belief, delete the progs.dat in the pak file. Then using a program like quark open the file "bbelief7.bsp" within the pak file. Find the monster_boss entry and add the attribute "spawnflags". For a killable boss, enter for a value: no gib= 1, gib= 3. Save and your done. Some files may require renaming "start.bsp" files to "xstart.bsp".


 
Version history:
----------------

Changes version 1.90:  release Date:  Feburary 4, 2004
   UD varible system overhauled, note changes in configuration and servercommands. Random damage cvar added. Make teleporter and create lightning storm now have spawnflag options. Botnames can now be altered. Recoil system and random damage controls added. Black mamba powerup added. Vengance and vore rune added. Rotate rpt values in menu changed, higher upper limit. Bots aren't affected by chaos and order rune interaction. Spectator mode now has noclip. Lock on weapons can't find invisible targets.

Changes version v1.80:  release Date: November 24, 2003
   Backpack processing improved. If you have unlimited ammo, recharge times for some weapons are longer. Catch fire chance and burn time varibles for flamethrower added. Brightfield effect added for rune shield. DSP's can't be deleted while invisible, no more removing them by mistake. Body limit in deathmatch varible added. Annoying enforcer  fire sound changed. Rules for invulerability and shield rune changed. Cloaked energy mine added. Monster body timeout varible added. Flares altered to general use map editing tool with UDC engine. "edit" command renamed to "editmode". Unlimited ammo doesn't work on mines. Best weapon improved. Control switches varible and super jumping rune added. Net performance increased by redesigning menu system. When you setup rune shield on a monster, you don't have to set the item bits. You can now set the ammo amount in the backpack a monster drops.

Changes in 1.70:  released July 16, 2003
   Rune shield damage reduction factor varible added. Track_Entity code overhalled. Weapon pickup fine tuned. Delete item function now includes three options: delete item off, delete next touched item, and delete items. Player rune limit varible added. Smarter pet friends, they will teleport away if they jump into lava or slime. Drop runes command added. Shockwave effects code overhauled. In SPQ, you are no longer immune to shockwave effects. Registered secret area tracker added. Tracking display improved. Wild magic rune and Flamethrower added. Full weapons mode now includes Flamethrower and Graphling Hook. Plasma cannon shot changed, looks really cool. Immunity rune powers altered. Energy grenade underwater sound added. SETV command added to UDC. Bot AI improved. Energy grenade damage table adjusted: slime 25-50, water 50-100, air 100-200. Energy grenade will lock on to any target in range. All list functions now include origins. Use UDC's setpos to go directly to items. "listrunes" command will list runes you currently carry. Report system varibles now includes varible codes. Monster boss start health adjusted. Lightning strikes are now random.
   Map spawn error "item fell out of level" improved for explosive boxes: no offset in Z adress, item named, item frozen in place where error occurred. "entity_flags" renamed to "rune_flags". If you place "mapname.cfg" in your maps directory, it can change varibles to your specific map. "weapon_flamethrower" and "item_storm" added.

Changes in 1.60:  released April 13, 2003
     Improved explosions. You can now select grenades for the attack button. Pet fiend summoning rune added. Tracker mode fine tuned. Lightning gun and plasma cannon position swapped. Bot AI improved. Varibles cfcc and cfcv merged into cfcg(configure cluster grenade). eleven control varibles added to normal weapons mode. If SPQ mode, menu defaults to "mapper values". If DM, menu defaults to "player values". Your energy grenades will not lock on to you in deathmatch. Note: My method of putting armor on monsters was wrong. It has been corrected in the UDmap file(hopefully). Impulse 10 and 12 functions swapped. "impulse 20" command replaced with god mode toggle. Fiends cut right through rune shield. Temporary commands:
"impulse 251": print origin, "impulse 252": set player position(temp1, gamecfg, savedgamecfg)
     Mapper functions added. Select gib or no gib chthon. Damage chthon with player weapons on or off. You can set chthon's health. Target aim leading flag for missiles and plasma cannon added to soldier. Added "random_rune", "random_health", "random_ammo", "random_weapon" map item. Map spawn error "item fell out of level" improved: no offset in Z adress, item named, item frozen in place where error occurred. "ent" command expanded, makes editing items in maps much easier. "impulse 252" gives you your origin(temporary command).

Changes in 1.50:
    Deleted skinup and skindown. Added support for "monster_spider" with bug fixes to the code. Improved Client Obituary processing. Drop in uni-directional and bi-directional teleporters with map support. Fine tuned cell gives on shield rune. Overhalled out of ammo code, fixing bugs. Added bsp ent output for deathmatch spawn points. Added graphling hook with map support. Energy Grenade will not lock onto team members in teamplay or coop. Added summon teammate and banish player/monster to teleport rune's powers. Mappers can now set individual gives for weapons, ammo boxes, health boxes, and shield rune. Players connected to a server can now change their own skins. Mappers can set health amounts for all monsters, except zombies. Renamed items to "weapon_plasma_cannon" and "item_scuba_gear". "UD.qrk" is now available as a Quark addon file, containing all UD entities.  Added varible spawnflags for passing data to items and falling damage multipler varible. Removed auto-aiming on rocket launcher and super nailgun in deathmatch. You can now select throw or eject down from grenade launcher. Crucified zombies now appear in deathmatch mode. Lightning bolt only visible to you added to tracking if your within your field of vision. Runes are no longer saved between SPQ episodes. You can now select the weapon of the grunt: shotgun, rocket launcher, plasma cannon. Shotgun damage level of grunt can be set. Runes can now be used on monsters(see elmdm5 on my website for the mega_grunt). Respawn times of individual items can be set for health, weapons, ammo, armor, and powerups. You can select between mapper values and player values in the menu. In mapper mode, if an item's respawn time hasn't been set, it will use your default values. You can now select between mapper values or use your own RPT's through the menu. Soldiers and Enforcers are now immune to energy grenades and plasma based attacks. Invisiblity improved, no more black dot. Invisibility rune added. "corporal.qc" support added.

Changes in 1.40:
  Weapon out of ammo processing altered. Shield rune link to invulnerability redesigned. Rune shield takes no damage from acid. Map support for "weapon_plasmacannon" and "item_rune". Added skins support for any player model skin pak. You can set the number of skins with the config variable "cfns". Change your teams skins with "skinup" and "skindown". Random enemy skins for teamplay off. Deathmatch and single player modes have different config files: "dm.cfg" and "sp.cfg". Map support for "monster_snakeman". "ent" command to print out for "qconsol.txt" UD specific items in bsp ents format. In SPQ, backpacks don't disappear in two minutes. Scuba Gear with map support added. Waypoints are now saved correctly in saved game files. Read the details in the udcomp package. Title screen on ten second timer. Mega add bots changed. Lightning strike max delay changed to 10 minutes. Lightning damage configure added. Cluster bomb, plasma grenade, and energy grenade fire without using the attack button. Current weapon will fire as normal after. More design flaws fixed. Ammo required on plasma mine lowered. Shield up/down more automatic.

