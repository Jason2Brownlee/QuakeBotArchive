================================================================
Title                   : FrikBot
Filename                : frkqw01.zip
Author                  : Frika C
Email Address           : frika-c@earthling.net
Description             : A simulated deathmatch opponent for QuakeWorld.
================================================================

* Play Information *

Single Player           : No
Cooperative             : No
Deathmatch              : Yes
Difficulty Settings     : No
New Sounds              : No
New Graphics            : No
New Monsters            : No
New Demos               : No
New Models              : No
QuakeC Patches          : Yes

* Construction *

Base                    : legion's Norse movement, Coffee's Tutor Bot and Alan Kivlin's rankings.qc
Editor(s) used          : ProQCC, Wordpad
Known Bugs              : Bots can cause major slow down on large
                          levels. Bots are very stupid and can't get to
                          most items they find. Bot's do not call the
                          ClientConnect(); function (they should, I
                          disabled it because sometimes players would
                          enter and have their ishuman flags set
                          incorrectly) However The function botConnect
                          in bot_rank.qc is equivalent.

Build Time              : forever and then some

Comments                : This bot takes a unique approach. Unlike all
                          other bots I've seen, FrikBot actually
                          pretends to be a player. When he fires his
                          weapon, it's the same function that the
                          player uses. It is all done through his
                          button flags. In other words, the bot fakes
                          all client functions, he looks like a Quake
                          client not only to the people in the game,
                          but also to the Quake C. So why did I make
                          him fake client behavior? Well with him using
                          all the player code, he automatically works
                          with hundreds of mods with a few short lines
                          of code added or changed. This bot will play
                          by the game rules of nearly every mod out
                          there. (though he doesn't always know the
                          rules)
                          
                          To spawn a bot type "impulse 100" on the
                          console. The server must be on a multiplayer
                          game to add a bot.


What to expect(but you might not get) in the next version.
---------------------
* Corrected Water Jumping, maybe
* Simplified weapon switching code, via self.impulse
* Better roaming
* Better handling of waypoints
* Item prioritizing
