#include "SocketObj.h"

// Create a socket.  Store socket handle in SocketID

void SocketObj::MakeSocket() {

	SocketID = socket ( PF_INET, SOCK_DGRAM, 0 );
	if(SocketID == INVALID_SOCKET) {
		printf("An error occured opening the socket\n");
		EvaluateError();
	}
	
}

void SocketObj::InitSocket() {

	// struct sockaddr {
	//	  u_short sa_family;     /* address family */
	//	  char    sa_data[14];   /* up to 14 bytes of direct address */
	// };

	// struct sockaddr_in {
	//	  short   sin_family;
	//	  u_short sin_port;
	//	  struct  in_addr sin_addr;
	//	  char    sin_zero[8];
	// };

	SOCKADDR_IN sin;

	struct hostent *HostEntry;

	int NameLength;

	char FAR LocalHost[HOSTNAME_LEN];
	
	// Get the local hostname
	if(gethostname ( LocalHost, HOSTNAME_LEN ) != 0) {
		printf("An error occured getting the local hostname\n");
		EvaluateError();
	}
	
	// Get the local IP
	if((HostEntry = gethostbyname ( LocalHost )) == NULL) {
		printf("An error occured getting the local host IP\n");
		EvaluateError();
	}

	// save the local IP
	strcpy(LocalIP, inet_ntoa(*(struct in_addr *)HostEntry->h_addr_list[0]));

	// bind the previous socket to a port on the host.
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;

	sin.sin_port = htons((u_short)LocalPort);

	if (bind(SocketID, (LPSOCKADDR)&sin, sizeof (sin)) != 0) {
		printf("bind() of Socket #%d failed\n", SocketID);
		EvaluateError();
	}
	// This gets the local port if I didn't care
	// where it bound, i.e. LocalPort was = 0

	NameLength = sizeof(sin);

	if(getsockname(SocketID, (LPSOCKADDR)&sin, &NameLength) != 0){
		printf("getsockname() of Socket #%d failed\n", SocketID);
		EvaluateError();
	}
	 
	LocalPort = ntohs(sin.sin_port);
}

//
//	Gets a packet from the Socket
//

void SocketObj::SetTimeoutHandler(long Timeout, void (*Handler)(void)) {

	RecvTimeout.tv_sec = Timeout/1000;  // convert timeout to timeval struct
	RecvTimeout.tv_usec = (Timeout - (RecvTimeout.tv_sec * 1000)) * 1000;

	TimeoutHandler = Handler; // Record Timout Routine


}

int SocketObj::IsData(timeval Timeout) {

	fd_set Input;

	FD_ZERO(&Input);
	FD_SET(SocketID, &Input);
	select(SocketID+1, &Input, NULL, NULL, &Timeout);
	if(FD_ISSET(SocketID, &Input))
		return 1;
	else
		return 0;

}

int SocketObj::GetPacket() {
		

	int DataLen, Received;
	if (IsData(RecvTimeout)) {

		DataLen = sizeof(SOCKADDR_IN);
		if( ((Received = recvfrom( SocketID, InputBuffer, BUFLEN, 0, (LPSOCKADDR)&RecvAddress, &DataLen) )) == -1 ) {
			printf("recvfrom() failed\n");
			EvaluateError();
		}

		return Received;
	} else {
		(*TimeoutHandler)();
		return -1;
	}
}


void SocketObj::CheckVersion() {  // Checks that winsock is ok and displays some stats

#ifndef __unix__
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;


	wVersionRequested = MAKEWORD( 1, 1 );

	err = WSAStartup( wVersionRequested, &wsaData );
	if ( err != 0 ) {
		/* Tell the user that we couldn't find a useable */
		/* winsock.dll.                                  */
		printf("Can't find winsock\n");

		EvaluateStartupError(err);
	}

	/* Confirm that the Windows Sockets DLL supports 1.1.*/
	/* Note that if the DLL supports versions greater    */
	/* than 1.1 in addition to 1.1, it will still return */
	/* 1.1 in wVersion since that is the version we      */
	/* requested.                                        */

	if ( LOBYTE( wsaData.wVersion ) != 1 ||
				HIBYTE( wsaData.wVersion ) != 1 ) {
		 /* Tell the user that we couldn't find a useable */
		 /* winsock.dll.                                  */
		printf("Your Protocal version is outdated. REPLACE IT!!!!\n");
		WSACleanup( );
		exit(-1);
	}
//	printf("Current Winsock Version is V%d.%d\n",
//		HIBYTE( wsaData.wVersion ), LOBYTE( wsaData.wVersion ));
//	printf("Socket Vendor: %s\n", wsaData.szDescription);
	
/*	if (wsaData.iMaxUdpDg == 0)
		printf("Unlimited Datagram Length\n");
	else
		printf("Max Datagram Length: %d\n", wsaData.iMaxUdpDg);

*/
	/* The Windows Sockets DLL is acceptable.  Proceed.  */
	/* Make sure that the version requested is >= 1.1.   */
	/* The low byte is the major version and the high    */
	/* byte is the minor version.                        */

	if ( LOBYTE( wVersionRequested ) < 1 ||
			( LOBYTE( wVersionRequested ) == 1 &&
				HIBYTE( wVersionRequested ) < 1 )) {
		printf("Your version of Winsock is ancient. REPLACE IT!!!!\n");
		WSACleanup( );
		exit(-1);
	}

	/* Since we only support 1.1, set both wVersion and  */
	/* wHighVersion to 1.1.                              */
#endif

}

// *****************************************
//
//		Sends a Raw Packet through socket
//
// *****************************************

void SocketObj::SendPacket(char *Data, int DataLen) {
	
	SOCKADDR_IN SendAddress;

#ifdef __unix__ 
	hostent *h;
#endif  

	SendAddress.sin_family = AF_INET;

#ifndef __unix__
 	SendAddress.sin_addr.s_addr = inet_addr(RemoteIP);
#else
	h = gethostbyname(RemoteIP);
	memcpy(&SendAddress.sin_addr.s_addr, h->h_addr, h->h_length);
#endif

	SendAddress.sin_port = htons((u_short)RemotePort);
	
	if( ( sendto( SocketID, Data, DataLen, 0, (LPSOCKADDR)&SendAddress, sizeof(SOCKADDR_IN)) ) == -1 ) {
		printf("sendto() failed\n");
		EvaluateError();
	}
}

void SocketObj::EvaluateError() {  // evaluate winsock errors

#ifndef __unix__
	
	int erno;

	erno = WSAGetLastError ();
	switch(erno) {
	case WSANOTINITIALISED:
			printf("WSANOTINITIALISED: A successful WSAStartup() must occur before using this API.\n");
			break;
	case WSAENETDOWN:
			printf("WSAENETDOWN: Network subsystem has failed.\n");
			break;
	case WSAEADDRINUSE:
			printf("WSAEADDRINUSE: The specified address is already in use.\n");
			break;
	case WSAEINTR:
			printf("WSAEINTR: The (blocking) call was canceled via WSACancelBlockingCall()\n");
			break;
	case WSAEINPROGRESS:
			printf("WSAEINPROGRESS: A blocking Windows Sockets call is in progress.\n");
			break;
	case WSAEADDRNOTAVAIL:
			printf("WSAEADDRNOTAVAIL: The specified address is not available from the local machine.\n");
			break;
	case WSAEAFNOSUPPORT:
			printf("WSAEAFNOSUPPORT: Addresses in the specified family cannot be used with this socket.\n");
			break;
	case WSAECONNREFUSED:
			printf("WSAECONNREFUSED: The attempt to connect was forcefully rejected.\n");
			break;
//	case WSAEDESTADDREQ:
//			printf("A destination address is required.\n");
//			break;
	case WSAEFAULT:
			printf("WSAEFAULT: The namelen argument is incorrect.\n");
			break;
	case WSAEINVAL:
			printf("WSAEINVAL: The socket is already bound to an address.\n");
			break;
	case WSAEISCONN:
			printf("WSAEISCONN: The socket is already connected.\n");
			break;
	case WSAEMFILE:
			printf("WSAEMFILE: No more file descriptors are available.\n");
			break;
	case WSAENETUNREACH:
			printf("WSAENETUNREACH: The network can't be reached from this host at this time.\n");
			break;
	case WSAENOBUFS:
			printf("WSAENOBUFS: No buffer space is available.  The socket cannot be connected.\n");
			break;
	case WSAENOTSOCK:
			printf("WSAENOTSOCK: The descriptor is not a socket.\n");
			break;
	case WSAETIMEDOUT:
			printf("WSAETIMEDOUT: Attempt to connect timed out without establishing a connection\n");
			break;
	case WSAEWOULDBLOCK:
			printf("WSAEWOULDBLOCK: The socket is marked as non-blocking and the connection cannot be completed manually.\n");
			break;

	case WSAEPROTONOSUPPORT:
			printf("WSAEPROTONOSUPPORT: The specified protocol is not supported.\n");
			break;
	case WSAEPROTOTYPE:
			printf("WSAEPROTOTYPE: The specified protocol is the wrong type for this socket.\n");
			break;
	case WSAESOCKTNOSUPPORT:
			printf("WSAESOCKTNOSUPPORT: The specified socket type is not supported in this address family.\n");
			break;
	case WSAEMSGSIZE:
			printf("WSAEMSGSIZE: The message was too large to fit int he buffer provided and was truncated\n");
			break;
	default:
			printf("No Error is defined for this exception (%d)\n",erno );
	}

#endif
	
	exit(-1);
}

void SocketObj::EvaluateStartupError(int erno) {

#ifndef __unix__

	switch(erno) {
	case WSASYSNOTREADY:
			printf("Indicates that the underlying network subsystem is not ready for network communication.\n");
			break;
	case WSAVERNOTSUPPORTED:
			printf("The version of Windows Sockets API support requested is not provided by this particular Windows Sockets implementation.\n");
			break;
	case WSAEINVAL:
			printf("The Windows Sockets version specified by the application is not supported by this DLL.\n");
			break;
	}

#endif

	exit(-1);
}

// ********************************************
// *
// * Closes socket and reopens for new session
// *
// ********************************************

void SocketObj::ResetSocket() {

	//	shutdown(SocketID, 2);
#ifndef __unix__
	closesocket(SocketID);
#else
	close(SocketID);
#endif
	MakeSocket();
}

// ********************************************
// *
// * Nice name, eh?  Sets the destination for
// * subsequent packet to the last received
// * packet.  mainly for server applications
// *
// ********************************************

void SocketObj::ServerListen() {

		listen(SocketID, 5);
}

void SocketObj::SetDestinationToPacketSource() {

	strcpy(RemoteIP, inet_ntoa(RecvAddress.sin_addr));
	RemotePort = ntohs(RecvAddress.sin_port);	

}
