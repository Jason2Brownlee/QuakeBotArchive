#ifndef ALIASOBJ_H
#define ALIASOBJ_H

#include <stdio.h>
#include "RuleObj.h"

class AliasObj {

private:

	RuleObj *FirstRule;

public:

	AliasObj(){
		FirstRule = NULL;
	}

	~AliasObj(){
		RuleObj *CurrentRule, *NextRule;
		
		CurrentRule = FirstRule;
		while(CurrentRule != NULL){
			NextRule = CurrentRule->NextRule; // Save next before delete
			delete CurrentRule;
			CurrentRule = NextRule;
		}
	}

	void Insert(char *Variable, char *Value) {

		FirstRule = new RuleObj(FirstRule); // Create new rule

		FirstRule->Assign(Variable, Value); // Store the values
		
	}

	RuleObj *GetFirstRule() {
		return FirstRule;
	}

	char *Find(char *VarName) {

		RuleObj *CurrentRule;

		CurrentRule = FirstRule;

		while(CurrentRule != NULL){
			if(stricmp(CurrentRule->Variable, VarName) == 0)
				return CurrentRule->Value;

			CurrentRule = CurrentRule->NextRule;
		}

		return NULL;
	}

};

#endif
