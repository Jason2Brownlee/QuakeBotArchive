#ifndef AIOBJ_H
#define AIOBJ_H

#include <stdio.h>


#include "QuakeBot.h"
#include "DataObj.h"
#include "NavObj.h"
#include "EventTableObj.h"

const unsigned char AI_MODE_IDLE = 0;
const unsigned char AI_MODE_TARGET = 1;
const unsigned char AI_MODE_ATTACK = 2;
const unsigned char AI_MODE_MAP = 3;
const unsigned char AI_MODE_RETRACE = 4;
const unsigned char AI_MODE_DEAD = 5;
const unsigned char AI_MODE_EVADE = 6;
const unsigned char AI_MODE_STALLED = 7;
const unsigned char AI_MODE_RESPAWNED = 8;
const unsigned char AI_MODE_MOVING = 9;
const unsigned char AI_MODE_REACHED = 10;

const unsigned char MAX_STRAFECOUNT = 20;

//class AIObj : virtual public EventHandlerObj {
class AIObj : virtual public EventHandlerObj , NavObj{
private:

	int Count, AIMode, OldAIMode;
	int Traveling, StartUp;
	int OldFrame, Health, OldWeaponCount, RespawnMode, OldHealth;

	Boolean Enabled; // AI on.off switch
	
	PlayerObj *Bot;
	EntityObj *BotEntity;

	GameCoord BotCoord, StartCoord, EndCoord;
	
	int AttackPlayer(int);
	void Chatter(int);
	void DisplayMode(int);
	void ProcessImpulse();
	void ProcessCommand(char *);

	EventTableObj *EventTable;
	DataObj *Data;

public:

	AIObj(EventTableObj *Event, DataObj *ServerData): NavObj(ServerData){

		Count = 0;
		AIMode = AI_MODE_IDLE;
		OldAIMode = -1;
		Traveling = 0;
		StartUp = 0;
		OldFrame = 0;
		OldWeaponCount = 0;
		RespawnMode = 0;
		OldHealth = 0;
		EventTable = Event;
		OwnerID = edAI;
		Enabled = False;
		Data = ServerData;

		// Register the AI Callback
		EventTable->RegisterCallback((EventHandlerObj *)this, (void *)NULL, etCycleEvent);
		EventTable->RegisterCallback((EventHandlerObj *)this, (void *)NULL, etMessageEvent);

	}
	// Register Callbacks

	virtual void CycleEvent(void *);  // AI method
	
	// Message event
	// For turning AI on and off and other stuff
	virtual void MessageEvent(ObjectEvent Event, void *Data); 

};

#endif
