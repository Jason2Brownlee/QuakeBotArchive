#include "ClientObj.h"

// ***********************************
//
// Establishes a connection to server.
//
// ***********************************

int ClientObj::ConnectClient() {


	int NewPort, DataLen = 12;

	unsigned char Response;
	// Build the packet.
	ClientPacket.Reset();

	ClientPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ClientPacket.SaveChar(COMMAND_CONNECT);
	ClientPacket.SaveString("QUAKE");
	ClientPacket.SaveChar((char) 0x03);
	ClientPacket.SendMessage();
	
	EventTable->Print("Connecting\n");
	do {

		DataLen = ClientPacket.GetMessage();
		Response = ClientPacket.ReadChar();

	} while(Response != CCREP_ACCEPT && Response != CCREP_REJECT);

	//struct ServerConnect Response {
    //    struct Header;                        // { 0x80, 0x00, 0x00, 0x09 }
    //    char OP_Code;							// 0x81 This is CCREP_ACCEPT 
    //    int Port								// This is your port assigned
    //											// by the server
    //    char Unknown[ 2] = {0x00, 0x00 };		// The packet header shows these two byte
                                                // to be valid data, I dunno what, tho.
	//};

	// if connection is successfull, server will return a new port for
	// init and runtime.  This takes care of that.

	if(Response == CCREP_ACCEPT){ //  Accepts!!!!
		time(&ClientStartTime); // Record start of game
		NewPort = ClientPacket.ReadShort();
		ClientPacket.Socket.RemotePort = NewPort;
		return NewPort;

	} else {

		EventTable->Print("Connection Rejected: %s\n", ClientPacket.ReadString());
		return -1;

	}

}

//
// This function queries the server for its name IP, etc.
//

int ClientObj::QueryClient() {

	int DataLen, Pass;

	ClientPacket.Reset();

	ClientPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ClientPacket.SaveChar(COMMAND_QUERY);
	ClientPacket.SaveString("QUAKEBOT");
	ClientPacket.SaveChar((char) 0x03);
	
	unsigned char Temp;

	do {
	
		ClientPacket.SendMessage();
		Pass = 0;
		do {
			DataLen = ClientPacket.GetMessage();
			Pass++;
			if(Pass >= 5) 
				return 0;

		} while(DataLen <= 0);

		Temp = ClientPacket.ReadChar();

	} while(Temp != (unsigned char) 0x83);

	// printf out various specs

	IPString = strdup(ClientPacket.ReadString());

	ClientName = strdup(ClientPacket.ReadString());

	EventTable->Print("Address: %s, Name: %s, Map: %s\n", IPString, ClientName);

	return 1;

}


void ClientObj::SendCommand(char *Message) {
	
	ClientPacket.Reset();	
	ClientPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ClientPacket.SaveChar(0x04); 
	ClientPacket.SaveString(Message); 
	ClientPacket.SendMessage();

	#ifdef DEBUG	
		EventTable->Print("Message Sent\n");
	#endif

}

//
// Logs off from Quake server
//

void ClientObj::SendGoodbye() {
	
	ClientPacket.Reset();	
	ClientPacket.SetHeader(MESSAGE_TYPE_CLIENT);

	ClientPacket.SaveChar(0x02); 

	ClientPacket.SendMessage();

	#ifdef DEBUG	
		EventTable->Print("Logoff completed\n");
	#endif

}

void ClientObj::DecodePacket() {

	int PacketType = ClientPacket.GetInputHeader();

	switch(PacketType) {
	case MESSAGE_TYPE_CONTROL:
		//		EventTable->Print("Not Decoded: Control Received\n");
		break;
	case MESSAGE_TYPE_CLIENT:
		//		EventTable->Print("Not Decoded: Control Received\n");
		DecodeClientPacket();
		break;
	case MESSAGE_TYPE_ACK:
//		EventTable->Print("Not Decoded: Ack Received\n");
		break;
	default:
		DecodeClientPacket();
	}

}

//**************************************
//
//  This routine parses client messages.
//
//**************************************

void ClientObj::DecodeClientPacket() {

//	float TempFloatX, TempFloatY, TempFloatZ;

	while(!ClientPacket.End()){

		unsigned char IDByte = ClientPacket.ReadChar();

		switch(IDByte) {
		case 0x00:
			BombOut("Something Died in Here. Bad Data. Go Away.");
			break;
		case 0x01:
#ifdef DECODE
			EventTable->Print("Command: NOOP\n");

#endif
			break;
		case 0x02: //  Logoff

#ifdef DECODE
			EventTable->Print("Client Disconnected\n");
#endif
			break;

		default:
			break;
		}
#ifdef DEBUG
		EventTable->Print("New offset: %lx\n", ClientPacket.Offset);
#endif
	}
}

//*************************
//
//  Debug Exit Routine.
//
//*************************


void ClientObj::BombOut(char *String){
	EventTable->Print("BOOM!: %s\n", String);
	SendGoodbye();
	exit(2);	
}






//***************************************************************
//
//  Frees up other BS
//
//***************************************************************

void ClientObj::FreeMisc() {

//	free(IPString);
//	free(ServerName);
//	free(MapName);
}




void ClientObj::Logon() {

	EventTable->Print("Connecting to Server\n");
	if((ClientPacket.Socket.RemotePort = ConnectClient()) == -1) {
		EventTable->Print("Client Connect Failed\n");
		exit(-1);
	}

}

ClientObj::ClientObj(EventTableObj *Event, char *IPString, int InitPort){		

//	ClientTimeStamp = (float)0.0;
	EventTable = Event;
	strcpy(ClientPacket.Socket.RemoteIP, IPString);

	ClientPacket.Socket.RemotePort = InitPort;
	ClientPacket.Socket.Init();


//	Console = UserConsole;

	EventTable->Print("Performing Query on %s:%d\n", IPString, InitPort);

	ClientPacket.Socket.SetTimeoutHandler(3000, ClientTimeoutHandler);

	if(QueryClient()) {

		Initialized = 1;
	
	} else {
		EventTable->Print("Server Query FAILED!!!!\n");
		Initialized = 0;
	}


}