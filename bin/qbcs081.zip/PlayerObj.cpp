#include "PlayerObj.h"

//************************************
//
// Check to see if player is dead by looking at model frames
//
//************************************

unsigned char PlayerObj::Dead() {

	if((this->Frame < 48 || this->Frame >= 103) && this->Frame != 0)
		return 0; 
	else
		return 1;
}


//************************************
//
// Sets up command structure for &this player to aim at Target
//
//************************************

float PlayerObj::Aim(PlayerObj *Target) {

	return Aim(Target->Location[0], Target->Location[1], Target->Location[2]);

}

//************************************
//
// Return distance to player
//
//************************************

float PlayerObj::Distance(PlayerObj *Target) {

	return ((EntityObj *)this)->Distance((EntityObj *)Target);

}


//************************************
//
// Sets up command structure for &this player to aim at Target
//
//************************************

float PlayerObj::Aim(float X, float Y, float Z) {

	float XOffset, YOffset, ZOffset, XYHyp, XYZHyp, RotationRadian;
	float RotationAngle, InclinationRadian, InclinationAngle;

	XOffset = X - Location[0];
	YOffset = Y - Location[1];
	ZOffset = Z - Location[2];


	XYHyp = (float) sqrt(pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));

	XYZHyp = (float) sqrt(pow(ZOffset, (float)2.0) + pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));

	RotationRadian = (float) asin(YOffset/XYHyp);

	RotationAngle = (float) (RotationRadian / (3.14/2.0)) * 90;

	InclinationRadian = (float) -asin(ZOffset/XYZHyp);

	InclinationAngle = (float) (InclinationRadian / (3.14/2.0)) * 90;

	if(XOffset < 0)
		RotationAngle = 180 - RotationAngle;

	if(RotationAngle < 0)
		RotationAngle += 360;

	CommandRotation = RotationAngle;
	CommandViewAngle = InclinationAngle;
	return XYZHyp;

}

//************************************
//
// Sets up command structure for &this player to aim at Target
//
//************************************

float PlayerObj::Aim(GameCoord Coord) {

	return Aim(Coord.X, Coord.Y, Coord.Z);

}


/*float PlayerObj::Distance(PlayerObj *Target) {

	return Distance(Target->Location[0], Target->Location[1], Target->Location[2]);

}
*/

void PlayerObj::SelectBestWeapon(){  // Select Best Weapon

	if((Items & IT_LIGHTNING) && (AmmoCells > 0)) // Got lightning gun and cells
		CommandImpulse = SELECT_WEAPON_LIGHTNING;
	else if((Items & IT_ROCKET_LAUNCHER) && (AmmoRockets > 0))  // Got Rocket and Rockets
		CommandImpulse = SELECT_WEAPON_ROCKET;
	else if((Items & IT_GRENADE_LAUNCHER) && (AmmoRockets > 0))  // Got Grenade and Rockets
		CommandImpulse = SELECT_WEAPON_GRENADE;
	else if((Items & IT_SUPER_NAILGUN) && (AmmoNails > 0))  // Got super nailgun and nails
		CommandImpulse = SELECT_WEAPON_SUPER_NAILGUN;
	else if((Items & IT_NAILGUN) && (AmmoNails > 0))  // Got nailgun and nails
		CommandImpulse = SELECT_WEAPON_NAILGUN;
	else if((Items & IT_SUPER_SHOTGUN) && (AmmoShells > 0))  // Got super shotgun and shells
		CommandImpulse = SELECT_WEAPON_SUPER_SHOTGUN;
	else if((Items & IT_SHOTGUN) && (AmmoShells > 0))  // Got shotgun and shells
		CommandImpulse = SELECT_WEAPON_SHOTGUN;
	else if(Items & IT_AXE) // Use da' AXE
		CommandImpulse = SELECT_WEAPON_AXE;
	else
		CommandImpulse = SELECT_WEAPON_NONE;

}

//*****************************************
//
//	Pick a weapon that wont kill you!!!
//	This is subjective since I can select the thunderbolt also.
//
//*****************************************
void PlayerObj::SelectSafeWeapon(){ 


	if((Items & IT_LIGHTNING) && (AmmoCells > 0))  // Got lightning gun and cells
		CommandImpulse = SELECT_WEAPON_LIGHTNING;
	else if((Items & IT_SUPER_NAILGUN) && (AmmoNails > 0))  // Got super nailgun and nails
		CommandImpulse = SELECT_WEAPON_SUPER_NAILGUN;
	else if((Items & IT_NAILGUN) && (AmmoNails > 0))  // Got nailgun and nails
		CommandImpulse = SELECT_WEAPON_NAILGUN;
	else if((Items & IT_SUPER_SHOTGUN) && (AmmoShells > 0))  // Got super shotgun and shells
		CommandImpulse = SELECT_WEAPON_SUPER_SHOTGUN;
	else if((Items & IT_SHOTGUN) && (AmmoShells > 0))  // Got shotgun and shells
		CommandImpulse = SELECT_WEAPON_SHOTGUN;
	else if(Items & IT_AXE) // Use da' AXE
		CommandImpulse = SELECT_WEAPON_AXE;
	else
		CommandImpulse = SELECT_WEAPON_NONE;  // This actually does occur
											// For servers with observers
}

//************************************
//
// Sets up command structure for &this player to aim at Target
//
//************************************

void PlayerObj::Reset() {


	for(int i = 0; i < 3; i++)
		ClientAngle[i] = (float)0.0;

	AmmoShells = 0;
	AmmoNails = 0;
	AmmoRockets = 0;
	AmmoCells = 0;

	ArmorValue = 0;
	Health = 0;
	Items = 0x0000;
	Dormant = 1;

}

void PlayerObj::SetName(char *Source){

	if(Name != NULL)
		free(Name);

	Name = strdup(Source);
}


	