//*************************************************************************
//
//			QuakeBot C/S (c)
//
//			by: Jim Rorie, John Simmerman
//			Email: jfrorie@uncc.edu
//
//			You may modify or distribute this code under
//			the following conditions:
//
//			1) This comment text must be included and may not 
//			be modified
//
//			2) All derivative works must display the following
//			in their initialization screen:
//
//			"Based on QuakeBot C/S Function Core"
//			or an appropriate variation thereof
//
//			Other than that, Have a ball!!!!!
//
//*************************************************************************


//*************************************************************************
//
//  Unix mods graciously supplied by Joel Jacobson
//
//*************************************************************************

#include <stdio.h>
#include <math.h>

#ifndef __unix__
 #include <conio.h>
 #include <process.h>
#endif


#include <ctype.h>

#include "QuakeBot.h"
#include "ServerObj.h"
#include "ConsoleObj.h"
#include "EventTableObj.h"
#include "ProxyServerObj.h"
#include "AIObj.h"



char VERSION[] = "V0.81";

//#define DEBUG 1
//#define DECODE 1

//#define VERBOSE


// ***********************************************
//
//			arg1 = IP Address of server
//			[arg2] = Bot Name,  Defaults to "QuakeBot"
//
// ***********************************************


int main(int argc, char **argv) {

	int ReturnVal;

	char Buffer[0x7f];

//	_CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_DEBUG);

	// This sturct handles IP supplied at the prompt
//	Address PromptAddress;
	Boolean ProxyActive;

	DataObj Data;

	// This object takes care of all communication
	// between objects
	EventTableObj EventTable;

	//  This controls I/O with the QuakeServer
	ServerObj QuakeServer(&EventTable, &Data);
	
	//  This be the smarts...
	AIObj Brains(&EventTable, &Data);
	
	// This interacts with the user
	ConsoleObj Console(&EventTable, &Data);
	
	ProxyServerObj ProxyServer(&EventTable, &Data, 26000);
	
	// Set Name
	Data.SetBotName("QuakeBot");
	
	ProxyActive = True;
	strcpy(Buffer, "");
	int i = 1;
	while(i < argc){
	
		if(*argv[i] == '+' || *argv[i] == '-') {
			strcpy(Buffer, argv[i]);
			i++;
			while(i < argc && !(*argv[i] == '+' || *argv[i] == '-')){
				strcat(Buffer, " ");
				strcat(Buffer, argv[i]);
				i++;
			}

//			EventTable.Print("Argument: %s\n", Buffer);
			
			if(Buffer[0] == '+')
				EventTable.SendMessage(edConsole, oeConsoleParse, (void *)&Buffer[1]);	
			else {
				if(stricmp(Buffer, "-noproxy") == 0) // no proxy argument
					ProxyActive = False;
			}

		} else  {
			EventTable.Print("Invalid Argument\n");
			i++;
		}

	}

	if(ProxyActive)
		ProxyServer.InitServerPort();

/*	if(argc >= 2) {

		if(stricmp(argv[1], "/?") == 0){
			EventTable.Print("\nusage: Quakebot <IPADDRESS> [<Bot Name>]\n");
			EventTable.Print("\nIPADDRESS: Address of Quake Server\n");
			EventTable.Print("Bot Name: Player Names\n");
			exit(0);
		} else {

			//  Set the server address and sees if it can connect
			PromptAddress.IPAddress = argv[1];
			PromptAddress.Port = 26000;
			EventTable.SendMessage(edServer, oeServerConnect, 
				(void *)&PromptAddress);
		}
	}
*/	
	// This loop continues until an object calls EventTable->Exit();
	// GOD, this works so much better!!!!!!!
	ReturnVal = EventTable.EventLoop();  
#ifndef __unix__
	_CrtCheckMemory();
#endif

	return ReturnVal;
}

