#include "EntityObj.h"

void EntityObj::SaveOldValues() {

	int i;
	
	for(i = 0; i < 3; i++){
		OldAngle[i] = Angle[i];
		OldLocation[i] = Location[i];
		OldVelocity[i] = Velocity[i];
	}
	
	OldModelIndex = ModelIndex;
	OldFrame = Frame;
	OldColorMap = ColorMap;
	OldSkin = Skin;
	OldAttackState = AttackState;
}

float EntityObj::Distance(EntityObj *Target) {

	float XOffset, YOffset, ZOffset;

	if(Target == NULL)
		return FLT_MAX;
	
	return Distance(Target->Location[0], Target->Location[1], Target->Location[2]);

	XOffset = Target->Location[0] - Location[0];
	YOffset = Target->Location[1] - Location[1];
	ZOffset = Target->Location[2] - Location[2];

	return (float) sqrt(pow(ZOffset, (float)2.0) + pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));

}

float EntityObj::Distance(float X, float Y, float Z) {

	float XOffset, YOffset, ZOffset;
	
	if(Location[0] == 0.0 && Location[1] == 0.0 && Location[2] == 0.0)
		return FLT_MAX;
	
	XOffset = X - Location[0];
	YOffset = Y - Location[1];
	ZOffset = Z - Location[2];

	return (float) sqrt(pow(ZOffset, (float)2.0) + pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));

}


