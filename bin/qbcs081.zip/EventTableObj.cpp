#include "EventTableObj.h"


EventTableObj::EventTableObj() {

	int x;

	for(x = 0; x < MaxEvents; x++) // init vector table
		EventTable[x].Socket = NULL;
	
	LastVectorEntry = -1; // Last entry in vector table

	SocketPolling = False; // Don't check sockets until told to

	Execution = 1;

	// Timeout for select() poll
	Timeout = 50; // 50ms
	RecvTimeout.tv_sec = Timeout/1000;  // convert timeout to timeval struct
	RecvTimeout.tv_usec = (Timeout - (RecvTimeout.tv_sec * 1000)) * 1000;

}

// **********************************************************
// *
// *  This function creates an entry in the event table for
// *  your object.  You get called based on what event you 
// *  register. (See EventTableObj.h)
// *
// *  YOUR MUST REGISTER AN OBJECT TO RECEIVE MESSAGES!!!!!!
// *  You must ALSO set your OWNERID to a unique value.
// *  There is a global enum in QuakeBot.h for this purpose
// *
// **********************************************************

int EventTableObj::RegisterCallback(EventHandlerObj *Callback, void *CallbackData, enum EventTypes Event) {

	if(LastVectorEntry < (MaxEvents - 1)) {
		LastVectorEntry++;
		EventTable[LastVectorEntry].Callback = Callback;
		EventTable[LastVectorEntry].CallbackData = CallbackData;
		if(Event == etRecvEvent)
			EventTable[LastVectorEntry].SocketID = ((SocketObj *)CallbackData)->GetSocket();
		if(Callback->OwnerID == -1)
			Print("ERROR: Your object must override the OwnerID to a unique value\n");
		else
			EventTable[LastVectorEntry].OwnerID = Callback->OwnerID;
		EventTable[LastVectorEntry].Event = Event;

		// Call object's init method
		EventTable[LastVectorEntry].Callback->InitEvent(EventTable[LastVectorEntry].CallbackData);
		
		return LastVectorEntry;
	} else
		return -1;
}

// **********************************************************
// *
// *  Removes a callback form you event list
// *
// **********************************************************
void EventTableObj::DeleteCallback(int EventNumber) {

	int x;

	if(EventNumber < (MaxEvents - 1)) {
		if(EventNumber == LastVectorEntry)
			LastVectorEntry--;
		else
			for(x = EventNumber; x < LastVectorEntry; x++)
				memcpy(&EventTable[x], &EventTable[x+1], sizeof(struct EventVectorStruct));
	}
}

// **********************************************************
// *
// *  Terminates the event process. ( called by console now)
// *
// **********************************************************
void EventTableObj::Exit(int Data) {

	ReturnValue = Data; // Return value sent by process
	Execution = 0;
}

// **********************************************************
// *
// *  Quasi-Infinite loop.  Dispatches events.
// *
// *  The socket polling stuff doesn't make me happy.  There
// *  needs to be a smarter way of doing this socket stuff
// *
// *  Beware of the UNIX code.  I haven't tried to compile it.
// *
// **********************************************************

int EventTableObj::EventLoop() {

	int Result, x, NumberFileDesc;
	fd_set Input;
	Boolean SPFlag, KeyboardHit;

	SOCKET stdinfd = 0; // !!!!!!!!!!!!!!!! This could be wrong


	while(Execution) {

#ifndef __unix__
		_CrtCheckMemory();	
#endif
		KeyboardHit = False;

		// Check for keyboard Data
#ifdef __unix__
		FD_ZERO(&Input);
		FD_SET(stdinfd, &Input);
		Result = select(1, &Input, NULL, NULL, &RecvTimeout);
		if(FD_ISSET(stdinfd, &Input))
			KeyboardHit = True;
#else
		if(_kbhit())
			KeyboardHit = True;
#endif

		// this is added so that the state cannot change during a loop
		SPFlag = SocketPolling;
//		Print("EventCycle\n");
		if(SPFlag) { // If socket polling turned on
			FD_ZERO(&Input);
			NumberFileDesc = 0;
			for(x = 0; x <= LastVectorEntry; x++){
				if(EventTable[x].Event == etRecvEvent) {
					NumberFileDesc++;
					FD_SET(EventTable[x].SocketID, &Input);
				}
			}

			Result = select(NumberFileDesc, &Input, NULL, NULL, &RecvTimeout);
//			if(Result == 0)
//				Print("Timeout\n");
		}


		for(x = 0; x <= LastVectorEntry; x++) {

			switch(EventTable[x].Event){
			case etKeyEvent:// if key hit, dispatch
				if(KeyboardHit) 
					EventTable[x].Callback->KeyEvent(EventTable[x].CallbackData);
				break;

			case etRecvEvent: // if data on the port
				if(SPFlag && (FD_ISSET(EventTable[x].SocketID, &Input)))
					EventTable[x].Callback->RecvEvent(EventTable[x].CallbackData);	
				break;

			case etCycleEvent: // Call once if registered for a cycle event
				EventTable[x].Callback->CycleEvent(EventTable[x].CallbackData);			
				break;
			case etMessageEvent: // Ignore
				break;
			default:
				Print("EventLoop(): Entry #%d, Unknown Event!!!!\n", x);
			}
		}
	}

#ifndef __unix__
	_CrtCheckMemory();
#endif
	
	// Somebody called Exit().  The party's over.
	// Call all remaining object's exit functions
	for(x = 0; x <= LastVectorEntry; x++)
		EventTable[x].Callback->ExitEvent(EventTable[x].CallbackData);

#ifndef __unix__
	_CrtCheckMemory();
#endif
	return ReturnValue;  // Value set by Exit() function
}

// **********************************************************
// *
// *  Wrapper for the SendMessage(oeConsole, ueConsolePrint..
// *  function.  Makes my life easier.
// *
// **********************************************************

void EventTableObj::Print(char *Data, ...) {

	va_list Marker;
	va_start(Marker, Data);
	char Buffer[0xff];

	// Display output
	vsprintf(Buffer, Data, Marker); // printf it to a Buffer

	SendMessage(edConsole, oeConsolePrint, Buffer); // Generate event

}

// **********************************************************
// *
// *  Generic Send Message routine.  Currently executes 
// *  immediately as opposed to queueing messages. (Might change)
// *
// **********************************************************

void EventTableObj::SendMessage(EventDest DestOwnerID, ObjectEvent LocalEvent, void *Data) {
	int x;

	if(DestOwnerID == edBroadcast) { // Call everyone
		for(x = 0; x <= LastVectorEntry; x++)
			if(EventTable[x].Event == etMessageEvent)
				EventTable[x].Callback->MessageEvent(LocalEvent, Data);
	} else {
		for(x = 0; x <= LastVectorEntry; x++){
			if((EventTable[x].OwnerID == DestOwnerID) && (EventTable[x].Event == etMessageEvent)){
				EventTable[x].Callback->MessageEvent(LocalEvent, Data);
				return;
			}
		}
	// This means it could find the destination.  Could be unregistered?
		Print("ERROR: No associated OwnerID for this event!!!!\n");
	}
}

// **********************************************************
// *
// *  Turns Socket Polling on of off.  Good for removing pauses
// *  when the server is not expecting data. (offline)
// *
// **********************************************************

void EventTableObj::SetSocketPolling(Boolean Mode) {

	SocketPolling = Mode;

}