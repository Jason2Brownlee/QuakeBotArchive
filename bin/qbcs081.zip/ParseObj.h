#include <stdio.h>
#include <stdlib.h>
#include <string.h>



// This holds the return data from the get expression command.

struct Expression {
	Command Variable;  // An enum that hold the Command Index
	DataType Type;		//  The type of Data returned
	int ArrayX, ArrayY;		// Subscripts, if any
	union {					// The argument
		float FloatData;
		int IntData;
		char *CharPData;
	};
};

class ParseObj {

private:
	char Buffer[0x80];
	int GetSubscript(char *);
	char Command[0x80], Argument[0x80];
public:

	char *GetToken();
	char GetChar();
	unsigned char Eof();
	int GetExpression(struct Expression *);


	FILE *InputFile;

	// Opens the file and readies it for reading

	ParseObj(char *Filename) {
	
		if(NULL == (InputFile = fopen(Filename, "r"))){
			printf("Error\n");
			exit(1);
		}
	}

	// closes the file
	~ParseObj() {
		fclose(InputFile);
	}
};

// Gets line from an input file. Returns a structure that
// contains the name and arguments already parse.
// Returns a 0 on end of file, Index of the command otherwise.
// This routine handles errors by returning a -1;

int ParseObj::GetExpression(struct Expression *ExpData){

	char  *Token;
	int Index = 0;
	unsigned int Offset;

	// Get command token.  Ignore blank lines
	while(1){
		
		Token = GetToken();
		if(Token == NULL)
			return -1;
		
		if(strlen(Token) > 0) {
			if(Token[0] != '/')
				break;
		}
	};

	//  See if a valid command, puke if not.

	for(Index = 0; Index < MAX_COMMANDS; Index++){
		if(Commands[Index].Variable) {
			if(strnicmp(Commands[Index].Command, Token, strlen(Commands[Index].Command)) == 0)
			break;
		} else {
			if(stricmp(Commands[Index].Command, Token) == 0)
			break;
		}
	}

	if(Index >= MAX_COMMANDS) {
		printf("Syntax Error!!! Command = \"%s\"\n", Token);
		return -2;
	}

	// if a variable command, get subscripts
	if(Commands[Index].Variable){ 
		for(Offset=0; (Offset < strlen(Token)) && (Token[Offset] != '['); Offset++); // finds the first [

		if(Token[Offset] != '['){
			printf("Invalid Subscript on %s", Token);
			return -2;
		}

		ExpData->ArrayX = GetSubscript(&Token[Offset]);

		for(Offset++; Offset < strlen(Token) && Token[Offset] != '['; Offset++); // finds the first [

		if(Token[Offset] != '['){
			printf("Invalid Subscript on %s", Token);
			return -2;
		}

		ExpData->ArrayY = GetSubscript(&Token[Offset]);
	}

	ExpData->Variable = (enum Command)Index; // save the token locally

	// Get the argument
	do {
		Token = GetToken();
		if(Token == NULL) {
			printf("Syntax Error! No Argument");
			return -2;
		}

	} while(Token[0] == '/');

	strcpy(Argument, Token);


	// Set up return data
	ExpData->Type = Commands[Index].Type;

	switch(Commands[Index].Type) {
	case ARG_FLOAT:
		ExpData->FloatData = (float)atof(Argument);
		break;
	case ARG_INT:
		ExpData->IntData = atoi(Argument);
		break;
	case ARG_CHARP:
		ExpData->CharPData = Argument;
		break;

	}

	return Index;
}


// get a char from the open file
char ParseObj::GetChar() {

	return fgetc(InputFile);
}

// Check end of file status on open file
unsigned char ParseObj::Eof() {
	return feof(InputFile);
}
