#ifndef QUAKE_H
#define QUAKE_H
const unsigned char CCREQ_CONNECT = 0x01;
const unsigned char CCREQ_SERVER_INFO = 0x02;
const unsigned char CCREQ_PLAYER_INFO = 0x03;
const unsigned char CCREQ_RULE_INFO = 0x04;

const unsigned char CCREP_ACCEPT = 0x81;
const unsigned char CCREP_REJECT = 0x82;
const unsigned char CCREP_SERVER_INFO = 0x83;
const unsigned char CCREP_PLAYER_INFO = 0x84;
const unsigned char CCREP_RULE_INFO = 0x85;


const unsigned char NET_PROTOCOL_VERSION = 0x03;

#endif
