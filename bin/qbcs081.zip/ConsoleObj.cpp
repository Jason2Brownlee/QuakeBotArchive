#include "ConsoleObj.h"

// *********************************************
// *
// *  Routine to print on console.  
// *
// *********************************************
void ConsoleObj::DisplayString(char *Data, ...) {

	va_list Marker;

	va_start(Marker, Data);

#ifndef __unix__
	SMALL_RECT Source;
	COORD Dest;
	CHAR_INFO Fill;
//	LPDWORD Written;

	Fill.Char.AsciiChar = ' ';
	Fill.Attributes = FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED;

	// get current prompt coords
	GetConsoleScreenBufferInfo(ConsoleHandle, &Csbi);
	PromptPosition.X = Csbi.dwCursorPosition.X;
	PromptPosition.Y = Csbi.dwCursorPosition.Y;

	// Set cursor for output
	SetConsoleCursorPosition( ConsoleHandle, CursorPosition);

	// Display output
	vprintf(Data, Marker);
	
	// get new coords
	GetConsoleScreenBufferInfo(ConsoleHandle, &Csbi);

	// Same em for next time
	CursorPosition.X = Csbi.dwCursorPosition.X;
	CursorPosition.Y = Csbi.dwCursorPosition.Y;

	// if too far, scroll up.
	if(CursorPosition.Y > 23) {

		Source.Left = 0;
		Source.Right = 79;
		Source.Top = 1;
		Source.Bottom = 23;

		Dest.X = 0;
		Dest.Y = 0;

		ScrollConsoleScreenBuffer(ConsoleHandle, &Source, NULL , Dest, &Fill);  

		// Save new coords
		CursorPosition.X = 0;
		CursorPosition.Y = 23;
	}

	//  Establish old coords

	SetConsoleCursorPosition( ConsoleHandle, PromptPosition);
	
#else
	vprintf(Data, Marker);
#endif
}

// *********************************************
// *
// *  Event routine to process keystrokes until a line
// * is received.  
// *
// *********************************************
void ConsoleObj::KeyEvent(void *Dummy) {
	
	char KeyData;

#ifndef __unix__
	KeyData = (char) _getche();
#else
	KeyData = (char) getchar();
#endif

	if(KeyData != 13) // if not equal to a return
		InputBuffer[InputOffset++] = KeyData;
	else {
		InputBuffer[InputOffset] = '\0';
		InputOffset = 0;
		ParseString(InputBuffer);
		ResetPrompt();
	}
}

// *********************************************
// *
// *  Grabs a string token
// *
// *********************************************
char *ConsoleObj::StringToken() {
	return GetToken();
}

// *********************************************
// *
// *  Grabs rest of line
// *
// *********************************************
char *ConsoleObj::LineToken() {
	return GetToken();
}


// *********************************************
// *
// *  Grabs a int token.  
// *
// *********************************************
int ConsoleObj::IntToken() {

	char *Argument;
	Argument = GetToken();
	if(Argument != NULL)
		return atoi(Argument);
	else
		return 0;

}


//*******************************************
//
//  Displays Game Output to a console window
//
//*******************************************

void ConsoleObj::DoGame() {

	int i;
	PlayerObj *TempPlayer;

	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}

	DisplayString("Game Status\n");
	DisplayString("Server : %s, Map: %s\n", Data->ServerName, Data->MapName);
	
	DisplayString("Server Time: %f, Client Time: %f\n", Data->ServerTimeStamp, Data->ClientTimeStamp);
	DisplayString("\n");
	DisplayString("Name\t\tFrags\tPosition\t\tDormant\tFrame\n");
	for(i=1; i<=Data->MaxPlayers; i++) {
		TempPlayer = (PlayerObj *)Data->BaselineEntity[i]; 
		DisplayString("%10s\t%d\t(%5.0f, %5.0f, %5.0f)\t%d\t%d\n",
			TempPlayer->Name, TempPlayer->Frags, 
			TempPlayer->Location[0], TempPlayer->Location[1], 
			TempPlayer->Location[2], TempPlayer->Dormant, 
			TempPlayer->Frame);
		DisplayString("\t(%5.0f, %5.0f, %5.0f)\t(%5.0f, %5.0f, %5.0f)\n",
			TempPlayer->Angle[0], TempPlayer->Angle[1], TempPlayer->Angle[2], 
			TempPlayer->ClientAngle[0], TempPlayer->ClientAngle[1], TempPlayer->ClientAngle[2]); 
	}

}

//*******************************************
//
//  Changes bot name
//
//*******************************************
void ConsoleObj::DoColor() {

	if(!ServerConnected){
		Data->BotShirtColor = IntToken();
		Data->BotPantColor = IntToken();
	} else {
		Data->BotShirtColor = IntToken();
		Data->BotPantColor = IntToken();
		sprintf(OutputBuffer, "color %d %d", Data->BotShirtColor,  Data->BotPantColor);
		EventTable->SendMessage(edServer, oeSendRaw, (void *)OutputBuffer);

	}

}

	//*******************************************
//
//  Changes bot name
//
//*******************************************
void ConsoleObj::DoName() {

	if(!ServerConnected)
		Data->SetBotName(StringToken());
	else {
		sprintf(OutputBuffer, "name %s", StringToken());
		EventTable->SendMessage(edServer, oeSendRaw, (void *)OutputBuffer);

	}

}

//*******************************************
//
//  Displays Network Statisitcs to a console window
//
//*******************************************
void ConsoleObj::DoNet() {

	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}

	EventTable->Print("Temporarily Disabled\n");
/*
	DisplayString("Network Status - %s\n", Data->IPString);
	DisplayString("Incoming - Reliable: %d, Update: %d, ", 
		Data->ServerPacket.IncomingPacketSequence[SEQUENCE_FINAL], 
		Data->ServerPacket.IncomingPacketSequence[SEQUENCE_UPDATE]);

	DisplayString("Acknowledgments: %d, ", Data->ServerPacket.IncomingPacketSequence[SEQUENCE_ACK]);
	DisplayString("Rejected Packets: %d\n", Data->ServerPacket.IncomingRejected);
	DisplayString("Outgoing - Reliable: %d, Update: %d, ", 
		Data->ServerPacket.OutgoingPacketSequence[SEQUENCE_FINAL], 
		Data->ServerPacket.OutgoingPacketSequence[SEQUENCE_UPDATE]);

	DisplayString("Acknowledgments: %d\n", Data->ServerPacket.OutgoingPacketSequence[SEQUENCE_ACK]);
*/
}

//*******************************************
//
//  Displays Entity Defaults
//
//*******************************************
void ConsoleObj::DoDefined() {

	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}

	int i, Hits;
	DisplayString("Static Entities\n");
	for(Hits = 0, i = 0; i < MAX_STATIC_ENTITIES; i++){
		if(Data->StaticEntity[i] != NULL) {
			DisplayString("#%3d=%20s ", i, 
			Data->PrecacheModel[Data->StaticEntity[i]->ModelIndex]);
			Hits++;
			if((Hits % 3) == 0)
				DisplayString("\n");
		}
	}

	DisplayString("\n");

	DisplayString("Baseline Entities\n");
	for(Hits = 0, i = 0; i < MAX_BASELINE_ENTITIES; i++){
		if(Data->BaselineEntity[i] != NULL) {
			DisplayString("#%3d=%20s ", i, 
			Data->PrecacheModel[Data->BaselineEntity[i]->ModelIndex]);
			Hits++;
			if((Hits % 3) == 0)
				DisplayString("\n");
		}

	}
	DisplayString("\n");
}

//*******************************************
//
//  Displays Entity information for arg
//
//*******************************************
void ConsoleObj::EntityInformation(EntityObj *Entity) {

	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}
	if(Entity == NULL) {
		DisplayString("Entity is not currently defined!!!!\n");
		return;
	}
	DisplayString("\nEntity Information\n");
	DisplayString("ModelIndex: %d, Frame: %d, ColorMap: %d, Skin: %d, Attack State: %d\n", 
		Entity->ModelIndex, Entity->Frame, Entity->ColorMap, Entity->Skin, Entity->AttackState);
	
	DisplayString("Location: (%5.0f, %5.0f, %5.0f)\n", Entity->Location[0], Entity->Location[1], Entity->Location[2]);
	DisplayString("Orientation: (%5.0f, %5.0f, %5.0f)\n", Entity->Angle[0], Entity->Angle[1], Entity->Angle[2]);
	DisplayString("Model Name: %s\n", Data->PrecacheModel[Entity->ModelIndex]);
}

// *******************************************
// *
// * Displays Player Information
// *
// *******************************************
void ConsoleObj::PlayerStatus(PlayerObj *Player) {

	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}
	DisplayString("\n");
	DisplayString("Player Information\n");

	DisplayPlayerStatus(Player);
	DisplayString("Weapon: ");
	DisplayWeapon(Player);
	DisplayString("Items: ");
	DisplayItems(Player);

	EntityInformation(Player);

}

void ConsoleObj::InsertAlias(char *Variable, char *Value) {

	DisplayString("Inserting alias\n");
	DisplayString("Variable: '%s', Value: '%s'\n", Variable, Value);
	Alias.Insert(Variable, Value);

}

// *********************************************
// *
// *  Grizzly.  Expect changes
// *
// *********************************************

void ConsoleObj::ParseString(char *InputBuffer){

	char *InputCommand;
	int Index;

	EndOfString = False;
	printf("\n\n");

	strcpy(Buffer, InputBuffer);
	BufferOffset = 0;

	InputCommand = StringToken();
	for(Index = 0; Index < LastCommand; Index++) {
		if(stricmp(Commands[Index].Command, InputCommand) == 0){
			(this->*Commands[Index].ParseFunction) ();
			return;
		}
	}
	DoOther(InputCommand);
}


void ConsoleObj::DoQuit(){

	EventTable->Exit(0); // This will stop event table after returning
}

void ConsoleObj::DoDisconnect(void){
	if(ServerConnected) {
		EventTable->SendMessage(edServer, oeServerDisconnect, (void *)NULL);
	}
}

void ConsoleObj::DoConnect(void){

	int TempPort;
	Address ConnectAddress;
	char *Arg;
	if(ServerConnected) {
		DisplayString("Dynamic reconnection not currently supported!\n");
//		EventTable->SendMessage(edServer, oeServerDisconnect, (void *)NULL);
		return;
	}

	Arg = StringToken();
	if(Arg == NULL)
		return;
	ConnectAddress.IPAddress = strdup(Arg);
	TempPort = IntToken();

	if(TempPort == 0)
		ConnectAddress.Port = 26000;
	else
		ConnectAddress.Port = TempPort;

	DisplayString("Address: %s, Port: %d\n", ConnectAddress.IPAddress, ConnectAddress.Port);
	EventTable->SendMessage(edServer, oeServerConnect, (void *)&ConnectAddress);
	free(ConnectAddress.IPAddress);
}

void ConsoleObj::DoSay(){

	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}

	sprintf(OutputBuffer, "(Console) %s", &Buffer[BufferOffset]);
	EventTable->SendMessage(edServer, oeSendSay, (void *)OutputBuffer);
}
	
void ConsoleObj::DoPlayer(){

	int Index;
	
	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}

	Index = IntToken();
	if(Index < 0 || Index > Data->MaxPlayers)
		PlayerStatus((PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex]);
	else
		PlayerStatus((PlayerObj *)Data->BaselineEntity[Index + 1]);		
}


void ConsoleObj::DoModel(void){
	int Index;

	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}

	Index = IntToken();
	if(Index < 1 || Index > Data->NumModels)
		DisplayString("Invalid Model Index - #%d\n", Index);
	else
		DisplayString("Model Name: %s\n", Data->PrecacheModel[Index]);		
}

void ConsoleObj::DoDynamic(void){
	int Index;
	
	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}
	Index = IntToken();
	if(Index < 1 || Index > MAX_BASELINE_ENTITIES)
		Index = Data->BotID;
	printf("index = %d\n", Index);

	EntityInformation(Data->BaselineEntity[Index]);		
	
}

void ConsoleObj::DoAlias(void){
	char *Arg1, *Arg2;

	Arg1 = StringToken();
	if(Arg1 != NULL) {

		Arg1 = strdup(Arg1); // Dupe the buffer)
		Arg2 = LineToken();
		if(Arg2 != NULL)
			InsertAlias(Arg1, Arg2);
		free(Arg1);
	} else
		DisplayAliases();
}

void ConsoleObj::DoAICommand(void){
	char *Arg1;

	Arg1 = StringToken();
	if(Arg1 == NULL)
		EventTable->Print("You must specify an argument");
	else {
		if(stricmp(Arg1, "off") == 0)
			EventTable->SendMessage(edAI, oeAIOff, (void *)NULL); // Turn on AI
		else if(stricmp(Arg1, "on") == 0)
			EventTable->SendMessage(edAI, oeAIOn, (void *)NULL); // Turn on AI
		else 
			EventTable->SendMessage(edAI, oeAICommand, (void *)Arg1); // Turn on AI
	}
}
void ConsoleObj::DoStatic(void){
	
	int Index;
	
	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}

	Index = IntToken();
	if(Index < 1 || Index > MAX_STATIC_ENTITIES)
		Index = 1;
	printf("index = %d\n", Index);

	EntityInformation(Data->StaticEntity[Index]);		
}
	
void ConsoleObj::DoImpulse(void){

	if(!ServerConnected){
		DisplayString("Server Offline\n");
		return;
	}

	((PlayerObj *)Data->BaselineEntity[Data->BotID])->CommandImpulse = IntToken();
}

	
void ConsoleObj::DoBF(void){
		DisplayString("BEEP! :)\n");
}
	
void ConsoleObj::DoOther(char *Command){
	
	char *Value, *RecurseValue;

	Value = Alias.Find(Command);  // See if an alias exists
	if(Value == NULL) { // Nope
		if(!ServerConnected){
			DisplayString("Server Offline\n");
			return;
		}
		sprintf(OutputBuffer, "%s", Command);
		EventTable->SendMessage(edServer, oeSendRaw, (void *)OutputBuffer);
	} else { // Call ParseString recursively with the new input
		RecurseValue = strdup(Value);
		ParseString(RecurseValue);  
		free(RecurseValue);
	}
}

void ConsoleObj::DoHelp(){
	
	int Index;

	for(Index = 0; Index <= LastCommand; Index++)
		DisplayString("%15s - %s\n", Commands[Index].Command, Commands[Index].Text);
	
}

void ConsoleObj::DoSkin(){
	

	((PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex])->Skin = IntToken(); 
	
}

// *********************************************
// *
// *  Displays all aliases in alias object
// *
// *********************************************
void ConsoleObj::DisplayAliases() {

	RuleObj *CurrentRule;

	CurrentRule = Alias.GetFirstRule();

	if(CurrentRule == NULL) {
		DisplayString("No Aliases currently Defined\n");
		return;
	}

	while(CurrentRule != NULL) {
		DisplayString("%s = %s\n", CurrentRule->Variable, CurrentRule->Value);
		CurrentRule = CurrentRule->GetNextRule();
	}
}


void ConsoleObj::DisplayWeapon(PlayerObj *Player) {

		switch (Player->Weapon) {
		case 0:
			DisplayString("Axe\n");
			break;
		case 1:
			DisplayString("ShotGun\n");
			break;
		case 2:
			DisplayString("Super Shotgun\n");
			break;
		case 3:
			DisplayString("Nailgun\n");
			break;
		case 4:
			DisplayString("Super Nailgun\n");
			break;
		case 5:
			DisplayString("Grenade Launcher\n");
			break;
		case 6:
			DisplayString("Rocket Launcher\n");
			break;
		case 7:
			DisplayString("Lightning Gun\n");
			break;
		}
}

void ConsoleObj::DisplayItems(PlayerObj *Player) {


	if(Player->Items & IT_EXTRA_WEAPON)
		DisplayString("Extra Weapon - ");
	if(Player->Items & IT_SHELLS)
		DisplayString("Shells - ");
	if(Player->Items & IT_NAILS)
		DisplayString("Nails - ");
	if(Player->Items & IT_ROCKETS)
		DisplayString("Rockets - ");
	if(Player->Items & IT_CELLS)
		DisplayString("Cells - ");
	if(Player->Items & IT_ARMOR1)
		DisplayString("Armor #1 - ");
	if(Player->Items & IT_ARMOR2)
		DisplayString("Armor #2 - ");
	if(Player->Items & IT_ARMOR3)
		DisplayString("Armor #3 - ");
	if(Player->Items & IT_SUPERHEALTH)
		DisplayString("Super Health - ");
	if(Player->Items & IT_KEY1)
		DisplayString("Key #1 - ");
	if(Player->Items & IT_KEY2)
		DisplayString("Key #2 - ");
	if(Player->Items & IT_INVISIBILITY)
		DisplayString("Invisibility - ");
	if(Player->Items & IT_INVULNERABILITY)
		DisplayString("Invunerability - ");
	if(Player->Items & IT_SUIT)
		DisplayString("Suit - ");
	if(Player->Items & IT_QUAD)
		DisplayString("Quad Damage - ");
	if(Player->Items & IT_LIGHTNING) // Got lightning gun and cells
		DisplayString("Lightning Gun - ");
	if(Player->Items & IT_ROCKET_LAUNCHER)  // Got Rocket and Rockets
		DisplayString("Rocket Launcher - ");
	if(Player->Items & IT_GRENADE_LAUNCHER)  // Got Grenade and Rockets
		DisplayString("Grenade Launcher - ");
	if(Player->Items & IT_SUPER_NAILGUN)  // Got super nailgun and nails
		DisplayString("Super NailGun - ");
	if(Player->Items & IT_NAILGUN)  // Got nailgun and nails
		DisplayString("NailGun - ");
	if(Player->Items & IT_SUPER_SHOTGUN)  // Got super shotgun and shells
		DisplayString("Super Shotgun - ");
	if(Player->Items & IT_SHOTGUN)  // Got shotgun and shells
		DisplayString("Shotgun - ");
	if(Player->Items & IT_AXE) // Use da' AXE
		DisplayString("Axe");
	DisplayString("\n");
}

void ConsoleObj::DisplayPlayerStatus(PlayerObj *Player) {
	DisplayString("Name: %s\n", Player->Name); 
	DisplayString("Frags: %d, Health %d, Armor %d\n", 
		Player->Frags, Player->Health, Player->ArmorValue); 

	DisplayString("Shells: %d, Nails: %d, Rockets: %d, Cells: %d\n", 
		Player->AmmoShells, Player->AmmoNails, Player->AmmoRockets,
		Player->AmmoCells); 

	DisplayString("Shirt: ");
	DecodeColors(Player->ShirtColor);
	DisplayString(" Pant: ");
	DecodeColors(Player->PantColor);
	DisplayString("\n");
}


void ConsoleObj::DecodeColors(int Color) {

	switch(Color) {

	case 0:
		DisplayString("White");
		break;
	case 1:
		DisplayString("Brown");
		break;
	case 2:
		DisplayString("Lt. Blue");
		break;
	case 3:
		DisplayString("Green");
		break;
	case 4:
		DisplayString("Red");
		break;
	case 5:
		DisplayString("Dark Yellow");
		break;
	case 6:
		DisplayString("Pink");
		break;
	case 7:
		DisplayString("Lt. Brown");
		break;
	case 8:
		DisplayString("Lt. Purple");
		break;
	case 9:
		DisplayString("Purple");
		break;
	case 10:
		DisplayString("Grey");
		break;
	case 11:
		DisplayString("Aqua");
		break;
	case 12:
		DisplayString("Yellow");
		break;
	case 13:
		DisplayString("Blue");
		break;
	}
}

void ConsoleObj::InsertCommand(char *Command, char *Text, void (ConsoleObj::*Function)()){

	if(LastCommand >= (MaxCommands - 1)) {
		DisplayString("Command table length exceeded!!!!\n");
		return;
	}

	LastCommand++;

	Commands[LastCommand].Command = strdup(Command);
	Commands[LastCommand].Text = strdup(Text);
	Commands[LastCommand].ParseFunction = Function;
}

void ConsoleObj::DeleteCommands(){

	int x;
	
	for(x = 0; x <= LastCommand; x++) {
		free(Commands[x].Command);
		free(Commands[x].Text);

	}

}

ConsoleObj::~ConsoleObj() {
	DeleteCommands();
}

ConsoleObj::ConsoleObj(EventTableObj *Event, DataObj *ServerData) {

	InputOffset = 0;
	OutputOffset = 0;
	LastCommand = -1;
	Data = ServerData;
	EventTable = Event;
	OwnerID = edConsole;
	EventTable->RegisterCallback((EventHandlerObj *)this, (void *)Data, etKeyEvent);
	EventTable->RegisterCallback((EventHandlerObj *)this, (void *)Data, etMessageEvent);

	ServerConnected = False;  // Server is offline  
	InsertCommand("help", "This List", DoHelp);	
	InsertCommand("AI", "Sends a message to the AI", DoAICommand);
	InsertCommand("alias", "Display Aliases", DoAlias);
	InsertCommand("bf", "Do a Console flash", DoBF);
	InsertCommand("color", "Change Bot Color", DoColor);
	InsertCommand("connect", "Connect to a Quake Server", DoConnect);
	InsertCommand("defined", "Display All Defined Entities", DoDefined);
	InsertCommand("disconnect", "Disconnect from a server", DoDisconnect);
	InsertCommand("dynamic", "Display Dynamic Entities", DoDynamic);
	InsertCommand("game", "Game Information", DoGame);
	InsertCommand("impulse", "Send server Command", DoImpulse);
	InsertCommand("model", "Display Models", DoModel);
	InsertCommand("name", "Change Bot Name", DoName);

	InsertCommand("net", "Network Statistics", DoNet);
	InsertCommand("player", "Player Status", DoPlayer);
	InsertCommand("quit", "Leave Bot", DoQuit);
	InsertCommand("say", "Sends a message", DoSay);
	InsertCommand("skin", "Change Skin", DoSkin);
	InsertCommand("static", "Display Static Entities", DoStatic);



#ifndef __unix__
	ConsoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTitle("QuakeBot C/S");
#endif
	ClearScreen();
	ResetPrompt();
}

void ConsoleObj::ResetPrompt() {


#ifndef __unix__
	PromptPosition.X = 0;
	PromptPosition.Y = 24;
	SetConsoleCursorPosition( ConsoleHandle, PromptPosition);
#endif

	printf("->"); // Use a printf because I want this at the bottom

#ifndef __unix__
	PromptPosition.X = 2;  // Account for shift 
#endif

}

void ConsoleObj::ClearScreen() {
#ifndef __unix__
	DWORD ConsoleSize, Written;

	CursorPosition.X = 0;
	CursorPosition.Y = 0;
	GetConsoleScreenBufferInfo(ConsoleHandle, &Csbi);
	ConsoleSize = Csbi.dwSize.X * Csbi.dwSize.Y;

	/* fill the entire screen with blanks */

	FillConsoleOutputCharacter( ConsoleHandle, (TCHAR) ' ', 
		ConsoleSize, CursorPosition, &Written );

	CursorPosition.X = 0;
	CursorPosition.Y = 22;
	SetConsoleCursorPosition( ConsoleHandle, CursorPosition);

#endif


}

void ConsoleObj::MessageEvent(ObjectEvent Event, void *Data){

	switch(Event) {
	case oeConsolePrint: // Print to the Console
		DisplayString("%s", (char *)Data);
		break;
	case oeConsoleParse: // Parse an input string
		ParseString((char *)Data);
		break;
	case oeServerOnline: // Tell console server is online
		DisplayString("Console Notified\n");
		ServerConnected = True;
		break;
	case oeServerOffline: // Tell console server is offline
		DisplayString("Console Notified\n");
		ServerConnected = False;
		break;
	default:
		DisplayString("Unknown Message Event\n");
	}


}


char ConsoleObj::GetChar(){

	return Buffer[BufferOffset++];

}

// ************************************************
// *
// * Token Finte State Machine.
// *
// ************************************************
char *ConsoleObj::GetToken() {

	char Data;
	Boolean Terminate;
	int Offset = 0, Index = 0;
	State NextState = Idle, CurrentState = Idle;

	if(EndOfString)
		return NULL;

	Terminate = False;

	while(!Terminate){
		Data = GetChar();
		switch(CurrentState){
		case Idle:
			switch(Data){
			case ' ':
				break;
			case '\"':
				NextState = Quote;
			default:
				Buffer[Index++] = Data;
				NextState = Token;
			}
			break;
		case Token:
			switch(Data){
			case '\0':
				EndOfString = True;
			case ' ':
			case '\n':
				Terminate = True;
				break;
			default:
				Buffer[Index++] = Data;
			}	
			break;
		case Quote:
			switch(Data){
			case '\"':
				Terminate = True;
				break;
			default:
				Buffer[Index++] = Data;
			}	
			break;
		}
		CurrentState = NextState;
	}	
	Buffer[Index] = '\0';
	return Buffer;
}

