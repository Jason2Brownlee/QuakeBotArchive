/*
All bot/AI related code in this file is (c) 2000 Rich Whitehouse

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "quakedef.h"

/*
=========================================
Globals/Externs/Predecs/Etc.
=========================================
*/
#define		WP_TYPE_NORMAL 0
#define		WP_TYPE_JUMP 1
#define		WP_TYPE_PLATFORM 2
#define		WP_TYPE_NOVIS 3
#define		WP_TYPE_SLIDE_START 4
#define		WP_TYPE_SLIDE_FINISH 5
#define		WP_TYPE_SLIDE_ONFOOT 6
#define		WP_TYPE_SLIDE_TELE 7
#define		WP_TYPE_TELEPORT 8
#define		WP_TYPE_ONLYFORWARD 9
//WP type 10 is reserved for highlighted waypoints
#define		WP_TYPE_SHOOTNEAROBJECT 11
#define		WP_TYPE_CHECKUNDER 12
#define		WP_TYPE_PUSHBUTTON 13
#define		WP_TYPE_PICKUP 14

#define		CHECK_DIR_FORWARD 1
#define		CHECK_DIR_BACK 2
#define		CHECK_DIR_RIGHT 3
#define		CHECK_DIR_LEFT 4

#define		BOT_MAX_VIEWDIST 4096

int			gUseCl;
float		gFakeCl;
int			gBotNum;
int			gBotTotal;
int			gWPEditMode;
int			gWPSetEdit;
int			gLoadWPs;
float		gLoadWPTime; //delay it a bit as an option
int			gWPNum;
int			gBotImpulse;
float		gParticleDelay;
int			gWPCounter;
waypoint_t	gWPArray[4096];

extern		cvar_t			sv_maxspeed;

void BotAI_Main(client_t *bcl, int cln);
void BotAI_Slide();
void BotAI_StandardDM();
void SV_ConnectClient (int clientnum);
void RGlb();
void LoadWaypointFile();
void WP_Draw();
void R_HighlightWP (vec3_t org, int wptype);
float bot_vlen (vec3_t value1);
void Host_Restart_f (void);
void Bot_Say(qboolean teamonly, char *p);
int SuitableBrushWeapon();


/*
=========================================
Bot (de)allocation/framework functions.
=========================================
*/
void BotImpulse(void) {
	//This allows players to enter an impulse that every bot in the
	//game will use for one frame.
	int bImp = 0;

	if (Cmd_Args()) {
		bImp = (int)strtod(Cmd_Args(), NULL);	
	}

	if (bImp < 1 || bImp > 255) {
		Con_SafePrintf("Impulse is out of range.\nShould be 1-255.\n");
		return;
	}

	gBotImpulse = bImp;
}

edict_t *ED_ClientAlloc (void) //find a free client slot to add a bot
{
	int MAX_CLIENTS = svs.maxclients;

	int			i;
	edict_t		*e;
	int clients = 0;
	client_t *cl = svs.clients;

	for (i=0 ; i<=MAX_CLIENTS ; i++,cl=svs.clients+i)
	{
		if (cl && cl->active == false)
			break;

		clients++;
	}
	clients++;

	gUseCl = i;

	if (!cl || cl->active)
		return NULL;

	host_client = cl;

	e = EDICT_NUM(i+1);
	return e;
}

void RemoveFakeClient(void) { //remove a bot from the highest used slot
	int			saveSelf;
	int			i;
	client_t	*client;
	int			MAX_CLIENTS = svs.maxclients;
	edict_t		*e = NULL;
	client_t	*cl = svs.clients;

	if (1 >= sv.max_edicts)
		return;

	for (i=MAX_CLIENTS ; i>=0 ; i--,cl=svs.clients+i)
	{
		if (cl && cl->active == true && cl->fakeclient == 1) {
			e = EDICT_NUM(i+1);

			if (cl && e) {
				sv_player = e;
				host_client = cl;
				break;
			}
		}

	}

	if (!cl || !e || !cl->fakeclient || !host_client || !sv_player || !host_client->fakeclient)
		return;

	host_client->fakeclient = 0;

	if (host_client->edict)
	{
		saveSelf = pr_global_struct->self;
		pr_global_struct->self = EDICT_TO_PROG(host_client->edict);
		PR_ExecuteProgram (pr_global_struct->ClientDisconnect);
		pr_global_struct->self = saveSelf;
	}

	sv_player->v.flags = 0;

	Sys_Printf ("Client %s removed\n",host_client->name);

	host_client->active = false;
	host_client->name[0] = 0;
	host_client->old_frags = -999999;

	for (i=0, client = svs.clients ; i<svs.maxclients ; i++, client++)
	{
		if (!client->active)
			continue;
		MSG_WriteByte (&client->message, svc_updatename);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteString (&client->message, "");
		MSG_WriteByte (&client->message, svc_updatefrags);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteShort (&client->message, 0);
		MSG_WriteByte (&client->message, svc_updatecolors);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteByte (&client->message, 0);
	}

	gBotNum--;

	if (gBotNum < 0)
		gBotNum = gBotTotal;
}

void SV_DropFakeClient() { //just drops host_client without finding a bot
	int			saveSelf;
	int			i;
	client_t	*client;
	int			MAX_CLIENTS = svs.maxclients;
	edict_t		*e = NULL;
	client_t	*cl = svs.clients;

	if (1 >= sv.max_edicts)
		return;

	for (i=MAX_CLIENTS ; i>=0 ; i--,cl=svs.clients+i)
	{
		if (cl && cl == host_client) {
			e = EDICT_NUM(i+1);

			if (cl && e) {
				sv_player = e;
				break;
			}
		}

	}

	if (!cl || !e || !cl->fakeclient || !host_client || !sv_player || !host_client->fakeclient)
		return;

	host_client->fakeclient = 0;

	if (host_client->edict)
	{
		saveSelf = pr_global_struct->self;
		pr_global_struct->self = EDICT_TO_PROG(host_client->edict);
		PR_ExecuteProgram (pr_global_struct->ClientDisconnect);
		pr_global_struct->self = saveSelf;
	}

	sv_player->v.flags = 0;

	Sys_Printf ("Client %s removed\n",host_client->name);

	host_client->active = false;
	host_client->name[0] = 0;
	host_client->old_frags = -999999;

	for (i=0, client = svs.clients ; i<svs.maxclients ; i++, client++)
	{
		if (!client->active)
			continue;
		MSG_WriteByte (&client->message, svc_updatename);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteString (&client->message, "");
		MSG_WriteByte (&client->message, svc_updatefrags);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteShort (&client->message, 0);
		MSG_WriteByte (&client->message, svc_updatecolors);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteByte (&client->message, 0);
	}
}

int SetBotInfo() { //sets info for host_client
	//This is a pathetic way to do this, but it's just a quick placeholder.
	//Rewrite it if you want (in fact, I recommend doing so).
	FILE *f;
	char buffer;
	int readlines = 0;
	int gotinfo = 0;
	char *placeread;
	int lineplace = 0;


	f = fopen("tsumi\\botinfo.txt", "r");

	if (!f) {
		strcpy(host_client->name, "Bot");
		host_client->botinfo.bottomcolor = 1;
		host_client->botinfo.topcolor = 1;
		host_client->botinfo.skills.accuracy = 10;
		host_client->botinfo.skills.yaw_speed = 90;
		host_client->botinfo.skills.intel = 4;
		return 1;
	}

	while(!feof(f)) {
		buffer = fgetc(f);
		if (buffer == '#') {
			while (buffer != '\n')
				buffer = fgetc(f);
		}
		else {
			if (readlines < gBotNum) {
				while (buffer && buffer != '\0' && buffer != '\n')
					buffer = fgetc(f);
				readlines++;
			}
			else if (readlines == gBotNum) {
				if (!buffer || buffer == -1) {
					return 0;
				}
				placeread = (char *)malloc(256);

				while (buffer != ' ') {
					placeread[lineplace] = buffer;
					lineplace++;
					buffer = fgetc(f);
				}
				placeread[lineplace] = '\0';
				strcpy(host_client->name, placeread);

				buffer = fgetc(f);
				lineplace = 0;
				while (buffer != ' ') {
					placeread[lineplace] = buffer;
					lineplace++;
					buffer = fgetc(f);
				}
				placeread[lineplace] = '\0';
				host_client->botinfo.topcolor = (int)strtod(placeread, NULL);

				buffer = fgetc(f);
				lineplace = 0;
				while (buffer != ' ') {
					placeread[lineplace] = buffer;
					lineplace++;
					buffer = fgetc(f);
				}
				placeread[lineplace] = '\0';
				host_client->botinfo.bottomcolor = (int)strtod(placeread, NULL);

				buffer = fgetc(f);
				lineplace = 0;
				while (buffer != ' ') {
					placeread[lineplace] = buffer;
					lineplace++;
					buffer = fgetc(f);
				}
				placeread[lineplace] = '\0';
				host_client->botinfo.skills.accuracy = (float)strtod(placeread, NULL);

				buffer = fgetc(f);
				lineplace = 0;
				while (buffer != ' ') {
					placeread[lineplace] = buffer;
					lineplace++;
					buffer = fgetc(f);
				}
				placeread[lineplace] = '\0';
				host_client->botinfo.skills.yaw_speed = (float)strtod(placeread, NULL);

				buffer = fgetc(f);
				lineplace = 0;
				while (buffer != ' ') {
					placeread[lineplace] = buffer;
					lineplace++;
					buffer = fgetc(f);
				}
				placeread[lineplace] = '\0';
				host_client->botinfo.skills.intel = (int)strtod(placeread, NULL);

				buffer = fgetc(f);
				lineplace = 0;
				while (buffer != '\n') {
					placeread[lineplace] = buffer;
					lineplace++;
					buffer = fgetc(f);
				}
				placeread[lineplace] = '\0';
				host_client->botinfo.skills.reflex = (float)strtod(placeread, NULL);

				free(placeread);

				gotinfo = 1;
				break;
			}
		}
	}

	if (!gotinfo) {
		fclose(f);
		return 0;
	}

	gBotNum++;

	fclose(f);
	return 1;
}

void CalculateBotNum() { //set gBotNum
	int i = 0;
	int bots = 0;
	client_t *client;

	for (i=0, client = svs.clients ; i<svs.maxclients ; i++, client++)
	{
		if (client && client->fakeclient)
			bots++;
	}

	if (gBotTotal && bots > gBotTotal)
		bots = bots - gBotTotal;

	gBotNum = bots;
}

void ClearHostAI() {
	host_client->botinfo.enemy = NULL;
	host_client->botinfo.shootat = NULL;
	host_client->botinfo.wp_dest = NULL;
	host_client->botinfo.wp_best = NULL;
	host_client->botinfo.wp_order = 0;
	host_client->botinfo.ideal_yaw = 0;
	host_client->botinfo.ideal_pitch = 0;
	host_client->botinfo.changeyaw_time = 0;
	host_client->botinfo.lastyawchange_time = 0;
	host_client->botinfo.jumptime = 0;
	host_client->botinfo.slidejumptime = 0;
	host_client->botinfo.wptimeout = 0;
	host_client->botinfo.wptroubleshoot = 0;
	host_client->botinfo.gointele = 0;
	host_client->botinfo.teleangles[0] = 0;
	host_client->botinfo.teleangles[1] = 0;
	host_client->botinfo.teleangles[2] = 0;
	host_client->botinfo.leavetime = 0;
	host_client->botinfo.leavestate = 0;
	host_client->botinfo.shootattime = 0;
	host_client->botinfo.fallbacktime = 0;
	host_client->botinfo.changeoffsettime = 0;
	host_client->botinfo.aimoffset = 0;
	host_client->botinfo.noisedist = 0;
	host_client->botinfo.madenoise = 0;
	host_client->botinfo.reflextime = 0;
	host_client->botinfo.alerttime = 0;
	host_client->botinfo.wchecktime = 0;
	host_client->botinfo.pushbutton = 0;
	host_client->botinfo.buttonangles[0] = 0;
	host_client->botinfo.buttonangles[1] = 0;
	host_client->botinfo.buttonangles[2] = 0;
}

void CreateFakeClient(void) { //call ED_ClientAlloc and do the rest of the
							  //spawn/connection stuff
	client_t *client;
	int i = 0;

	edict_t *ent = ED_ClientAlloc();

	if (!ent) {
		Con_SafePrintf("No client slots available.\n");
		return;
	}

	sv_player = ent;

	gFakeCl = 1;
	SV_ConnectClient(gUseCl);
	gFakeCl = 0;

	//go ahead and clear out the AI values
	ClearHostAI();

	memset (&ent->v, 0, progs->entityfields * 4);

	for (i=0 ; i< NUM_SPAWN_PARMS ; i++)
		(&pr_global_struct->parm1)[i] = host_client->spawn_parms[i];

	CalculateBotNum();

	if (!SetBotInfo()) {
		gBotTotal = gBotNum;
		gBotNum = 0;
		SetBotInfo();
	}

	ent->v.netname = host_client->name - pr_strings;

	pr_global_struct->time = sv.time;
	pr_global_struct->self = EDICT_TO_PROG(sv_player);
	PR_ExecuteProgram (pr_global_struct->ClientConnect);

	host_client->fakeclient = 1;

	PR_ExecuteProgram (pr_global_struct->PutClientInServer);	

	host_client->active = true;

	host_client->sendsignon = false;

	sv_player->v.flags += FL_FAKECLIENT;

	//formula is top*16+bottom
	host_client->colors = host_client->botinfo.topcolor*16+host_client->botinfo.bottomcolor;

	ent->v.colormap = NUM_FOR_EDICT(ent);
	ent->v.team = (host_client->colors & 15) + 1;

	for (i=0, client = svs.clients ; i<svs.maxclients ; i++, client++)
	{
		if (!client->active)
			continue;
		MSG_WriteByte (&client->message, svc_updatename);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteString (&client->message, host_client->name);
		MSG_WriteByte (&client->message, svc_updatefrags);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteShort (&client->message, host_client->old_frags);
		MSG_WriteByte (&client->message, svc_updatecolors);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteByte (&client->message, host_client->colors);
	}

	sv_player->v.fixangle = 0;
}

void RecreateFakeClient() { //host_client already exists, just make a place
							//for this guy in the world
	client_t *client;
	int i = 0;

	edict_t *ent = host_client->edict;

	if (!ent) {
		return;
	}

	sv_player = ent;

	//go ahead and clear out the AI values
	ClearHostAI();

	memset (&ent->v, 0, progs->entityfields * 4);

	for (i=0 ; i< NUM_SPAWN_PARMS ; i++)
		(&pr_global_struct->parm1)[i] = host_client->spawn_parms[i];

	ent->v.netname = host_client->name - pr_strings;

	pr_global_struct->time = sv.time;
	pr_global_struct->self = EDICT_TO_PROG(sv_player);
	PR_ExecuteProgram (pr_global_struct->ClientConnect);

	host_client->fakeclient = 1;

	PR_ExecuteProgram (pr_global_struct->PutClientInServer);	

	host_client->active = true;

	host_client->sendsignon = false;

	sv_player->v.flags += FL_FAKECLIENT;

	host_client->colors = host_client->botinfo.topcolor*16+host_client->botinfo.bottomcolor;

	ent->v.colormap = NUM_FOR_EDICT(ent);
	ent->v.team = (host_client->colors & 15) + 1;

	for (i=0, client = svs.clients ; i<svs.maxclients ; i++, client++)
	{
		if (!client->active)
			continue;
		MSG_WriteByte (&client->message, svc_updatename);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteString (&client->message, host_client->name);
		MSG_WriteByte (&client->message, svc_updatefrags);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteShort (&client->message, host_client->old_frags);
		MSG_WriteByte (&client->message, svc_updatecolors);
		MSG_WriteByte (&client->message, host_client - svs.clients);
		MSG_WriteByte (&client->message, host_client->colors);
	}

	sv_player->v.fixangle = 0;
}

void ReinitBots() {
	int MAX_CLIENTS = svs.maxclients;
	int			i;
	edict_t		*e;
	client_t *cl = svs.clients;

	//While we're at it, reset the global values and init the waypoint stuff.
	RGlb();

	gLoadWPs = 1;
	gLoadWPTime = sv.time;

	if (1 >= sv.max_edicts)
		return;

	for (i=0 ; i<=MAX_CLIENTS ; i++,cl=svs.clients+i)
	{
		if (cl && cl->active == true && cl->fakeclient == 1) {
			e = EDICT_NUM(i+1);

			if (cl && e) {
				sv_player = e;
				host_client = cl;
				RecreateFakeClient();
			}
		}
		else if (cl && cl->active == true) {
			cl->botinfo.noisedist = 0;
			cl->botinfo.madenoise = 0;
		}

	}
}

void BotFrameStart() { //cycle through clients, and make bot clients "think"
	int MAX_CLIENTS = svs.maxclients;
	int			i;
	edict_t		*e;
	client_t *cl = svs.clients;

	if (1 >= sv.max_edicts)
		return;

	//just a quick additional frame check for waypoints
	if (gLoadWPs && gLoadWPTime < sv.time) {
		gLoadWPs = 0;
		gLoadWPTime = 0;
		LoadWaypointFile();
	}

	//and draw them in edit mode:
	if (!gLoadWPs && gWPEditMode)
		WP_Draw();

	for (i=0 ; i<=MAX_CLIENTS ; i++,cl=svs.clients+i)
	{
		if (cl && cl->active == true && cl->fakeclient == 1) {
			e = EDICT_NUM(i+1);

			if (cl && e) {
				sv_player = e;
				if (!(int)e->v.flags & FL_FAKECLIENT)
					e->v.flags += FL_FAKECLIENT;

				//if gBotImpulse has a value, all bots will use it this frame
				if (gBotImpulse) {
					e->v.impulse = gBotImpulse;
				}

				BotAI_Main(cl, i);
			}
		}

	}

	//Reset gBotImpulse after the frame
	gBotImpulse = 0;
}


/*
=========================================
Waypoint/Utility functions.
=========================================
*/
void WP_Draw() { //draw waypoints as particles in edit mode
	int i = 0;
	vec3_t dir;

	if (gParticleDelay > sv.time)
		return;

	while (gWPCounter <= 4096) {
		if (gWPArray[gWPCounter].wpnum) {
			dir[0] = gWPArray[gWPCounter].origin[0];
			dir[1] = gWPArray[gWPCounter].origin[1];
			dir[2] = gWPArray[gWPCounter].origin[2] + 32;

			if (gWPArray[gWPCounter].glowme > sv.time)
				R_HighlightWP(gWPArray[gWPCounter].origin, 10);
			else if (gWPCounter == gWPNum-1)
				R_HighlightWP(gWPArray[gWPCounter].origin, 10);
			else
				R_HighlightWP(gWPArray[gWPCounter].origin, gWPArray[gWPCounter].wptype);
			gParticleDelay = sv.time + 0.1;
			i++;
		}
		
		if (i >= 8)
			break;

		gWPCounter++;
	}

	i = 0;

	while (i <= 4096) {
		if (gWPArray[i].wpnum && gWPArray[i].glowme > sv.time) {
			dir[0] = gWPArray[i].origin[0];
			dir[1] = gWPArray[i].origin[1];
			dir[2] = gWPArray[i].origin[2] + 32;
			R_HighlightWP(gWPArray[i].origin, 10);
		}

		i++;
	}

	if (gWPCounter > 4096)
		gWPCounter = 0;
}

void WP_Edit(void) { //toggle edit mode
	if (gWPSetEdit) {
		gWPSetEdit = 0;
		Con_SafePrintf("Waypoint edit mode disabled (after level restart).\n");
	}
	else {
		gWPSetEdit = 1;
		Con_SafePrintf("Waypoint edit mode enabled (after level restart).\n");
	}
}

void WP_Add_Type(int type) { //add a waypoint into the trail of a specified type
	edict_t *ent;
	int i = 0;

	ent = EDICT_NUM(1);

	if (!ent) //use first client to place waypoints
		return;

	if (!gWPEditMode)
		return;

	while (gWPArray[i].wpnum && i <= 4096) {
		i++;
	}

	if (i == 4096)
		return;

	gWPNum++;

	gWPArray[i].wpnum = gWPNum;
	gWPArray[i].wptype = type;
	gWPArray[i].origin[0] = ent->v.origin[0];
	gWPArray[i].origin[1] = ent->v.origin[1];
	gWPArray[i].origin[2] = ent->v.origin[2];
}

void MoveWPData(int from, int to) { //moves data from one slot to another
	gWPArray[to].glowme = gWPArray[from].glowme;
	gWPArray[to].disttonext = gWPArray[from].disttonext;
	gWPArray[to].iWeightVal = gWPArray[from].iWeightVal;
	gWPArray[to].wpnum = gWPArray[from].wpnum;
	gWPArray[to].wptype = gWPArray[from].wptype;
	gWPArray[to].origin[0] = gWPArray[from].origin[0];
	gWPArray[to].origin[1] = gWPArray[from].origin[1];
	gWPArray[to].origin[2] = gWPArray[from].origin[2];
}

void WP_Insert_Type(int type, int wpnum) { //insert into trail, rather than add
	edict_t *ent;
	int i = 0;
	int founddesired = 0;
	int foundit = 0;

	ent = EDICT_NUM(1);

	if (!ent) //use first client to place waypoints
		return;

	if (!gWPEditMode)
		return;

	while (gWPArray[i].wpnum && i <= 4096) {
		i++;
	}

	if (i == 4096)
		return;

	i = 0;

	while (i < gWPNum) {
		if (gWPArray[i].wpnum == wpnum) {
			founddesired = i;
			foundit = 1;
			break;
		}

		i++;
	}

	if (!foundit) {
		Con_SafePrintf("The waypoint number you entered does not exist.\n");
		return;
	}

	i = gWPNum-1;

	while (i != founddesired) {
		gWPArray[i].wpnum++;
		MoveWPData(i, i+1);
		i--;
	}

	gWPNum++;

	gWPArray[founddesired+1].wpnum = wpnum+1;
	gWPArray[founddesired+1].wptype = type;
	gWPArray[founddesired+1].origin[0] = ent->v.origin[0];
	gWPArray[founddesired+1].origin[1] = ent->v.origin[1];
	gWPArray[founddesired+1].origin[2] = ent->v.origin[2];
}

//WP_Add* functions are called as commands, then refer to the actual adding
//function with the proper argument(s)
void WP_Add(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_NORMAL, WPNum);
	else
		WP_Add_Type(WP_TYPE_NORMAL);
}

void WP_AddJ(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_JUMP, WPNum);
	else
		WP_Add_Type(WP_TYPE_JUMP);
}

void WP_AddPlat(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_PLATFORM, WPNum);
	else
		WP_Add_Type(WP_TYPE_PLATFORM);
}

void WP_AddNV(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_NOVIS, WPNum);
	else
		WP_Add_Type(WP_TYPE_NOVIS);
}

void WP_AddSS(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_SLIDE_START, WPNum);
	else
		WP_Add_Type(WP_TYPE_SLIDE_START);
}

void WP_AddSF(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_SLIDE_FINISH, WPNum);
	else
		WP_Add_Type(WP_TYPE_SLIDE_FINISH);
}

void WP_AddSOF(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_SLIDE_ONFOOT, WPNum);
	else
		WP_Add_Type(WP_TYPE_SLIDE_ONFOOT);
}

void WP_AddST(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_SLIDE_TELE, WPNum);
	else
		WP_Add_Type(WP_TYPE_SLIDE_TELE);
}

void WP_AddTele(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_TELEPORT, WPNum);
	else
		WP_Add_Type(WP_TYPE_TELEPORT);
}

void WP_AddOnlyFor(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_ONLYFORWARD, WPNum);
	else
		WP_Add_Type(WP_TYPE_ONLYFORWARD);
}

void WP_AddShootNear(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_SHOOTNEAROBJECT, WPNum);
	else
		WP_Add_Type(WP_TYPE_SHOOTNEAROBJECT);
}

void WP_AddCheck(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_CHECKUNDER, WPNum);
	else
		WP_Add_Type(WP_TYPE_CHECKUNDER);
}

void WP_AddButt(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_PUSHBUTTON, WPNum);
	else
		WP_Add_Type(WP_TYPE_PUSHBUTTON);
}

void WP_AddPickup(void) {
	int WPNum = 0;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum)
		WP_Insert_Type(WP_TYPE_PICKUP, WPNum);
	else
		WP_Add_Type(WP_TYPE_PICKUP);
}

void WP_Remove_Place(int wpnum) { //remove waypoint within trail
	int i = 0;
	int founddesired = 0;
	int foundit = 0;

	while (i < gWPNum) {
		if (gWPArray[i].wpnum == wpnum) {
			founddesired = i;
			foundit = 1;
			break;
		}

		i++;
	}

	if (!foundit) {
		Con_SafePrintf("The waypoint number you entered does not exist.\n");
		return;
	}

	gWPArray[founddesired].wpnum = 0;
	gWPArray[founddesired].wptype = 0;
	gWPArray[founddesired].glowme = 0;
	gWPArray[founddesired].disttonext = 0;
	gWPArray[founddesired].iWeightVal = 0;
	gWPArray[founddesired].origin[0] = 0;
	gWPArray[founddesired].origin[1] = 0;
	gWPArray[founddesired].origin[2] = 0;

	i = founddesired + 1;

	while (i < gWPNum) {
		gWPArray[i].wpnum--;
		MoveWPData(i, i-1);

		gWPArray[i].wpnum = 0;
		gWPArray[i].wptype = 0;
		gWPArray[i].glowme = 0;
		gWPArray[i].disttonext = 0;
		gWPArray[i].iWeightVal = 0;
		gWPArray[i].origin[0] = 0;
		gWPArray[i].origin[1] = 0;
		gWPArray[i].origin[2] = 0;

		i++;
	}

	gWPNum--;
}

void WP_Remove(void) { //remove waypoint
	int WPNum = 0;

	if (!gWPEditMode)
		return;

	if (gWPNum < 1)
		return;

	if (Cmd_Args()) {
		WPNum = (int)strtod(Cmd_Args(), NULL);	
	}

	if (WPNum) {
		WP_Remove_Place(WPNum);
		return;
	}

	gWPNum--;
	gWPArray[gWPNum].wpnum = 0;
	gWPArray[gWPNum].origin[0] = 0;
	gWPArray[gWPNum].origin[1] = 0;
	gWPArray[gWPNum].origin[2] = 0;
}

int CanTraceTo(vec3_t org1, vec3_t org2) { //waypoint trace function
	trace_t trace;

	trace = SV_Move(org1, vec3_origin, vec3_origin, org2, false, NULL);

	if (trace.fraction == 1.0)
		return 1;

	return 0;
}

void WP_Save(void) { //calculate various waypoint-related things and save the
					 //waypoint data file.
	char *tellstr;
	char *dirname;
	char *fname;
	int tellstri = 0;
	int gamediri = 0;
	FILE *f;
	int cli = 1;
	int	i = 0;
	int i_wp = 0;
	float disttonext = 0;
	edict_t *clen;
	vec3_t vecsub;
	int curpaths = 0;
	int maxpaths = 20;
	char *wp_data;
	char *wp_line;
	char *wp_arraychunk;
	float fllen = 0;

	if (!gWPEditMode)
		return;

	dirname = (char *)malloc(256);

	if (com_gamedir) {
		tellstr = (char *)malloc(256);
		gamediri = strlen(com_gamedir);
		while (com_gamedir[gamediri] != '/') {
			gamediri--;
		}
		gamediri++;

		while (com_gamedir[gamediri] && com_gamedir[gamediri] != '\0') {
			tellstr[tellstri] = com_gamedir[gamediri];
			tellstri++;
			gamediri++;
		}
		tellstr[tellstri] = '\0';

		sprintf(dirname, "tsumi\\navdata\\%s\0", tellstr);

		free(tellstr);
	}
	else
		return;

	if (_chdir(dirname)) {
		if (_mkdir(dirname)) {
			Con_SafePrintf("ERROR CREATING FOLDER\n");
			free(dirname);
			gWPEditMode = 0;
			return;
		}
	}
	else {
		_chdir("..");
		_chdir("..");
		_chdir("..");
	}

	fname = (char *)malloc(256);

	sprintf(fname, "%s\\%s.tbr\0", dirname, sv.name);

	free(dirname);

	f = fopen(fname, "w+");

	if (!f) {
		free(fname);
		return;
	}

	free(fname);

	wp_data = (char *)malloc(262144); //This is another terrible thing to do.
									  //I suggest redoing it, but it works.
	wp_line = (char *)malloc(4096); //Probably doesn't need to be this large.
	wp_arraychunk = (char *)malloc(4096); //Ditto.

	sprintf(wp_data, "\0");

	//Make players unhittable by traces for the position checking
	while (i <= svs.maxclients) {
		clen = EDICT_NUM(i);

		if (clen) {
			clen->v.solid = SOLID_NOT;
			clen->v.origin[0] = 0;
			clen->v.origin[1] = 0;
			clen->v.origin[2] = 0;
		}

		i++;
	}

	i = 0;

	//Read data from array and calculate nearby points
	while (i < gWPNum) {
		if (gWPArray[i].wpnum) {
			curpaths = 0;
			i_wp = 0;
			disttonext = 0;

			while (i_wp < gWPNum) {
				if (gWPArray[i_wp].wpnum == gWPArray[i].wpnum+1) {
					VectorSubtract(gWPArray[i_wp].origin, gWPArray[i].origin, vecsub);
					disttonext = bot_vlen(vecsub);
					break;
				}
				i_wp++;
			}

			i_wp = 0;

			sprintf(wp_line, "%i %i (%f %f %f) %f { ", gWPArray[i].wpnum, gWPArray[i].wptype, gWPArray[i].origin[0], gWPArray[i].origin[1], gWPArray[i].origin[2], disttonext);

			while (i_wp < gWPNum) {
				if (gWPArray[i_wp].wpnum) {
					VectorSubtract(gWPArray[i_wp].origin, gWPArray[i].origin, vecsub);
					fllen = bot_vlen(vecsub);

					if (fllen < 150 &&
						gWPArray[i].wpnum != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum+1) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum+2) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum+3) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum+4) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum+5) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum-1) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum-2) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum-3) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum-4) != gWPArray[i_wp].wpnum &&
						(gWPArray[i].wpnum-5) != gWPArray[i_wp].wpnum &&
						gWPArray[i].origin[2] < (gWPArray[i_wp].origin[2]+5) &&
						gWPArray[i].origin[2] > (gWPArray[i_wp].origin[2]-5) &&
						CanTraceTo(gWPArray[i].origin, gWPArray[i_wp].origin))
					{
						sprintf(wp_arraychunk, "%i %f \0", gWPArray[i_wp].wpnum, fllen);
						Q_strcat(wp_line, wp_arraychunk);
						curpaths++;
					}
				}

				if (curpaths == maxpaths)
					break;

				i_wp++;
			}

			Q_strcat(wp_line, "}\n");

			Q_strcat(wp_data, wp_line);
		}
		i++;
	}

	fwrite(wp_data, strlen(wp_data), 1, f);

	free(wp_arraychunk);
	free(wp_data);
	free(wp_line);
	fclose(f);

	gWPSetEdit = 0;
	Host_Restart_f();
}

void WP_TeleTo(void) { //teleport to last waypoint in trail
	edict_t *ent;

	ent = EDICT_NUM(1);

	if (!ent)
		return;

	if (!gWPEditMode)
		return;

	if (gWPArray[gWPNum-1].wpnum) {
		ent->v.origin[0] = gWPArray[gWPNum-1].origin[0];
		ent->v.origin[1] = gWPArray[gWPNum-1].origin[1];
		ent->v.origin[2] = gWPArray[gWPNum-1].origin[2];
	}
}

char *TypeToString(int type) { //Rather than just printing a number
	if (type == WP_TYPE_NORMAL) {
		return "Standard";
	}
	else if (type == WP_TYPE_JUMP) {
		return "Jump";
	}
	else if (type == WP_TYPE_PLATFORM) {
		return "Platform";
	}
	else if (type == WP_TYPE_NOVIS) {
		return "Force Visbility";
	}
	else if (type == WP_TYPE_SLIDE_START) {
		return "Slide Start Point";
	}
	else if (type == WP_TYPE_SLIDE_FINISH) {
		return "Slide Finish Point";
	}
	else if (type == WP_TYPE_SLIDE_ONFOOT) {
		return "Slide Walk Point";
	}
	else if (type == WP_TYPE_SLIDE_TELE) {
		return "Slide Teleport Point";
	}
	else if (type == WP_TYPE_TELEPORT) {
		return "Teleport Point";
	}
	else if (type == WP_TYPE_ONLYFORWARD) {
		return "Forward-only Point";
	}
	else if (type == WP_TYPE_SHOOTNEAROBJECT) {
		return "Object Destruction Point";
	}
	else if (type == WP_TYPE_CHECKUNDER) {
		return "Check-under Point";
	}
	else if (type == WP_TYPE_PUSHBUTTON) {
		return "Pushbutton Point";
	}
	else if (type == WP_TYPE_PICKUP) {
		return "Trail Pickup Point";
	}
	else {
		return "Undefined Type";
	}
}

void WP_ShowInfo(void) { //display information in the console for the nearest
						 //waypoint, and highlight that point for a second.
	vec3_t sub;
	int i = 0;
	float bestlen = 99999999999;
	float checklen = 0;
	int bestnum = 0;
	int foundone = 0;
	edict_t *ent;

	ent = EDICT_NUM(1);

	if (!ent)
		return;

	if (!gWPEditMode)
		return;

	while (i < gWPNum) {
		if (gWPArray[i].wpnum) {
			VectorSubtract(ent->v.origin, gWPArray[i].origin, sub);
			checklen = bot_vlen(sub);

			if (checklen < bestlen) {
				foundone = 1;
				bestlen = checklen;
				bestnum = i;
			}
		}
		i++;
	}

	if (foundone) {
		gWPArray[bestnum].glowme = sv.time + 1;
		Con_SafePrintf("\nWaypoint information:\nNumber: %i\nType: %s\n\n", gWPArray[bestnum].wpnum, TypeToString(gWPArray[bestnum].wptype));
	}
}

char *GetGameDir() { //cuts out the unneeded stuff and returns the game dir
	char *tellstr;
	int tellstri = 0;
	int gamediri = 0;

	tellstr = (char *)malloc(256);
	gamediri = strlen(com_gamedir);
	while (com_gamedir[gamediri] != '/') {
		gamediri--;
	}
	gamediri++;

	while (com_gamedir[gamediri] && com_gamedir[gamediri] != '\0') {
		tellstr[tellstri] = com_gamedir[gamediri];
		tellstri++;
		gamediri++;
	}
	tellstr[tellstri] = '\0';

	return tellstr;
}

void TearLineApart(char *wpdata) { //Takes lines of waypoint data in string
								   //format and turns it into a real waypoint.
	int i = 0;
	char *in_buffer;
	int in_i = 0;

	in_buffer = (char *)malloc(1024);

	while (wpdata[i] != ' ') {
		in_buffer[in_i] = wpdata[i];
		in_i++;
		i++;
	}
	in_buffer[in_i] = '\0';
	i++;
	in_i = 0;

	gWPArray[gWPNum].wpnum = (int)strtod(in_buffer, NULL);

	while (wpdata[i] != ' ') {
		in_buffer[in_i] = wpdata[i];
		in_i++;
		i++;
	}
	in_buffer[in_i] = '\0';
	i++;
	i++;
	in_i = 0;

	gWPArray[gWPNum].wptype = (int)strtod(in_buffer, NULL);

	while (wpdata[i] != ' ') {
		in_buffer[in_i] = wpdata[i];
		in_i++;
		i++;
	}
	in_buffer[in_i] = '\0';
	i++;
	in_i = 0;

	gWPArray[gWPNum].origin[0] = (float)strtod(in_buffer, NULL);

	while (wpdata[i] != ' ') {
		in_buffer[in_i] = wpdata[i];
		in_i++;
		i++;
	}
	in_buffer[in_i] = '\0';
	i++;
	in_i = 0;

	gWPArray[gWPNum].origin[1] = (float)strtod(in_buffer, NULL);

	while (wpdata[i] != ' ') {
		in_buffer[in_i] = wpdata[i];
		in_i++;
		i++;
	}
	in_buffer[in_i] = '\0';
	i++;
	i++;
	in_i = 0;

	gWPArray[gWPNum].origin[2] = (float)strtod(in_buffer, NULL);

	while (wpdata[i] != ' ') {
		in_buffer[in_i] = wpdata[i];
		in_i++;
		i++;
	}
	in_buffer[in_i] = '\0';
	i++;
	i++;
	i++;
	in_i = 0;

	gWPArray[gWPNum].disttonext = (float)strtod(in_buffer, NULL);

	while (wpdata[i] != '}') {
		while (wpdata[i] != ' ') {
			in_buffer[in_i] = wpdata[i];
			in_i++;
			i++;
		}
		in_buffer[in_i] = '\0';
		gWPArray[gWPNum].nearby[gWPArray[gWPNum].nearbyi].wpnum = (int)strtod(in_buffer, NULL);
		in_i = 0;
		i++;
		while (wpdata[i] != ' ') {
			in_buffer[in_i] = wpdata[i];
			in_i++;
			i++;
		}
		in_buffer[in_i] = '\0';
		gWPArray[gWPNum].nearby[gWPArray[gWPNum].nearbyi].wpdist = (float)strtod(in_buffer, NULL);
		in_i = 0;
		gWPArray[gWPNum].nearbyi++;
		i++;
	}
	gWPNum++;
	free(in_buffer);
}

void LoadWaypointFile() { //Checks for a waypoint file for this level.
						  //If it exists, file is read in and fed to the
						  //above function.
	char *tellstr;
	char *dirname;
	char *fname;
	char *thisline;
	char buffer;
	int thislinei = 0;
	int tellstri = 0;
	int gamediri = 0;
	FILE *f;

	dirname = (char *)malloc(512);

	if (com_gamedir) {
		tellstr = (char *)malloc(512);
		gamediri = strlen(com_gamedir);
		while (com_gamedir[gamediri] != '/') {
			gamediri--;
		}
		gamediri++;

		while (com_gamedir[gamediri] && com_gamedir[gamediri] != '\0') {
			tellstr[tellstri] = com_gamedir[gamediri];
			tellstri++;
			gamediri++;
		}
		tellstr[tellstri] = '\0';

		sprintf(dirname, "tsumi\\navdata\\%s\0", tellstr);

		free(tellstr);
	}
	else
		return;

	if (_chdir(dirname)) {
		Con_SafePrintf("There is no path data for this mod.\n");
		Con_SafePrintf("The data will be placed in:\n");
		Con_SafePrintf("%s\n", dirname);

		if (_mkdir(dirname)) {
			Con_SafePrintf("ERROR CREATING FOLDER\n");
			free(dirname);
			gWPEditMode = 0;
			return;
		}
	}
	else {
		_chdir("..");
		_chdir("..");
		_chdir("..");
	}

	fname = (char *)malloc(512);

	sprintf(fname, "%s\\%s.tbr\0", dirname, sv.name);

	free(dirname);

	f = fopen(fname, "r");

	if (!f) {
		Con_SafePrintf("No route file for this level.\n");
		Con_SafePrintf("Waypoint edit mode enabled.\n");
		gWPEditMode = 1;
		free(fname);
		return;
	}

	free(fname);

	if (gWPSetEdit)
		gWPEditMode = 1;
	else
		gWPEditMode = 0;

	thisline = (char *)malloc(4096); //=)

	while (!feof(f)) {
		buffer = fgetc(f);

		if (!buffer || buffer == -1)
			break;

		thislinei = 0;

		while (buffer != '\n') {
			thisline[thislinei] = buffer;
			thislinei++;
			buffer = fgetc(f);
		}
		thisline[thislinei] = '\0';
		TearLineApart(thisline);
	}

	fclose(f);

	free(thisline);
}

void RGlb() { //Reset the global values between level changes.
	int i = 0;
	int i_n = 0;

	gUseCl = 0;
	gFakeCl = 0;
	//gBotNum = 0; (leave botnum as-is, because bots are carried over levels)
	//gBotTotal = 0; (ditto)
	//gWPEditMode = 0; (set elsewhere)
	//gLoadWPs = 0; (ditto)
	//gLoadWPTime = 0; (ditto)

	gWPNum = 0;
	gBotImpulse = 0;
	gParticleDelay = 0;
	gWPCounter = 0;

	//Clear out the waypoint array:
	while (i <= 4095) {
		gWPArray[i].glowme = 0;
		gWPArray[i].disttonext = 0;
		gWPArray[i].iWeightVal = 0;
		gWPArray[i].wpnum = 0;
		gWPArray[i].wptype = 0;
		gWPArray[i].origin[0] = 0;
		gWPArray[i].origin[1] = 0;
		gWPArray[i].origin[2] = 0;
		gWPArray[i].nearbyi = 0;
		i_n = 0;
		while (i_n <= 31) {
			gWPArray[i].nearby[i_n].wpnum = 0;
			gWPArray[i].nearby[i_n].wpdist = 0;
			i_n++;
		}

		i++;
	}
	return;
}

//Most of the following are just math and utility functions
float bot_vlen (vec3_t value1)
{
	float	new;
	
	new = value1[0] * value1[0] + value1[1] * value1[1] + value1[2]*value1[2];
	new = sqrt(new);
	
	return new;
}

float bot_vectoyaw (vec3_t value1)
{
	float	yaw;
	
	if (value1[1] == 0 && value1[0] == 0)
		yaw = 0;
	else
	{
		yaw = (int) (atan2(value1[1], value1[0]) * 180 / M_PI);
		if (yaw < 0)
			yaw += 360;
	}

	return yaw;
}

void bot_vectoangles (vec3_t value1, vec3_t output)
{
	float	forward;
	float	yaw, pitch;
	
	if (value1[1] == 0 && value1[0] == 0)
	{
		yaw = 0;
		if (value1[2] > 0)
			pitch = 90;
		else
			pitch = 270;
	}
	else
	{
		yaw = (int) (atan2(value1[1], value1[0]) * 180 / M_PI);
		if (yaw < 0)
			yaw += 360;

		forward = sqrt (value1[0]*value1[0] + value1[1]*value1[1]);
		pitch = (int) (atan2(value1[2], forward) * 180 / M_PI);
		if (pitch < 0)
			pitch += 360;
	}

	output[PITCH] = pitch;
	output[YAW] = yaw;
	output[ROLL] = 0;
}

void bot_changeyaw (float override_yaw, float override_speed)
{
	edict_t		*ent;
	float		ideal, current, move, speed;
	
	if (!override_yaw)
		override_yaw = host_client->botinfo.ideal_yaw;

	if (!override_speed)
		override_speed = host_client->botinfo.skills.yaw_speed;

	ent = sv_player;
	current = anglemod( ent->v.v_angle[1] );
	ideal = override_yaw;
	speed = override_speed;
	
	if (current == ideal)
		return;
	move = ideal - current;
	if (ideal > current)
	{
		if (move >= 180)
			move = move - 360;
	}
	else
	{
		if (move <= -180)
			move = move + 360;
	}
	if (move > 0)
	{
		if (move > speed)
			move = speed;
	}
	else
	{
		if (move < -speed)
			move = -speed;
	}
	
	ent->v.v_angle[1] = anglemod (current + move);
}

client_t *GetMatchingClientForEdict(edict_t *ent) {
	int			MAX_CLIENTS = svs.maxclients;
	int			i = 0;
	edict_t		*e;
	client_t	*cl = svs.clients;
	int			found = 0;

	if (!ent || !((int)ent->v.flags & FL_CLIENT))
		return NULL;

	if (1 >= sv.max_edicts)
		return NULL;

	for (i=0 ; i<=MAX_CLIENTS ; i++,cl=svs.clients+i)
	{
		if (cl && cl->active == true) {
			e = cl->edict;

			if (cl && e && ent == e) {
				found = 1;
				break;
			}
		}
	}

	if (!found)
		return NULL;

	return cl;
}

void Bot_SoundWasMade(edict_t *ent, int channel, int volume) {
	//Register a sound a client made for the bot to check on
	int			MAX_CLIENTS = svs.maxclients;
	int			i = 0;
	edict_t		*e;
	client_t	*cl = svs.clients;
	int			found = 0;

	if (!ent || !((int)ent->v.flags & FL_CLIENT))
		return;

	cl = GetMatchingClientForEdict(ent);

	if (!cl)
		return;

	cl->botinfo.madenoise = sv.time + 0.5;
	cl->botinfo.noisedist = (float)volume*3; //seems fair to me
}

int ClientMadeNoise(client_t *cl, edict_t *cle) {
	//Did this client make a noise? If so, are we close enough to hear it?
	vec3_t hostdist;

	if (!cl && !cle)
		return 0;

	if (!cl) { //didn't supply a client, so find it using the edict
		cl = GetMatchingClientForEdict(cle);

		if (!cl)
			return 0;
	}

	if (cl->botinfo.madenoise < sv.time)
		return 0;

	VectorSubtract(cl->edict->v.origin, host_client->edict->v.origin, hostdist);

	if (bot_vlen(hostdist) <= cl->botinfo.noisedist)
		return 1;

	return 0;
}

int Bot_CanTraceTo(vec3_t org) { //the bot's visibility function
	vec3_t orgup;
	trace_t trace;

	trace = SV_Move(host_client->edict->v.origin, vec3_origin, vec3_origin, org, true, host_client->edict);

	if (trace.fraction == 1.0)
		return 1;

	orgup[0] = host_client->edict->v.origin[0];
	orgup[1] = host_client->edict->v.origin[1];
	orgup[2] = host_client->edict->v.origin[2]+16;

	trace = SV_Move(orgup, vec3_origin, vec3_origin, org, true, host_client->edict);

	if (trace.fraction == 1.0)
		return 1;

	return 0;
}

int Bot_CanTraceToFirst(vec3_t org) { //the bot's visibility function
	trace_t trace;

	trace = SV_Move(host_client->edict->v.origin, vec3_origin, vec3_origin, org, MOVE_NORMAL, host_client->edict);
	//don't ignore monsters when going to the first waypoint

	if (trace.fraction == 1.0)
		return 1;

	return 0;
}

void Bot_DestroyObstacles(vec3_t org) {
	trace_t trace_shoot;

	trace_shoot = SV_Move(host_client->edict->v.origin, vec3_origin, vec3_origin, org, false, host_client->edict);

	if (trace_shoot.ent &&
		trace_shoot.ent->v.health > 0 &&
		trace_shoot.ent->v.takedamage != DAMAGE_NO &&
		!((int)trace_shoot.ent->v.flags & FL_CLIENT)) {
		if (!host_client->botinfo.shootat)
			host_client->botinfo.shootat = trace_shoot.ent;
	}
}

void Bot_PushButtons() {
	vec3_t v_for, v_right, v_up, trto;
	trace_t trace_shoot;

	if (host_client->botinfo.pushbutton > sv.time)
		return;

	AngleVectors(host_client->edict->v.v_angle, v_for, v_right, v_up);

	trto[0] = host_client->edict->v.origin[0] + v_for[0]*128;
	trto[1] = host_client->edict->v.origin[1] + v_for[1]*128;
	trto[2] = host_client->edict->v.origin[2] + v_for[2]*128;

	trace_shoot = SV_Move(host_client->edict->v.origin, vec3_origin, vec3_origin, trto, false, host_client->edict);

	if (trace_shoot.ent &&
		trace_shoot.ent->v.classname &&
		(strstr(pr_strings+trace_shoot.ent->v.classname, "trigger_") ||
		strstr(pr_strings+trace_shoot.ent->v.classname, "button")))
	{
		host_client->botinfo.pushbutton = sv.time + 0.5;
		host_client->botinfo.buttonangles[0] = host_client->edict->v.v_angle[0];
		host_client->botinfo.buttonangles[1] = host_client->edict->v.v_angle[1];
		host_client->botinfo.buttonangles[2] = host_client->edict->v.v_angle[2];
	}
}

int Bot_ObjectInFront() { //see if we should strafe
	vec3_t fororg;
	vec3_t trorg;
	vec3_t v_forward, v_right, v_up, vectemp;
	vec3_t angyaw;
	trace_t trace;
	vec3_t mins;
	vec3_t maxs;

	mins[0] = 0; //-16
	mins[1] = 0; //-16
	mins[2] = host_client->edict->v.mins[2]; //-24
	maxs[0] = 1; //16
	maxs[1] = 1; //16
	maxs[2] = host_client->edict->v.maxs[2]; //32

	angyaw[YAW] = host_client->edict->v.v_angle[YAW];
	angyaw[PITCH] = 0;
	angyaw[ROLL] = 0;

	AngleVectors(angyaw, v_forward, v_right, v_up);

	trorg[0] = host_client->edict->v.origin[0];
	trorg[1] = host_client->edict->v.origin[1];
	trorg[2] = host_client->edict->v.origin[2];

	fororg[0] = (trorg[0] + v_forward[0]*(18)) + v_right[0]*(16);
	fororg[1] = (trorg[1] + v_forward[1]*(18)) + v_right[1]*(16);
	fororg[2] = (trorg[2] + v_forward[2]*(18)) + v_right[2]*(16);

	trace = SV_Move(trorg, mins, maxs, fororg, false, host_client->edict);

	if (trace.fraction != 1)
		return 2;

	fororg[0] = (trorg[0] + v_forward[0]*(18)) - v_right[0]*(16);
	fororg[1] = (trorg[1] + v_forward[1]*(18)) - v_right[1]*(16);
	fororg[2] = (trorg[2] + v_forward[2]*(18)) - v_right[2]*(16);

	trace = SV_Move(trorg, mins, maxs, fororg, false, host_client->edict);

	if (trace.fraction != 1)
		return 1;

	fororg[0] = (trorg[0] + v_forward[0]*(18));
	fororg[1] = (trorg[1] + v_forward[1]*(18));
	fororg[2] = (trorg[2] + v_forward[2]*(18));

	trace = SV_Move(trorg, mins, maxs, fororg, false, host_client->edict);

	if (trace.fraction != 1)
		return 3;

	return 0;
}

int Bot_ObjectAtFeet() { //see if we should jump
	vec3_t fororg;
	vec3_t trorg;
	vec3_t v_forward, v_right, v_up, vectemp;
	vec3_t angyaw;
	trace_t trace;
	vec3_t mins;
	vec3_t maxs;

	mins[0] = 0; //-16
	mins[1] = 0; //-16
	mins[2] = 0; //-24
	maxs[0] = 0; //16
	maxs[1] = 0; //16
	maxs[2] = 0; //32

	angyaw[YAW] = host_client->edict->v.v_angle[YAW];
	angyaw[PITCH] = 0;
	angyaw[ROLL] = 0;

	AngleVectors(angyaw, v_forward, v_right, v_up);

	trorg[0] = host_client->edict->v.origin[0];
	trorg[1] = host_client->edict->v.origin[1];
	trorg[2] = host_client->edict->v.origin[2];

	fororg[0] = trorg[0] + v_forward[0]*(20);
	fororg[1] = trorg[1] + v_forward[1]*(20);
	fororg[2] = trorg[2] + v_forward[2]*(20);

	trace = SV_Move(trorg, mins, maxs, fororg, false, host_client->edict);

	if (trace.fraction == 1) {
		trorg[0] = fororg[0];
		trorg[1] = fororg[1];
		trorg[2] = fororg[2]-14;

		trace = SV_Move(fororg, mins, maxs, trorg, false, host_client->edict);

		if (trace.fraction == 1)
			return 0;
	}

	trorg[0] = host_client->edict->v.origin[0];
	trorg[1] = host_client->edict->v.origin[1];
	trorg[2] = host_client->edict->v.origin[2];
	trorg[2] += 16;

	fororg[0] = trorg[0] + v_forward[0]*(20);
	fororg[1] = trorg[1] + v_forward[1]*(20);
	fororg[2] = trorg[2] + v_forward[2]*(20);

	trace = SV_Move(trorg, mins, maxs, fororg, false, host_client->edict);

	if (trace.fraction == 1)
		return 1;

	return 0;
}

int NoEntUnder(vec3_t org) {
	trace_t trace;
	vec3_t trorg;
	trorg[0] = org[0];
	trorg[1] = org[1];
	trorg[2] = org[2] - 40;

	trace = SV_Move(org, vec3_origin, vec3_origin, trorg, false, NULL);

	if (trace.fraction != 1)
		return 0;

	return 1;
}

void TryPickup() {
	int i = 0;
	vec3_t vecsub;

	while (i < gWPNum) {
		if (gWPArray[i].wpnum && gWPArray[i].wptype == WP_TYPE_PICKUP) {
			VectorSubtract(host_client->edict->v.origin, gWPArray[i].origin, vecsub);
			if (bot_vlen(vecsub) < 128 && Bot_CanTraceToFirst(gWPArray[i].origin)) {
				host_client->botinfo.wp_dest = &gWPArray[i];
			}
		}
		i++;
	}
}

void GetNextWP() { //standard routine for getting the next waypoint in the
				   //trail
	int i = 0;
	int goalnum = 0;
	int foundit = 0;

	if (!host_client->botinfo.wp_order) {
		goalnum = host_client->botinfo.wp_dest->wpnum + 1;
	}
	else
		goalnum = host_client->botinfo.wp_dest->wpnum - 1;

	while (i < gWPNum) {
		if (gWPArray[i].wpnum == goalnum) {
			foundit = 1;
			host_client->botinfo.wp_dest = &gWPArray[i];
			if (host_client->botinfo.wp_dest->wptype == WP_TYPE_NOVIS)
				host_client->botinfo.wptroubleshoot = sv.time + 5;
			else
				host_client->botinfo.wptroubleshoot = sv.time + 15;
			break;
		}
		i++;
	}

	if (!foundit) {
		if (!host_client->botinfo.wp_order)
			host_client->botinfo.wp_order = 1;
		else
			host_client->botinfo.wp_order = 0;
	}
	else if (foundit && host_client->botinfo.wp_dest->wptype == WP_TYPE_CHECKUNDER && NoEntUnder(host_client->botinfo.wp_dest->origin)) {
		if (!host_client->botinfo.wp_order)
			host_client->botinfo.wp_order = 1;
		else
			host_client->botinfo.wp_order = 0;
		host_client->botinfo.wp_dest = NULL;
	}
	else if (foundit && host_client->botinfo.wp_dest->wptype == WP_TYPE_ONLYFORWARD && host_client->botinfo.wp_order) {
		host_client->botinfo.wp_order = 0;
		host_client->botinfo.wp_dest = NULL;
	}
	else if (foundit && host_client->botinfo.wp_dest->wptype == WP_TYPE_SHOOTNEAROBJECT && !SuitableBrushWeapon()) {
		if (!host_client->botinfo.wp_order)
			host_client->botinfo.wp_order = 1;
		else
			host_client->botinfo.wp_order = 0;
	}
	else {
		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_NOVIS)
			host_client->botinfo.wptroubleshoot = sv.time + 5;
		else
			host_client->botinfo.wptroubleshoot = sv.time + 15;
		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_TELEPORT)
			host_client->botinfo.wptimeout = sv.time + 3;
		else if (host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_TELE)
			host_client->botinfo.wptimeout = sv.time + 6;
	}
}

void GetNextWP_Slide() { //same as above, but changed for Slide
	int i = 0;
	int goalnum = 0;
	int foundit = 0;

	if (!host_client->botinfo.wp_order) {
		goalnum = host_client->botinfo.wp_dest->wpnum + 1;
	}
	else
		goalnum = host_client->botinfo.wp_dest->wpnum - 1;

	while (i < gWPNum) {
		if (gWPArray[i].wpnum == goalnum) {
			foundit = 1;
			host_client->botinfo.wp_dest = &gWPArray[i];
			if (host_client->botinfo.wp_dest->wptype == WP_TYPE_NOVIS)
				host_client->botinfo.wptroubleshoot = sv.time + 5;
			else
				host_client->botinfo.wptroubleshoot = sv.time + 15;
			break;
		}
		i++;
	}

	if (!foundit) {
		host_client->botinfo.wp_dest = NULL;
	}
	else {
		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_NOVIS)
			host_client->botinfo.wptroubleshoot = sv.time + 5;
		else
			host_client->botinfo.wptroubleshoot = sv.time + 15;
		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_TELEPORT)
			host_client->botinfo.wptimeout = sv.time + 3;
		else if (host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_TELE)
			host_client->botinfo.wptimeout = sv.time + 6;
	}
}

int PassedLedgeCheck(vec3_t org) {
	vec3_t v_forward, v_right, v_up;
	vec3_t vecsub;
	float dist = 0;
	vec3_t traceat;
	vec3_t traceorg, tracedown;
	trace_t trace;
	float contents;
	vec3_t checkendpos;

	VectorSubtract(org, host_client->edict->v.origin, vecsub);
	dist = bot_vlen(vecsub)/2;

	traceat[PITCH] = 0;
	traceat[ROLL] = 0;
	traceat[YAW] = bot_vectoyaw(vecsub);

	AngleVectors(traceat, v_forward, v_right, v_up);

	traceorg[0] = host_client->edict->v.origin[0] + v_forward[0]*dist;
	traceorg[1] = host_client->edict->v.origin[1] + v_forward[1]*dist;
	traceorg[2] = host_client->edict->v.origin[2] + v_forward[2]*dist;

	tracedown[0] = traceorg[0];
	tracedown[1] = traceorg[1];
	tracedown[2] = traceorg[2] - 40;

	trace = SV_Move(traceorg, vec3_origin, vec3_origin, tracedown, true, NULL);

	if (trace.fraction == 1)
		return 0;
	else {
		checkendpos[0] = trace.endpos[0];
		checkendpos[1] = trace.endpos[1];
		checkendpos[2] = trace.endpos[2];

		contents = SV_PointContents(checkendpos);

		if (contents == CONTENTS_SLIME || contents == CONTENTS_LAVA)
			return 0;

		checkendpos[0] = trace.endpos[0];
		checkendpos[1] = trace.endpos[1];
		checkendpos[2] = trace.endpos[2] + 1;

		contents = SV_PointContents(checkendpos);

		if (contents == CONTENTS_SLIME || contents == CONTENTS_LAVA)
			return 0;

		checkendpos[0] = trace.endpos[0];
		checkendpos[1] = trace.endpos[1];
		checkendpos[2] = trace.endpos[2] - 1;

		contents = SV_PointContents(checkendpos);

		if (contents == CONTENTS_SLIME || contents == CONTENTS_LAVA)
			return 0;
	}

	return 1;
}

void GetNearestVisibleWP() { //don't have a waypoint? Get one.
	int i = 0;
	vec3_t vecsub;
	float checklen = 0;
	float bestlen = 512;
	int bestindex = 0;
	int found = 0;

	while (i < gWPNum) {
		if (gWPArray[i].wpnum && gWPArray[i].wptype != WP_TYPE_TELEPORT && gWPArray[i].wptype != WP_TYPE_SLIDE_TELE && gWPArray[i].wptype != WP_TYPE_CHECKUNDER) {
			//It's generally not a good idea to start a trail on a teleport
			VectorSubtract(host_client->edict->v.origin, gWPArray[i].origin, vecsub);
			checklen = bot_vlen(vecsub);
			if (checklen < bestlen && host_client->edict->v.origin[2] > gWPArray[i].origin[2]-25 && host_client->edict->v.origin[2] < gWPArray[i].origin[2]+25 &&
				Bot_CanTraceToFirst(gWPArray[i].origin) &&
				PassedLedgeCheck(gWPArray[i].origin)) {
				bestlen = checklen;
				bestindex = i;
				found = 1;
			}
		}
		i++;
	}

	if (found) {
		host_client->botinfo.wp_dest = &gWPArray[bestindex];
		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_NOVIS)
			host_client->botinfo.wptroubleshoot = sv.time + 5;
		else
			host_client->botinfo.wptroubleshoot = sv.time + 15;
	}
}

void GetNearestVisibleWP_Slide() { //same as above, customized for Slide
	int i = 0;
	vec3_t vecsub;
	float checklen = 0;
	float bestlen = 1024;
	int bestindex = 0;
	int found = 0;

	while (i < gWPNum) {
		if (gWPArray[i].wpnum && gWPArray[i].wptype != WP_TYPE_TELEPORT && gWPArray[i].wptype != WP_TYPE_SLIDE_TELE && gWPArray[i].wptype != WP_TYPE_CHECKUNDER) {
			//It's generally not a good idea to start a trail on a teleport
			VectorSubtract(host_client->edict->v.origin, gWPArray[i].origin, vecsub);
			checklen = bot_vlen(vecsub);
			if ((checklen < bestlen || gWPArray[i].wptype == WP_TYPE_SLIDE_START) && Bot_CanTraceTo(gWPArray[i].origin)) {
				bestlen = checklen;
				bestindex = i;
				found = 1;
				if (gWPArray[i].wptype == WP_TYPE_SLIDE_START)
					break;
			}
		}
		i++;
	}

	if (found) {
		if (gWPArray[bestindex].wptype != WP_TYPE_SLIDE_START && Bot_CanTraceTo(gWPArray[1].origin)) {
			host_client->botinfo.wp_dest = &gWPArray[1];
		}
		else {
			host_client->botinfo.wp_dest = &gWPArray[bestindex];
		}
		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_NOVIS)
			host_client->botinfo.wptroubleshoot = sv.time + 5;
		else
			host_client->botinfo.wptroubleshoot = sv.time + 15;
	}
}

int GetAimOffset() {
	int targetmovement = 0;

	if (host_client->botinfo.skills.accuracy > 180)
		host_client->botinfo.skills.accuracy = 180;
	if (host_client->botinfo.skills.accuracy < 1)
		host_client->botinfo.skills.accuracy = 1;

	if (host_client->botinfo.enemy &&
		host_client->botinfo.enemy->v.velocity[0] > -30 &&
		host_client->botinfo.enemy->v.velocity[0] < 30 &&
		host_client->botinfo.enemy->v.velocity[1] > -30 &&
		host_client->botinfo.enemy->v.velocity[1] < 30 &&
		host_client->botinfo.enemy->v.velocity[2] > -30 &&
		host_client->botinfo.enemy->v.velocity[2] < 30) {
		targetmovement = (int)host_client->botinfo.skills.accuracy/2;
	}
	else {
		targetmovement = (int)host_client->botinfo.skills.accuracy;
	}

	if (host_client->botinfo.changeoffsettime < sv.time) {
		if (rand()%10 <= 5) {
			host_client->botinfo.aimoffset = (rand()&targetmovement);
		}
		else {
			host_client->botinfo.aimoffset = -(rand()&targetmovement);
		}
		host_client->botinfo.changeoffsettime = sv.time + 0.3 + (rand()&1);
	}

	return host_client->botinfo.aimoffset;
}


/*
=========================================
Here is where the AI begins.
=========================================
*/
void BotAI_Main(client_t *bcl, int cln) { //set everything up, call AI, then
										  //client think function
	char *gamedir;

	host_client = bcl;

	//reset defaults for this frame
	host_client->edict->v.button0 = 0;
	host_client->edict->v.button1 = 0;
	host_client->edict->v.button2 = 0;
	host_client->cmd.forwardmove = 0;
	host_client->cmd.sidemove = 0;
	host_client->cmd.upmove = 0;

	sv_player->v.fixangle = 0; //Oh well.

	gamedir = GetGameDir();

	//If we have an enemy, make sure we stay alert for a little
	if (host_client->botinfo.enemy) {
		host_client->botinfo.alerttime = sv.time + 15 + rand()%10;
	}

	//Constantly update our delay for hostile reaction
	if (!host_client->botinfo.enemy) {
		if (host_client->botinfo.alerttime > sv.time)
			host_client->botinfo.reflextime = sv.time + host_client->botinfo.skills.reflex*0.4;
		else
			host_client->botinfo.reflextime = sv.time + host_client->botinfo.skills.reflex;
	}

	if (gWPEditMode) { //No route data for this level and/or in edit mode.
		if (host_client->botinfo.leavetime < sv.time) {
			if (host_client->botinfo.leavestate == 0) {
				host_client->botinfo.leavestate = 1;
				host_client->botinfo.leavetime = sv.time + rand()%3 + 3;
			}
			else if (host_client->botinfo.leavestate == 1) {
				host_client->botinfo.leavestate = 2;
				host_client->botinfo.leavetime = sv.time + rand()%1 + 1;
				Bot_Say(0, "I don't like this level. Bye.");
			}
			else if (host_client->botinfo.leavestate == 2) {
				host_client->botinfo.leavestate = 3;
				SV_DropFakeClient();
			}
		}
	}
	else if (com_gamedir && strcmp(gamedir, "slide") == 0)
		BotAI_Slide(); //special Slide AI
	else
		BotAI_StandardDM(); //any other mod

	//Angle correction. I'm completely sure there's a better way to do this.
	if (host_client->edict->v.v_angle[PITCH] > 90)
		host_client->edict->v.v_angle[PITCH] -= 360;
	host_client->edict->v.v_angle[PITCH] = -host_client->edict->v.v_angle[PITCH];

	free(gamedir);

	host_client->cmd.viewangles[0] = host_client->edict->v.v_angle[0];
	host_client->cmd.viewangles[1] = host_client->edict->v.v_angle[1];
	host_client->cmd.viewangles[2] = host_client->edict->v.v_angle[2];

	if (host_client->edict->v.health < 1) {
		host_client->botinfo.wp_dest = NULL;

		if (rand()%10 <= 5)
			host_client->edict->v.button0 = 1;
		else
			host_client->edict->v.button0 = 0;
	}

	SV_ClientThink ();
}

int BotAI_Slide_LowVel() { //determines if we're stuck or not
	if (host_client->botinfo.gointele)
		return 0;

	if (host_client->botinfo.slidejumptime > sv.time)
		return 0;

	if (host_client->edict->v.velocity[0] < 60 &&
		host_client->edict->v.velocity[0] > -60 &&
		host_client->edict->v.velocity[1] < 60 &&
		host_client->edict->v.velocity[1] > -60) {
		host_client->botinfo.slidejumptime = sv.time + 1;
		return 1; //this means we're probably stuck, so try jumping
	}

	return 0;
}

int FireFOVCheck (edict_t *bot, edict_t *enemy) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t v_forward, v_right, v_up, vectemp;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int cvarval = host_client->botinfo.skills.accuracy;
	int fovaddangle = 0;
	int fovsubangle = 0;	
	int gothroughrange = 0;

	VectorSubtract(enemy->v.origin, bot->v.origin, vectemp);

	enemy_yaw = bot_vectoyaw( vectemp );
	
	AngleVectors(bot->v.v_angle, v_forward, v_right, v_up);

	fororg[0] = bot->v.origin[0] + v_forward[0]*(5);
	fororg[1] = bot->v.origin[1] + v_forward[1]*(5);
	fororg[2] = bot->v.origin[2];
	
	VectorSubtract(fororg, bot->v.origin, vectemp);

	current_yaw = bot_vectoyaw (vectemp);

	if (cvarval < 1)
		cvarval = 0;
	if (cvarval > 160)
		cvarval = 160;
	
	botfovval = cvarval + 10;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw)
			return 1;

		gothroughrange++;
	}

	return 0;
}

int DirCheck (edict_t *bot, vec3_t org, int dir, int fov) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t v_forward, v_right, v_up, vectemp;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int fovaddangle = 0;
	int fovsubangle = 0;	
	int gothroughrange = 0;

	VectorSubtract(org, bot->v.origin, vectemp);

	enemy_yaw = bot_vectoyaw( vectemp );
	
	AngleVectors(bot->v.v_angle, v_forward, v_right, v_up);

	if (dir == CHECK_DIR_FORWARD) {
		fororg[0] = bot->v.origin[0] + v_forward[0]*(5);
		fororg[1] = bot->v.origin[1] + v_forward[1]*(5);
		fororg[2] = bot->v.origin[2];
	}
	else if (dir == CHECK_DIR_BACK) {
		fororg[0] = bot->v.origin[0] - v_forward[0]*(5);
		fororg[1] = bot->v.origin[1] - v_forward[1]*(5);
		fororg[2] = bot->v.origin[2];
	}
	else if (dir == CHECK_DIR_RIGHT) {
		fororg[0] = bot->v.origin[0] + v_right[0]*(5);
		fororg[1] = bot->v.origin[1] + v_right[1]*(5);
		fororg[2] = bot->v.origin[2];
	}
	else if (dir == CHECK_DIR_LEFT) {
		fororg[0] = bot->v.origin[0] - v_right[0]*(5);
		fororg[1] = bot->v.origin[1] - v_right[1]*(5);
		fororg[2] = bot->v.origin[2];
	}
	
	VectorSubtract(fororg, bot->v.origin, vectemp);

	current_yaw = bot_vectoyaw (vectemp);

	botfovval = fov;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw)
			return 1;

		gothroughrange++;
	}

	return 0;
}

void MoveToVector_Slide(vec3_t org) {
	//Move to a specified position regardless of which direction we're
	//facing.
	int gotdir = 0;
	float bot_speed = sv_maxspeed.value;

	if (DirCheck(host_client->edict, org, CHECK_DIR_FORWARD, 90) == 1) {
		host_client->cmd.forwardmove = bot_speed;
		gotdir = 1;
	}
	else if (DirCheck(host_client->edict, org, CHECK_DIR_BACK, 90) == 1) {
		host_client->cmd.forwardmove = -bot_speed;
		gotdir = 1;
	}

	if (gotdir == 1) {
		if (DirCheck(host_client->edict, org, CHECK_DIR_RIGHT, 75) == 1) {
			host_client->cmd.sidemove = bot_speed;
		}
		else if (DirCheck(host_client->edict, org, CHECK_DIR_LEFT, 75) == 1) {
			host_client->cmd.sidemove = -bot_speed;
		}
	}
	else {
		if (DirCheck(host_client->edict, org, CHECK_DIR_RIGHT, 90) == 1) {
			host_client->cmd.sidemove = bot_speed;
		}
		else if (DirCheck(host_client->edict, org, CHECK_DIR_LEFT, 90) == 1) {
			host_client->cmd.sidemove = -bot_speed;
		}
	}
}

void MoveToVector(vec3_t org) {
	//Move to a specified position regardless of which direction we're
	//facing.
	int gotdir = 0;
	float bot_speed = sv_maxspeed.value;

	if (DirCheck(host_client->edict, org, CHECK_DIR_FORWARD, 90) == 1) {
		host_client->cmd.forwardmove = bot_speed;
		gotdir = 1;
	}
	else if (DirCheck(host_client->edict, org, CHECK_DIR_BACK, 90) == 1) {
		host_client->cmd.forwardmove = -bot_speed;
		gotdir = 1;
	}

	if (gotdir == 1) {
		if (DirCheck(host_client->edict, org, CHECK_DIR_RIGHT, 45) == 1) {
			host_client->cmd.sidemove = bot_speed;
		}
		else if (DirCheck(host_client->edict, org, CHECK_DIR_LEFT, 45) == 1) {
			host_client->cmd.sidemove = -bot_speed;
		}
	}
	else {
		if (DirCheck(host_client->edict, org, CHECK_DIR_RIGHT, 90) == 1) {
			host_client->cmd.sidemove = bot_speed;
		}
		else if (DirCheck(host_client->edict, org, CHECK_DIR_LEFT, 90) == 1) {
			host_client->cmd.sidemove = -bot_speed;
		}
	}
}

void BotAI_FallbackNav() { //If we just don't have a waypoint...
	//Then change angles randomly taking nothing else into account!
	//(yes, I know this is almost completely useless, it just helps in
	//a few cases when the bot is completely stuck)

	//This could cause the bot to do something very stupid like walk
	//into lava, so reverting to it should be done only if there are
	//no other options.

	float bot_speed = sv_maxspeed.value;

	if (host_client->botinfo.changeyaw_time < sv.time) {
		host_client->botinfo.changeyaw_time = sv.time + 1 + rand()%5;
		host_client->botinfo.ideal_yaw = rand()%360;
	}

	host_client->cmd.forwardmove = bot_speed;
}

int Bot_EdictVisible(edict_t *ent) { //the bot's visibility function
	trace_t trace;

	trace = SV_Move(host_client->edict->v.origin, vec3_origin, vec3_origin, ent->v.origin, true, host_client->edict);

	if (trace.fraction == 1.0 ||
		(trace.ent && trace.ent == ent))
		return 1;

	return 0;
}

int Bot_EdictVisibleOrg(edict_t *ent, vec3_t org) { //the bot's visibility function
	trace_t trace;

	trace = SV_Move(host_client->edict->v.origin, vec3_origin, vec3_origin, org, true, host_client->edict);

	if (trace.fraction == 1.0 ||
		(trace.ent && trace.ent == ent))
		return 1;

	return 0;
}

int Bot_TwoEdictVisible(edict_t *bot, edict_t *ent) { //check between two ents
	trace_t trace;

	trace = SV_Move(bot->v.origin, vec3_origin, vec3_origin, ent->v.origin, true, bot);

	if (trace.fraction == 1.0 ||
		(trace.ent && trace.ent == ent))
		return 1;

	return 0;
}

int VerticalFOV (edict_t *bot, edict_t *enemy) {
	float enemy_roll;
	float current_roll;
	vec3_t fororg;
	vec3_t v_forward, v_right, v_up, vectemp;
	int ienemy_roll, icurrent_roll, botfovval;
	vec3_t newanges, newanges2;	
	int fovaddangle = 0;
	int fovsubangle = 0;
	int gothroughrange = 0;

	VectorSubtract(enemy->v.origin, bot->v.origin, vectemp);

	bot_vectoangles(vectemp, newanges);
	enemy_roll = newanges[ROLL];
	
	AngleVectors(bot->v.v_angle, v_forward, v_right, v_up);

	fororg[0] = bot->v.origin[0] + v_forward[0]*(5);
	fororg[1] = bot->v.origin[1] + v_forward[1]*(5);
	fororg[2] = bot->v.origin[2];
	
	VectorSubtract(fororg, bot->v.origin, vectemp);

	bot_vectoangles (vectemp, newanges2);

	current_roll = newanges2[ROLL];
	
	botfovval = 90;
	
	ienemy_roll = enemy_roll;
	icurrent_roll = current_roll;
	
	fovaddangle = icurrent_roll + botfovval*1;
	fovsubangle = icurrent_roll - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_roll)
			return 1;

		gothroughrange++;
	}

	return 0;
}

int StandardFOVCheck (edict_t *bot, edict_t *enemy) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t v_forward, v_right, v_up, vectemp;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int fovaddangle = 0;
	int fovsubangle = 0;
	int gothroughrange = 0;

	VectorSubtract(enemy->v.origin, bot->v.origin, vectemp);

	enemy_yaw = bot_vectoyaw( vectemp );
	
	AngleVectors(bot->v.v_angle, v_forward, v_right, v_up);

	fororg[0] = bot->v.origin[0] + v_forward[0]*(5);
	fororg[1] = bot->v.origin[1] + v_forward[1]*(5);
	fororg[2] = bot->v.origin[2];
	
	VectorSubtract(fororg, bot->v.origin, vectemp);

	current_yaw = bot_vectoyaw (vectemp);
	
	botfovval = 90;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw && VerticalFOV(bot, enemy))
			return 1;

		gothroughrange++;
	}

	return 0;
}

int SpecificFOVCheck (edict_t *bot, edict_t *enemy, int fov) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t v_forward, v_right, v_up, vectemp;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int fovaddangle = 0;
	int fovsubangle = 0;
	int gothroughrange = 0;

	VectorSubtract(enemy->v.origin, bot->v.origin, vectemp);

	enemy_yaw = bot_vectoyaw( vectemp );
	
	AngleVectors(bot->v.v_angle, v_forward, v_right, v_up);

	fororg[0] = bot->v.origin[0] + v_forward[0]*(5);
	fororg[1] = bot->v.origin[1] + v_forward[1]*(5);
	fororg[2] = bot->v.origin[2];
	
	VectorSubtract(fororg, bot->v.origin, vectemp);

	current_yaw = bot_vectoyaw (vectemp);
	
	botfovval = fov;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw && VerticalFOV(bot, enemy))
			return 1;

		gothroughrange++;
	}

	return 0;
}

void FiredAtMe(edict_t *bot, edict_t *ent) {
	//This bot is taking fire.
	client_t *botcl = GetMatchingClientForEdict(bot);
	client_t *entcl = GetMatchingClientForEdict(ent);

	if (!botcl || !entcl)
		return;

	//For now, we're just going to have the bot instantly set the client
	//as its enemy if it does not have one.
	if (!botcl->botinfo.enemy) {
		botcl->botinfo.enemy = ent;
	}
}

void NotifyBotOfAttack(edict_t *ent) {
	//Called whenever a client has fire down. We will see who is in
	//the client's FOV, and tell them the client's firing at us.

	int i = 1;
	vec3_t distmeas;
	float dist;
	float mindist = BOT_MAX_VIEWDIST+1;
	edict_t *clent = EDICT_NUM(i);

	while (i <= svs.maxclients) {
		if (clent &&
			clent->v.health > 0 &&
			clent->v.team != ent->v.team &&
			SpecificFOVCheck(ent, clent, 25)) {
			VectorSubtract(ent->v.origin, clent->v.origin, distmeas);
			dist = bot_vlen(distmeas);

			if (dist < mindist && Bot_TwoEdictVisible(ent, clent)) {
				FiredAtMe(clent, ent);
			}
		}
		i++;
		clent = EDICT_NUM(i);
	}
}

void GetNearBrushObject() {
	int i = svs.maxclients;
	vec3_t visorg;
	float visdifx = 0;
	float visdify = 0;
	float visdifz = 0;
	edict_t *checkent = EDICT_NUM(i);

	while (i <= 512) {
		if (checkent &&
			checkent->v.health > 0 &&
			checkent->v.takedamage != DAMAGE_NO &&
			checkent->v.classname /*&&
			strstr(pr_strings+checkent->v.classname, "trigger_") &&
			(!(int)checkent->v.flags & FL_MONSTER)*/)
		{
				visdifx = checkent->v.absmax[0] - checkent->v.absmin[0];
				visdify = checkent->v.absmax[1] - checkent->v.absmin[1];
				visdifz = checkent->v.absmax[2] - checkent->v.absmin[2];

				visorg[0] = checkent->v.absmin[0]+visdifx*0.5;
				visorg[1] = checkent->v.absmin[1]+visdify*0.5;
				visorg[2] = checkent->v.absmin[2]+visdifz*0.5;

				if (Bot_EdictVisibleOrg(checkent, visorg)) {
					host_client->botinfo.shootat = checkent;
					break;
				}
		}
		
		i++;
		checkent = EDICT_NUM(i);
	}
}

void BotAI_GetClientEnemy() {
	//checks through client edicts for possible enemies.
	int i = 1;
	vec3_t distmeas;
	float dist;
	edict_t *bestent = NULL;
	float bestdist = BOT_MAX_VIEWDIST+1;
	edict_t *clent = EDICT_NUM(i);

	while (i <= svs.maxclients) {
		if (clent &&
			clent->v.health > 0 &&
			clent->v.team != host_client->edict->v.team &&
			(StandardFOVCheck(host_client->edict, clent) || ClientMadeNoise(NULL, clent))) {
			VectorSubtract(host_client->edict->v.origin, clent->v.origin, distmeas);
			dist = bot_vlen(distmeas);

			if (dist < bestdist && Bot_EdictVisible(clent)) {
				bestent = clent;
				bestdist = dist;
			}
		}
		i++;
		clent = EDICT_NUM(i);
	}

	if (bestent)
		host_client->botinfo.enemy = bestent;
}

//The slide AI is pretty simple, but it works (most of the time).
//The bot basically goes around the trail in a circle constantly.
void BotAI_Slide() {
	float bot_speed = sv_maxspeed.value;
	vec3_t xy1, xy2;
	vec3_t vecsub;
	vec3_t pitchang;
	float wplen = 0;

	if (host_client->edict->v.health < 1) {
		return; //AI_Main takes care of this
	}

	//limit calls to changeyaw by time in case of super-high framerate
	if (host_client->botinfo.lastyawchange_time <= sv.time) {
		bot_changeyaw(0, 0);
		host_client->botinfo.lastyawchange_time = sv.time + 0.1;
	}

	if (host_client->botinfo.fallbacktime > sv.time) {
		BotAI_FallbackNav();
		host_client->edict->v.v_angle[PITCH] = 0;
		return;
	}

	if (host_client->botinfo.wp_dest &&
		host_client->botinfo.wptroubleshoot < sv.time) {
		host_client->botinfo.wp_dest = NULL;
		host_client->botinfo.fallbacktime = sv.time + 8;
		return;
	}

	if (host_client->botinfo.wp_dest &&
		host_client->botinfo.gointele &&
		host_client->botinfo.wptimeout < sv.time) {
		//took too long to get into the teleport, something bad probably happened
		host_client->botinfo.wp_dest = NULL;
	}


	if (!host_client->botinfo.wp_dest) {
		GetNearestVisibleWP_Slide();
	}

	if (host_client->botinfo.wp_dest) {
		if ((host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_START ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_FINISH ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_ONFOOT ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_TELEPORT ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_TELE) &&
			(host_client->botinfo.enemy && host_client->botinfo.reflextime <= sv.time)) {
			VectorSubtract(host_client->botinfo.enemy->v.origin, host_client->edict->v.origin, vecsub);
		}
		else {
			VectorSubtract(host_client->botinfo.wp_dest->origin, host_client->edict->v.origin, vecsub);
		}

		if (host_client->botinfo.enemy && host_client->botinfo.reflextime <= sv.time) {
			host_client->botinfo.ideal_yaw = bot_vectoyaw(vecsub) + GetAimOffset();
		}
		else {
			host_client->botinfo.ideal_yaw = bot_vectoyaw(vecsub);
		}

		host_client->edict->v.v_angle[PITCH] = 0;

		if (host_client->botinfo.gointele && !Bot_CanTraceTo(host_client->botinfo.wp_dest->origin)) {
			//cheap hack for teleporters
			host_client->edict->v.v_angle[PITCH] = host_client->botinfo.teleangles[PITCH];
			host_client->botinfo.ideal_yaw = host_client->botinfo.teleangles[YAW];
		}
		else {
			host_client->botinfo.gointele = 0;
		}

		host_client->cmd.forwardmove = bot_speed;

		if (!host_client->botinfo.enemy || host_client->botinfo.reflextime > sv.time)
			bot_changeyaw(0, 360);

		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_START ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_FINISH ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_ONFOOT ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_TELEPORT ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_TELE) {
			//onfoot is a cheap way of seeing if we should be on our board or not

			if (host_client->botinfo.wp_dest->wptype != WP_TYPE_SLIDE_FINISH && !host_client->botinfo.gointele && !Bot_CanTraceTo(host_client->botinfo.wp_dest->origin)) {
				host_client->botinfo.wp_dest = NULL;
				return;
			}

			if (host_client->botinfo.enemy &&
				(!Bot_EdictVisible(host_client->botinfo.enemy)
				|| host_client->botinfo.enemy->v.health < 1 ||
				host_client->botinfo.wp_dest->wptype != WP_TYPE_SLIDE_ONFOOT))
				host_client->botinfo.enemy = NULL;

			if (!host_client->botinfo.enemy && host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_ONFOOT)
				BotAI_GetClientEnemy();

			if (host_client->botinfo.enemy && host_client->botinfo.reflextime <= sv.time) {
				VectorSubtract(host_client->botinfo.enemy->v.origin, host_client->edict->v.origin, vecsub);
			}
			else {
				VectorSubtract(host_client->botinfo.wp_dest->origin, host_client->edict->v.origin, vecsub);
			}

			pitchang[0] = 0;
			pitchang[1] = 0;
			pitchang[2] = 0;
			bot_vectoangles(vecsub, pitchang);
			host_client->edict->v.v_angle[PITCH] = pitchang[PITCH];

			VectorSubtract(host_client->edict->v.origin, host_client->botinfo.wp_dest->origin, vecsub);
			wplen = bot_vlen(vecsub);

			if (wplen < 42) {
				if (host_client->botinfo.wp_dest->wptype == WP_TYPE_JUMP)
					host_client->botinfo.jumptime = sv.time + 1;

				host_client->botinfo.gointele = 0;

				if (host_client->botinfo.wp_dest->wptype == WP_TYPE_TELEPORT || host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_TELE) {
					host_client->botinfo.gointele = 1;
					host_client->botinfo.teleangles[0] = host_client->edict->v.v_angle[0];
					host_client->botinfo.teleangles[1] = host_client->edict->v.v_angle[1];
					host_client->botinfo.teleangles[2] = host_client->edict->v.v_angle[2];
				}

				GetNextWP_Slide();

				if (!host_client->botinfo.wp_dest)
					return;
			}

			if (host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_FINISH ||
				host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_START ||
				host_client->botinfo.wp_dest->wptype == WP_TYPE_SLIDE_TELE ||
				(host_client->botinfo.enemy && host_client->botinfo.reflextime <= sv.time && FireFOVCheck(host_client->edict, host_client->botinfo.enemy)))
				host_client->edict->v.button0 = 1;

			if (!host_client->botinfo.gointele && host_client->botinfo.enemy && host_client->botinfo.reflextime <= sv.time) {
				MoveToVector_Slide(host_client->botinfo.wp_dest->origin);
			}
		}
		//For Slide, waypoints act more as "hint" points.
		//In other words, we don't need to care about vertical position or
		//a tight distance when checking to see if we "hit" points.
		else {
			xy1[0] = host_client->edict->v.origin[0];
			xy1[1] = host_client->edict->v.origin[1];
			xy1[2] = 0;
			xy2[0] = host_client->botinfo.wp_dest->origin[0];
			xy2[1] = host_client->botinfo.wp_dest->origin[1];
			xy2[2] = 0;

			if (host_client->botinfo.enemy)
				host_client->botinfo.enemy = NULL;

			host_client->botinfo.gointele = 0;

			VectorSubtract(xy1, xy2, vecsub);
			wplen = bot_vlen(vecsub);

			if (wplen < 256) {
				if (host_client->botinfo.wp_dest->wptype == WP_TYPE_JUMP)
					host_client->botinfo.jumptime = sv.time + 1;
				GetNextWP_Slide();
			}

			host_client->edict->v.button0 = 1;
		}
	}

	if ((rand()%10 <= 5 && BotAI_Slide_LowVel()) || host_client->botinfo.jumptime > sv.time) {
		host_client->edict->v.button2 = 1;
	}
	else {
		host_client->edict->v.button2 = 0;
	}

	if (!host_client->botinfo.wp_dest) {
		BotAI_FallbackNav();
		host_client->edict->v.v_angle[PITCH] = 0;
	}
}

void Bot_BestWeapon() {
	//a bit hackish and may not work with some mods, but oh well.
	if (host_client->botinfo.wchecktime > sv.time ||
		host_client->edict->v.button0 ||
		gBotImpulse)
		return;

	host_client->botinfo.wchecktime = sv.time + 1;

	if ((int)host_client->edict->v.items & IT_ROCKET_LAUNCHER &&
		host_client->edict->v.ammo_rockets > 0) {
		if (host_client->edict->v.weapon != IT_ROCKET_LAUNCHER)
			host_client->edict->v.impulse = 7;
	}
	else if ((int)host_client->edict->v.items & IT_LIGHTNING &&
		host_client->edict->v.ammo_cells > 0) {
		if (host_client->edict->v.weapon != IT_LIGHTNING)
			host_client->edict->v.impulse = 8;
	}
	else if ((int)host_client->edict->v.items & IT_GRENADE_LAUNCHER &&
		host_client->edict->v.ammo_rockets > 0) {
		if (host_client->edict->v.weapon != IT_GRENADE_LAUNCHER)
			host_client->edict->v.impulse = 6;
	}
	else if ((int)host_client->edict->v.items & IT_SUPER_NAILGUN &&
		host_client->edict->v.ammo_nails > 1) {
		if (host_client->edict->v.weapon != IT_SUPER_NAILGUN)
			host_client->edict->v.impulse = 5;
	}
	else if ((int)host_client->edict->v.items & IT_SUPER_SHOTGUN &&
		host_client->edict->v.ammo_shells > 1) {
		if (host_client->edict->v.weapon != IT_SUPER_SHOTGUN)
			host_client->edict->v.impulse = 3;
	}
	else if ((int)host_client->edict->v.items & IT_NAILGUN &&
		host_client->edict->v.ammo_nails > 0) {
		if (host_client->edict->v.weapon != IT_NAILGUN)
			host_client->edict->v.impulse = 4;
	}
	else if ((int)host_client->edict->v.items & IT_SHOTGUN &&
		host_client->edict->v.ammo_shells > 0) {
		if (host_client->edict->v.weapon != IT_SHOTGUN)
			host_client->edict->v.impulse = 2;
	}
}

int SuitableBrushWeapon() {
	//also a bit hackish and may not work with some mods.

	if ((int)host_client->edict->v.items & IT_LIGHTNING)
	{
		if (host_client->edict->v.ammo_cells > 0)
			return 1;
	}
	
	if ((int)host_client->edict->v.items & IT_SUPER_NAILGUN)
	{
		if (host_client->edict->v.ammo_nails > 1)
			return 1;
	}
	
	if ((int)host_client->edict->v.items & IT_SUPER_SHOTGUN)
	{
		if (host_client->edict->v.ammo_shells > 1)
			return 1;
	}
	
	if ((int)host_client->edict->v.items & IT_NAILGUN)
	{
		if (host_client->edict->v.ammo_nails > 0)
			return 1;
	}
	
	if ((int)host_client->edict->v.items & IT_SHOTGUN)
	{
		if (host_client->edict->v.ammo_shells > 0)
			return 1;
	}

	return 0;
}

void SelectSuitableBrushWeapon() {
	//same as above

	host_client->botinfo.wchecktime = sv.time + 1;

	if ((int)host_client->edict->v.items & IT_LIGHTNING &&
		host_client->edict->v.ammo_cells > 0) {
		if (host_client->edict->v.weapon != IT_LIGHTNING)
			host_client->edict->v.impulse = 8;
	}
	else if ((int)host_client->edict->v.items & IT_SUPER_NAILGUN &&
		host_client->edict->v.ammo_nails > 1) {
		if (host_client->edict->v.weapon != IT_SUPER_NAILGUN)
			host_client->edict->v.impulse = 5;
	}
	else if ((int)host_client->edict->v.items & IT_SUPER_SHOTGUN &&
		host_client->edict->v.ammo_shells > 1) {
		if (host_client->edict->v.weapon != IT_SUPER_SHOTGUN)
			host_client->edict->v.impulse = 3;
	}
	else if ((int)host_client->edict->v.items & IT_NAILGUN &&
		host_client->edict->v.ammo_nails > 0) {
		if (host_client->edict->v.weapon != IT_NAILGUN)
			host_client->edict->v.impulse = 4;
	}
	else if ((int)host_client->edict->v.items & IT_SHOTGUN &&
		host_client->edict->v.ammo_shells > 0) {
		if (host_client->edict->v.weapon != IT_SHOTGUN)
			host_client->edict->v.impulse = 2;
	}
}

void BotAI_StandardDM() { //the standard any-mod AI
	float bot_speed = sv_maxspeed.value;
	vec3_t vecsub;
	vec3_t shootatorg;
	vec3_t xy1, xy2;
	float shootdifx = 0;
	float shootdify = 0;
	float shootdifz = 0;
	vec3_t pitchang;
	float wplen = 0;
	int bestill = 0;
	int strafetr = 0;
	float WP_MINDIST = 32;

	if (host_client->edict->v.health < 1) {
		return; //AI_Main takes care of this
	}

	host_client->edict->v.button2 = 0;

	//limit calls to changeyaw by time in case of super-high framerate
	if (host_client->botinfo.lastyawchange_time <= sv.time) {
		bot_changeyaw(0, 0);
		host_client->botinfo.lastyawchange_time = sv.time + 0.1;
	}

	Bot_BestWeapon();

	if (host_client->botinfo.fallbacktime > sv.time) {
		BotAI_FallbackNav();
		host_client->edict->v.v_angle[PITCH] = 0;
		return;
	}

	if (host_client->botinfo.shootat) {
		//Unfortunately, brush objects don't get their origins set, so we
		//have to go through a bit of trouble to calculate the center using
		//absmin and absmax.
		shootdifx = host_client->botinfo.shootat->v.absmax[0] - host_client->botinfo.shootat->v.absmin[0];
		shootdify = host_client->botinfo.shootat->v.absmax[1] - host_client->botinfo.shootat->v.absmin[1];
		shootdifz = host_client->botinfo.shootat->v.absmax[2] - host_client->botinfo.shootat->v.absmin[2];

		shootatorg[0] = host_client->botinfo.shootat->v.absmin[0]+shootdifx*0.5;
		shootatorg[1] = host_client->botinfo.shootat->v.absmin[1]+shootdify*0.5;
		shootatorg[2] = host_client->botinfo.shootat->v.absmin[2]+shootdifz*0.5;

		if (host_client->botinfo.shootat->v.health < 1) {
			host_client->botinfo.shootat = NULL;
			return;
		}
		else if (host_client->botinfo.shootat->v.takedamage == DAMAGE_NO) {
			host_client->botinfo.shootat = NULL;
		}
		else if (!SuitableBrushWeapon()) {
			host_client->botinfo.shootat = NULL;
			return;
		}
		else if (!Bot_EdictVisibleOrg(host_client->botinfo.shootat, shootatorg)) {
			host_client->botinfo.shootat = NULL;
			return;
		}

		VectorSubtract(shootatorg, host_client->edict->v.origin, vecsub);
		pitchang[0] = 0;
		pitchang[1] = 0;
		pitchang[2] = 0;
		bot_vectoangles(vecsub, pitchang);
		host_client->edict->v.v_angle[PITCH] = pitchang[PITCH];
		host_client->botinfo.ideal_yaw = pitchang[YAW];

		bot_changeyaw(0, 360);

		SelectSuitableBrushWeapon();

		host_client->edict->v.button0 = 1;

		return;
	}

	if (host_client->botinfo.wp_dest &&
		host_client->botinfo.gointele &&
		host_client->botinfo.wptimeout < sv.time) {
		//took too long to get into the teleport, something bad probably happened
		host_client->botinfo.wp_dest = NULL;
	}

	if (host_client->botinfo.wp_dest &&
		!host_client->botinfo.gointele &&
		host_client->botinfo.wp_dest->wptype != WP_TYPE_NOVIS &&
		!Bot_CanTraceTo(host_client->botinfo.wp_dest->origin)) {
		//destination is not visible
		host_client->botinfo.wp_dest = NULL;
		if (!host_client->botinfo.wp_order)
			host_client->botinfo.wp_order = 1;
		else
			host_client->botinfo.wp_order = 0;
	}

	if (host_client->botinfo.wp_dest &&
		host_client->botinfo.wptroubleshoot < sv.time) {
		host_client->botinfo.wp_dest = NULL;
		if (!host_client->botinfo.wp_order)
			host_client->botinfo.wp_order = 1;
		else
			host_client->botinfo.wp_order = 0;
		host_client->botinfo.fallbacktime = sv.time + 1;
		return;
	}

	if (!host_client->botinfo.wp_dest) {
		GetNearestVisibleWP();
	}

	if (host_client->botinfo.wp_dest) {
		VectorSubtract(host_client->botinfo.wp_dest->origin, host_client->edict->v.origin, vecsub);
		wplen = bot_vlen(vecsub);

		Bot_DestroyObstacles(host_client->botinfo.wp_dest->origin);
		//Bot_PushButtons();
		//Using waypoint instead for speed

		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_PLATFORM)
			WP_MINDIST = 16;

		if (wplen <= WP_MINDIST) {
			if (host_client->botinfo.wp_dest->wptype == WP_TYPE_JUMP)
				host_client->botinfo.jumptime = sv.time + 1;

			if (host_client->botinfo.wp_dest->wptype == WP_TYPE_PUSHBUTTON) {
				host_client->botinfo.pushbutton = sv.time + 0.5;
				host_client->botinfo.buttonangles[0] = host_client->edict->v.v_angle[0];
				host_client->botinfo.buttonangles[1] = host_client->edict->v.v_angle[1];
				host_client->botinfo.buttonangles[2] = host_client->edict->v.v_angle[2];
			}

			if (host_client->botinfo.wp_dest->wptype == WP_TYPE_TELEPORT) {
				host_client->botinfo.gointele = 1;
				host_client->botinfo.teleangles[0] = host_client->edict->v.v_angle[0];
				host_client->botinfo.teleangles[1] = host_client->edict->v.v_angle[1];
				host_client->botinfo.teleangles[2] = host_client->edict->v.v_angle[2];
			}

			if (host_client->botinfo.wp_dest->wptype == WP_TYPE_SHOOTNEAROBJECT) {
				GetNearBrushObject();
				if (host_client->botinfo.shootat)
					return;
			}

			GetNextWP();

			if (!host_client->botinfo.wp_dest) {
				TryPickup();
				return;
			}
		}
		else if (host_client->botinfo.wp_dest->wptype == WP_TYPE_NOVIS) {
			xy1[0] = host_client->edict->v.origin[0];
			xy1[1] = host_client->edict->v.origin[1];
			xy1[2] = 0;
			xy2[0] = host_client->botinfo.wp_dest->origin[0];
			xy2[1] = host_client->botinfo.wp_dest->origin[1];
			xy2[2] = 0;
			VectorSubtract(xy1, xy2, vecsub);
			if (bot_vlen(vecsub) <= 16)
				bestill = 1;
		}

		if (host_client->botinfo.wptroubleshoot < (sv.time + 4) &&
			host_client->botinfo.wp_dest->wptype != WP_TYPE_NOVIS) {
			if (rand()%10 <= 5)
				host_client->edict->v.button2 = 1;
		}
		else if (host_client->botinfo.wptroubleshoot < (sv.time + 14)) {
			if (Bot_ObjectAtFeet()) {
				host_client->edict->v.button2 = 1;
			}
			else {
				strafetr = Bot_ObjectInFront();
				if (strafetr == 1) {
					host_client->cmd.sidemove = bot_speed;
				}
				else if (strafetr == 2) {
					host_client->cmd.sidemove = -bot_speed;
				}
				else if (strafetr == 3) {
					host_client->cmd.sidemove = bot_speed;
				}
			}
		}

		VectorSubtract(host_client->botinfo.wp_dest->origin, host_client->edict->v.origin, vecsub);
		pitchang[0] = 0;
		pitchang[1] = 0;
		pitchang[2] = 0;
		bot_vectoangles(vecsub, pitchang);
		host_client->edict->v.v_angle[PITCH] = pitchang[PITCH];
		host_client->botinfo.ideal_yaw = pitchang[YAW];

		if (host_client->botinfo.wp_dest &&
			(host_client->botinfo.wp_dest->wptype == WP_TYPE_TELEPORT ||
			host_client->botinfo.wp_dest->wptype == WP_TYPE_PUSHBUTTON))
			bot_changeyaw(0, 360);

		if (host_client->botinfo.gointele && !Bot_CanTraceTo(host_client->botinfo.wp_dest->origin)) {
			//cheap hack for teleporters
			host_client->edict->v.v_angle[PITCH] = host_client->botinfo.teleangles[PITCH];
			host_client->botinfo.ideal_yaw = host_client->botinfo.teleangles[YAW];
			bot_changeyaw(0, 360);
		}
		else {
			host_client->botinfo.gointele = 0;
		}

		if (host_client->botinfo.wp_dest->wptype == WP_TYPE_PLATFORM && NoEntUnder(host_client->botinfo.wp_dest->origin))
			bestill = 1;

		if (bestill) {
			host_client->cmd.forwardmove = 0;
			host_client->cmd.sidemove = 0;
		}
		else if (!host_client->botinfo.gointele)
			MoveToVector(host_client->botinfo.wp_dest->origin);
		else
			host_client->cmd.forwardmove = bot_speed;
	}
	else {
		BotAI_FallbackNav();
	}

	if (host_client->botinfo.jumptime > sv.time && rand()%10 < 5)
		host_client->edict->v.button2 = 1;

	if (host_client->botinfo.pushbutton > sv.time) {
		host_client->edict->v.v_angle[0] = host_client->botinfo.buttonangles[0];
		host_client->edict->v.v_angle[1] = host_client->botinfo.buttonangles[1];
		host_client->edict->v.v_angle[2] = host_client->botinfo.buttonangles[2];
		host_client->botinfo.ideal_yaw = host_client->botinfo.buttonangles[YAW];
		host_client->cmd.sidemove = 0;
		host_client->cmd.forwardmove = bot_speed;
	}
}
