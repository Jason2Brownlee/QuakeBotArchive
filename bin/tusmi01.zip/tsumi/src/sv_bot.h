typedef struct
{
	int				wpnum;
	float			wpdist;
} nearpoint_t;

typedef struct
{
	vec3_t			origin;
	int				wpnum;
	int				wptype;
	int				iWeightVal;
	float			disttonext;
	float			glowme;
	nearpoint_t		nearby[32];
	int				nearbyi;
} waypoint_t;

typedef struct
{
	float			accuracy;
	float			yaw_speed;
	int				intel;
	float			reflex;
} botskills_t;


typedef struct
{
	edict_t			*enemy;
	edict_t			*shootat;
	waypoint_t		*wp_dest;
	waypoint_t		*wp_best;
	int				wp_order;
	float			ideal_yaw;
	float			ideal_pitch;
	float			changeyaw_time;
	float			lastyawchange_time;
	botskills_t		skills;
	int				topcolor;
	int				bottomcolor;
	float			jumptime;
	vec3_t			teleangles;
	int				gointele;
	float			wptimeout;
	float			wptroubleshoot;
	float			slidejumptime;
	float			leavetime;
	int				leavestate;
	float			shootattime;
	float			fallbacktime;
	float			changeoffsettime;
	int				aimoffset;
	float			madenoise;
	float			noisedist;
	float			reflextime;
	float			alerttime;
	float			wchecktime;
	float			pushbutton;
	vec3_t			buttonangles;
} botstruct_t;
