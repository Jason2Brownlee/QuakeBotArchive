Name:		Tsumi to Botsu
Filename:	tsumi01.zip
Author:		Rich Whitehouse
Version:	0.1
Date:		December 24, 2000
E-mail:		thefatal@telefragged.com
Web site:	http://www.telefragged.com/thefatal/
----------------------------------------------------
This is a generic Quake bot. The AI for Slide is currently fully working
and basically complete (though a bit simple). However, the standard AI
currently only allows the bot to roam around randomly on levels with
waypoint files and does not even have combat code. The source code is
bundled in with this release. Before I go on explaining the source and
how you can improve on it, I'll give a quick explanation on those only
using the bot so they can get into a game of Slide.

Oh, and for those of you who have no idea what Slide is, it's a nice
Quake mod. Currently, you can get it here:
http://singe.telefragged.com/

INSTALLATION AND USE
--------------------
To get into a game of Slide with bots, first make sure you've unzipped
the file this file was in into your main Quake folder (e.g. c:\quake)
with directory structure. You should not have a tsumigl.exe file in
your main Quake directory, along with a sub-directory named tsumi
(c:\quake\tsumi) that holds all the bot-related files, included all of
the waypoint stuff. I should note now that I've not bothered to compile
a software version of the bot. If you want one, you can just do it
yourself or get someone to do it for you. Anyway, now that you've
installed the bot properly, just run Slide with tsumigl.exe as you
would with glquake.exe or whatever else, then start a multiplayer Slide
game on one of the default levels (the levels that have waypoint files
already made for them). Bring down the console and type addbot to add
a bot, or removebot to remove a bot. There you go.

You can use the bot with mods other than Slide, but you'll find they
do not behave well or even have any combat AI (due to the generic AI
currently being incomplete).

OTHER
-----
The source code included with this bot is pretty well-documented and
easy to understand. The files included other than the sv_bot.* files
have all changes marked with "rww" and "end rww", so merging the bot
into a new code base should be as easy as incorporating those changes
in your project and adding sv_bot.c and sv_bot.h to your project. That
is all you'll need to do to compile the bot in the original Quake code
base as well (though if that's all you're doing you'd might as well
just copy all the files over their originals and add the sv_bot.* files
to your project). That should pretty much cover how to compile the bot
properly.

You can take a look at all the commands currently available for the bot
in the void Host_InitCommands (void) function in host_cmd.c. You'll
notice that there are a terrible amount of waypoint adding commands
for the various types, and they are indeed all functional. I should
also note that waypoint files currently store a bunch of information
that is unused but will be needed for speed optimization if you decide
to start working in my planned navigation routine. I'll get to that
more in a moment. Right now, I present you with a current list of
to-do items for the bot which I intended/intend to do:

{Make use of over-ledge checks for items}
{Make routine for finding shortest route to places}
{When finding shortest route, make oneway points return high
distance}
{Figure out some way to take buttons into account with priority
navigation (most likely by dealing with as oneway points)}
{Have bots camp a little on red armor and RL and things}
{Rocket-jumping}
{Remember to set enemy, shootat, etc. null when dead}
{Make bots shoot grenades around corners if being chased}
{Switch to melee weapon at close range if health is low}
{Grenade and rocket explosion avoidance}
{Make bots go toward players using waypoint route if on offense and
away if running}
{Make ring of shadows affect bot's targetting ability/reflex level}
{Rocket launcher aim leading}
{Improve fallback navigation}
{Look into CTF support}
{Bot chat}

The list is directly from my own personal todo list, so I apologize
for any bad wording/spelling/whatever. A majority of the things on
this list will actually be relatively easy to do if the route-finding
routine is put in properly. While I'm on this topic, I'll go ahead and
explain the current route file format.

Each waypoint is stored on a line of text. Each line is formatted as
follows:

<wp number> <wp type> <(wp origin)> <distance to next wp>
<{list of nearby visible points and distances to}>

All of the data is probably pretty obvious. You'll want to use the
nearby point data in making a route-finding routine, most likely, since
it's already there and convenient. This data is also already read into
the waypoint data structure in the program, so you won't have to do
anything special as far as that goes either. It's just a matter of
utilizing the data in your own route-finding method.

I guess that's pretty much all you'll need to know. The rest of the
code is pretty self-explanitory and is also documented decently.

GPL
---
This code, like the Quake source code, is distributed under the GPL
(gnu public license, see gnu.txt in the bot archive for more info).
This means that if you distribute a binary of the bot (modified or
not in any form), you MUST make the source code available to anyone
who wants it as well. I would appreciate being credited properly
myself as well for anything you may decide to do with this code.
