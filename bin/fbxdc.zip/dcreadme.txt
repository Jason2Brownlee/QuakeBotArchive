Title    : FrikMenu, FBX DC
Filename : fbxdc.zip
Version  : 
Date     : 3-15-2002
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Fragger for JoyMenu which was the germ of this idea, TheDumbAss for testing
Electro for being Electro.

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no
context diff  : no
.qc files     : yes 
progs.dat     : yes


Description of the Modification
-------------------------------

This zip file contains two things: FrikMenu, which is intended to be a sophisticated JoyMenu like mod plugin that enables authors to give users with no keyboard a way to enter console commands and perform mod related configuration. It's intended as a tool kit, and though the code is rather complicated in places, if you are familiar with FBX's menu system you should be able to handle it. The entire code for the menu is contained in frikmenu.qc aswell as instructions for it's use.

The second thing this archive contains is a rather nasty hack to allow more than 3 bots if you are unable to set the maxclientlimit via the commandline (eg, on a DreamCast). This is acheived by changing the frikbots to be non clients (like, say, a Reaper). Because of this change, only the first 3 bots will still show on the scoreboard. If you'd like to use this hack in some other mod, please read the fbxdchack.txt file. Also note, as the other bots will not have a client slot they will appear with the default player colors.

Both modifications are combined and compiled into the included progs.dat for your conveinance.

How to Install the Modification
-------------------------------

For PC users, just use regular FBX. There's nothing you want to see here.
For PC Mod Authors, I assume you know how to install a mod.
For DC Users, I recommend you read this tutorial: http://quakedev.dcemulation.com/tutorials/generic/generic.htm

Impulses
===========
On startup, frikmenu will bind DC_DRIGHT to impulse 13 and DC_DLEFT to impulse 14 to speed up entry in the console screen. If this conflicts with your configuration then tough, I haven't got time for your belly aching :)


Copyright and Distribution Permissions
--------------------------------------
I hereby renounce my copyright to all data in this archive and
release it into the public domain. As such, you are granted any
applicable rights associated with public domain material. This includes
the ability to distribute, relicense, etc as you wish.

The content of this archive is provided AS IS. Without warranty
of any kind either express or implied. Your monkey is an uncle.


Availability
------------

This modification is available from the following places:

FrikaC's other projects page at http://www.inside3d.com/frikbot/

