Title    : FrikBot in PerQuake
Filename : frikper.zip
Version  : 0.09
Date     : 2-26-00
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Alan Kivlin for his rankings.qc and step movement
Frog for releasing the Frogbot code and giving me a good goal
to shoot for.

Additional thanks to Wazat, Asdf and MaNiAc who helped immensly with suggestions, code snipplets and ideas.

Major thanks to Per Kristian Risvik who wrote this mod in the first place, it's one great mod!

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : no
progs.dat     : yes


Description of the Modification
-------------------------------

PerQuake is one very well crafted mod, I was quite impressed with it when I read the review over on Fat Controller's website. I tried it out, and the elephant rifle was absolutely my favorite weapon I've seen for Quake. Anyway, it gets kinda boring blasting dumb old monsters, don't you think? 
                          
How to Install the Modification
-------------------------------

You must have the PerQuake patch to use the included files. PerQuake can be found at ftp://ftp.cdrom.com/pub/idgames2/quakec/weapons/perq.zip or whatever that translates to on your local mirror.

Copy all included files into your PerQuake directory. DO NOT OVERWRITE ANY PAK FILES.


Impulses
===========
100 Add a bot or add a bot to your team in a team game
101 Add a bot to an enemy team
102 Remove a bot
103 Bot Cam cycle. Cycles through the view of all bots & players currently on the server
104 Dump Waypoint data to console

Technical Details
-----------------

Known Bugs
==========
* Bots have a tendency to use up the ammo on the "Heavy Armor" and keep shooting
* The bots are a terrible shot with the elephant gun
* Bots don't like to use the Jobu chainsaw or the Voltaloydz gun very often.

For general frikbot bugs, please finger frika-c@mdqnet.net or visit the FrikBot homepage.


Availability
------------

This modification is available from the following places:

FrikBot homepage at http://www.mdqnet.net/frikbot/


