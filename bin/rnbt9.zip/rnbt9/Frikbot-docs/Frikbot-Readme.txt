11-21-01

At this time the Frikbot site seems to be down, so I cannot get all the related docs on the bot.

You can try later by visiting
www.inside3d.com/Frikbot


Chuck