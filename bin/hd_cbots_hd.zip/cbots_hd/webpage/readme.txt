Some quick notes on running CronosBots...to be revised at some point :)

Quick Start Instructions:
-------------------------
1. unzip all files to a subdirectory called cbots in the main quake directory.
2. copy the q95.bat file to the quake directory, and name it something else if you don't want to overwrite the current one.
3. run the batch file (double click it in win95) and quake will start up.
(if you run it in dos you will need to remove the -mpath argument).
4. start a multiplayer game and pick some options (timelimit, fraglimit, etc).
5. enter the game, and you will be on your chosen level. A message will appear 'now playing cronosbots', in which case all is well.
6. press f11 to add four bots, or f12 to add one. (note this will be random, so you could face hard or easy bots). now play!
7. press f8 at any time to remove the bots and f11/f12 to add them.

Playing Rocket Arena Rules (Quickstart):
----------------------------------------
1. You will need the rocket arena add-on for proper play of rocket arena. This includes the proper sounds and a load of levels which are excellent for proper rocket arena play. This is a free download from somewhere like ftp.cdrom.com, file farena12.zip. You can still start up rocket arena without the proper add-on but it isn't really recommended. The proper levels are the best and properly made for rocket arena with a proper waiting area for people to wait to fight in the arenas and view the current battle. It also includes the proper sounds. In fact I tried rocket arena on dm6 and it just sucks. farena12 has the full 46 levels from about three other packs too, so go get it!
2. Move or copy the pak file from rocket arena into your CronosBots directory.
3. Start Quake, running the CronosBots and begin a level.
4. Type 'Map arenax' at the console and you should restart in the first of the rocket arena levels. Note if you set a timelimit for the levels then it will move to the next level in the rocket arena add-on,etc.
5. Type 'Arena' at the console. The level should restart and this time you will see the message 'CronosBots Rocket Arena Mod' when it starts.
6. Now add bots as before with f11/f12,etc. To switch back to normal deathmatch use 'map xxxxxx' or 'restart'.

Other Hints/Tips:
-----------------
1. If you want to changelevel during rocket arena play then type 'changelevel xxxxxxx' at the console where xxxxxxx is the name of your level. This ensures the program stays in rocket arena mode.
2. To change the timelimit type timelimit xx at the console where xx is the number of minutes per level.
3. In rocket arena don't let too many bots in unless you enjoy waiting around. Three to four works well. If you find them too hard then try f8 and f12 to change them or ask for easy ones by name (type 'bugs' or 'barney' at the console). If they are too easy then try typing 'mantas' or 'abaddon' or 'pluto' at the console. If they are still too easy or too hard then change the skill level too (type 'skill 1' or 'skill 3' at the console).
4. Some of the other rocket arena levels if you can't be bothered to check out the names of them and look in the pak,etc (taken from points throughout the list) are arenax, arenrg3a, arenarg5, hill20, barena1, marena4, arendm1a, dom2_1ra, lowgrav. That way you can start at almost any point in the 45 levels or so and play a few at any point in time.

other commands:
---------------
alternative deathmatch rules - console command: 
'deathmatch 3' - for weaponstay rules (and respawn other items)
and then 'restart' to start level again.
(default is deathmatch 1 rules = respawn after time).
(also deathmatch 2 has some differences to 1).
deathmatch 4,5,6 added - as for 1,2,3 but no pentagrams/quads/envirosuits/invisibility

general keys
------------
f11 - add four bots
f12 - add one bot
f10 - change viewpoint (botcam)
f9  - bot info (can pause and scroll up)
f8  - remove bots 

impulses:
---------
impulse 100:BOT_CREATE adds four bots in deathmatch, 1 in coop.
impulse 101:BOT_ADDONE adds a bot
impulse 102:BOT_CAM enters botcam mode
impulse 103:BOT_LIST lists bots with basic details (health,target)
impulse 104:BOT_REMOVE removes all bots

impulse 105:COMP_DEMORECORD toggles competition recording as a demo file (called comp.dem)
impulse 106:COMP_START starts the competition (20 sec countdown).
impulse 107:COMP_EASY predefined 'easy' competition.
impulse 108:COMP_EASYMEDIUM predefined easy-medium competition.
impulse 109:COMP_MEDIUM predefined 'medium' competition.
impulse 110:COMP_MEDIUMHARD predefined 'medium-hard' competition.
impulse 111:COMP_HARD predefined 'hard' competition.
impulse 112:COMP_RULES summarises competition rules.
impulse 113:COMP_REC starts recorded comp against current bots.
impulse 114:COMP_A starts comp a - recorded 10 min 1 on 1 with Mantas, dmatch 4 rules
impulse 115:COMP_B starts comp b - recorded 10 min 1 on 1 with Abaddon, dmatch 4 rules

impulse 150 :ARENA_START (ordinary impulse) to switch to rocket arena rules.

impulse 201:BOT_ADD1 adds BOT_1 (Barney)
impulse 202:BOT_ADD2 adds BOT_2 (Bugs)
....................
impulse 217:BOT_ADD17 adds BOT_17 (Boogeyman)

Rocket Arena only:
------------------
impulse 68 :ARENA_STATS (rocket arena impulse) for stats.
impulse 69 :ARENA_POS (rocket arena impulse) to give position in queue.

Debugging only at the moment:
-----------------------------
impulse 90 :WAYPOINT_LIST
impulse 91 :WAYPOINT_SHOWPOINT
