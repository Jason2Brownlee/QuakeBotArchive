//*******************************************
//
//			SocketObj.h
//
//			V1.0 beta
//
//			by: Jim Rorie
//			Email: jfrorie@uncc.edu
//
// This is a Socket object.  Its keeps track of I/O, closing, opening, etc.
// It is general purpose and should work for anything
//
//*******************************************

#ifndef SOCKETOBJ_H
#define SOCKETOBJ_H

#ifdef __unix__
 #include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
 #include <netdb.h>
 #include <netinet/in.h>
 #include <sys/time.h>
 #include <sys/socket.h>
 typedef int SOCKET;
 typedef sockaddr *LPSOCKADDR;
 typedef sockaddr_in SOCKADDR_IN;
 #define INVALID_SOCKET -1
 #define FAR
#else
 #include <winsock.h>
 #include <stdio.h>
#endif


#define HOSTNAME_LEN 30

#define BUFLEN 2048

class SocketObj {

	SOCKADDR_IN RecvAddress; // Last Receive Address
public:

	void ServerListen();
	void SetDestinationToPacketSource();

	void SetTimeoutHandler(long, void (*Handler)(void));

	char InputBuffer[BUFLEN]; // Input packet buffer
	char OutputBuffer[BUFLEN]; // Output packet buffer
	char RemoteIP[18];			// Remote System's IP
	int RemotePort;				// its port

	char LocalIP[18];			// My IP
	int LocalPort;				// MY local Port

	void SendPacket(char *Data, int DataLen);  // Sends a raw packet
	int GetPacket();							// Get s raw packet
	int IsData(timeval);

	friend class PacketObj;			// Lets my packetobj talk

	void ResetSocket();
	
	SocketObj() {
		LocalPort = 0;
		RemotePort = 0;
		CheckVersion();				// Check winsock version
		MakeSocket();				// create a socket
	}
	
	void Init(){
		InitSocket(); // does a bind
		SetTimeoutHandler(3000, DefaultTimeoutHandler);
	}

	SOCKET GetSocket(){
		return SocketID;
	}
	
	~SocketObj() {					// shut down

		shutdown(SocketID, 2);
		closesocket(SocketID);
#ifndef __unix__
 
 		WSACleanup();
#endif

	}


private:

	SOCKET SocketID;					// System socket for object
										// All functions reference this	long RecvTimeout;
	timeval RecvTimeout;
	void CheckVersion();		
	void MakeSocket();
	void EvaluateStartupError(int);		// error routines
	void EvaluateError();
	void InitSocket();

	void (*TimeoutHandler) (void);				//  Routine that handles 
												// Receive timeouts

	static void DefaultTimeoutHandler(void) {

		printf("Receive timed out!!!!\n");

	}
	
};


#endif