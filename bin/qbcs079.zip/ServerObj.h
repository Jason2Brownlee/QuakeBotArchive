#ifndef SERVEROBJ_H
#define SERVEROBJ_H

#include "SocketObj.h"
#include "PacketObj.h"
#include "EntityObj.h"
#include "PlayerObj.h"
#include "EventTableObj.h"
#include "QuakeBot.h"
#include "Quake.h"

#include <limits.h>
#include <float.h>
#include <time.h>

#define QUITSTRING "No bots"


#ifdef __unix__
 #define strnicmp strncmp
 #define stricmp strcmp
 #define Sleep sleep
 #define TRUE 1
 #define FALSE 0
#endif



#define MAX_MODELS 255
#define MAX_SOUNDS 255

#define MAX_BASELINE_ENTITIES 450
#define MAX_STATIC_ENTITIES 128
#define GAME_STATE_PRESPAWN 1
#define GAME_STATE_LIGHTING 2
#define GAME_STATE_RENDER 3

//#define DECODE


enum QuakeServerModes { smSetup, smQuery, smGetRules, smConnect, smGameInit, smIdle };

typedef enum QuakeServerModes QuakeServerMode;

enum QuakeSocketModes { skIdle, skWaiting };

typedef enum QuakeSocketModes QuakeSocketMode;

class ServerObj: EventHandlerObj {

private:

	boolean Connected;

	// ***************************************************
	//
	//  Server Timeout routine. Uses Console instead of printf
	//
	// ***************************************************

	static void ServerTimeoutHandler(void) {

//		Console.DisplayString("Receive timed out!!!!\n");
		printf("Receive timed out!!!!\n");

	}

	EventTableObj *EventTable;
	time_t ClientStartTime;
	float ServerStartTime;
	int GameMode;
	boolean GetServerStartTime; // Flag to get the first start time
	QuakeServerMode ServerMode;
	QuakeSocketMode SocketMode;
	int SocketEventID;

public:

	PacketObj ServerPacket;


	// These are server parameters
	int sv_gravity, sv_friction, sv_maxspeed, noexit;
	int teamplay, fraglimit, timelimit;
	int NumModels, NumSounds;
	int StaticEntityCount;
	float DefaultOrigin[3], DefaultAngle[3];
	int DefaultModelIndex, DefaultFrame, DefaultColorMap, DefaultSkin, DefaultAttackState;
	int EntityIndex;
	char *PrecacheModel[255], *PrecacheSound[255];
	int NumberOfPlayers, MaxPlayers, MaxClients, Multi, BotID;
	PlayerObj **Player;
	EntityObj *BaselineEntity[MAX_BASELINE_ENTITIES];
	EntityObj *StaticEntity[MAX_STATIC_ENTITIES];
	char *BotName;
	char *ServerName; // Name of server
	char *IPString;
	char *MapName;		// Current Map Name
	long ServerVersion;
	int ProtocolVersion;
	float ServerTimeStamp, ClientTimeStamp;
	char Initialized;

	// Registered callbacks
	
	void CycleEvent(void *);
	void ExitEvent(void *); 
	void RecvEvent(void *);
	void MessageEvent(ObjectEvent, void *);
	
	// Member Functions
	ServerObj(EventTableObj *);
	void DecodePacket();
	void DecodeServerPacket();
	void SendGoodbye();
	void SetServer(char *, int);
	void QueryServer();
	void GetRules();
	void SendRuntimePacket(PlayerObj *);
	void SendBroadcastMessage(char *);
	void SendCommand(char *);
	void ConnectServer();
	int GameInit();
	void Respawn();
	int WhatIsAt(float, float, float);
	void SendClientParms(), SendBegin(), SendNoOp();
	void SendPrespawn();
	void BombOut(char *);
	void FreeEntities(), FreePlayers(), FreePrecache(), FreeMisc();
	int NearestPlayerByVector();
	int NearestEntityByVector(float, float, float);
	void DecodeAccept();
	void DecodeReject();
	void DecodeRule();
	void DecodeQuery();



	GameCoord *NextEntity(GameCoord *);

	void FreeData() {
		FreePlayers();
		FreeEntities();
		FreePrecache();
		SendGoodbye();
	}

};


#endif