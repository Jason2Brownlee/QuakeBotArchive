#include "WaypointObj.h"


WaypointObj::WaypointObj(float NewX, float NewY, float NewZ) {
	int i;

//	Console.DisplayString("Instantiating Waypoint\n");
	for(i = 0; i < MAX_CONNECTIONS; i++)//  Ground Connections
		Connection[i] = NULL;

	X = NewX; // Store location of Waypoint
	Y = NewY;
	Z = NewZ;
	Visited = FALSE;

}

void WaypointObj::Block(WaypointObj *PrevWaypoint){
	int Index;

//	Console.DisplayString("Blocking Waypoint\n");
	Index = FindFreeConnection();
	Connection[Index] = PrevWaypoint;
	Blocked[Index] = 1;

}

void WaypointObj::Attach(WaypointObj *PrevWaypoint){
	int Index;

//	Console.DisplayString("Attaching Waypoint\n");
	Index = FindFreeConnection();
	Connection[Index] = PrevWaypoint;
	Blocked[Index] = 0;
}

// ************************************
// *
// * Creates a new Waypoint Object
// * Should be call from previous Waypoint or NULL
// * Entrypoint
// *
// ************************************


WaypointObj *WaypointObj::Insert(float X, float Y, float Z) {
	WaypointObj *NewWaypoint;

	printf("Inserting Waypoint\n");
	NewWaypoint = new WaypointObj(X, Y, Z);
	Attach(NewWaypoint);
	return NewWaypoint;
}

int WaypointObj::FindFreeConnection() {
	int i;

	for(i = 0; i < MAX_CONNECTIONS; i++) {
		if(Connection[i] == NULL)
			return i;
	}

	printf("****Connections are all Full!!!\n");
	exit(2);
	return 0;

}

int WaypointObj::WithinRange(float CoordX, float CoordY, float CoordZ) {

	int Distance;

	Distance = (int)(pow(CoordX - X, 2) + pow(CoordY - Y, 2) + pow(CoordZ - Z, 2));
	if(Distance <= MAX_RANGE)
		return 1;
	else
		return 0;

}
