#ifndef PROXYSERVEROBJ_H
#define PROXYSERVEROBJ_H

#include "SocketObj.h"
#include "PacketObj.h"
#include "EventTableObj.h"
#include "QuakeBot.h"
#include "Quake.h"


#include <limits.h>
#include <float.h>
#include <time.h>

#ifdef __unix__
 #define strnicmp strncmp
 #define stricmp strcmp
 #define Sleep sleep
 #define TRUE 1
 #define FALSE 0
#endif


class ProxyServerObj : EventHandlerObj {


private:

	EventTableObj *EventTable;

	int SocketEventID;


	void Logon();

	// ***************************************************
	//
	//  Server Timeout routine. Uses Console instead of printf
	//
	// ***************************************************


	static void TimeoutHandler(void) {

//		Console.DisplayString("Receive timed out!!!!\n");
		printf("Receive timed out!!!!\n");

	}
	void RespondQuery();
	void RespondRule();
	void RespondConnect();

public:

	PacketObj ProxyServerPacket;

	// Server Parameters
//	char *IPString;
	char *BotName;
	long ClientVersion;
	char Initialized;
	ProxyServerObj(EventTableObj *, int);

	// Registered Callbacks
	void RecvEvent(void *);

	// Member Functions
	void DecodePacket();
	void DecodeClientPacket();
	void Init();

	time_t ClientStartTime;

};


#endif