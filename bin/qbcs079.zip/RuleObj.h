#ifndef RULEOBJ_H
#define RULEOBJ_H

#include <stdio.h>

class AliasObj;

class RuleObj {


private:

	
	RuleObj *PrevRule, *NextRule;

	friend AliasObj;

public:

	char *Variable;
	char *Value;


	RuleObj(RuleObj *Next) {

		NextRule = Next; // Point to previous object

	}

	RuleObj *GetNextRule() {
		return NextRule;
	}

	void Assign(char *VarName, char *VarValue) {

		Variable = strdup(VarName);
		Value = strdup(VarValue);

	}

	~RuleObj() {

		free(Variable);
		free(Value);
	}


};

#endif
