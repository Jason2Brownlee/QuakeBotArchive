#ifndef WaypointOBJ_H
#define WaypointOBJ_H

#include <stdio.h>

#include "ConsoleObj.h"

#define MAX_CONNECTIONS 50  // Number of different paths from Waypoint

#include <math.h>


const int MAX_RANGE = 100;

class WaypointObj {

private:
	int Weight;


public:
	int Visited;
	float X, Y, Z;

	WaypointObj *Connection[MAX_CONNECTIONS];
	int Blocked[MAX_CONNECTIONS];

	WaypointObj(float NewX, float NewY, float NewZ);
	void Attach(WaypointObj *NewWaypoint);
	void Block(WaypointObj *NewWaypoint);
	WaypointObj *Insert(float X, float Y, float Z);
	int FindFreeConnection();
	int WithinRange(float CoordX, float CoordY, float CoordZ);

	
};

#endif

