#ifndef QUAKEBOT_H
#define QUAKEBOT_H

struct CoordStruct{
	float X, Y, Z, Distance;
	int Index;
};

typedef struct CoordStruct GameCoord;

struct AddressStruct{
	char * IPAddress;
	int Port;
};

typedef struct AddressStruct Address;

enum EventDestinations {edConsole, edServer, edIBCServer, 
	edAI, edProxyServer}; // Event Destinations

typedef enum EventDestinations EventDest;

enum ObjectEvents {oeConsoleParse, oeConsolePrint, oeAIOn, oeAIOff,
oeServerOnline, oeServerOffline, oeServerConnect, oeServerDisconnect}; // Object events

typedef enum ObjectEvents ObjectEvent;


#endif

