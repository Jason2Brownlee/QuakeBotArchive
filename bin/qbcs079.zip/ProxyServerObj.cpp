#include "ProxyServerObj.h"

// ***********************************
// *
// * Sets up Proxy Server.
// *
// ***********************************

ProxyServerObj::ProxyServerObj(EventTableObj *Event, int LocalServerPort){		

	
	EventTable = Event;

	OwnerID = edProxyServer;
	ProxyServerPacket.Socket.LocalPort = LocalServerPort;

}

void ProxyServerObj::Init(){		

	EventTable->Print("Binding to Local Socket %d\n", ProxyServerPacket.Socket.LocalPort);

	ProxyServerPacket.Socket.Init();

	EventTable->Print("Proxy Server Bound\n");
	SocketEventID = EventTable->RegisterCallback((EventHandlerObj *)this, (void *)&(ProxyServerPacket.Socket), etRecvEvent);
	EventTable->SetSocketPolling(TRUE);
}


void ProxyServerObj::DecodePacket() {

	int PacketData = ProxyServerPacket.GetInputHeader();

	switch(PacketData) {
	case MESSAGE_TYPE_CONTROL:
//		EventTable->Print("Control Received\n");
		PacketData = ProxyServerPacket.ReadChar();
		switch(PacketData) {
		case CCREQ_RULE_INFO: // Rule Request
			RespondRule();
			break;		
		case CCREQ_SERVER_INFO: // Query Request
			RespondQuery();
			break;
		case CCREQ_CONNECT: // Connect Request
			RespondConnect();
			break;
		}
		break;
	case MESSAGE_TYPE_CLIENT:
		EventTable->Print("Client Received\n");
		break;
	case MESSAGE_TYPE_ACK:
		EventTable->Print("Ack Received\n");
		break;
	default:
		EventTable->Print("Default Received\n");
		break;
	}

}
void ProxyServerObj::RespondQuery() {

	EventTable->Print("Responding to Query\n");
	char Buffer[0x40];

	// This long named function makes sure that I transmit
	// to the same person that sent to me.
	// I will need to change this later so that only
	// One connection will be supported.

	ProxyServerPacket.Socket.SetDestinationToPacketSource();


	ProxyServerPacket.Reset();	
	ProxyServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);

	ProxyServerPacket.SaveChar(CCREP_SERVER_INFO); // Response
	sprintf(Buffer, "%s:%d", 	ProxyServerPacket.Socket.LocalIP,
		ProxyServerPacket.Socket.LocalPort);

	ProxyServerPacket.SaveString(Buffer); // IP:Port
	ProxyServerPacket.SaveString("BotProxy"); // Server name
	
	// This will change later.....
	ProxyServerPacket.SaveString("start");// Map Name
	ProxyServerPacket.SaveChar(0x00); // Number of players
	ProxyServerPacket.SaveChar(0x08); // Max Players

	ProxyServerPacket.SaveChar(NET_PROTOCOL_VERSION); // Net Protocol Version
	ProxyServerPacket.SendMessage();
}

void ProxyServerObj::RespondRule() {

	EventTable->Print("Responding to Rule Request\n");
	char Buffer[0x40];

	// This long named function makes sure that I transmit
	// to the same person that sent to me.
	// I will need to change this later so that only
	// One connection will be supported.

	// Get the rule argument sent to server
	strcpy(Buffer, ProxyServerPacket.ReadString());

	ProxyServerPacket.Socket.SetDestinationToPacketSource();
	ProxyServerPacket.Reset();	
	ProxyServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ProxyServerPacket.SaveChar(CCREP_RULE_INFO); // Response
	if(stricmp(Buffer, "") == 0) {
		ProxyServerPacket.SaveString("sv_gravity"); // Rule
		ProxyServerPacket.SaveString("800"); // Value

	} else if(stricmp(Buffer, "sv_gravity") == 0) {
		ProxyServerPacket.SaveString("sv_friction"); // Rule
		ProxyServerPacket.SaveString("123"); // Value

	} else if(stricmp(Buffer, "sv_friction") == 0) {
		ProxyServerPacket.SaveString("sv_maxspeed"); // Rule
		ProxyServerPacket.SaveString("123"); // Value

	} else if(stricmp(Buffer, "sv_maxspeed") == 0) {
		ProxyServerPacket.SaveString("fraglimit"); // Rule
		ProxyServerPacket.SaveString("123"); // Value
	
	} else if(stricmp(Buffer, "fraglimit") == 0) {
		ProxyServerPacket.SaveString("timelimit"); // Rule
		ProxyServerPacket.SaveString("123"); // Value
	
	} else if(stricmp(Buffer, "timelimit") == 0) {
		ProxyServerPacket.SaveString("teamplay"); // Rule
		ProxyServerPacket.SaveString("123"); // Value
	
	} else if(stricmp(Buffer, "teamplay") == 0) {
		ProxyServerPacket.SaveString("noexit"); // Rule
		ProxyServerPacket.SaveString("123"); // Value

	} else if(stricmp(Buffer, "noexit") == 0); // Do nothing
	ProxyServerPacket.SendMessage();
}

void ProxyServerObj::RespondConnect() {

	EventTable->Print("Responding to Connect\n");
//	char Buffer[0x40];

	// This long named function makes sure that I transmit
	// to the same person that sent to me.
	// I will need to change this later so that only
	// One connection will be supported.

	ProxyServerPacket.Socket.SetDestinationToPacketSource();

	ProxyServerPacket.Reset();	
	ProxyServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);

	ProxyServerPacket.SaveChar(CCREP_REJECT); // Response
	ProxyServerPacket.SaveString("Bot not connected to a server"); // Server name
	ProxyServerPacket.SendMessage();
}

void ProxyServerObj::RecvEvent(void * Dummy) {

//	EventTable->Print("Got Connection\n");
	ProxyServerPacket.GetMessage();
	DecodePacket();

}

