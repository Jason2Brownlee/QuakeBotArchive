#ifndef EVENTTABLEOBJ_H
#define EVENTTABLEOBJ_H

#include "SocketObj.h"
//#include "PacketObj.h"
#include "QuakeBot.h"

#ifndef __unix__
	#include <conio.h>
#endif


#include <limits.h>
#include <float.h>
#include <time.h>

const int MaxEvents = 16;

#ifdef __unix__
 #define strnicmp strncmp
 #define stricmp strcmp
 #define Sleep sleep
 #define TRUE 1
 #define FALSE 0
#endif

// **********************************************************
// *
// *  Events - only affect registered objects
// *
// *  etCycleEvent -  Get called once each event loop
// *  etRecvEvent - When data comes in your socket
// *  etKeyEvent - Keypress (For console mainly)
// *  etMessageEvent - When another object sends you a message
// *
// **********************************************************

enum EventTypes { etCycleEvent, etRecvEvent, etKeyEvent, etMessageEvent}; 


// **********************************************************
// *
// *  This is a skeleton base class used by all objects that
// *  Respond to events.  You inhereit it and override
// *  these functions with one of your own that fill the 
// *  specified task
// *
// **********************************************************

class EventHandlerObj {

public:
	
	// Override these in your object code and they will be called
	virtual void RecvEvent(void *Dummy){};
	virtual void CycleEvent(void *Dummy){};
	virtual void KeyEvent(void *Dummy){};
	virtual void MessageEvent(ObjectEvent EventType, void *Dummy){};

	// Special events. Called on Registration and Exit respectively
	virtual void InitEvent(void *Dummy){};
	virtual void ExitEvent(void *Dummy){};

	int OwnerID;  // Your ID, to handler
	char OwnerName[0x20];

	EventHandlerObj() {

		OwnerID = -1;	// -1 = unknown!!!!!
						//  You must override!!!

		strcpy(OwnerName, "Unknown");	// For debug purposes
										// Override in your object
										// if you like
	}
};

// **********************************************************
// *
// *  This object controls and dispatches events to registered
// *  objects.
// *
// **********************************************************

class EventTableObj {


private:

	int Execution, Timeout, ReturnValue, LastVectorEntry;

	timeval RecvTimeout;

	struct EventVectorStruct {
		SocketObj *Socket;
		SOCKET SocketID;
		EventHandlerObj *Callback;
		int OwnerID;
		void *CallbackData;
		enum EventTypes Event;
	};

	struct EventVectorStruct EventTable[MaxEvents];
	boolean SocketPolling;

public:

	EventTableObj();
	int RegisterCallback(EventHandlerObj *, void *, enum EventTypes);
	void DeleteCallback(int);
	void Exit(int);
	int EventLoop();
	void Print(char *Data, ...);	
	void SendMessage(EventDest, ObjectEvent, void *);
	void SetSocketPolling(boolean);

};


#endif