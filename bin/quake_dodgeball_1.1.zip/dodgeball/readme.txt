QUAKE DODGEBALL 1.1

		Trickle and Orion (rfalcetti@gmail.com)

///////////////////////////////////


::Description::

This isn't your typical dodgeball mod.  There are a lot of different ways
and strategies to be victorious! You will find that your power throw and
special dodgeballs will ultimately come in handy.  Critical hits and headshots
will help you in the best of times.  You have the choice of gold or green and 
the match will start upon using impulse 18.

::Rules::

Take out the entire opposite team.  Once everyone is in prison, the match is
over and a new one starts!


::Damages::


LEGEND:
(**) - Critical Damage
[**] - Critical Hit Chance
{**} - Headshot Damage (Power Ball only)
{(**)} - Headshot Critical (Power Ball only)

Normal Ball - 10-25 (30-75) [5%]

Normal Ball + Sprint - 25-45 (75-135) [10%]

Power Ball - 40-50 (120-150) [15%] {80-100} {(240-300)}

Power Ball + Sprint - 75-100 (225-300) [25%] {150-200} {(450-600)}


Special balls have no critical hit.

Ice Ball - 10, freezes enemy for 3 seconds

Fire Ball - 10, burns enemy for 10 seconds, burning does 10 damage per second

Bomb Ball - 160, just explodes on impact within a big radius

Homing Ball - 50, chases enemy for 10 seconds before exploding



::Commands::

impulse 15 - Catches a dodgeball(only regular ones).
impulse 16 - Power throw.  You can only use it each 20 seconds. 
impulse 17 - Sprinting(requires stamina which is displayed on your ammo HUD).
impulse 18 - Starts the match.
impulse 100 - Add a bot on the Gold Team.
impulse 101 - Add a bot on the Green Team.
impulse 102 - Kick a bot on the Gold Team.
impulse 103 - Kick a bot on the Green Team.


Deathmatch 2 - Enables special balls(enables saving prisoners on classic mode).

Scratch1 - Sets the amount of dodgeballs(maximum of 10 balls).

temp1 - If set to 1, game will play on classic one-hit kill mode. Note that there will be no special balls on this mode, even when deathmatch is set to 2. Deathmatch 2 will enable saving prisoners instead. Power throws won't work too, but sprinting is still there. 


::NOTE::

bots will only work if you set up a darkplaces server!

4/25/2011 Changelog:
Added missing 24-bit textures to certain models.
Three new maps by negke: dbbase, dbcastle, and dbvault.
Renamed models/sounds for better universal server compatibility.
Bots will no longer go after flying balls
Added a very special new ball ;)
You can now save teammates from prison by catching the ball with deathmatch 2, temp1 1



HAVE FUN!

