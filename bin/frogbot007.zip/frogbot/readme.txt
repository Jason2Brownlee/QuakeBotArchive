Title       : Frogbot
Filename    : frogbot007.zip
Version     : Beta 0.07
Date        : 8 May 1998
Author      : Robert Field
Email       : frog@powerup.com.au
Download    : http://www.telefragged.com/metro/
Build time  : Numerous hours


Note 1
------

This version may contain some minor unwanted buggy aspects of the
local navigation AI which were not evident in version 0.05. I decided
to release this version now because it has been too long since the
last release. As you can see, there are no new maps yet. Sometimes a
step backward must be taken to take two steps forward.

Note 2
------

I have decided to change from using a Pak0.pak file and now use a
progs.dat file. Make sure you delete the Pak0.pak file of any previous
Frogbot version in your current Frogbot directory.


About the mod
-------------

The Frogbot mod is a tribute to the excellent gameplay of multiplayer
LAN Quake and my continuing attempt to create a bot that is believably
human. I judge my efforts largely on the game product you play.

The current AI of the Frogbot is what I would regard as a fairly
minimal working model. I do intend to greatly improve it over time.
Though it is true that QuakeC presents limitations of all sorts, by
using a bit of ingenuity I have been able to push QuakeC to the
limits.

The first requirement of a 'human' bot, as opposed to a 'bot' bot, is
fluent navigational skills. With the sacrifice of using static
waypoints the Frogbot can achieve fluent navigation around a level,
and moreover can actually be programmed in QuakeC (this is assuming
todays relatively slow cpu speeds).

The Frogbot is basically an exact client emulation bot. It is the only
QuakeC bot that I have seen accomplish this.

I have decided to make my so far incomplete efforts available to the
Quake community so that other people can share in the enjoyment of
playing the Frogbot.


How to Install the Modification
-------------------------------

Create a directory called frogbot as a subdirectory in your Quake
directory and unzip frogbot007.zip into it. This version does not
require any additional player.mdl skin file or Pak0.pak file.


Commands
--------

Some commands only take effect after a level change (this includes
teamplay).

To add one to four Frogbots at a time:
addbot, add2bots, add3bots, add4bots

To add a bot of a particular color (for teamplay):
addbot0, addbot1, addbot2, addbot3, addbot4, addbot5, addbot6,
addbot7, addbot8, addbot9, addbot10, addbot11, addbot12, addbot13

removebot         - removes last bot that joined the game.

removeallbots     - removes all bots.

frogbot           - makes the internal frogbot AI take control of
                    your controls. Sit back and enjoy the smooth ride.

player            - to start playing if you weren't before.

framerate         - prints three framerate numbers on screen. For
                    debug/testing purposes only.

kascam            - turns on kascam camera. This camera uses the
                    Kascam 'engine' but I have modified its interface.
                    Use fire button to change between the observer,
                    kascam, and kascam follow modes. Use jump to move
                    up in observer mode, and change target in the
                    other modes. impulse 1 toggles auto/lock target.
                    The observer mode is a modification of the CTF
                    observer mode.

teamplay 0        - every man for himself.
teamplay 1        - teammate and self health protect.
teamplay 2        - teammate kill frag penalty.
teamplay 3        - teammate health protect.
teamplay 4        - teammate health and armor protect.
teamplay 5        - teammate health and armor protect, self health
                    protect.
(warning: in teamplay you suicide if you change pants color).
(note: unlike regular Quake, you must restart a map for new teamplay
settings to take effect with the Frogbot mod).

deathmatch 1      - all items respawn.
deathmatch 2      - only weapons stay.
deathmatch 3      - weapons stay and other items respawn.
deathmatch 4      - start with full armor, 250 health, all weapons
                    except the grenade launcher, unlimitted ammo.
                    health and armor respawn. quad becomes octa.
deathmatch 5      - start with full armor, 200 health, all weapons.
                    items besides weapons respawn.
deathmatch 6      - start with full armor, 100 health, all weapons,
                    sufficient ammo. no items. (not Rocket Arena, in
                    case you were wondering).

skill is from 0 to 102 (default 100 is the hardest noncheating skill).
Note: Once a Frogbot is spawned it retains its initial individual
skill level (the skill setting when it was spawned) even if you change
the skill variable at the console later. To change the skill of the
Frogbots you should remove them from the game.
Note: By spawning a few Frogbots, then changing the skill variable,
then spawning a few more Frogbots, you can have different skill
Frogbots in the same game.

Cheat skills:
skill 101         - same as skill 100 but Frogbots have cheaty aim.
skill 102         - same as skill 101 but Frogbots can't be bounced.

skin_up           - Increase the skin index.
skin_down         - Decrease the skin index.
(warning: all clients must have an appropriate player.mdl file if you
set the skin index to be nonzero)

powerup           - toggles powerups on and off.
rune              - allow/disallow runes.
rune_rj           - if runes are allowed and rune_rj is set then
                    self-inflicted splash damage/momentum (eg. for a
                    rocket jump) is the same as for normal Quake.
hook              - allow/disallow hook for clients (Frogbots don't
                    use it currently).
custom            - toggle use of CTF custom sounds and models (you
                    need to copy the Threewave Capture Pak0.pak and
                    Pak1.pak files into the frogbot directory for
                    this to work). Note: CTF is not currently
                    supported.
match             - toggle countdown match mode.
rl_pref           - toggle Frogbots' preference of rocket launcher
                    over the shaft.
samelevel         - stores the above commands' configuration (you
                    could set it in your autoexec.cfg after you find
                    out what it is for a configuration - this number
                    may change in future versions).

use_hook          - use the hook if it is allowed (bind this to a
                    convenient key).
ready             - start 15 second timer (in match mode).


Currently supported maps: dm4, dm6.


Notes on computer requirements and dedicated servers
----------------------------------------------------

If you want to run a large game (say 8 or more players) then if you
are not using a Pentium II you will need to run a dedicated server. I
tested a dedicated server with 16 players (15 bots) first with a 66
MHZ 486 and then with a 133 MHZ Pentium. You can forget about running
a dedicated server with a 486, since I got only 10 fps with the 486.
The dedicated Pentium server on the other hand had 35 fps using
WinQuake and 40 fps (the maximum, set using sys_ticrat 0.025) using
the MS_DOS prompt.


Remote commands (mainly for a dedicated server)
-----------------------------------------------

The deathmatch and teamplay commands are server only. However, there
is provided remote equivalent commands. Use deathmatch_n instead of
deathmatch n, and teamplay_n instead of teamplay n. Also map_dm4,
map_dm6 will remotely change to these maps.


Copyright and Distribution Permissions
--------------------------------------

The modifications included in this archive are Copyright 1998, Robert
Field. The original QuakeC source is Copyright 1996, id software.

You may distribute this Quake modification in any electronic format as
long as all the files in this archive remain intact and unmodified and
are distributed together.


Disclaimer
----------

Software under this agreement is under no kind of warranty. Software
under this agreement is provided as is, and isn't guaranteed in any
way by the mod author. Use this software at your own risk.


Code Credits
------------

id softare for Quake and QuakeC.

Alan 'Strider' Kivlin whose scoreboard code let me understand how to
do the scoreboard for QuakeC bots (normal Quake and Quakeworld).

Mr Elusive for suggesting a better stair climbing method, and for
suggesting Alan Kilvin's color bot method and thud removal method.

Alan Kivlin for the part he played in the previous sentence.

Karel 'Kasuha' Suhajda for the KasCam DeathMatch Camera code.

Dave 'Zoid' Kirsch for the CTF code.


Compiler Credit
---------------

This mod was compiled with meqcc.exe, the 'undecompilable' QuakeC
compiler written by Mr Elusive.


Names Credit
------------

Timm Stokke for zap, yoda, frag-god, dragon, Superman, and dizzy.

Mark 'Dethon' Petler for killingmachine, generalfailure, corpsegrind,
and addicted2quake.


Further Thanks
--------------

Mr Elusive for providing inspiration with his impressive Omicron bot.
If you haven't played it then what are you waiting for!

Timm Stokke for helping with the beta testing and for providing space
on Metropolis.
