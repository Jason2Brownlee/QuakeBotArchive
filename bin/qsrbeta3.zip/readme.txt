Title    : Hellsmash Beta 3
Filename : qsrbeta3.zip
Version  : 0.3
Date     : 02/11/2010
Author   : Dr. Shadowborg.
Email    : prismrifle@gmail.com
Credits  : FrikaC, Sajt, ceriux, Goldenboy, Ijed, leileilol, Lightning Hunter 
           and the rest of the Quake Community.  Also iD, and anybody else who
           I've managed to forget.
           (bug me and remind me what you did to aid in the development of this
            and I'll put you in here.)
Build time: Insanes.  And it's not done yet.

Type of Mod
-----------
Quake C    : yes
Sound      : yes
MDL        : yes
Brush type : yes  


Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (the hell is this?)
context diff  : no (I dunno what this is either.)
.qc files     : No (distributed separately)
.mdl files    : Duh.
sound files   : oh yeah.
.bsp files    : this too.
progs.dat     : this is what makes it work after all.


Description of the Modification
-------------------------------

The next exciting installment of hellsmash!  Woooo!

New Weapons, enemies, maps, and a whole slew of other neat things that are
still very much prototypey dwell inside!  But you'll have a blast playing it
nonetheless!  And yes, frikbots are included if deathmatch isn't your thing.

You can play both SP and DM on hse1m1.bsp, skill settings are included for SP.

press f1 ingame to get the gist of what you need to bind, etc.

All standard frikbot X impulse commands also apply.


How to Install the Modification
-------------------------------

Extract qsrbeta3.zip into your quake folder preferably into a qsr directory.

Start quake engine of your choice with -game qsr commandline with any other
appropriate commandlines.

Enjoy!

Technical Details
-----------------

...


Author Information
------------------

...


Copyright and Distribution Permissions
--------------------------------------

You may distribute this Quake modification in any electronic format as long 
as all the files in this archive remain intact and unmodified and are 
distributed together.

You may also steal any models or whatnot from this mod provided you do not
attempt to sell for profit, or claim credit for something you haven't done.
