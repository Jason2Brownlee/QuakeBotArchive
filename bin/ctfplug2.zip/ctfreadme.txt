Version 2.0
Author: Wazat (aka Dan Hale)

CTF Plugin is a Capture The Flag mod that can be easily plugged into most any mod.  Simply follow the simple instructions in ctf.qc to give your mod CTF.  This mod will support most CTF levels, including ThreeWave.

As an added bonus, there are 4 new CTF variations integrated into the mod, such as Rob The Nest.  Please see the CTF modes section for info on them.

========================
Playing Capture the Flag
========================

To start playing CTF, set deathmatch to 3 and load up a map with CTF flags on it.

How to play: Capture the Flag is easy.  There are two bases in the level - Red and Blue.  Each base has a flag in it.  Your goal is to steal the flag from the enemy base, and take it to your base, maybe making a few kills on the way.  Touch your flag while it is in its normal spot to capture the enemy flag and get a load of points for yourself and your team.  Your flag must be in its base position or you cannot capture it, until it is returned.

The only way to get your flag from an enemy player is to kill him, then touch your flag to return it to your base.  Some flags won't let team mates return them. You have to wait until they return on their own after a certain time limit.

You may drop the flag(s) you are carrying with impulse 15, but it can't be picked up again until 2 seconds later.

Lock and load.


==============
Changing Teams
==============

By default, this mod only lets players change their team when dead or durring an intermission, and takes away all their points when they do.  This can be changed in the code to fit the mod author's liking.
To change colors while dead, press Esc. and select multiplayer.  Then select setup, and change your pants color to the color of the team (Red or Blue, any other color for ThreeTeam CTF).  Or use the "color <shirt> <pants>" command at the console (for example, color 4 will set your shirt and pants to red, color 13 will set them to blue).


==============================
Gameplay differences in levels
==============================

In some levels the flags may differ a little than in others.  The flag may look different or make different sounds.  It may require that it return itself instead of allowing teammates to return it.  It may give different amounts of points for a capture, for the team and the person who captured it, or it may take points away from the other team when you capture their flag.  In some maps the enemy flag will be in your base, and you must take it to their base to capture it on your flag.  These things are up to the person who created the map.

Quite often such small differences can greatly change the strategy needed.  For example, if the enemy flag is in your base, the team must decide who is best suited to carry it into the enemy base and capture it, and then they must protect him on the way.  The enemy team will have advanced notice of who to look out for, and if they kill him, they will get a point for touching the flag to return it to base.  This works well for most CTF modes, including Offensive-Defensive CTF.


========================
CTF entities for mapping
========================

Read ctfents.txt for info on the CTF entities.  To make a normal ctf map, you simply build the map and place a flag for red and blue team, and the spawnpoints for the teams.  A third flag can be placed for the special CTF modes (see below).



==================
New CTF Variations
==================
These new CTF modes can be activated with the deathmatch variable.  See the section below for information on turning them on.  Please note that these modes will need a map that was designed for them (some require a third flag, etc).


Three-Team CTF
Red and Blue team exist as normal.  There is a third, neutral team that tries to grab either team's flag and capture it on their own flag.  Neutral Team's flag normally cannot be picked up (unless the level you are on allows for this).  Players on the Neutral team can be identified by their pants colors - they should be neither red nor blue.


Rob The Nest
The goal of RTN is not to capture your enemy's flag, but rather to capture another flag (the "Egg") which spawns somewhere in the map (the "Nest").  You must find the Egg and capture it on your own flag, which, depending on the map you're on, could be in your base or the enemy base.


Protect The Nest
PTN is similar to Rob The Nest, but rather than capturing the Egg on your flag, you must capture the enemy flag on the Egg.  The Egg cannot be picked up, only captured on, and both teams can capture on it.  Guarding the Nest from enemy players carrying your flag is as important as guarding your own base.  Some maps will have your flag in the enemy base, and the enemy flag in your base.


Offensive-Defensive CTF (aka: Assault CTF)
In Offensive-Defensive mode, one team is Offensive Team (Red), the other is Defensive Team (Blue).  Offensive Team has a small base consisting only of a flag and spawn points/ammo rooms.  Defensive Team has a large, defendable base, which the Offensive must penetrate.  Offensive Team must steal the flag, and capture it on their own flag.
Defense Team has advantages such as team doors that can only be crossed by its members, many mod-specific traps (laser gates, pits, monsters, turrets, whatever is in the mod you put it into), sometimes a larger team than Offensive Team has, and the relative size of their base.

Defensive Team can neither steal or capture Offensive Team's flag.  However, Offensive Team gets no points for kills, and so must rely on captures to gain points.
When a member of Defensive Team gets a kill, that member gets two points, and everyone else on the team gets 1 point.

Depending on the map, you may want to have more members on Offensive Team than on Defensive Team.  Other maps may require that Defensive Team be larger to have a fair, balanced game.  It all depends on the size of the map, what the map is like, the skill of the players, and how many points Offensive Team gets for a capture.


====================
Turning on CTF modes
====================
The deathmatch option is used to turn on the CTF modes when you want to play them.  To use it, simply type deathmatch at the console, followed by the number of the option you want.  1 and 2 are the classic deathmatch values.

1	Normal Deathmatch
2	Weapons Stay Deathmatch
3	Play Normal CTF
4	Play Three-Team CTF
5	Play Rob The Nest
6	Play Protect The Nest
7	Play Offensive-Defensive CTF

For example, to play RobTheNest, type:
deathmatch 5
restart

The restart command will restart the map so that the game mode can take effect.

All the ctf modes (including Normal CTF) will set teamplay if it's not already set

Keep in mind that some maps may not support certain modes.  Offensive-Defensive mode is the most map specific, though it will work ok with most CTF maps.
