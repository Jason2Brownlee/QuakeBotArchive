#!/bin/sh
cd /usr/local/games/quake
./qw_botserver
