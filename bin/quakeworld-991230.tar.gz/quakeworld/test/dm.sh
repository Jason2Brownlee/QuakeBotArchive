#!/bin/sh
cd /usr/local/games/quake
./qw-client-x11 -width 512 -height 345
