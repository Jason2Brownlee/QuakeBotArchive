.entity targetnode2;
.entity targetnode3;
.entity targetnode4;
.entity targetnode5;
.entity targetnode6;

.string target2;
.string target3;
.string target4;
.string target5;
.string target6;



// testing toggle
float 					MAGIK; 
float					ROUTE_ON;
float                                   NORSE_ON;
float                                   ATTACK_ON;
float 					VERBOSE; 

// admin code
float  					ADMIN1 	= 250; 
float  					ADMIN2 	= 251; 
float  					ADMIN3 	= 252;
float  					ADMIN4 	= 253;  


// bot defs 
float					standing;
float modelindex_female;
float 					SCAN_DIST = 600;
float 					ALLOWED_NUM = 100;
float 					PATH_NUM;
float 					FEMALE = 1; 
float					FEMALE_GAME;
float    				bot_ping;
string                                  mapname;
.float          			gender;
.float 					bot_skill;
.float					watertype2;
.vector					lastpos;
.entity					stuff;
.void()					th_stuff;
.string					cl;
.entity targetnode;



// darkext.qc
void    () 						DarkImpulseCommands; 
void    (float dist)                                    check_movetogoal;
void	(string botmsg)					BotTalk; 
void    (entity me, entity camera)                      BotCam;

// addon.qc
void    (entity e) 					deathmatch_four;
void    (entity e) 					start_frags;
void    () 						deathmatch_five;

// botroute.qc
void    (string map_name) 				SpawnWaypoints;

// shiva.qc
float	()						CheckDrop;
void	()				NewMemory;
// void	()						DropMemory;
void    (entity object)                                 tele_scan;
void    (entity object, string given)                   verbprint;
entity  (string search_name)                            BotRequestRoute;

// bot.qc
void 	(vector org) 					spawn_tfog;
void 	()                 				Bot_Precache;
void	(string name, float team_num, float skill_level)BotCreate;
void    ()                                      	botrespawn;

// darkemu.qc
void	(string abba)					BotManage;
void 	(float abba) 					MakeGood;
void	()						SpawnBotLevel;
float  	(string killname)                		RemoveBot;
float	() 						FindGood;

// norse.qc
void(float run_type)                                    norse_movetogoal; 
void	(entity me) 					find_trap;
float	(entity me, float dist) 			find_ledge;
float	(entity me) 					avoid_trap;
float	(entity me, vector org, vector dir) 		check_traj_pt;

// vision.qc
float    ()                                              combat_item;

// botfight.qc
void    ()                                              ThinkFight;
vector 	()                               		botaim;

// botai.qc
void    ()                                              BotPostThink;
void    ()                                              BotPreThink;
void    (entity wanted)                                 FoundKewl;
void    ()                                              bot_ai_stand;
void    ()                                              BotFoundTarget;
void    ()                                              BotHuntTarget;
void    ()                                              BotFoundStuff;
void    ()                                              BotHuntStuff;
float   ()                                              BotFindTarget;
float   ()                                              BotFindStuff;


// botmove.qc
void    (float dist)                                    bot_ai_walk;
void    (float dist)                                    bot_ai_run;
void    (float dist)                                    bot_ai_stuff;
void    ()                                              ai_chargez;
void    ()                                              ai_chargez2;
void	(entity object)					BotJump;
void	()						BotSwim;

// botfuzzy.qc
void	()						BotWaterLevel;
float	(entity object)					CanJump;
float   ()                                              BotPickWeapon;


void() BotAttackTarg;
float () FindNextGoal;
float	(string object, entity sub_goal)					BotWorth;
void	(string given) 					vbprint;
void	() 						button_wait;
void    (entity attacker, float damage)                 bot_pain;
void    ()                                              bot_pain_type;
void    ()                                              bot_die;
void    ()                                              BotSelfDeActivate;
void    ()                                              PainSound;
void    ()                                              button_touch;
void    ()                             			bot_attack;
void   	()                               		bot_kill1;
void   	()                               		bot_diea6;
