GENEBOT QUAKEWORLD SERVER SOURCE CODE DISTRIBUTION
--------------------------------------------------
AUTHOR:            Rich Whitehouse
CONTACT:           thefatal@telefragged.com
HOMEPAGE:          http://www.telefragged.com/thefatal/
RELEASE NUMBER:    1

From what I understand, the terms under which the Quake
source code has been distributed require me to make this
source code release as well since I am distributing my
modifications in binary form.

This is alright, because I would have wanted to distribute
this code either way. What's been done here is I've hacked
the engine apart to allow true yet still fake clients to
be placed into the game (or bots, in other words). Before
the source code release, QuakeC and client-side programs
were the only method of playing against bots. QuakeC is
very limited, and client-side programs are nearly
impossible to construct. Now with the Quake source code
release, there's an alternative. However, since the QW
server is not set up to handle fake clients, there's a
large slew of difficulties hacking them into it (many
of which resemble the problems experienced in early
versions of Half-Life with the fake client API). So, I've
spent my free holiday time fixing those problems and I've
put a basic bot into the server.

This method has many advantages over QuakeC. The bots
use true player physics which has never before been possible
except with client-side bots, you can use the bot in any
mod at all without having the source code to the mod, and
you get to program in C/C++ instead of QuakeC which destroys
all of those nasty limitations.

This has all been possible with client-side programs, but
many people (myself included) have neglected to bother with
that because it's such a pain to get one working.

Anyway, now about the bot itself. It's very, very basic. I
only spent a few minutes on the AI and all the rest was
spent mutilating the existing engine code to get fake
clients to work the way I wanted. This is where you come in.
I'd like to see people use this code as a base, and maybe
even eventually see a really good bot based on this frame
with decent advanced AI and such. HOWEVER, I must distribute
this code under the same terms that the Quake source code
was distributed. That means the GPL (gnu public license,
see gnu.txt in this archive for more info and I'd recommend
reading the whole thing) applies to you as well, so you
are obligated to distribute the source code for any changes
you make to this code itself if you decide to distribute
your work in binary form.

Now, onto what you need to compile this mess. First you need
the Quake source code in its entirety (go find it on an FTP
somewhere, it's pretty hard to miss). After that, put all of
the files in the \source folder from this archive into your
QW\Server folder under your Quake source code directory.

After that, you should be able to compile as normal pretty
much, I think. You may have to adjust a few things first, but
I'm not absolutely sure. I've only tried compiling this in
Microsoft Visual C++ 5.0.

When/if you distribute your modified source code, note that
it must be distributed under the terms of the GPL as well.
Again, make sure you read gnu.txt for all the information
you need on that.

One other thing. This is ONLY for the QW server. I haven't
even attempted a port of my hack job to the normal Quake
base, but you're welcome to attempt it yourself if you want.
Just remember that if you use any part of my code in doing
so you should give me full credit for it, and that any
modifications you make to the Quake source code still apply
to the terms under the GPL even if it doesn't have anything
to do with my code.

There's also probably still some nasty bugs lying around
because I don't think I was able to catch all the problems
caused by inserting clients without net channels into the
server, so you may want to improve on that a bit as well if
you can find anything else to do to it.

The bot work is mostly in sv_main.c (AddBot, DoBotThink,
etc), so that's where you'll want to start out.

Have fun, and happy bot-making.

-Rich
