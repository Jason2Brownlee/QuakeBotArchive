			SAM-FRAG Multi-Patch v0.01a

	Extract archive to a subdirectory of Quake called SAM.
			(ie. c:\quake\sam\)
	See SAM-FraG Multi-Patch v0.01a.txt for more info 