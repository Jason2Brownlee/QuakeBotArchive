/*
**
**  MBTALK
**
**  (c) 1997 mike warren
**  mikeBot
**
**  sends random insults, parses MBL- commands. see 
**
**   http://www.ucalgary.ca/~mbwarren/mikeBot/ 
**
**  for more on the mikeBotLanguage (MBL-)
**
*/

#ifndef _MBTALK_H_
#define _MBTALK_H_

#include "defines.h"
#include "mbotbase.h"

class mbtalk : public mbotbase
{
  int lastTalk;
  int current;		
  int cooperating;		// playerNumber of cooperating player, or 0

  char mbt_message[ Q_MAX_STRING ];

  char ** goodVerbs;
  char ** badVerbs;		
  char ** goodNouns;
  char ** badNouns;
  char ** cannedHurt;

  int numBadVerbs;
  int numGoodVerbs;
  int numGoodNouns;
  int numBadNouns;
  int numCannedHurt;

  void initWords();
  void deleteWords();
  void parseMessage( char * );

protected:
  int mbt_wingman;		// playerNumber for wingman (follow) mode (or 0)

  
public:

  mbtalk() { initWords(); lastTalk=0; current=0; cooperating=0; mbt_wingman=0;}
  ~mbtalk() { deleteWords(); }

  void update();

  void talkDamage( int );

  void gotSayMessage( char * x );

  int cmd( char * );

};


#endif
