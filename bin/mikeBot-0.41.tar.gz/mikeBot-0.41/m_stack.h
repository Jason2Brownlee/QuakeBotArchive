/*
**  m_stack
**  mike warren 1997
**
**  simple stack, based on m_list
**
*/


#ifndef _M_STACK_H_
#define _M_STACK_H_


#include "m_list.h"


template< class T >
class m_stack : protected m_list< T >
{
private:
	T m_errorValue;

public:
	m_stack() {}
	~m_stack() {}
	
	void push( T item ) { addHead( item ); }
	T pop() { T value = peek(); deleteHead(); return value; }
	T peek() const { return head ? head->data : m_errorValue; }

	int isEmpty() const { return !head; }
	void empty() { _deleteAllElements(); }

	void errorValue( T t ) { m_errorValue = t; }
	T errorValue() const { return m_errorValue; }

};




#endif