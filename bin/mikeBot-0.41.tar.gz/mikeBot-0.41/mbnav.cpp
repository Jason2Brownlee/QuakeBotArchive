/*
**
**  MBNAV class 
**
**  (c) 1997, mike warren
**  mikeBot
**
**  uses ROAMING code (see doc. for more)
**
**  handles navigation : has complete control over idealSpeeds, which are
**  changed to actual speeds after facing is determined (by mbfire). Also 
**  controls jumping. (unused, basically)
**
**  TODO:
**    . fix player chasing
**    . implement path-finding stuff
**    . get turn-vector stuff working before release
**    . when above, implement wall-avoidance
**    . probabilistic entity ratings
**
*/

#include "defines.h"
#include "mbnav.h"
#include <math.h>		// fmod()
#include <stdio.h>

/*
**  ctor
**
*/

mbnav::mbnav()
{ 
	stoppedTime = (double)0.0;
	stoppedTimestamp = (double)0.0;

	mbn_facing.set( (double)0.0,(double)0.0,(double)0.0 ); 

	mbn_jump=10; 

	mbn_target = 0;
	mbn_oldTarget = 0;
	mbn_los = FALSE;

	chase_isChasing = FALSE;
	chase_queue.empty();

	path_followingPath = FALSE;
	path_path.empty();
}

/*
**  aimAt 
**
**  Changes facing to target the point passed
**
*/


int mbnav::aimAt( vector & v )
{
   mbn_facing = entities[myEntityNumber].origin - v;
   return TRUE;
}

/*
**  update 
**
**  picks a target and goes for it (now just picks first visible 
**  non-player thing it sees
**
*/

void mbnav::update()
{
  vector tv = entities[ myEntityNumber ].velocity;

  tv.setz( (double)0.0 );

  if( entities[ myEntityNumber ].velocity.length() < (double)30.0 )
  {
	  if( stoppedTimestamp == (double)0.0 )
	  {
		  stoppedTimestamp = newTimestamp;
	  }

	  stoppedTime = newTimestamp - stoppedTimestamp;
	  path_stoppedTime = newTimestamp - stoppedTimestamp;
  }
  else
  {
	  stoppedTimestamp = (double)0.0;
	  stoppedTime = (double)0.0;
  }


  updateRatings();			// rate all visible targets
  aquireTarget();			// pick something interesting

			//
			//  try and find a path to the target entity
			//

  if( mbn_oldTarget != mbn_target && !path_followingPath )
  {
	  path_followingPath = map.pathToPoint( entities[ mbn_target ].origin, path_path );

	  if( path_followingPath )
	  {
		  path_target = path_path.pop();
		  path_targetNumber = mbn_target;
		  path_rating = entities[ mbn_target ].rate;

		  sayLocal( "found path" );
		  sendConsole( "say \"found path\"\n" );
	  }
  }

  if( chase_isChasing && isVisible( chase_targetNumber ) )
  {
	  if( (entities[myEntityNumber].origin-entities[ chase_targetNumber ].origin).length() < (entities[ myEntityNumber ].origin-chase_target).length() )
	  {
		  chase_queue.empty();
		  chase_queue.addTail( entities[ chase_targetNumber ].origin );
		  chase_target = entities[ chase_targetNumber ].origin;

		  sayLocal( "queue re-positioned" );
	  }
	  else
	  {
		  chase_queue.addTail( entities[ chase_targetNumber ].origin );
	  }
  }
  else
  {
	  if( mbt_wingman && isVisible( mbt_wingman ) )
	  {
		  if( !map.isShotBlocked( mbt_wingman ) )
		  {
				  chase_isChasing = TRUE;
				  chase_targetNumber = mbt_wingman;
				  chase_rating = 1000000.0;

				  chase_queue.empty();
				  chase_queue.addTail( entities[ chase_targetNumber ].origin );
				  chase_target = entities[ chase_targetNumber ].origin;
		  }
	  }
  }

  mbn_velocity = (double)320.0;

			//
			//  let behaviours have a go at some stuff; called in 
			//  heiarchacal order (most important are called LAST)
			//

//  mbn_facing.scale( (double)320.0 );

  b_pursueandevade();		// this just sets the seekTarget, navMode
  b_chaseplayer();			// possibly changes the seekTarget to chase
							// players along the chase_queue path
  b_pathfollow();			// follows a path, if one exists.
  b_seekandflee();			// this actually seeks, etc.
  b_avoidwall();			// "follows" walls
  b_avoidlava();			// stops if lava ahead.

  mbn_facing = mbn_turnvector;		// FIXME

			//
			//  show where I'm going
			//

  navParticle = seekTarget;

			//
			//  attempt to jump; this is naive and SHOULD CHANGE, DAMMIT
			//

  if( entities[mbn_target].origin.getz() - entities[myEntityNumber].origin.getz()  > 80.0 )
    if( !opts.get( "no-jump" ) )
      jump();	

			//
			// check for water
			//

  if( map.getCurrentLeafType() == 2 )
    if( !opts.get( "no-swim" ) )
      jump();

			//
			//  possibly cancel all the above stuff ;)
			//

  if( opts.get("no-move" ) )
    mbn_velocity = (double)0.0;

}

/*
**  updateRatings
**
**  Recalculates all the .rate and .rateMultiplier varaibles for every
**  entity;
**
**  TODO:
**    probabilistic updating; don't give non-visible entities 0 rating, 
**    unless they could have moved (i.e. players, projectiles)
**
*/

void mbnav::updateRatings()
{
  double rate;
  int i;
  vector tv0, tv1;

  for( i=info.maxPlayers; i < QCS_MAX_ENTITIES; i++ )
  {
	  rate = (double)0.0;
	  if( isVisible( i ) )
      {
		  if( isHealth( i ) )
		  {
			  if( health > 50 )
				  rate = (double)(100-health)*2;
			  else
				  rate = (double)(100-health)*4;
		  }
		  else if( isShells( i ) )
			  rate = (double)(100-shells);
		  else if ( isCells( i ) )
		  {
			  if( haveLG() )
				  rate = (double)(100-cells)/2;
			  else
				  rate = (double)1.0;
		  }
		  else if ( isRockets( i ) )
		  {
			  if( haveRL() )
				  rate = (double)(200-rockets)/2;
			  else
				  rate = (double)1.0;
		  }
		  else if( isNails( i ) )
		  {
			  if( (haveNG()||haveSNG())  )
				rate = (double)(200-nails)/2;
			  else
				  rate = (double)1.0;
		  }
		  else if ( isArmour( i ) )
			  rate = (double)(100-armour)/2;
		  else if ( isLG( i ) && !haveLG() )
			  rate = (double)110;
		  else if ( isRL( i ) && !haveRL() )
			  rate = (double)100;
		  else if ( isSNG( i ) && !haveSNG() )
			  rate = (double)100;
		  else if ( isSSG( i ) && !haveSSG() )
			  rate = (double)105;
		  else if ( isNG( i ) && !haveNG() )
			  rate = (double)100;
		  else if ( isBackpack( i ) )
			  rate = (double)102;
		  else if ( isPowerup( i ) )
			  rate = (double)100;
		  else if ( isProjectile( i ) )
		  {
			  rate = (double)0.0;
			  if( willHitMe( i ) )
			  {
				  vector temp = (entities[ myEntityNumber ].origin-entities[i].origin);
				  mbn_intersection =  entities[i].velocity.intersectWithPlane( entities[i].origin, entities[myEntityNumber].origin, temp );
				  if( (entities[ myEntityNumber ].origin - mbn_intersection).length() < 256.0 )
				  {
					  rate = (double)1500.0;
				  }
				  if( (entities[ myEntityNumber ].origin - mbn_intersection).length() < 512.0 && isMissile( i ) )
				  {
					  rate = (double)2000.0;
				  }
			  }
  			  else if( isGrenade( i ) )
			  {
				  if( (entities[myEntityNumber].origin-entities[i].origin).length() < 200 )
					  rate = (double)1000.0;
			  }
		  }
		  else if( isPlayer( i ) )
		  {
			  if( health + armour < 100 )
			  {
				  vector v0 = entities[i].facing;
				  vector v1 = entities[myEntityNumber].origin - entities[i].origin;

				  v0.normalize();
				  v1.normalize();

				  if( v0 * v1 > 0 )
				  {
					  mbn_intersection = v0.intersectWithPlane( entities[i].origin, entities[myEntityNumber].origin, v1 );
					  rate = (double)500.0;
				  }
			  }
		  }
		  else
			  rate = (double)0.0;
	  }
	  else
	  {
		  entities[ i ].rate = (float)0.0;
		  entities[ i ].rateMultiplier = (float)1.0;
	  }

	  rate *= 1000.0;
	  entities[ i ].rate = (float)rate;
  }

}


/*
**  aquireTarget
**
**  gets a nav target. If fireTarget != 0, then it will only
**  go after something else if health/ammo low
**
**  CALL UPDATE RATINGS FIRST
**
*/


void mbnav::aquireTarget()
{
  double bestRate,rate;
  int bestTarget;
  int i;
  vector tv;

  if( mbn_target )
  {
	  if (stoppedTime >= (double)1.3 )
	  {
		  stoppedTime = (double)0.0;
		  stoppedTimestamp = (double)0.0;
		  entities[ mbn_target ].rateMultiplier /= (float)2.0;
	  }
  	  if( !isPlayer( mbn_target ) && !isProjectile( mbn_target ) )
	  {
		  double p = (entities[mbn_target].origin-entities[myEntityNumber].origin).getPitch();
		  if( p > 50.0 || p < -75 )
			  entities[mbn_target].rateMultiplier /= (float)8.0;
	  }
	  if( !isVisible( mbn_target ) )
	  {
		  mbn_target = 0;
	  }
  }

  if( mbf_target )
  {
	  bestRate = (double)((2*(health+armour)) + shells + rockets + cells);
      //bestRate /= 10.0;
	  bestRate *= (double)100.0;
      bestTarget = mbf_target;
  }
  else
  {
      bestRate = (double)0;
      bestTarget = 0;
  }

  for( i=info.maxPlayers; i < QCS_MAX_ENTITIES; i++ )
  {
	  rate = entities[ i ].rate;
	  rate *= entities[ i ].rateMultiplier;

//	  if( i == mbn_target )
//	  {
//		  rate *= (double)opts.get( "persistency" );
//	  }


	  if( rate > bestRate )
	  {
		  bestRate=rate;
		  bestTarget = i;
	  }
  }

  if( bestTarget != mbn_target && bestTarget )
  {
	  mbn_oldTarget = mbn_target;
	  mbn_target = bestTarget;
#if DEBUG & DMBN
	  printf("mbnav::selectTarget(): new target `%s'\n", modeltable[ entities[mbn_target ].index ] );
#endif
  }
}

  
/*
**  dumpPath 
**
*/

void mbnav::dumpPath()
{
}



/*
**
**       BEHAVIOURS
**
**
*/

/*
**  b_avoidlava
**
**  Sets mbn_velocity to 0 if lava is ahead. Relies on wall-avoidance
**  mechanism to turn, etc.
**
*/

void mbnav::b_avoidlava()
{
   vector tv0 = mbn_facing;
   vector tv1 = mbn_facing;

   tv0.normalize();
   tv0 *= (double)-64.0;
   tv0.setz( (double)0.0 );
   tv0 += entities[myEntityNumber].origin;
   vector tv02 = tv0;
   tv02.setz( -(double)32700.0 );
      
   tv1.normalize();
   tv1 *= (double)-96.0;
   tv1.setz( (double)0.0 );
   tv1 += entities[myEntityNumber].origin;
   vector tv12 = tv1;
   tv12.setz( -(double)32700.0 );
      
   if( map.isLineBlockedFluid( tv0, tv02, 0, opts.get( "avoid-water" ) ) ||
	   map.isLineBlockedFluid( tv1, tv12, 0, opts.get( "avoid-water" ) )   )
   {
	   mbn_velocity = (double) -1.0;
   }
   
}

/*
**  b_avoidwall
**
**  intersects a short forward-facing line segment into the BSP and
**  uses (endpoint - intersectionpoint) as the "wall normal" (as per
**  http://hmt.com/cwr/steer/) and then uses it as the turn vector
**  unless it is too "short" (i.e. < 1 unit?)
**
**  TODO: implement this
**
*/

void mbnav::b_avoidwall()
{
}



/*
**  b_pursueandevade
**
**  Sets navmode, relies on b_seekandflee()
**
*/

void mbnav::b_pursueandevade()
{
	if( mbn_target )
	{
		if( isProjectile( mbn_target ) || (isPlayer(mbn_target)&&(health+armour<100)) )
			mode = nm_flee;
		else
			mode = nm_seek;

		if( isPlayer( mbn_target ) && (health+armour>=100) )
		{
			vector tv = entities[myEntityNumber].origin - entities[mbn_target].origin;
			tv.normalize();
			tv *= (double)mbf_idealrange;
			seekTarget = entities[ mbn_target ].origin + tv;
		}
		else if( (isProjectile( mbn_target ) && !isGrenade( mbn_target )) || (isPlayer(mbn_target)&&(health+armour<90)) )
		{
			if( isPlayer( mbn_target ) ) mbn_los = TRUE;
			else mbn_los=FALSE;
			seekTarget = mbn_intersection;
		}
		else
		{
			seekTarget = entities[ mbn_target ].origin;
		}
	}
}

/*
**  b_pathfollow
**
**  If a path exists, this behavior follows it.
**
*/

void mbnav::b_pathfollow()
{
	if( !path_followingPath )
		return;

	vector tva = path_target;
	vector tvb = entities[ myEntityNumber ].origin;

	tva.setz( 0.0 );
	tvb.setz( 0.0 );

	if( !path_path.isEmpty() )
	{
		mode = nm_path;
		seekTarget = path_target;

		double distanceToNextWaypoint = (tva-tvb).length();

		if( distanceToNextWaypoint < 32.0 )
		{
			path_target = path_path.pop();

			sayLocal( "waypoint reached" );
			sendConsole( "say \"waypoint\n" );
		}

		if( path_stoppedTime > 0.2 )
		{
			path_stoppedTime = 0.0;
			path_target = path_path.pop();
			
			sayLocal( "dropped waypoint" );
			sendConsole( "say \"dropped waypoint\n" );
		}
	}
	else
	{
		path_followingPath = FALSE;
		path_targetNumber = 0;
		path_rating = 0.0;

		sayLocal( "arrived at destination" );
		sendConsole( "say \"arrived\n" );
	}

}

/*
**  b_chaseplayer
**
**  If "chasing", decides whether or not to skip a waypoint and
**  sets the seektarget to the next waypoint
**
*/

void mbnav::b_chaseplayer()
{
	if( !chase_isChasing )
		return;

	/*
	if( mbn_target && (mbn_target != chase_targetNumber) && chase_rating < entities[ mbn_target ].rate )
	{
		chase_rating = 0.0;
		chase_targetNumber = 0;
		chase_isChasing = FALSE;
		chase_queue.empty();

		sayLocal( "gave up chase" );

		return;
	}
	*/

	vector tva = chase_target;
	vector tvb = entities[ myEntityNumber ].origin;

	tva.setz( 0.0 );
	tvb.setz( 0.0 );

	if( !chase_queue.isEmpty() )
	{
		mode = nm_chase;
		seekTarget = chase_target;

		double distanceToNextWaypoint = (tva-tvb).length();

		if( distanceToNextWaypoint < 32.0 || entities[ myEntityNumber ].velocity.length() < 20.0 )
		{
			chase_queue.deleteHead();
			chase_queue.reset();
			if( !chase_queue.isEmpty() )
			{
				chase_target = *chase_queue;
				seekTarget = chase_target;
			}
			else
			{
				chase_rating = 0.0;
				chase_targetNumber = 0;
				chase_isChasing = FALSE;

				sayLocal( "ran out of chase points" );
			}
		}
	}
}




/*
**  b_seekandflee
**
**  Depending on nav mode, this goes after or runs from seekTarget
**
*/

void mbnav::b_seekandflee()
{
	vector tv = entities[ myEntityNumber ].origin - seekTarget;

	mbn_turnvector = tv; //- mbn_facing;
//	mbn_turnvector.scale( 32.0 );

	if( mode == nm_flee )
	{
		mbn_turnvector *= -1.0;
	}
}


/*
**  cmd
**
**  see qcs::cmd()
**
*/

int mbnav::cmd( char * in )
{
	switch( in[0] )
	{
	case 'j':
		printf("Jump\n");
		forceJump();
		return TRUE;
		break;

		
    case 't':
		printf("Target : mbfire : ");
		mbf_printTarget();
		printf(" : mbnav : ");
		mbn_printTarget();
		printf("\n");
		return TRUE;
	    break;
	}

		
	return mbfire::cmd( in );
}