/*
** "overridable" (i.e. designed to be) functions
**
*/

#include "defines.h"
#include "qcs.h"


/*
** rankings : displays names and rankings
**
**  TODO : sort by frags
*/

void qcs::rankings()
{
  for( int i=0; i < info.maxPlayers; i++ )
    if( players[ i ].name && *players[ i ].name )
      {
	printf("%-20s    %2d [ ", players[ i ].name, players[ i ].frags);
	printf("%02d | %02d ]\n", players[ i ].shirt, players[i].pants);
      }

	    
}
    
	
