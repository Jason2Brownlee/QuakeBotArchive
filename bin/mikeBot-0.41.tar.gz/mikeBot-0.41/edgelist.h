/*
**  support class for bspFile
**  (c) 1997 mike warren
**
**  this code is *not* freeware. See the file ``README'' or contact
**  mbwarren@acs.ucalgary.ca
**
**  (excuse the rather long ::read() inlined functions, but i didn't feel like
**   having lotsa .cc files :) )
**
*/



#ifndef _EDGELIST_H_
#define _EDGELIST_H_


#include "defines.h"
#include "mfile.h"


class bspEdgeList
{
  int * edgelists;
  int loadedEdgelists;

  bspEdgeList(){}

public:
  bspEdgeList( mFile & mf, int n ) 
  { 
	  edgelists=new int[ n ];
	  loadedEdgelists=0; 
	  read( mf, n ); 
  }
  ~bspEdgeList(){ delete edgelists; }

  void read( mFile & mf, int n )
  {
	  for( int i=0; i < n; i++) 
		  edgelists[i]=mf.readLEint(); 
	  loadedEdgelists=n; 
  }

  int getEdgeList( int x ) { return operator[]( x ); }
  int operator[] ( int x )
  { 
	  if ( x >=0 && x < loadedEdgelists ) 
		  return edgelists[x];
	  return 0; 
  }
  int getNum() { return loadedEdgelists; }

  void dump() { for( int i=0; i < loadedEdgelists; i++) printf("%d : %d\n", i, edgelists[i] ); }

};

#endif

