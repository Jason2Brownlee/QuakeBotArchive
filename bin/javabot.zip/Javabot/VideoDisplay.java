import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

class VideoDisplay extends Canvas {

    Vect3D player=new Vect3D();
    Vect3D target=new Vect3D();
    Vect3D destination=new Vect3D();
    boolean drawtarget,drawdestination;

    public VideoDisplay() {
 
    }

    public void paint(Graphics g) {
        int x,y;

        g.clearRect(0,0,304,236);

        if(drawtarget) {
            x=(int)((target.x-player.x)/16);
            y=(int)((target.y-player.y)/16);
            g.setColor(new Color(255,0,0));
            g.fillOval(148+x,114+y,8,8);
        }

        if(drawdestination) {
            x=(int)((destination.x-player.x)/16);
            y=(int)((destination.y-player.y)/16);
            g.setColor(new Color(0,255,0));
            g.fillOval(148+x,114+y,8,8);
        }

        g.setColor(new Color(0,128,0));
        g.fillOval(148,114,8,8);
    }
}