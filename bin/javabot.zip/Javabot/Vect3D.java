class Vect3D {
    float x,y,z;

    public Vect3D() {
        x=0;
        y=0;
        z=0;
    }

    public Vect3D(Vect3D u,Vect3D v) {
        float d;
        x=u.y*v.z-v.y*u.z;
        y=u.z*v.x-v.z*u.x;
        z=u.x*v.y-v.x*u.y;
        d=(float)Math.sqrt((double)(x*x+y*y+z*z));
        x=x/d;
        y=y/d;
        z=z/d;
    }

    public void println() {
        System.out.println("("+x+","+y+","+z+")");
    }
}