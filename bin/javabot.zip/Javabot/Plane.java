class Plane {
    Vect3D normal=new Vect3D();
    float dist;
    int type;
}