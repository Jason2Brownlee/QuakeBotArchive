class StaticEntity {
    int default_modelindex;
    int default_frame;
    int default_colormap;
    int default_skin;
    int x,y,z;
    int xa,ya,za;
}