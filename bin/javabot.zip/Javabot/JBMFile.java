import java.lang.SecurityException;
import java.lang.IllegalArgumentException;
import java.io.RandomAccessFile;
import java.io.IOException;

class JBMFile {
    RandomAccessFile file;
    JBMFileHeader header;
    Plane planes[];
    BSPNode bspnodes[];
    ClipNode clipnodes[];
    Hull hulls[];
    BSPLeaf bspleaves[];
    Vertex verticies[];
    Face faces[];
    Edge edges[];
    int facelist[];
    int edgelist[];
    Link links[];
    int dist[];
    LinkList lists[];
    int path[];
    int path_length;

    public JBMFile(String filename) throws IOException {
        filename=convertFileName(filename);
        System.out.println("Opening Map: "+filename);
        try {
            file=new RandomAccessFile(filename,"r");
        } catch(IllegalArgumentException e) {
            System.err.println("Arguement Error: "+e);
        } catch(SecurityException e) {
            System.err.println("Security Error: "+e);
        }
        header=new JBMFileHeader(file);
        header.readHeader();

        System.out.print("Reading Hulls:");
        file.seek(header.hulls.offset);
        hulls=new Hull[header.hulls.entries];
        System.out.println(" "+header.hulls.entries);
        for(int i=0;i<header.hulls.entries;i++) {
            hulls[i]=new Hull();
            hulls[i].bound.min.x=file.readFloat();
            hulls[i].bound.min.y=file.readFloat();
            hulls[i].bound.min.z=file.readFloat();
            hulls[i].bound.max.x=file.readFloat();
            hulls[i].bound.max.y=file.readFloat();
            hulls[i].bound.max.z=file.readFloat();
            hulls[i].origin.x=file.readFloat();
            hulls[i].origin.y=file.readFloat();
            hulls[i].origin.z=file.readFloat();
            hulls[i].rootbspnode=file.readInt();
            hulls[i].rootclipnode=file.readInt();
            hulls[i].secondaryclipnode=file.readInt();
            hulls[i].unknownnode=file.readInt();
            hulls[i].numleafs=file.readInt();
            hulls[i].face_id=file.readInt();
            hulls[i].face_num=file.readInt();
        }

        System.out.print("Reading Planes:");
        file.seek(header.planes.offset);
        planes=new Plane[header.planes.entries];
        System.out.println(" "+header.planes.entries);
        for(int i=0;i<header.planes.entries;i++) {
            planes[i]=new Plane();
            planes[i].normal.x=file.readFloat();
            planes[i].normal.y=file.readFloat();
            planes[i].normal.z=file.readFloat();
            planes[i].dist=file.readFloat();
            planes[i].type=file.readInt();
        }

        System.out.print("Reading BSP Nodes:");
        file.seek(header.nodes.offset);
        bspnodes=new BSPNode[header.nodes.entries];
        System.out.println(" "+header.nodes.entries);
        for(int i=0;i<header.nodes.entries;i++) {
            bspnodes[i]=new BSPNode();
            bspnodes[i].plane_id=file.readInt();
            bspnodes[i].front=file.readShort();
            bspnodes[i].back=file.readShort();
            bspnodes[i].face_id=file.readShort();
            bspnodes[i].face_num=file.readShort();
        }

        System.out.print("Reading Clip Nodes:");
        file.seek(header.clipnodes.offset);
        clipnodes=new ClipNode[header.clipnodes.entries];
        System.out.println(" "+header.clipnodes.entries);
        for(int i=0;i<header.clipnodes.entries;i++) {
            clipnodes[i]=new ClipNode();
            clipnodes[i].plane_id=file.readInt();
            clipnodes[i].front=file.readShort();
            clipnodes[i].back=file.readShort();
        }

        System.out.print("Reading BSP Leaves:");
        file.seek(header.leaves.offset);
        bspleaves=new BSPLeaf[header.leaves.entries];
        System.out.println(" "+header.leaves.entries);
        for(int i=0;i<header.leaves.entries;i++) {
            bspleaves[i]=new BSPLeaf();
            bspleaves[i].type=file.readShort();
            bspleaves[i].lface_id=file.readShort();
            bspleaves[i].lface_num=file.readShort();
        }

        System.out.print("Reading Verticies:");
        file.seek(header.verticies.offset);
        verticies=new Vertex[header.verticies.entries];
        System.out.println(" "+header.verticies.entries);
        for(int i=0;i<header.verticies.entries;i++) {
            verticies[i]=new Vertex();
            verticies[i].x=file.readFloat();
            verticies[i].y=file.readFloat();
            verticies[i].z=file.readFloat();
        }

        System.out.print("Reading Faces:");
        file.seek(header.faces.offset);
        faces=new Face[header.faces.entries];
        System.out.println(" "+header.faces.entries);
        for(int i=0;i<header.faces.entries;i++) {
            faces[i]=new Face();
            faces[i].plane_id=file.readShort();
            faces[i].side=file.readShort();
            faces[i].ledge_id=file.readInt();
            faces[i].ledge_num=file.readShort();
            faces[i].link_id=file.readInt();
            faces[i].link_num=file.readShort();
            faces[i].floor=file.readInt();
            faces[i].x=file.readFloat();
            faces[i].y=file.readFloat();
            faces[i].z=file.readFloat();
        }

        System.out.print("Reading Edges:");
        file.seek(header.edges.offset);
        edges=new Edge[header.edges.entries];
        System.out.println(" "+header.edges.entries);
        for(int i=0;i<header.edges.entries;i++) {
            edges[i]=new Edge();
            edges[i].vertex0=file.readShort();
            edges[i].vertex1=file.readShort();
        }

        System.out.print("Reading Face List:");
        file.seek(header.lfaces.offset);
        facelist=new int[header.lfaces.entries];
        System.out.println(" "+header.lfaces.entries);
        for(int i=0;i<header.lfaces.entries;i++) {
            facelist[i]=file.readShort();
        }

        System.out.print("Reading Edge List:");
        file.seek(header.ledges.offset);
        edgelist=new int[header.ledges.entries];
        System.out.println(" "+header.ledges.entries);
        for(int i=0;i<header.ledges.entries;i++) {
            edgelist[i]=file.readInt();
        }

        System.out.print("Reading Links:");
        file.seek(header.links.offset);
        links=new Link[header.links.entries];
        System.out.println(" "+header.links.entries);
        for(int i=0;i<header.links.entries;i++) {
            links[i]=new Link();
            links[i].face=file.readInt();
            links[i].flags=file.readInt();
            links[i].x=file.readFloat();
            links[i].y=file.readFloat();
            links[i].z=file.readFloat();
        }

        System.out.println("Creating Database Array: 200 x 100");
        dist=new int[header.faces.entries];
        lists=new LinkList[200];
        path=new int[200];
        for(int i=0;i<200;i++) {
            lists[i]=new LinkList();
        }

        System.out.println("Map loaded");
        file.close();
    }

    private String convertFileName(String s) {
        char c[];
        c=s.toCharArray();
        int i=0;
        while(c[i]!='.') {
            i++;
        }
        c[i+1]='j';
        c[i+2]='b';
        c[i+3]='m';
        return (new String(c));
    }

    public boolean traceLine(Vect3D o,Vect3D p) {
        boolean test;
        test=intersect(o,p,hulls[0].rootclipnode,0,1);
        if(test) {
            return false;
        } else {
            return true;
        }
    }

    private boolean intersect(Vect3D o,Vect3D p,int node,float min,float max) {
        float tx,ty,tz;
        float nx,ny,nz;
        float dist,t;
        float temp;
        int near,far;
        int plane_id;
        plane_id=clipnodes[node].plane_id;
        tx=p.x-o.x;
        ty=p.y-o.y;
        tz=p.z-o.z;
        nx=planes[plane_id].normal.x;
        ny=planes[plane_id].normal.y;
        nz=planes[plane_id].normal.z;
        dist=planes[plane_id].dist;
        if(planes[plane_id].type==0) {
            if(tx!=0) {
                t=(nx*dist-o.x)/tx;
            } else {
                t=Float.NaN;
            }
            if((o.x*nx)<dist) {
                near=clipnodes[node].back;
                far=clipnodes[node].front;
            } else {
                near=clipnodes[node].front;
                far=clipnodes[node].back;
            }
        } else if(planes[plane_id].type==1) {
            if(ty!=0) {
                t=(ny*dist-o.y)/ty;
            } else {
                t=Float.NaN;
            }
            if((o.y*ny)<dist) {
                near=clipnodes[node].back;
                far=clipnodes[node].front;
            } else {
                near=clipnodes[node].front;
                far=clipnodes[node].back;
            }
        } else if(planes[plane_id].type==2) {
            if(tz!=0) {
                t=(nz*dist-o.z)/tz;
            } else {
                t=Float.NaN;
            }
            if((o.z*nz)<dist) {
                near=clipnodes[node].back;
                far=clipnodes[node].front;
            } else {
                near=clipnodes[node].front;
                far=clipnodes[node].back;
            }
        } else {
            temp=nx*tx+ny*ty+nz*tz;
            if(temp!=0) {
                t=(dist-o.x*nx-o.y*ny-o.z*nz)/temp;
            } else {
                t=Float.NaN;
            }
            if((o.x*nx+o.y*ny+o.z*nz)<dist) {
                near=clipnodes[node].back;
                far=clipnodes[node].front;
            } else {
                near=clipnodes[node].front;
                far=clipnodes[node].back;
            }
        }
        if((t>=max)||(t<=0)||(Float.isNaN(t))) {
            if(near==-2) {
                return true;
            } else if(near==-1) {
                return false;
            } else {
                return intersect(o,p,near,min,max);
            }
        } else if(t<min) {
            if(far==-2) {
                return true;
            } else if(far==-1) {
                return false;
            } else {
                return intersect(o,p,far,min,max);
            }
        } else {
            boolean test;
            if(near==-2) {
                test=true;
            } else if(near==-1) {
                test=false;
            } else {
                test=intersect(o,p,near,min,t);
            }
            if(test) {
                return true;
            } else {
                if(far==-2) {
                    return true;
                } else if(far==-1) {
                    return false;
                } else {
                    return intersect(o,p,far,t,max);
                }
            }
        }
    }

    public boolean findPath(Vect3D o,Vect3D p,boolean check) {
        int startface,endface,face=0,link,index,face2;
        boolean found=false;
        int far=0;
        if(whichLeaf(o)==0) {
            System.err.println("Player is not in map");
            return false;
        }
        if(whichLeaf(p)==0) {
            System.err.println("Target is not in map");
            return false;
        }
        startface=whichFace(o);
        endface=whichFace(p);
        if(startface==-1 || endface==-1) {
            return false;
        }
        for(int i=0;i<header.faces.entries;i++) {
            dist[i]=-1;
        }
        lists[0].faces[0]=startface;
        lists[0].num=1;
        dist[startface]=0;
        while(!found) {
            far++;
            if(far==200) {
//                System.err.println("Path too long");
                return false;
            }
            lists[far].num=0;
            for(int i=0;i<lists[far-1].num;i++) {
                face=lists[far-1].faces[i];
                for(int j=0;j<faces[face].link_num;j++) {
                    link=faces[face].link_id+j;
                    face2=links[link].face;
                    if(face2==endface) {
                        found=true;
                    }
                    if(dist[face2]==-1) {
                        dist[face2]=far;
                        index=lists[far].num;
                        if(index==100) {
                            System.err.println("Too many faces at distance: "+far);
                            return false;
                        }
                        lists[far].faces[index]=face2;
                        lists[far].num++;
                    }
                }
            }
        }
        if(check) {
            return true;
        }
/*
        for(int i=0;i<=far;i++) {
            System.out.print("Distance "+i+":");
            for(int j=0;j<lists[i].num;j++) {
                System.out.print(" "+lists[i].faces[j]);
            }
            System.out.println();
        }
*/
        face2=endface;
        for(int i=far-1;i>=0;i--) {
            found=false;
            for(int j=0;!found;j++) {
                face=lists[i].faces[j];
                for(int k=0;k<faces[face].link_num;k++) {
                    link=faces[face].link_id+k;
                    if(links[link].face==face2) {
                        found=true;
                        path[i]=link;
                    }
                }
            }
//            System.out.println("Distance "+i+" face "+face2+" by "+path[i]);
            face2=face;
        }
        path_length=far;
        return true;
    }

    public int whichLeaf(Vect3D p) {
        int nextnode=hulls[0].rootbspnode;
        Plane plane;
        while(nextnode>=0) {
            plane=planes[bspnodes[nextnode].plane_id];
            if(plane.type==0) {
                if((p.x*plane.normal.x)<plane.dist) {
                    nextnode=bspnodes[nextnode].back;
                } else {
                    nextnode=bspnodes[nextnode].front;
                }
            } else if(plane.type==1) {
                if((p.y*plane.normal.y)<plane.dist) {
                    nextnode=bspnodes[nextnode].back;
                } else {
                    nextnode=bspnodes[nextnode].front;
                }
            } else if(plane.type==2) {
                if((p.z*plane.normal.z)<plane.dist) {
                    nextnode=bspnodes[nextnode].back;
                } else {
                    nextnode=bspnodes[nextnode].front;
                }
            } else {
                if((p.x*plane.normal.x+p.y*plane.normal.y+p.z*plane.normal.z)<plane.dist) {
                    nextnode=bspnodes[nextnode].back;
                } else {
                    nextnode=bspnodes[nextnode].front;
                }
            }
        }
        return (-1-nextnode);
    }

    public int leafType(int n) {
        if(n>=0 && n<header.leaves.entries) {
            return bspleaves[n].type;
        } else {
            return 0;
        }
    }

    public int whichFace(Vect3D p) {
        int leaf;
        int firstface,lastface,face;
        int firstedge,lastedge,edge;
        int v0,v1;
        int hits,possible;
        float dx,dy,t;

        leaf=whichLeaf(p);
        firstface=bspleaves[leaf].lface_id;
        lastface=bspleaves[leaf].lface_num+firstface;
        possible=0;

        for(int i=firstface;i<lastface;i++) {
            face=facelist[i];
//            if(planes[faces[face].plane_id].normal.z==1 && faces[face].side==0) {
            if(faces[face].floor==1) {
                firstedge=faces[face].ledge_id;
                lastedge=faces[face].ledge_num+firstedge;
                hits=0;
                for(int j=firstedge;j<lastedge;j++) {
                    edge=edgelist[j];
                    if(edge>0) {
                        v0=edges[edge].vertex0;
                        v1=edges[edge].vertex1;
                    } else {
                        edge=-edge;
                        v0=edges[edge].vertex1;
                        v1=edges[edge].vertex0;
                    }
                    dx=verticies[v1].x-verticies[v0].x;
                    dy=verticies[v1].y-verticies[v0].y;
                    if(dy!=0) {
                        t=(p.y-verticies[v0].y)/dy;
                    } else {
                        t=Float.NaN;
                    }
                    if((t<1)&&(t>=0)&&(!Float.isNaN(t))) {
                        if((t*dx+verticies[v0].x)>=p.x) {
                            hits++;
                        }
                    }
                }
                if(hits==1) {
//                    System.out.println("Player Z: "+p.z+" Face Z: "+planes[faces[face].plane_id].dist);
                    return face;
                }
            }
        }
        return -1;
    }

    private void testAllFaces() {
        int firstedge,lastedge,edge;
        int v0,v1;
        Vect3D u,v,w,p;
        u=new Vect3D();
        v=new Vect3D();
        for(int i=0;i<header.faces.entries;i++) {
            System.out.println();
            System.out.print("Face: "+i);
            System.out.print(" Plane: "+faces[i].plane_id);
            System.out.print(" Edges: "+faces[i].ledge_num);
            System.out.println(" Side: "+faces[i].side);
            firstedge=faces[i].ledge_id;
            lastedge=faces[i].ledge_num+firstedge;

            p=new Vect3D();
            p.x=planes[faces[i].plane_id].normal.x;
            p.y=planes[faces[i].plane_id].normal.y;
            p.z=planes[faces[i].plane_id].normal.z;
            if(faces[i].side==0) {
                p.x=-p.x;
                p.y=-p.y;
                p.z=-p.z;
            }
            System.out.print("P ");
            p.println();

            for(int j=0;j<faces[i].ledge_num;j++) {

                edge=edgelist[firstedge+j];
                if(edge>0) {
                    v0=edges[edge].vertex0;
                    v1=edges[edge].vertex1;
                } else {
                    edge=-edge;
                    v0=edges[edge].vertex1;
                    v1=edges[edge].vertex0;
                }
                u.x=verticies[v1].x-verticies[v0].x;
                u.y=verticies[v1].y-verticies[v0].y;
                u.z=verticies[v1].z-verticies[v0].z;

                if(j==(faces[i].ledge_num-1)) {
                    edge=edgelist[firstedge];
                } else {
                    edge=edgelist[firstedge+1+j];
                }
                if(edge>0) {
                    v0=edges[edge].vertex0;
                    v1=edges[edge].vertex1;
                } else {
                    edge=-edge;
                    v0=edges[edge].vertex1;
                    v1=edges[edge].vertex0;
                }
                v.x=verticies[v1].x-verticies[v0].x;
                v.y=verticies[v1].y-verticies[v0].y;
                v.z=verticies[v1].z-verticies[v0].z;

                w=new Vect3D(u,v);

                if(Float.isNaN(w.x)) {
                    System.out.print("G ");
                } else {
                    if(w.x==p.x && w.y==p.y && w.z==p.z) {
                        System.out.print("G ");
                    } else {
                        System.out.print("* ");
                    }
                }
                w.println();
            }
        }
    }
}
