class Edge {
    int vertex0;
    int vertex1;
}