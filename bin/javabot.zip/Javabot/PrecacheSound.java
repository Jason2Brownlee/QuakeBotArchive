class PrecacheSound {
    String name;
}