import java.io.RandomAccessFile;
import java.io.IOException;

class JBMFileHeader {
    RandomAccessFile file;
    JBMFileDirEntry hulls=new JBMFileDirEntry();
    JBMFileDirEntry planes=new JBMFileDirEntry();
    JBMFileDirEntry nodes=new JBMFileDirEntry();
    JBMFileDirEntry leaves=new JBMFileDirEntry();
    JBMFileDirEntry clipnodes=new JBMFileDirEntry();
    JBMFileDirEntry verticies=new JBMFileDirEntry();
    JBMFileDirEntry faces=new JBMFileDirEntry();
    JBMFileDirEntry lfaces=new JBMFileDirEntry();
    JBMFileDirEntry edges=new JBMFileDirEntry();
    JBMFileDirEntry ledges=new JBMFileDirEntry();
    JBMFileDirEntry links=new JBMFileDirEntry();

    public JBMFileHeader(RandomAccessFile file) throws IOException {
        this.file=file;
        hulls.sizeof=64;
        hulls.entries=0;
        hulls.offset=0;
        planes.sizeof=20;
        planes.entries=0;
        planes.offset=0;
        nodes.sizeof=12;
        nodes.entries=0;
        nodes.offset=0;
        leaves.sizeof=6;
        leaves.entries=0;
        leaves.offset=0;
        clipnodes.sizeof=8;
        clipnodes.entries=0;
        clipnodes.offset=0;
        verticies.sizeof=12;
        verticies.entries=0;
        verticies.offset=0;
        faces.sizeof=32;
        faces.entries=0;
        faces.offset=0;
        lfaces.sizeof=2;
        lfaces.entries=0;
        lfaces.offset=0;
        edges.sizeof=4;
        edges.entries=0;
        edges.offset=0;
        ledges.sizeof=4;
        ledges.entries=0;
        ledges.offset=0;
        links.sizeof=20;
        links.entries=0;
        links.offset=0;
    }

    public void readHeader() throws IOException {
        file.seek(0);
        readVersion();
        readDirEntry(hulls);
        readDirEntry(planes);
        readDirEntry(nodes);
        readDirEntry(leaves);
        readDirEntry(clipnodes);
        readDirEntry(verticies);
        readDirEntry(faces);
        readDirEntry(lfaces);
        readDirEntry(edges);
        readDirEntry(ledges);
        readDirEntry(links);
    }

    public void writeHeader() throws IOException {
        file.seek(0);
        writeVersion("JAVABOT MAP FILE");
        writeDirEntry(hulls);
        writeDirEntry(planes);
        writeDirEntry(nodes);
        writeDirEntry(leaves);
        writeDirEntry(clipnodes);
        writeDirEntry(verticies);
        writeDirEntry(faces);
        writeDirEntry(lfaces);
        writeDirEntry(edges);
        writeDirEntry(ledges);
        writeDirEntry(links);
    }

    private void readVersion() throws IOException {
        for(int i=0;i<16;i++) {
            file.readByte();
        }        
    }

    private void writeVersion(String s) throws IOException {
        char c[];
        c=s.toCharArray();
        for(int i=0;i<16;i++) {
            file.writeByte((int)c[i]);
        }
    }

    private void readDirEntry(JBMFileDirEntry d) throws IOException {
        d.offset=file.readInt();
        d.size=file.readInt();
        d.entries=d.size/d.sizeof;
    }

    private void writeDirEntry(JBMFileDirEntry d) throws IOException {
        d.size=d.entries*d.sizeof;
        file.writeInt(d.offset);
        file.writeInt(d.size);
    }
}
