import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

class PolyViewer extends Canvas {

    JBMFile map;
    Vect3D player;
    int leaf,hface;

    public PolyViewer(JBMFile map) {
        this.map=map;
    }

    public void drawFace(Graphics g,int face) {
        int firstedge,lastedge,edge;
        int v0,v1;
        float x0,y0,z0,x1,y1,z1;

        firstedge=map.faces[face].ledge_id;
        lastedge=map.faces[face].ledge_num+firstedge;
        for(int j=firstedge;j<lastedge;j++) {
            edge=map.edgelist[j];
            if(edge>0) {
                v0=map.edges[edge].vertex0;
                v1=map.edges[edge].vertex1;
            } else {
                edge=-edge;
                v0=map.edges[edge].vertex1;
                v1=map.edges[edge].vertex0;
            }
            x0=(map.verticies[v0].x-player.x)/5;
            y0=(map.verticies[v0].y-player.y)/5;
            z0=(map.verticies[v0].z-player.z)/5;
            x1=(map.verticies[v1].x-player.x)/5;
            y1=(map.verticies[v1].y-player.y)/5;
            z1=(map.verticies[v1].z-player.z)/5;
            g.drawLine(200+(int)(x0+y0),
                       200-(int)(z0+y0),
                       200+(int)(x1+y1),
                       200-(int)(z1+y1));
        }
    }

    public void paint(Graphics g) {
        int firstface,lastface,face;

        g.clearRect(0,0,400,400);

        firstface=map.bspleaves[leaf].lface_id;
        lastface=map.bspleaves[leaf].lface_num+firstface;
        for(int i=firstface;i<lastface;i++) {
            g.setColor(new Color(0,0,0));
            face=map.facelist[i];
            drawFace(g,face);
        }
        if(hface!=-1) {
            System.out.println("Num links: "+map.faces[hface].link_num);
            g.setColor(new Color(0,255,0));
            for(int i=0;i<map.faces[hface].link_num;i++) {
                drawFace(g,map.links[i+map.faces[hface].link_id].face);
            }
            g.setColor(new Color(255,0,255));
            drawFace(g,hface);
        }

        g.setColor(new Color(255,0,0));
        g.fillOval(200,200,6,6);
    }
}