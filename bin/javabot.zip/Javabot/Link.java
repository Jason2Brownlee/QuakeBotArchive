class Link {
    int face;
    int flags;
    float x,y,z;
}