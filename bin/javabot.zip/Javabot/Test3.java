import java.io.IOException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

class Test3 {

    JBMFile map;
    long start_time;
    PrintWriter pts_file;

    public Test3() {

        try {
            pts_file=new PrintWriter(new FileOutputStream("maps/test1.pts"));
        } catch(IllegalArgumentException e) {
            System.err.println("Arguement Error: "+e);
            System.exit(1);
        } catch(SecurityException e) {
            System.err.println("Security Error: "+e);
            System.exit(1);
        } catch(IOException e) {
            System.err.println("Error opening point file: "+e);
            System.exit(1);
        }

        try {
            map=new JBMFile("maps/test1.bsp");
        } catch(IOException e) {
            System.err.println("Error opening map: "+e);
            System.exit(1);
        }

        System.out.println();
        Vect3D player=new Vect3D();
        Vect3D target=new Vect3D();
        player.x=0;
        player.y=-70;
        player.z=24;
        target.x=96;
        target.y=-70;
        target.z=40;
        System.out.println("Player: "+map.whichFace(player));
        System.out.println("Target: "+map.whichFace(target));
        start_time=System.currentTimeMillis();
        System.out.println("Success: "+map.findPath(player,target));
        System.out.println("Time: "+(System.currentTimeMillis()-start_time)+"ms");
        int face;
        face=map.whichFace(player);
        for(int i=0;i<map.path_length;i++) {
            drawLink(face,map.path[i]);
            face=map.links[map.path[i]].face;
        }
        System.out.println(map.faces[map.whichFace(target)].z);
        pts_file.flush();
    }

    private void drawLink(int n,int m) {
        int face=map.links[m].face;
        double x0=map.faces[n].x;
        double y0=map.faces[n].y;
        double z0=map.faces[n].z+32;
        double dx=map.faces[face].x-map.faces[n].x;
        double dy=map.faces[face].y-map.faces[n].y;
        double dz=map.faces[face].z-map.faces[n].z;
        double length=Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(length>0) {
            dx=dx*4/length;
            dy=dy*4/length;
            dz=dz*4/length;
            for(int j=0;j<(int)length;j+=4) {
            pts_file.println((int)x0+" "+(int)y0+" "+(int)z0);
                x0=x0+dx;
                y0=y0+dy;
                z0=z0+dz;
            }
        }
    }


    public static void main(String args[]) {
        System.out.println();
        System.out.print("Running Java version "+System.getProperty("java.version"));
	System.out.println(" by "+System.getProperty("java.vendor"));
	System.out.print("System is "+System.getProperty("os.name"));
	System.out.print(" "+System.getProperty("os.version"));
	System.out.println(" for "+System.getProperty("os.arch"));
        System.out.println();
        new Test3();
    }
}