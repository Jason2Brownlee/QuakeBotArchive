class TemporaryEntity {
    int creator;
    int entitytype;
    int x,y,z;
    int xe,ye,ze;
}