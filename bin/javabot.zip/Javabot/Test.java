import java.io.IOException;
import java.awt.Frame;
import java.awt.Color;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;

// Notes
// -1 ordinary
// -2 solid
// -3 water
// -4 slime
// -5 lava
// -6 sky

class Test extends Frame implements WindowListener {

    JBMFile map;
    PolyViewer pv;

    boolean maploaded=false;

    public Test(String s) {
        super("Test");

        setLayout(null);
        addNotify();
        setSize(416,438);
        setBackground(new Color(192,192,192));

        try {
            map=new JBMFile(s);
        } catch(IOException e) {
            System.err.println("Error opening map: "+e);
            System.exit(1);
        }

        pv=new PolyViewer(map);
        add(pv);
        pv.setBounds(8,30,400,400);
        pv.setBackground(new Color(255,255,255));

        addWindowListener(this);

	setTitle("Test");
        System.out.println("Starting");
        setVisible(true);

        System.out.println();
        Vect3D player=new Vect3D();
        int leaf,type,face;
        for(int i=0;i<10;) {
            player.x=(float)(2*Math.random()-1)*1024;
            player.y=(float)(2*Math.random()-1)*1024;
            player.z=(float)(2*Math.random()-1)*1024;
            leaf=map.whichLeaf(player);
            if(leaf!=0) {
                type=map.leafType(leaf);
                System.out.println("("+player.x+","+player.y+","+player.z+") : "+leaf+" : "+type);
                face=map.whichFace(player);
                if(face==-1) {
                    System.out.println("Floating");
                } else {
                    System.out.println("Above Face: "+face);
                }
                pv.leaf=leaf;
                pv.hface=face;
                pv.player=player;
                pv.repaint();
                i++;
                try {
                    System.in.read();
                    System.in.read();
                } catch(IOException e) {
                    return;
                }
            }
        }
    }

    public static void main(String args[]) {
        System.out.println();
        System.out.print("Running Java version "+System.getProperty("java.version"));
	System.out.println(" by "+System.getProperty("java.vendor"));
	System.out.print("System is "+System.getProperty("os.name"));
	System.out.print(" "+System.getProperty("os.version"));
	System.out.println(" for "+System.getProperty("os.arch"));
        System.out.println();
        if (args.length == 1) {
            new Test(args[0]);
        } else {
            System.out.println("Usage:\n  java Test <filename>");
            System.exit(1);
        }
    }

    public void windowClosing(WindowEvent event) {
        System.out.println("Exiting");
        setVisible(false);
        dispose();
        System.exit(0);
    }

    public void windowClosed(WindowEvent event) {
    }

    public void windowDeiconified(WindowEvent event) {
    }

    public void windowIconified(WindowEvent event) {
    }

    public void windowActivated(WindowEvent event) {
    }

    public void windowDeactivated(WindowEvent event) {
    }

    public void windowOpened(WindowEvent event) {
    }
}