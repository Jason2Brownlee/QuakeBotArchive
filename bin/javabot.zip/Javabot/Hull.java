class Hull {
    BoundBox bound=new BoundBox();
    Vect3D origin=new Vect3D();
    int rootbspnode;
    int rootclipnode;
    int secondaryclipnode;
    int unknownnode;
    int numleafs;
    int face_id;
    int face_num;
}
