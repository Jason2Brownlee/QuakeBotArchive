class Face {
    int plane_id;
    int side;
    int ledge_id;
    int ledge_num;
    int link_id;
    int link_num;
    int floor;
    int texinfo;
    float x,y,z;
}