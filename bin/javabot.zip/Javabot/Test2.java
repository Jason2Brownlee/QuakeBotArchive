import java.io.IOException;

// Notes
// -1 ordinary
// -2 solid
// -3 water
// -4 slime
// -5 lava
// -6 sky

class Test2 {

    JBMFile map;

    boolean maploaded=false;

    public Test2(String s) {
        try {
            map=new JBMFile(s);
        } catch(IOException e) {
            System.err.println("Error opening map: "+e);
            System.exit(1);
        }
        map.testAllFaces();
    }

    public static void main(String args[]) {
        System.out.println();
        System.out.print("Running Java version "+System.getProperty("java.version"));
	System.out.println(" by "+System.getProperty("java.vendor"));
	System.out.print("System is "+System.getProperty("os.name"));
	System.out.print(" "+System.getProperty("os.version"));
	System.out.println(" for "+System.getProperty("os.arch"));
        System.out.println();
        if (args.length == 1) {
            new Test2(args[0]);
        } else {
            System.out.println("Usage:\n  java Test2 <filename>");
            System.exit(1);
        }
    }
}