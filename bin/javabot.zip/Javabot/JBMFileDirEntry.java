class JBMFileDirEntry {
    int offset;
    int size;
    int sizeof;
    int entries;
}