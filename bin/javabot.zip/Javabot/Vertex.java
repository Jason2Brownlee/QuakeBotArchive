class Vertex {
	float x,y,z;
}