import java.io.IOException;

public class QuakeBot {

    Player player;
    boolean done=false;

    public QuakeBot(String host) {

        System.out.println("Starting");
        player=new Player(host);
        try {
            System.in.read();
        } catch(IOException e) {
            System.err.println("Error reading from stdio");
        }
        player.disconnect();
        System.out.println("Exiting");
        player.stop();
        player=null;
        System.exit(0);
    }

    public static void main(String args[]) {
        System.out.println();
        System.out.print("Running Java version "+System.getProperty("java.version"));
	System.out.println(" by "+System.getProperty("java.vendor"));
	System.out.print("System is "+System.getProperty("os.name"));
	System.out.print(" "+System.getProperty("os.version"));
	System.out.println(" for "+System.getProperty("os.arch"));
        System.out.println();
        if (args.length >= 1) {
            try {
                new QuakeBot(args[0]);
            } catch(NumberFormatException e) {
                System.out.println("Not a valid IP address");
                System.exit(1);
            }
        } else {
            System.out.println("Usage:\n  java QuakeBot <hostname/ipaddress>");
            System.exit(1);
        }
    }
}