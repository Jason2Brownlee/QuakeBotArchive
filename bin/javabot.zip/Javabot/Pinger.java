
class Pinger implements Runnable {

	Server server;

	public Pinger(Server s) {
		server=s;
	}

	public void run() {
		while(true) {
			server.ping();
			try {
				Thread.sleep(10000);
			} catch(InterruptedException e) {
				System.err.println("Error: Programmer is a moron");
			}
		}
	}
}