class BSPNode {
    int plane_id;
    int front;
    int back;
    int face_id;
    int face_num;
}