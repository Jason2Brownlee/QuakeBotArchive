import java.io.RandomAccessFile;
import java.io.IOException;

class BSPFileHeader {
    RandomAccessFile file;
    int version;
    BSPFileDirEntry entities=new BSPFileDirEntry();  // X
    BSPFileDirEntry planes=new BSPFileDirEntry();
    BSPFileDirEntry miptex=new BSPFileDirEntry();
    BSPFileDirEntry verticies=new BSPFileDirEntry();
    BSPFileDirEntry vislist=new BSPFileDirEntry();
    BSPFileDirEntry nodes=new BSPFileDirEntry();
    BSPFileDirEntry texinfo=new BSPFileDirEntry();
    BSPFileDirEntry faces=new BSPFileDirEntry();
    BSPFileDirEntry lightmaps=new BSPFileDirEntry(); // X
    BSPFileDirEntry clipnodes=new BSPFileDirEntry();
    BSPFileDirEntry leaves=new BSPFileDirEntry();
    BSPFileDirEntry lfaces=new BSPFileDirEntry();
    BSPFileDirEntry edges=new BSPFileDirEntry();
    BSPFileDirEntry ledges=new BSPFileDirEntry();
    BSPFileDirEntry hulls=new BSPFileDirEntry();

    public BSPFileHeader(RandomAccessFile file) throws IOException {
        this.file=file;
        file.seek(0);
        version=readIntBigEndian();
        readDirEntry(entities,1);
        readDirEntry(planes,20);
        readDirEntry(miptex,1);
        readDirEntry(verticies,12);
        readDirEntry(vislist,1);
        readDirEntry(nodes,24);
        readDirEntry(texinfo,40);
        readDirEntry(faces,20);
        readDirEntry(lightmaps,1);
        readDirEntry(clipnodes,8);
        readDirEntry(leaves,28);
        readDirEntry(lfaces,2);
        readDirEntry(edges,4);
        readDirEntry(ledges,4);
        readDirEntry(hulls,64);
    }

    private void readDirEntry(BSPFileDirEntry d,int i) throws IOException {
        d.offset=readIntBigEndian();
        d.size=readIntBigEndian();
        d.sizeof=i;
        d.entries=d.size/d.sizeof;
    }

    private int readIntBigEndian() throws IOException {
        int i;
        i=((int)file.readUnsignedByte());
        i=i+((int)file.readUnsignedByte())*256;
        i=i+((int)file.readUnsignedByte())*65536;
        i=i+((int)file.readByte())*16777216;
        return i;
    }
}
