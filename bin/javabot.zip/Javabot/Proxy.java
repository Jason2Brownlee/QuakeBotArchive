import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.io.IOException;

class Proxy implements Runnable {

	DatagramSocket sock=null;
	InetAddress remote_ip_address;
	InetAddress local_ip_address;
	int remote_port;
	int local_port;

	boolean connected=false;                            

	public Proxy() {
		try {
			local_ip_address=InetAddress.getLocalHost();
		} catch(UnknownHostException e) {
			System.err.println("Error getting IP address: "+e);
		return;
		}
		if(sock==null) {
			try {
				sock=new DatagramSocket();
			} catch(SocketException e) {
				System.err.println("Error: Couldn't create socket: "+e);
				return;
			}
			local_port=sock.getLocalPort();
		}
		local_port=sock.getPort();
	}

    public void send(byte m[],int len) {
        byte b[]=new byte[2048];
        int i=0,j=0;
        b[i++]=(byte)((type>>8)&0xff);
        b[i++]=(byte)(type&0xff);
        if(type==0x8000) {
            b[i++]=(byte)(((len+4)>>8)&0xff);
            b[i++]=(byte)((len+4)&0xff);
            System.out.println("Trying...");
        }
		while(j<len) {
			b[i++]=m[j++];
		}
		DatagramPacket pack=new DatagramPacket(b,i,target_ip_address,target_port);
		try {
			sock.send(pack);
		} catch(IOException e) {
			System.err.println("Error sending: "+e);
		}
	}

	public void run() {
		byte b[]=new byte[2048];
		int packet_type=0;
		int packet_length=0;
		while(true) {
			try {
				DatagramPacket pack=new DatagramPacket(b,2000);
				sock.receive(pack);
				remote_ip_address=pack.getAddress();
				remote_port=pack.getPort();
				packet_length=pack.getLength();
			} catch(IOException e) {
				System.err.println("Error receiving: "+e);
			}
			packet_type=b[1];
			while(packet_type<0) packet_type+=256;
			packet_type=packet_type+b[0]*256;
			while(packet_type<0) packet_type+=65536;

			if((packet_type&0x8000)==0x8000) {
				int control_code;
				control_code=b[4];
				if((control_code&0xff)==0x01) {
					b[0]=0x80;
					b[1]=0x00;
					b[2]=0x07;
					b[3]=0x00;
					b[4]=0x01;
					b[5]=local_port&0xff;
					b[6]=(local_port>>8);
//					connected=true;
					System.out.println("Proxy Connect");
				}
			}
		}
	}
}