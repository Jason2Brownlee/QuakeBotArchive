class BSPLeaf {
    int type;
    int vislist;
    int lface_id;
    int lface_num;
}