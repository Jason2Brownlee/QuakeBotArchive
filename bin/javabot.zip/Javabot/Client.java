import java.io.IOException;

class Client {

    // Class Variables

    Thread pingerThread;
    Server server;
    JBMFile map;
    Pinger pinger;
    String ip_address;

    // Game Variables

    boolean connected=false;                            
    boolean attack=false;
    boolean jump=false;
    boolean move=false;
    boolean maploaded=false;
    double destination_x,destination_y,destination_z;
    double target_x,target_y,target_z;
    double last_x,last_y,last_z;
    float last_time;
    int needhealth,needarmor,needweapons,needammo;
    int weapon;
    String targetString="";
    String destinationString="";
    String questString="";
    String fearString="";

    // Constants

    int TYPE_ITEM = 0x01;
    int TYPE_FEAR = 0x02;
    int TYPE_HATE = 0x04;
    int TYPE_ARMOR = 0x08;
    int TYPE_AMMO = 0x10;
    int TYPE_HEAL = 0x20;
    int TYPE_GUN = 0x40;
    int TYPE_COOL = 0x80;

    int IT_SHOTGUN =          0x00000001;
    int IT_SUPER_SHOTGUN =    0x00000002;
    int IT_NAILGUN =          0x00000004;
    int IT_SUPER_NAILGUN =    0x00000008;
    int IT_GRENADE_LAUNCHER = 0x00000010;
    int IT_ROCKET_LAUNCHER =  0x00000020;
    int IT_LIGHTNING =        0x00000040;

    public Client(String s) {
        ip_address=s;
        server=new Server(ip_address);
        pinger=new Pinger(server);
    }

    public void initialize() {
        while(!server.connected) {
            try {
                Thread.sleep(100);
            } catch(InterruptedException e) {
                System.err.println("Error: Programmer is a moron");
            }
        }
        while(!connected) {
            try {
                Thread.sleep(100);
            } catch(InterruptedException e) {
                System.err.println("Error: Programmer is a moron");
            }
        }
        say("Ahh! Fresh Meat!");
        pingerThread=new Thread(pinger);
        pingerThread.start();
    }

    public void waitfor_uptodate() {
        while(!server.uptodate) {
            try {
                Thread.sleep(33);
            } catch(InterruptedException e) {
                System.err.println("Error: Programmer is a moron");
            }
        }
        server.uptodate=false;
    }

    public void sendcommand() {
        byte b[]=new byte[32];
        int temp;
        double fyaw=0,fpitch=0;
        double dyaw=0;
        double fx,fy,fz,fw;
        double dx,dy,dz;
        double tx,ty,tz;
        double distance;
        byte flags;
        byte impulse;
        int forward_int,forward_hi,forward_lo;
        int right_int,right_hi,right_lo;
        int up_int,up_hi,up_lo;
        if(!server.connected) {
            disconnect();
        }
        if(server.time>(last_time+5.0)) {
            last_x=((double)server.self_x)/8;
            last_y=((double)server.self_y)/8;
            last_z=((double)server.self_z)/8;
            last_time=server.time;
        }
        fx=target_x-((double)server.self_x)/8;
        fy=target_y-((double)server.self_y)/8;
        fz=target_z-((double)server.self_z)/8;
        fw=Math.sqrt(fx*fx+fy*fy)+0.000001;
        if(fx==0) {
            if(fy>=0) {
                fyaw=Math.PI/2;
            } else {
                fyaw=3*Math.PI/2;
            }
        } else {
            if(fx>=0) {
                fyaw=Math.atan(fy/fx);
            } else {
                fyaw=Math.PI+Math.atan(fy/fx);
            }
        }
        fpitch=-Math.atan(fz/fw);
        if(move) {
            dx=destination_x-((double)server.self_x)/8;
            dy=destination_y-((double)server.self_y)/8;
            dz=destination_z-((double)server.self_z)/8;
            if(dx==0) {
                if(dy>=0) {
                    dyaw=Math.PI/2;
                } else {
                    dyaw=3*Math.PI/2;
                }
            } else {
                if(dx>=0) {
                   dyaw=Math.atan(dy/dx);
                } else {
                   dyaw=Math.PI+Math.atan(dy/dx);
                }
            }
            distance=Math.sqrt(dx*dx+dy*dy);
//            if(distance>320) {
                tx=320*Math.cos(dyaw-fyaw);
                ty=-320*Math.sin(dyaw-fyaw);
                tz=0;
//            } else {
//                tx=distance*Math.cos(dyaw-fyaw);
//                ty=-distance*Math.sin(dyaw-fyaw);
//                tz=0;
//            }
            forward_int=(int)tx;
            right_int=(int)ty;
            up_int=(int)tz;
        } else {
            forward_int=0;
            right_int=0;
            up_int=0;
        }
        forward_hi=(forward_int>>8)&0xff;
        forward_lo=forward_int&0xff;
        right_hi=(right_int>>8)&0xff;
        right_lo=right_int&0xff;
        up_hi=(up_int>>8)&0xff;
        up_lo=up_int&0xff;
        flags=0;
        if(attack) flags+=1;
        if(jump) flags+=2;
        impulse=(byte)weapon;
        temp=Float.floatToIntBits(server.time);
        server.myyaw=(float)(fyaw*180/Math.PI);
        server.mypitch=(float)(fpitch*180/Math.PI);
        server.myroll=(float)0;
        b[0]=(byte)0x03;
        b[1]=(byte)(temp&0xff);
        b[2]=(byte)((temp>>8)&0xff);
        b[3]=(byte)((temp>>16)&0xff);
        b[4]=(byte)((temp>>24)&0xff);
        b[5]=(byte)(fpitch*128/Math.PI); // tilt
        b[6]=(byte)(fyaw*128/Math.PI); // yaw
        b[7]=(byte)0x00; // flip
        b[8]=(byte)forward_lo; // forward
        b[9]=(byte)forward_hi;
        b[10]=(byte)right_lo; // right
        b[11]=(byte)right_hi;
        b[12]=(byte)up_lo; // up
        b[13]=(byte)up_hi;
        b[14]=(byte)flags; // flag
        b[15]=(byte)impulse; // impulse
        server.send(0x0010,b,16);
        server.centerprintString=new String("Target: "+targetString+"\n  Dest: "+destinationString+"\n Quest: "+questString+"\n  Fear: "+fearString+"\nPing: "+server.pingvalue+" ms");
    }

    public boolean stuck() {
        double x,y,z;
        x=last_x-((double)server.self_x)/8;
        y=last_y-((double)server.self_y)/8;
        z=last_z-((double)server.self_z)/8;
        return ((Math.sqrt(x*x+y*y+z*z)<64) && move);
    }

    public float predict(float speed,int t) {
        float pdx,pdy,pdz;
        float vex,vey,vez;
        float a,b,c,d,e,f;
        pdx=(float)server.entities[t].x-(float)server.self_x;
        pdy=(float)server.entities[t].y-(float)server.self_y;
        pdz=(float)server.entities[t].z-(float)server.self_z;
        vex=server.entities[t].xv;
        vey=server.entities[t].yv;
        vez=server.entities[t].zv;
        a=vex*vex+vey*vey+vez*vez-speed*speed;
        b=2*(pdx*vex+pdy*vey+pdz*vez);
        c=pdx*pdx+pdy*pdy+pdz*pdz;
        d=-b/(2*a);
        e=(float)Math.sqrt(b*b-4*a*c)/(2*a);
        if((d+e)>0) {
            f=d+e;
        } else {
            f=d-e;
        }
        return f;
    }

    public String entity_name(int t) {
        String s=new String();
        s=server.precache_models[server.entities[t].modelindex].name;
//        s=s+" ("+server.entities[t].xa;
//        s=s+","+server.entities[t].ya;
//        s=s+","+server.entities[t].za;
//        s=s+") ";
//        s=s+") "+predict(10000,t);
        return s;
    }

    public int my_health() {
        return server.health;
    }

    public int my_frags() {
        return server.playerfrags[server.viewpoint_entity-1];
    }

    public void stand() {
        move=false;
    }

    public int identify_entity(int t) {
        return server.precache_models[server.entities[t].modelindex].type;
    }
 
    public boolean fresh(int t) {
        return (server.entities[t].lastupdate>=(server.time-1));
    }

    public boolean respawned(int t) {
        return (server.entities[t].respawn_time<=server.time);
    }

    public void set_spawn(int t) {
        server.entities[t].respawn_time=server.time+server.precache_models[server.entities[t].modelindex].respawn_time;
    }

    public int get_viewlist(int i[]) {
        int k=0;
//        viewList.removeAll();
        for(int j=0;j<server.viewlistlength;j++) {
            if(server.viewlist[j]!=server.viewpoint_entity) {
                i[k++]=server.viewlist[j];
//                viewList.add("Item: "+server.viewlist[j]);
            }
        }
        return server.viewlistlength-1;
    }

    public int get_spawnlist(int i[]) {
        for(int j=0;j<server.spawnlistlength;j++) {
            i[j]=server.spawnlist[j];
        }
        return server.spawnlistlength;
    }

    public int whichLeaf() {
        Vect3D player=new Vect3D();
        if(!maploaded) {
            return -1;
        }
        player.x=(float)server.self_x/8;
        player.y=(float)server.self_y/8;
        player.z=(float)server.self_z/8;
        return map.whichLeaf(player);
    }

    public int leafType() {
        Vect3D player=new Vect3D();
        int leaf;
        if(!maploaded) {
            return 0;
        }
        player.x=(float)server.self_x/8;
        player.y=(float)server.self_y/8;
        player.z=(float)server.self_z/8;
        leaf=map.whichLeaf(player);
        return map.leafType(leaf);
    }

    public int whichFace() {
        Vect3D player=new Vect3D();
        if(!maploaded) {
            return -1;
        }
        player.x=(float)server.self_x/8;
        player.y=(float)server.self_y/8;
        player.z=(float)server.self_z/8;
        return map.whichFace(player);
    }

    public int make_path(int t) {
        boolean possible;
        Vect3D player=new Vect3D();
        Vect3D target=new Vect3D();
        if(!maploaded) {
            return -1;
        }
        player.x=(float)server.self_x/8;
        player.y=(float)server.self_y/8;
        player.z=(float)server.self_z/8;
        target.x=(float)server.entities[t].x/8;
        target.y=(float)server.entities[t].y/8;
        target.z=(float)server.entities[t].z/8;
        possible=map.findPath(player,target,false);
        if(!possible) {
            return -1;
        }
        return map.path_length;
    }

    public boolean check_path(int t) {
        boolean possible;
        Vect3D player=new Vect3D();
        Vect3D target=new Vect3D();
        if(!maploaded) {
            return false;
        }
        player.x=(float)server.self_x/8;
        player.y=(float)server.self_y/8;
        player.z=(float)server.self_z/8;
        target.x=(float)server.entities[t].x/8;
        target.y=(float)server.entities[t].y/8;
        target.z=(float)server.entities[t].z/8;
        possible=map.findPath(player,target,true);
        return possible;
    }

    public boolean visible(int t) {
        boolean see;
        Vect3D player=new Vect3D();
        Vect3D target=new Vect3D();
        if(!maploaded) {
            return false;
        }
        player.x=(float)server.self_x/8;
        player.y=(float)server.self_y/8;
        player.z=(float)server.self_z/8;
        target.x=(float)server.entities[t].x/8;
        target.y=(float)server.entities[t].y/8;
        target.z=(float)server.entities[t].z/8;
        see=map.traceLine(player,target);
        if(!see) {
            player.x+=32;
            target.x+=32;
            see=map.traceLine(player,target);
        }
        if(!see) {
            player.x-=32;
            player.y+=32;
            target.x-=32;
            target.y+=32;
            see=map.traceLine(player,target);
        }
        if(!see) {
            player.x-=32;
            player.y-=32;
            target.x-=32;
            target.y-=32;
            see=map.traceLine(player,target);
        }
        if(!see) {
            player.x+=32;
            player.y-=32;
            target.x+=32;
            target.y-=32;
            see=map.traceLine(player,target);
        }
        if(!see) {
            player.y+=32;
            player.z+=32;
            target.y+=32;
            target.z+=32;
            see=map.traceLine(player,target);
        }
        if(!see) {
            player.z-=64;
            target.z-=64;
            see=map.traceLine(player,target);
        }
        return see;
    }

    public void rate_need() {
        int armor=0;
        int health=0;
        int weapons=0;
        int ammo=0;

        int armortype;
        int shells;
        int cells;
        int nails;
        int rockets;

        if((server.items&server.IT_ARMOR1)!=0) {
            armortype=3;
        } else if((server.items&server.IT_ARMOR2)!=0) {
            armortype=6;
        } else if((server.items&server.IT_ARMOR3)!=0) {
            armortype=8;
        } else {
            armortype=0;
        }
        armor=server.armorvalue*armortype;
        health=server.health;

        shells=server.ammo_shells;
        cells=server.ammo_cells;
        nails=server.ammo_nails;
        rockets=server.ammo_rockets;
        if((server.items&server.IT_SHOTGUN)!=0) {
            ammo+=shells;
            weapons+=1;
        }
        if((server.items&server.IT_SUPER_SHOTGUN)!=0) {
            ammo+=2*shells;
            weapons+=3;
        }
        if((server.items&server.IT_NAILGUN)!=0) {
            ammo+=nails;
            weapons+=3;
        }
        if((server.items&server.IT_SUPER_NAILGUN)!=0) {
            ammo+=2*nails;
            weapons+=5;
        }
        if((server.items&server.IT_GRENADE_LAUNCHER)!=0) {
            ammo+=rockets;
            weapons+=4;
        }
        if((server.items&server.IT_ROCKET_LAUNCHER)!=0) {
            ammo+=2*rockets;
            weapons+=6;
        }
        if((server.items&server.IT_LIGHTNING)!=0) {
            ammo+=2*cells;
            weapons+=7;
        }
        needammo=ammo/2;
        needweapons=weapons*35;
        needarmor=armor/2; // *.6
        needhealth=health*4;
    }

    public int item_value(int t) {
        int minum;
        int armortype;
        minum=server.entities[t].modelindex;
        if((server.precache_models[minum].type&TYPE_ARMOR)!=0) {
            if(server.entities[t].skin==0) {
                return Math.max(180-needarmor,1);
            } else if(server.entities[t].skin==1) {
                return Math.max(540-needarmor,1);
            } else if(server.entities[t].skin==2) {
                return Math.max(960-needarmor,1);
            }
        }
        if((server.precache_models[minum].type&TYPE_HEAL)!=0) {
            return Math.max(server.precache_models[minum].value-needhealth,1);
        }
        if((server.precache_models[minum].type&TYPE_COOL)!=0) {
            return 1000;
        }
        if((server.precache_models[minum].type&TYPE_GUN)!=0) {
            return Math.max(server.precache_models[minum].value-needweapons,1);
        }
        if((server.precache_models[minum].type&TYPE_AMMO)!=0) {
            return Math.max(server.precache_models[minum].value-needammo,1);
        }
        return 0;
    }

    public boolean itemBetterThan(int item1,int item2) {
        int type1,type2;
        type1=server.entities[item1].modelindex;
        type2=server.entities[item2].modelindex;
        if((type1&TYPE_ARMOR)>0) {
            if((type2&TYPE_ARMOR)>0) {
                return (server.entities[item2].skin>server.entities[item1].skin);
            } else if((type2&TYPE_HEAL)>0) {
                if(server.health<50) { 
                    return true;
                } else if(server.armorvalue<50) {
                    return false;
                } else {
                    return (server.health<server.armorvalue);
                }
            } else if((type2&TYPE_GUN)>0) {
                if(server.armorvalue<50) {
                    return false;
                } else if(server.precache_models[type2].mask==IT_LIGHTNING || server.precache_models[type2].mask==IT_ROCKET_LAUNCHER) {
                    return true;
                } else if(server.armorvalue<150) {
                    return false;
                } else {
                    return true;
                }
            } else if((type2&TYPE_AMMO)>0) {
                if(server.armorvalue<100) {
                    return false;
                } else if((best_weapon_type()&server.precache_models[type2].mask)>0) {
                    return true;
                } else {
                    return false;
                }
            } else if((type2&TYPE_COOL)>0) {
                return true;
            } else {
                return false;
            }
        } else if((type1&TYPE_HEAL)>0) {
            if((type2&TYPE_ARMOR)>0) {
                if(server.health<50) { 
                    return false;
                } else if(server.armorvalue<50) {
                    return true;
                } else {
                    return (server.health>server.armorvalue);
                }
            } else if((type2&TYPE_HEAL)>0) {
                return (server.precache_models[type2].value>server.precache_models[type1].value);
            } else if((type2&TYPE_GUN)>0) {
                if(server.health<50) {
                    return false;
                } else if(server.precache_models[type2].mask==IT_LIGHTNING || server.precache_models[type2].mask==IT_ROCKET_LAUNCHER) {
                    return true;
                } else if(server.health<100) {
                    return false;
                } else {
                    return true;
                }
            } else if((type2&TYPE_AMMO)>0) {
                if(server.health<75) {
                    return false;
                } else if((best_weapon_type()&server.precache_models[type2].mask)>0) {
                    return true;
                } else {
                    return false;
                }
            } else if((type2&TYPE_COOL)>0) {
                return true;
            } else {
                return false;
            }
        } else if((type1&TYPE_GUN)>0) {
            if((type2&TYPE_ARMOR)>0) {
                if(server.armorvalue<50) {
                    return true;
                } else if(server.precache_models[type1].mask==IT_LIGHTNING || server.precache_models[type1].mask==IT_ROCKET_LAUNCHER) {
                    return false;
                } else if(server.armorvalue<150) {
                    return true;
                } else {
                    return false;
                }
            } else if((type2&TYPE_HEAL)>0) {
                if(server.health<50) {
                    return true;
                } else if(server.precache_models[type1].mask==IT_LIGHTNING || server.precache_models[type1].mask==IT_ROCKET_LAUNCHER) {
                    return false;
                } else if(server.health<100) {
                    return true;
                } else {
                    return false;
                }
            } else if((type2&TYPE_GUN)>0) {
                return (server.precache_models[type2].mask>server.precache_models[type1].mask);
            } else if((type2&TYPE_AMMO)>0) {
                if(server.precache_models[type1].mask==IT_LIGHTNING && (server.items&IT_LIGHTNING)==0) { 
                    return false;
                } else if(server.precache_models[type1].mask==IT_ROCKET_LAUNCHER && (server.items&IT_ROCKET_LAUNCHER)==0) {
                    return false;
                } else if((best_weapon_type()&server.precache_models[type2].mask)>0) {
                    return true;
                } else {
                    return false;
                }
            } else if((type2&TYPE_COOL)>0) {
                return true;
            } else {
                return false;
            }
        } else if((type1&TYPE_AMMO)>0) {
            if((type2&TYPE_ARMOR)>0) {
                if(server.armorvalue<100) {
                    return true;
                } else if((best_weapon_type()&server.precache_models[type1].mask)>0) {
                    return false;
                } else {
                    return true;
                }
            } else if((type2&TYPE_HEAL)>0) {
                if(server.health<75) {
                    return true;
                } else if((best_weapon_type()&server.precache_models[type1].mask)>0) {
                    return false;
                } else {
                    return true;
                }
            } else if((type2&TYPE_GUN)>0) {
                if(server.precache_models[type2].mask==IT_LIGHTNING && (server.items&IT_LIGHTNING)==0) { 
                    return true;
                } else if(server.precache_models[type2].mask==IT_ROCKET_LAUNCHER && (server.items&IT_ROCKET_LAUNCHER)==0) {
                    return true;
                } else if((best_weapon_type()&server.precache_models[type1].mask)>0) {
                    return false;
                } else {
                    return true;
                }
            } else if((type2&TYPE_AMMO)>0) {
                if((best_weapon_type()&server.precache_models[type1].mask)>0) {
                    if((best_weapon_type()&server.precache_models[type2].mask)>0) {
                        return (server.precache_models[type2].value>server.precache_models[type1].value);
                    } else {
                        return false;
                    }
                } else {
                    if((best_weapon_type()&server.precache_models[type2].mask)>0) {
                        return true;
                    } else {
                        return (server.precache_models[type2].value>server.precache_models[type1].value);
                    }
                }
            } else if((type2&TYPE_COOL)>0) {
                return true;
            } else {
                return false;
            }
        } else if((type1&TYPE_COOL)>0) {
            return false;
        } else {
            return true;
        }
    }

    public int danger_value(int t) {
        int minum;
        minum=server.entities[t].modelindex;
        if((server.precache_models[minum].type&TYPE_FEAR)!=0) {
            return server.precache_models[minum].fearvalue-entity_dist(t);
        }
        return 0;
    }

    public boolean need_item(int t) {
        int minum;
        int armortype;
        minum=server.entities[t].modelindex;
        if((server.precache_models[minum].type&TYPE_ARMOR)!=0) {
            if((server.items&server.IT_ARMOR1)!=0) {
                armortype=3;
            } else if((server.items&server.IT_ARMOR2)!=0) {
                armortype=6;
            } else if((server.items&server.IT_ARMOR3)!=0) {
                armortype=8;
            } else {
                armortype=0;
            }
            if(server.entities[t].skin==0) {
               if((server.armorvalue*armortype)>=300) {
                   return false;
               }
            } else if(server.entities[t].skin==1) {
               if((server.armorvalue*armortype)>=900) {
                   return false;
               }
            } else if(server.entities[t].skin==2) {
               if((server.armorvalue*armortype)>=1600) {
                   return false;
               }
            }
        }
        if((server.precache_models[minum].type&TYPE_HEAL)!=0) {
            if(server.health>=server.precache_models[minum].max_health) {
               return false;
            }
        }
        if((server.precache_models[minum].type&TYPE_COOL)!=0) {
            return true;
        }
        if((server.precache_models[minum].type&TYPE_GUN)!=0) {
            if((server.items&server.precache_models[minum].mask)!=0) {
                return false;
            }
        }
        if((server.precache_models[minum].type&TYPE_AMMO)!=0) {
            if(server.ammo_shells>=server.precache_models[minum].max_shells) {
                return false;
            } else if(server.ammo_nails>=server.precache_models[minum].max_nails) {
                return false;
            } else if(server.ammo_rockets>=server.precache_models[minum].max_rockets) {
                return false;
            } else if(server.ammo_cells>=server.precache_models[minum].max_cells) {
                return false;
            }
        }
        return true;
    }

    public int best_weapon_ammo() {
        if((server.items&IT_LIGHTNING)==IT_LIGHTNING) {
            return server.ammo_cells;
        } else if((server.items&IT_ROCKET_LAUNCHER)==IT_ROCKET_LAUNCHER) {
            return server.ammo_rockets;
        } else if((server.items&IT_SUPER_NAILGUN)==IT_SUPER_NAILGUN) {
            return server.ammo_nails;
        } else if((server.items&IT_NAILGUN)==IT_NAILGUN) {
            return server.ammo_nails;
        } else if((server.items&IT_SUPER_SHOTGUN)==IT_SUPER_SHOTGUN) {
            return server.ammo_shells;
        } else if((server.items&IT_SHOTGUN)==IT_SHOTGUN) {
            return server.ammo_shells;
        } else if((server.items&IT_GRENADE_LAUNCHER)==IT_GRENADE_LAUNCHER) {
            return server.ammo_rockets;
        }
        return 0;
    }

    public int best_weapon_type() {
        if((server.items&IT_LIGHTNING)==IT_LIGHTNING) {
            return IT_LIGHTNING;
        } else if((server.items&IT_ROCKET_LAUNCHER)==IT_ROCKET_LAUNCHER) {
            return IT_ROCKET_LAUNCHER;
        } else if((server.items&IT_SUPER_NAILGUN)==IT_SUPER_NAILGUN) {
            return IT_SUPER_NAILGUN;
        } else if((server.items&IT_NAILGUN)==IT_NAILGUN) {
            return IT_NAILGUN;
        } else if((server.items&IT_SUPER_SHOTGUN)==IT_SUPER_SHOTGUN) {
            return IT_SUPER_SHOTGUN;
        } else if((server.items&IT_SHOTGUN)==IT_SHOTGUN) {
            return IT_SHOTGUN;
        } else if((server.items&IT_GRENADE_LAUNCHER)==IT_GRENADE_LAUNCHER) {
            return IT_GRENADE_LAUNCHER;
        }
        return 0;
    }

    public int best_weapon(boolean safe) {
        int best=1;
        if(safe) {
            if((server.items&IT_LIGHTNING)==IT_LIGHTNING && server.ammo_cells>0) {
                best=8;
            } else if((server.items&IT_SUPER_NAILGUN)==IT_SUPER_NAILGUN && server.ammo_nails>0) {
                best=5;
            } else if((server.items&IT_NAILGUN)==IT_NAILGUN && server.ammo_nails>0) {
                best=4;
            } else if((server.items&IT_SUPER_SHOTGUN)==IT_SUPER_SHOTGUN && server.ammo_shells>0) {
                best=3;
            } else if((server.items&IT_SHOTGUN)==IT_SHOTGUN && server.ammo_shells>0) {
                best=2;
            }
        } else {
            if((server.items&IT_LIGHTNING)==IT_LIGHTNING && server.ammo_cells>0) {
                best=8;
            } else if((server.items&IT_ROCKET_LAUNCHER)==IT_ROCKET_LAUNCHER && server.ammo_rockets>0) {
                best=7;
            } else if((server.items&IT_SUPER_NAILGUN)==IT_SUPER_NAILGUN && server.ammo_nails>0) {
                best=5;
            } else if((server.items&IT_NAILGUN)==IT_NAILGUN && server.ammo_nails>0) {
                best=4;
            } else if((server.items&IT_SUPER_SHOTGUN)==IT_SUPER_SHOTGUN && server.ammo_shells>0) {
                best=3;
            } else if((server.items&IT_SHOTGUN)==IT_SHOTGUN && server.ammo_shells>0) {
                best=2;
            } else if((server.items&IT_GRENADE_LAUNCHER)==IT_GRENADE_LAUNCHER && server.ammo_rockets>0) {
                best=6;
            }
        }
        return best;
    }

    public boolean entity_alive(int t) {
        int death_start;
        int death_end;
        int frame;
        int type;
        death_start=server.precache_models[server.entities[t].modelindex].death_start;
        death_end=server.precache_models[server.entities[t].modelindex].death_end;
        frame=server.entities[t].frame;
        type=server.precache_models[server.entities[t].modelindex].type;
        if(frame>=death_start && frame<death_end || (type&0x04)!=0x04) {
            return false;
        } else {
            return true;
        }
    }

    public void faceVect(Vect3D v) {
        target_x=(double)v.x;
        target_y=(double)v.y;
        target_z=(double)v.z;
    }

    public void face_entity(int t,boolean predict) {
        Vect3D v=new Vect3D();
        Vect3D s=new Vect3D();
        float time=0;
        float extratime;

        v.x=(float)server.entities[t].x/8;
        v.y=(float)server.entities[t].y/8;
        v.z=(float)server.entities[t].z/8;

        if(predict) {
            extratime=((float)server.pingvalue+100)/1000;
            s.x=extratime*server.entities[server.viewpoint_entity].xv/8;
            s.y=extratime*server.entities[server.viewpoint_entity].yv/8;
            s.z=extratime*server.entities[server.viewpoint_entity].zv/8;
            if(weapon==1) {
                time=0;
            } else if(weapon==2) {
                time=0;
            } else if(weapon==3) {
                time=0;
            } else if(weapon==4) {
                time=predict(4000,t);
            } else if(weapon==5) {
                time=predict(8000,t);
            } else if(weapon==6) {
                time=predict(2560,t);
            } else if(weapon==7) {
                time=predict(8000,t);
            } else if(weapon==8) {
                time=0;
            }
            v.x+=time*server.entities[t].xv/8+s.x;
            v.y+=time*server.entities[t].yv/8+s.y;
            v.z+=time*server.entities[t].zv/8+s.z;
        }
        faceVect(v);
    }

    public void avoid(int t) {
        Vect3D v=new Vect3D();
        v.x=server.entities[t].x/8;
        v.y=server.entities[t].y/8;
        v.z=server.entities[t].z/8;
    }

    public void gotoVect(Vect3D v) {
        move=true;
        destination_x=(double)v.x;
        destination_y=(double)v.y;
        destination_z=(double)v.z;
    }

    public Vect3D vectForWaypoint(int t) {
        Vect3D v=new Vect3D();
        int link=map.path[t];
        v.x=map.links[link].x;
        v.y=map.links[link].y;
        v.z=map.links[link].z+24;
        return v;
    }

    public Vect3D vectForWaypointface(int t) {
        Vect3D v=new Vect3D();
        int link=map.path[t];
        int face=map.links[link].face;
        v.x=map.faces[face].x;
        v.y=map.faces[face].y;
        v.z=map.faces[face].z+24;
        return v;
    }

    public Vect3D vectForMe() {
        Vect3D v=new Vect3D();
        v.x=(float)server.self_x/8;
        v.y=(float)server.self_y/8;
        v.z=(float)server.self_z/8;
        return v;
    }

    public Vect3D vectForEntity(int t) {
        Vect3D v=new Vect3D();
        v.x=(float)server.entities[t].x/8;
        v.y=(float)server.entities[t].y/8;
        v.z=(float)server.entities[t].z/8;
        return v;
    }

    public int entity_dist(int t) {
        int link=map.path[t];
        double x,y,z;
        x=(double)(server.entities[t].x-server.self_x)/8;
        y=(double)(server.entities[t].y-server.self_y)/8;
        z=(double)(server.entities[t].z-server.self_z)/8;
        return (int)Math.sqrt(x*x+y*y+z*z);
    }

    public int waypoint_dist(int t) {
        int link=map.path[t];
        double x,y,z;
        x=(double)map.links[link].x-((double)server.self_x)/8;
        y=(double)map.links[link].y-((double)server.self_y)/8;
        z=(double)map.links[link].z-((double)server.self_z)/8+24;
        return (int)Math.sqrt(x*x+y*y+z*z);
    }

    public int waypointface_dist(int t) {
        int link=map.path[t];
        int face=map.links[link].face;
        double x,y,z;
        x=(double)map.faces[face].x-((double)server.self_x)/8;
        y=(double)map.faces[face].y-((double)server.self_y)/8;
        z=(double)map.faces[face].z-((double)server.self_z)/8+24;
        return (int)Math.sqrt(x*x+y*y+z*z);
    }

    public void respawn() {
        byte b[]=new byte[32];
        int temp;
        temp=Float.floatToIntBits(server.time);
        b[0]=(byte)0x03;
        b[1]=(byte)(temp&0xff);
        b[2]=(byte)((temp>>8)&0xff);
        b[3]=(byte)((temp>>16)&0xff);
        b[4]=(byte)((temp>>24)&0xff);
        b[5]=(byte)0x00; // tilt
        b[6]=(byte)0x00; // yaw
        b[7]=(byte)0x00; // flip
        b[8]=(byte)0x00; // forward
        b[9]=(byte)0x00;
        b[10]=(byte)0x00; // right
        b[11]=(byte)0x00;
        b[12]=(byte)0x00; // up
        b[13]=(byte)0x00;
        b[14]=(byte)0x00; // flag
        b[15]=(byte)0x00; // impulse
        server.send(0x0010,b,16);
        try {
            Thread.sleep(100);
        } catch(InterruptedException e) {
            System.err.println("Error: Programmer is a moron");
        }
        b[14]=(byte)0x01; // flag
        server.send(0x0010,b,16);
        try {
            Thread.sleep(100);
        } catch(InterruptedException e) {
            System.err.println("Error: Programmer is a moron");
        }
    }

    public void say(String s) {
        byte b[]=new byte[2048];
        char c[];
        int strlen;
        int length;
        c=s.toCharArray();
        strlen=s.length();
        length=0;
        b[length++]=(byte)0x04;
        b[length++]=(byte)'s';
        b[length++]=(byte)'a';
        b[length++]=(byte)'y';
        b[length++]=(byte)0x20;
        b[length++]=(byte)'"';
        for(int i=0;i<strlen;i++) {
            b[length++]=(byte)c[i];
        }
        b[length++]=(byte)'"';
        b[length++]=(byte)0x00;
        server.send(0x0010,b,length);
    }

    public void connect() {
        byte b[]=new byte[2048];
        char c[];
        int namelen;
        int length;
        String botname=new String("Javabot v"+server.version_string);
        c=botname.toCharArray();
        namelen=botname.length();
        connected=false;
        try {
            length=0;
            b[length++]=(byte)0x01;
            b[length++]=(byte)'Q';
            b[length++]=(byte)'U';
            b[length++]=(byte)'A';
            b[length++]=(byte)'K';
            b[length++]=(byte)'E';
            b[length++]=(byte)0x00;
            b[length++]=(byte)0x03;
            server.send(0x8000,b,length);
            Thread.sleep(1000);
            while(!server.connected) {
                Thread.sleep(4000);
                server.send(0x8000,b,length);
            }
            while(server.signon==0) { }
            length=0;
            b[length++]=(byte)0x01;
            server.acknowledged=false;
            server.send(0x0009,b,length);
            Thread.sleep(1000);
            while(!server.acknowledged) {
                Thread.sleep(1000);
                server.send(0x0009,b,length);
            }
            server.reliable_send_order++;
            length=0;
            b[length++]=(byte)0x04;
            b[length++]=(byte)'p';
            b[length++]=(byte)'r';
            b[length++]=(byte)'e';
            b[length++]=(byte)'s';
            b[length++]=(byte)'p';
            b[length++]=(byte)'a';
            b[length++]=(byte)'w';
            b[length++]=(byte)'n';
            b[length++]=(byte)0x00;
            server.acknowledged=false;
            server.send(0x0009,b,length);
            Thread.sleep(1000);
            while(!server.acknowledged) {
                Thread.sleep(5000);
                server.send(0x0009,b,length);
            }
            server.reliable_send_order++;
            map=server.open_map();
            maploaded=true;
            while(server.signon==1) { }
            length=0;
            b[length++]=(byte)0x04;
            b[length++]=(byte)'n';
            b[length++]=(byte)'a';
            b[length++]=(byte)'m';
            b[length++]=(byte)'e';
            b[length++]=(byte)0x20;
            b[length++]=(byte)'"';
            for(int i=0;i<namelen;i++) {
                b[length++]=(byte)c[i];
            }
            b[length++]=(byte)'"';
            b[length++]=(byte)'\n';
            b[length++]=(byte)0x00;
            b[length++]=(byte)0x04;
            b[length++]=(byte)'c';
            b[length++]=(byte)'o';
            b[length++]=(byte)'l';
            b[length++]=(byte)'o';
            b[length++]=(byte)'r';
            b[length++]=(byte)0x20;
            b[length++]=(byte)'5';
            b[length++]=(byte)0x20;
            b[length++]=(byte)'1';
            b[length++]=(byte)'3';
            b[length++]=(byte)'\n';
            b[length++]=(byte)0x00;
            b[length++]=(byte)0x04;
            b[length++]=(byte)'s';
            b[length++]=(byte)'p';
            b[length++]=(byte)'a';
            b[length++]=(byte)'w';
            b[length++]=(byte)'n';
            b[length++]=(byte)0x20;
            b[length++]=(byte)0x00;
            server.acknowledged=false;
            server.send(0x0009,b,length);
            Thread.sleep(1000);
            while(!server.acknowledged) {
                Thread.sleep(5000);
                server.send(0x0009,b,length);
            }
            server.reliable_send_order++;
            while(server.signon==2) { }
            length=0;
            b[length++]=(byte)0x04;
            b[length++]=(byte)'b';
            b[length++]=(byte)'e';
            b[length++]=(byte)'g';
            b[length++]=(byte)'i';
            b[length++]=(byte)'n';
            b[length++]=(byte)0x00;
            server.acknowledged=false;
            server.send(0x0009,b,length);
            Thread.sleep(1000);
            while(!server.acknowledged) {
                Thread.sleep(5000);
                server.send(0x0009,b,length);
            }
            server.reliable_send_order++;
            connected=true;
        } catch(InterruptedException e) {
            System.err.println("Error: Programmer is a moron");
        }
    }

    public void disconnect() {
        byte b[]=new byte[2048];
        int length;
        connected=false;
        pingerThread.stop();
        try {
            length=0;
            b[length++]=(byte)0x02;
            for(int i=0;i<3;i++) {
                server.send(0x0010,b,length);
                System.out.print("Sent Disconnection Request\n");
                    Thread.sleep(333);
            }
        } catch(InterruptedException e) {
            System.err.println("Error: Programmer is a moron");
        }
    }
}