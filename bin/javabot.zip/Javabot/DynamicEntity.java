class DynamicEntity {
    int default_modelindex;
    int modelindex;
    int default_frame;
    int frame;
    int default_colormap;
    int colormap;
    int default_skin;
    int skin;
    int x,y,z;
    int xa,ya,za;
    float xv,yv,zv;
    float respawn_time;
    float lastupdate;

    public void newlocation(int xn,int yn,int zn,float time) {
        float dt;
        if(xn>=32768) xn-=65537;
        if(yn>=32768) yn-=65537;
        if(zn>=32768) zn-=65537;
        dt=time-lastupdate;
        if(dt!=0) {
            xv=(float)(xn-x)/dt;
            yv=(float)(yn-y)/dt;
            zv=(float)(zn-z)/dt;
        }
        x=xn;
        y=yn;
        z=zn;
        lastupdate=time;
    }
}