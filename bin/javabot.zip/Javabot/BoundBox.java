class BoundBox {
    Vect3D min=new Vect3D();
    Vect3D max=new Vect3D();
}