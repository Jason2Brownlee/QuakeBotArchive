/////////////////////////////////////////////
// *** To do:
//  1) Target prediction code
//  2) PAK reading code
//  3) Dynamic level loading
//  4) Level navigation code
//  5) Learn to do a .join()
//  6) Remove Player.class
//  7) put all packet code in server
//  8) make client send 1 movement per update
//  9) Make modes of attack (charge,zag,circle)
// 10) make proxy
/////////////////////////////////////////////

class Player implements Runnable {
    Thread playerThread=null;
    Client client;

    // Emotions

    int COMPLACENT=0;
    int GREEDY=1;
    int AGGRESIVE=2;
    int PANIC=3;
    int CONFUSED=4;
    int INSIDIOUS=5;

    // Constants

    int TYPE_ITEM = 0x01;
    int TYPE_FEAR = 0x02;
    int TYPE_HATE = 0x04;

    // Game Varibles

    int emotion=0;
    int target=0;
    int destination=0;
    int danger=0;
    int quest=0;
    boolean onquest=false;
    int viewlist[]=new int[512];
    int viewlistlength;
    int spawnlist[]=new int[512];
    int spawnlistlength;
    int last_frags;
    int path_length;
    int waypoint;
    boolean waypointface=false;
    Vect3D destinationVect=new Vect3D();

    public Player(String s) {
        client=new Client(s);
        start();
    }

    public synchronized void start() {
        if(playerThread==null) {
            playerThread=new Thread(this);
            playerThread.setPriority(7);
            playerThread.start();
        }
    }

    public synchronized void stop() {
        if(playerThread!=null) {
            playerThread.stop();
            playerThread=null;
        }
    }

    public void run() {
        int loop=10;

        client.connect();
        playerThread.setPriority(3);
        client.initialize();
        while(client.connected) {
            client.waitfor_uptodate();
            if(client.my_frags()>last_frags) {
                double value=Math.random();
                last_frags=client.my_frags();
                if(value<.2) {
                    client.say("Oh yes! You can't come close!");
                } else if(value<.4) {
                    client.say("Another one bites the dust!");
                } else if(value<.6) {
                    client.say("Chalk one up for the good guys!");
                } else if(value<.8) {
                    client.say("Ha Ha! You're dead!");
                } else {
                    client.say("Damn, I'm good!");
                }
            }
            if(client.my_health()<=0) {
                double value=Math.random();
                if(value<.2) {
                    client.say("You won't get away so easy!");
                } else if(value<.4) {
                    client.say("You haven't seen the last of me!");
                } else if(value<.6) {
                    client.say("Arr! That sucked!");
                } else if(value<.8) {
                    client.say("I'll get you for that!");
                } else {
                    client.say("Come back here and try that again!");
                }
            }
            while(client.my_health()<=0) {
                client.respawn();
                onquest=false;
                loop=10;
            }
            client.jump=false;

            target=find_target();
            if(target==0) {
                client.attack=false;
                client.weapon=1;
                client.targetString="nothing";
            } else {
                client.attack=true;
                int best=client.best_weapon(false);
                client.weapon=best;
                client.face_entity(target,true);
                client.targetString=client.entity_name(target);
            }

            client.rate_need();
            destination=find_supplies();
            danger=find_danger();
            danger=0;

            if(!onquest) {
                quest=0;
                client.questString="nothing";
                if(loop==0) {
                    quest=find_quest();
                    if(quest!=0) {
                        path_length=client.make_path(quest);
                        if(path_length>=0) {
                            waypoint=0;
                            waypointface=false;
                            onquest=true;
                        }
                    } else {
//                        System.out.println("No Quest");
                        loop=20;
                    }
                } else {
                    loop--;
                }
            } else {
                if(client.stuck()) {
                    onquest=false;
                    loop=5;
                    client.set_spawn(quest);
                    client.say("I'm stuck!");
                    if(target==0) {
                        client.weapon=1;
                        client.attack=true;
                    }
                }
                boolean seeking=true;
                while(seeking) {
                    if(waypointface) {
                        if(client.waypointface_dist(waypoint)<64) {
                            waypoint++;
                            waypointface=false;
                        } else {
                            seeking=false;
                        }
                    } else {
                        if(client.waypoint_dist(waypoint)<64) {
                            waypointface=true;
                        } else {
                            seeking=false;
                        }
                    }
                    if(waypoint==path_length) {
                        seeking=false;
                    }
                }
                if(waypoint==path_length) {
                    onquest=false;
                    loop=5;
                    client.set_spawn(quest);
                } else {
                    if(waypointface) {
                        client.questString=client.entity_name(quest)+" "+waypoint+".5/"+path_length;
                        destinationVect=client.vectForWaypointface(waypoint);
                    } else {
                        client.questString=client.entity_name(quest)+" "+waypoint+".0/"+path_length;
                        destinationVect=client.vectForWaypoint(waypoint);
                    }
                }
            }

            if(destination>0) {
                destinationVect=client.vectForEntity(destination);
                client.destinationString=client.entity_name(destination);
            } else {
                client.destinationString="nothing";
            }
            client.gotoVect(destinationVect);

            if(danger>0) {
                client.avoid(danger);
                client.fearString=client.entity_name(danger);
            } else {
                client.fearString="nothing";
            }

            if(target==0) {
                client.faceVect(destinationVect);
            }
            if(destination==0 && quest==0 && danger==0) {
                if(target==0) {
                    client.stand();
                } else {
                    client.jump=true;
                }
            }
            client.sendcommand();
        }
        stop();
    }

    private int find_danger() {
        int entity,mostdanger=0,danger,mostfeared=0;
        viewlistlength=client.get_viewlist(viewlist);
        for(int i=0;i<viewlistlength;i++) {
            entity=viewlist[i];
            if((client.identify_entity(entity)&TYPE_FEAR)!=0) {
                if(client.fresh(entity)) {
                    if((client.identify_entity(entity)&TYPE_HATE)==0 || client.entity_alive(entity)) {
                        danger=client.danger_value(entity);
                        if(danger>mostdanger) {
                            mostdanger=danger;
                            mostfeared=entity;
                        }
                    }
                }
            }
        }
        return mostfeared;
    }

    private int find_target() {
        int target;
        viewlistlength=client.get_viewlist(viewlist);
        for(int i=0;i<viewlistlength;i++) {
            target=viewlist[i];
            if((client.identify_entity(target)&TYPE_HATE)!=0) {
                if(client.fresh(target)) {
                    if(client.entity_alive(target)) {
                        if(client.visible(target)) {
                            return target;
                        }
                    }
                }
            }
        }
        return 0;
    }

    private int find_supplies() {
        int item,bestitem=0,value,bestvalue=0;
        viewlistlength=client.get_viewlist(viewlist);
        for(int i=0;i<viewlistlength;i++) {
            item=viewlist[i];
            if((client.identify_entity(item)&TYPE_ITEM)!=0) {
                if(client.fresh(item)) {
                    if(client.need_item(item)) {
                        if(client.visible(item)) {
/*
                            value=client.item_value(item);
                            if(value<=0) {
                                System.err.println(client.entity_name(item)+" has value of "+value);
                                disconnect();
                                System.exit(1);
                            }
                            if(value>bestvalue) {
                                bestvalue=value;
                                bestitem=item;
                            }
*/
                            if(client.itemBetterThan(bestitem,item)) {
                                bestitem=item;
                            }
                        }
                    }
                }
            }
        }
        return bestitem;
    }

    private int find_quest() {
        int item,bestitem=0,value,bestvalue=0;
        spawnlistlength=client.get_spawnlist(spawnlist);
        for(int i=0;i<spawnlistlength;i++) {
            item=spawnlist[i];
            if((client.identify_entity(item)&TYPE_ITEM)!=0) {
                if(client.respawned(item)) {
                    if(client.need_item(item)) {
                        if(client.check_path(item)) {
/*
                            value=client.item_value(item);
                            if(value<=0) {
                                System.err.println(client.entity_name(item)+" has value of "+value);
                                disconnect();
                                System.exit(1);
                            }
                            if(value>bestvalue) {
                                bestvalue=value;
                                bestitem=item;
                            }
*/
                            if(client.itemBetterThan(bestitem,item)) {
                                bestitem=item;
                            }
                        }
                    }
                }
            }
        }
        return bestitem;
    }

    public void disconnect() {
        client.disconnect();
    }
}
