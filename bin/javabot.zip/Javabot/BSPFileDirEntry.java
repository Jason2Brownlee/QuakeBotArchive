class BSPFileDirEntry {
    int offset;
    int size;
    int sizeof;
    int entries;
}