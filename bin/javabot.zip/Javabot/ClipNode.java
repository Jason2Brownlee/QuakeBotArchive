class ClipNode {
    int plane_id;
    int front;
    int back;
}