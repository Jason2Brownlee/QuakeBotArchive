import java.lang.SecurityException;
import java.lang.IllegalArgumentException;
import java.io.RandomAccessFile;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;

class BSPtoJBM {
	RandomAccessFile infile,outfile;
	BSPFileHeader inheader;
	JBMFileHeader outheader;
	Plane planes[];
	BSPNode bspnodes[];
	ClipNode clipnodes[];
	Hull hulls[];
	BSPLeaf bspleaves[];
	Vertex verticies[];
	Edge edges[];
	Face faces[];
	byte vislist[];
	int edgelist[];
	int facelist[];
	int texinfo[];			// store texture id only
	int miptex[];			// store name flags only
	int nummiptex;
	byte texname[];
	Link links[];
	int numlinks;
	int edge_to_face1[];
	int edge_to_face2[];
	long start_time,link_start_time;
	PrintWriter pts_file;
	boolean fullCheck;

	public BSPtoJBM(String filename,String opts) throws IOException {
		if(opts.compareTo("-f")==0) {
			fullCheck=true;
			System.out.println("Stairs Enabled");
		} else {
			fullCheck=false;
		}
		start_time=System.currentTimeMillis();
		System.out.println("Converting BSP to JBM");
		try {
//			pts_file=new PrintWriter(new FileOutputStream(filename+".pts"));
			infile=new RandomAccessFile(filename+".bsp","r");
		} catch(IllegalArgumentException e) {
			System.err.println("Arguement Error: "+e);
		} catch(SecurityException e) {
			System.err.println("Security Error: "+e);
		}
		inheader=new BSPFileHeader(infile);
		try {
			File temp=new File(filename+".jbm");
			if(temp.exists()) {
				temp.delete();
			}
		} catch(SecurityException e) {
			System.err.println("Security Error: "+e);
		}
		try {
			outfile=new RandomAccessFile(filename+".jbm","rw");
		} catch(IllegalArgumentException e) {
			System.err.println("Arguement Error: "+e);
		} catch(SecurityException e) {
			System.err.println("Security Error: "+e);
		}
		outheader=new JBMFileHeader(outfile);
		outheader.writeHeader();

		System.out.print("Converting Hulls:");
		infile.seek(inheader.hulls.offset);
		outheader.hulls.offset=(int)outfile.getFilePointer();
		hulls=new Hull[inheader.hulls.entries];
		outheader.hulls.entries=inheader.hulls.entries;
		System.out.println(" "+outheader.hulls.entries);
		for(int i=0;i<inheader.hulls.entries;i++) {
			hulls[i]=new Hull();
			hulls[i].bound.min.x=readFloatBigEndian();
			hulls[i].bound.min.y=readFloatBigEndian();
			hulls[i].bound.min.z=readFloatBigEndian();
			hulls[i].bound.max.x=readFloatBigEndian();
			hulls[i].bound.max.y=readFloatBigEndian();
			hulls[i].bound.max.z=readFloatBigEndian();
			hulls[i].origin.x=readFloatBigEndian();
			hulls[i].origin.y=readFloatBigEndian();
			hulls[i].origin.z=readFloatBigEndian();
			hulls[i].rootbspnode=readIntBigEndian();
			hulls[i].rootclipnode=readIntBigEndian();
			hulls[i].secondaryclipnode=readIntBigEndian();
			hulls[i].unknownnode=readIntBigEndian();
			hulls[i].numleafs=readIntBigEndian();
			hulls[i].face_id=readIntBigEndian();
			hulls[i].face_num=readIntBigEndian();
			outfile.writeFloat(hulls[i].bound.min.x);
			outfile.writeFloat(hulls[i].bound.min.y);
			outfile.writeFloat(hulls[i].bound.min.z);
			outfile.writeFloat(hulls[i].bound.max.x);
			outfile.writeFloat(hulls[i].bound.max.y);
			outfile.writeFloat(hulls[i].bound.max.z);
			outfile.writeFloat(hulls[i].origin.x);
			outfile.writeFloat(hulls[i].origin.y);
			outfile.writeFloat(hulls[i].origin.z);
			outfile.writeInt(hulls[i].rootbspnode);
			outfile.writeInt(hulls[i].rootclipnode);
			outfile.writeInt(hulls[i].secondaryclipnode);
			outfile.writeInt(hulls[i].unknownnode);
			outfile.writeInt(hulls[i].numleafs);
			outfile.writeInt(hulls[i].face_id);
			outfile.writeInt(hulls[i].face_num);
		}

		System.out.print("Converting Planes:");
		infile.seek(inheader.planes.offset);
		outheader.planes.offset=(int)outfile.getFilePointer();
		planes=new Plane[inheader.planes.entries];
		outheader.planes.entries=inheader.planes.entries;
		System.out.println(" "+outheader.planes.entries);
		for(int i=0;i<inheader.planes.entries;i++) {
			planes[i]=new Plane();
			planes[i].normal.x=readFloatBigEndian();
			planes[i].normal.y=readFloatBigEndian();
			planes[i].normal.z=readFloatBigEndian();
			planes[i].dist=readFloatBigEndian();
			planes[i].type=readIntBigEndian();
//			System.out.println("Planes #"+i+" Type: "+planes[i].type+" Dist: "+planes[i].dist);
			outfile.writeFloat(planes[i].normal.x);
			outfile.writeFloat(planes[i].normal.y);
			outfile.writeFloat(planes[i].normal.z);
			outfile.writeFloat(planes[i].dist);
			outfile.writeInt(planes[i].type);
		}

		System.out.print("Converting BSP Nodes:");
		infile.seek(inheader.nodes.offset);
		outheader.nodes.offset=(int)outfile.getFilePointer();
		bspnodes=new BSPNode[inheader.nodes.entries];
		outheader.nodes.entries=inheader.nodes.entries;
		System.out.println(" "+outheader.nodes.entries);
		for(int i=0;i<inheader.nodes.entries;i++) {
			bspnodes[i]=new BSPNode();
			bspnodes[i].plane_id=readIntBigEndian();
			bspnodes[i].front=readShortBigEndian();
			bspnodes[i].back=readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			bspnodes[i].face_id=readShortBigEndian();
			bspnodes[i].face_num=readShortBigEndian();
//			System.out.println("Node #"+i+" Plane: "+bspnodes[i].plane_id+" Front: "+bspnodes[i].front+" Back: "+bspnodes[i].back);
			outfile.writeInt(bspnodes[i].plane_id);
			outfile.writeShort((short)bspnodes[i].front);
			outfile.writeShort((short)bspnodes[i].back);
			outfile.writeShort((short)bspnodes[i].face_id);
			outfile.writeShort((short)bspnodes[i].face_num);
		}

		System.out.print("Converting Clip Nodes:");
		infile.seek(inheader.clipnodes.offset);
		outheader.clipnodes.offset=(int)outfile.getFilePointer();
		clipnodes=new ClipNode[inheader.clipnodes.entries];
		outheader.clipnodes.entries=inheader.clipnodes.entries;
		System.out.println(" "+outheader.clipnodes.entries);
		for(int i=0;i<inheader.clipnodes.entries;i++) {
			clipnodes[i]=new ClipNode();
			clipnodes[i].plane_id=readIntBigEndian();
			clipnodes[i].front=readShortBigEndian();
			clipnodes[i].back=readShortBigEndian();
//			System.out.println("Node #"+i+" Front: "+clipnodes[i].front+" Back: "+clipnodes[i].back);
			outfile.writeInt(clipnodes[i].plane_id);
			outfile.writeShort((short)clipnodes[i].front);
			outfile.writeShort((short)clipnodes[i].back);
		}

		System.out.print("Converting BSP Leaves:");
		infile.seek(inheader.leaves.offset);
		outheader.leaves.offset=(int)outfile.getFilePointer();
		bspleaves=new BSPLeaf[inheader.leaves.entries];
		outheader.leaves.entries=inheader.leaves.entries;
		System.out.println(" "+inheader.leaves.entries);
		for(int i=0;i<inheader.leaves.entries;i++) {
			bspleaves[i]=new BSPLeaf();
			bspleaves[i].type=readIntBigEndian();
			bspleaves[i].vislist=readIntBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			readShortBigEndian();
			bspleaves[i].lface_id=readShortBigEndian();
			bspleaves[i].lface_num=readShortBigEndian();
			readIntBigEndian();
			outfile.writeShort((short)bspleaves[i].type);
			outfile.writeShort((short)bspleaves[i].lface_id);
			outfile.writeShort((short)bspleaves[i].lface_num);
//			System.out.println("Leaf #"+i+" VisList: "+bspleaves[i].vislist);
		}

		System.out.print("Reading VIS List:");
		infile.seek(inheader.vislist.offset);
		vislist=new byte[inheader.vislist.entries];
		System.out.println(" "+inheader.vislist.entries);
		for(int i=0;i<inheader.vislist.entries;i++) {
			vislist[i]=(byte)infile.readUnsignedByte();
		}

		System.out.print("Converting Verticies:");
		infile.seek(inheader.verticies.offset);
		outheader.verticies.offset=(int)outfile.getFilePointer();
		verticies=new Vertex[inheader.verticies.entries];
		outheader.verticies.entries=inheader.verticies.entries;
		System.out.println(" "+inheader.verticies.entries);
		for(int i=0;i<inheader.verticies.entries;i++) {
			verticies[i]=new Vertex();
			verticies[i].x=readFloatBigEndian();
			verticies[i].y=readFloatBigEndian();
			verticies[i].z=readFloatBigEndian();
			outfile.writeFloat(verticies[i].x);
			outfile.writeFloat(verticies[i].y);
			outfile.writeFloat(verticies[i].z);
		}

		System.out.print("Converting Edges:");
		infile.seek(inheader.edges.offset);
		outheader.edges.offset=(int)outfile.getFilePointer();
		edges=new Edge[inheader.edges.entries];
		outheader.edges.entries=inheader.edges.entries;
		System.out.println(" "+inheader.edges.entries);
		for(int i=0;i<inheader.edges.entries;i++) {
			edges[i]=new Edge();
			edges[i].vertex0=readUnsignedShortBigEndian();
			edges[i].vertex1=readUnsignedShortBigEndian();
			outfile.writeShort(edges[i].vertex0);
			outfile.writeShort(edges[i].vertex1);
		}

		System.out.print("Reading Faces:");
		infile.seek(inheader.faces.offset);
		faces=new Face[inheader.faces.entries];
		System.out.println(" "+inheader.faces.entries);
		for(int i=0;i<inheader.faces.entries;i++) {
			faces[i]=new Face();
			faces[i].plane_id=readUnsignedShortBigEndian();
			faces[i].side=readUnsignedShortBigEndian();
			faces[i].ledge_id=readIntBigEndian();
			faces[i].ledge_num=readUnsignedShortBigEndian();
			faces[i].texinfo=readShortBigEndian();
			readIntBigEndian();
			readIntBigEndian();
		}

		System.out.print("Converting Edge List:");
		infile.seek(inheader.ledges.offset);
		outheader.ledges.offset=(int)outfile.getFilePointer();
		edgelist=new int[inheader.ledges.entries];
		outheader.ledges.entries=inheader.ledges.entries;
		System.out.println(" "+inheader.ledges.entries);
		for(int i=0;i<inheader.ledges.entries;i++) {
			edgelist[i]=readIntBigEndian();
			outfile.writeInt(edgelist[i]);
		}

		System.out.print("Converting Face List:");
		infile.seek(inheader.lfaces.offset);
		outheader.lfaces.offset=(int)outfile.getFilePointer();
		facelist=new int[inheader.lfaces.entries];
		outheader.lfaces.entries=inheader.lfaces.entries;
		System.out.println(" "+inheader.lfaces.entries);
		for(int i=0;i<inheader.lfaces.entries;i++) {
			facelist[i]=readUnsignedShortBigEndian();
			outfile.writeShort(facelist[i]);
		}

		System.out.print("Reading Texinfo:");
		infile.seek(inheader.texinfo.offset);
		texinfo=new int[inheader.texinfo.entries];
		System.out.println(" "+inheader.texinfo.entries);
		for(int i=0;i<inheader.texinfo.entries;i++) {
			readIntBigEndian();
			readIntBigEndian();
			readIntBigEndian();
			readIntBigEndian();
			readIntBigEndian();
			readIntBigEndian();
			readIntBigEndian();
			readIntBigEndian();
			texinfo[i]=readIntBigEndian();
			readIntBigEndian();
		}

		System.out.print("Reading MipTex:");
		infile.seek(inheader.miptex.offset);
		nummiptex=readIntBigEndian();
		texname=new byte[16];
		miptex=new int[nummiptex];
		System.out.println(" "+nummiptex);
		for(int i=0;i<nummiptex;i++) {
			int j=0;
			infile.seek(inheader.miptex.offset+4*(i+1));
			infile.seek(inheader.miptex.offset+readIntBigEndian());
			infile.read(texname);
/*
			while(texname[j]!=0) {
				j++;
			}
			new String(texname,0,j);
*/
			if(texname[0]==(byte)'*') {
				miptex[i]=0;
			} else {
				miptex[i]=1;
			}
		}

		link_start_time=System.currentTimeMillis();

		System.out.print("Creating Links: ");
		links=new Link[20000];
		for(int i=0;i<20000;i++) {
			links[i]=new Link();
		}
		edge_to_face1=new int[inheader.edges.entries];
		edge_to_face2=new int[inheader.edges.entries];
		for(int i=0;i<inheader.edges.entries;i++) {
			edge_to_face1[i]=-1;
			edge_to_face2[i]=-1;
		}
		for(int i=0;i<hulls[0].face_num;i++) {
			float f;
			if(planes[faces[i].plane_id].normal.z>0.7 && faces[i].side==0) {
				if(miptex[texinfo[faces[i].texinfo]]==1) {
					faces[i].floor=1;
				} else {
					faces[i].floor=0;
				}
			} else {
				faces[i].floor=0;
			}
			faces[i].x=0;
			faces[i].y=0;
			faces[i].z=0;
			f=(float)1/(float)faces[i].ledge_num;
			for(int j=0;j<faces[i].ledge_num;j++) {
				int v;
				int k=edgelist[j+faces[i].ledge_id];
				if(k>0) {
					v=edges[k].vertex0;
				} else {
					k=-k;
					v=edges[k].vertex1;
				}
				faces[i].x=faces[i].x+verticies[v].x*f;
				faces[i].y=faces[i].y+verticies[v].y*f;
				faces[i].z=faces[i].z+verticies[v].z*f;
				if(edge_to_face1[k]==-1) {
					edge_to_face1[k]=i;
				} else if(edge_to_face2[k]==-1) {
					edge_to_face2[k]=i;
				} else {
					System.err.println("Critical Error: more than 2 faces on one edge");
					System.exit(1);
				}
			}
		}

		numlinks=0;

		for(int i=0;i<hulls[0].face_num;i++) {
			faces[i].link_id=numlinks;
			faces[i].link_num=0;
			if(faces[i].floor==1) {
//				System.out.print("Face #"+i);
				for(int j=0;j<faces[i].ledge_num;j++) {
					int k=edgelist[j+faces[i].ledge_id];
					if(k<0) {
						k=-k;
					}
					if(edge_to_face1[k]==i) {
						if(edge_to_face2[k]!=-1) {
							if(faces[edge_to_face2[k]].floor==1) {
//								System.out.print(" "+edge_to_face2[k]+",");
								links[numlinks].face=edge_to_face2[k];
								links[numlinks].flags=0;
								links[numlinks].x=(verticies[edges[k].vertex0].x+verticies[edges[k].vertex1].x)/2;
								links[numlinks].y=(verticies[edges[k].vertex0].y+verticies[edges[k].vertex1].y)/2;
								links[numlinks].z=(verticies[edges[k].vertex0].z+verticies[edges[k].vertex1].z)/2;
								faces[i].link_num++;
								numlinks++;
//								drawLink(i,edge_to_face2[k]);
							} else if(planes[faces[edge_to_face2[k]].plane_id].normal.z==0) {
								if(fullCheck) checkWall(edge_to_face2[k],i,k);
							}
						}
					} else if(edge_to_face2[k]==i) {
						if(edge_to_face1[k]!=-1) {
							if(faces[edge_to_face1[k]].floor==1) {
//								System.out.print(" "+edge_to_face1[k]+",");
								links[numlinks].face=edge_to_face1[k];
								links[numlinks].flags=0;
								links[numlinks].x=(verticies[edges[k].vertex0].x+verticies[edges[k].vertex1].x)/2;
								links[numlinks].y=(verticies[edges[k].vertex0].y+verticies[edges[k].vertex1].y)/2;
								links[numlinks].z=(verticies[edges[k].vertex0].z+verticies[edges[k].vertex1].z)/2;
								faces[i].link_num++;
								numlinks++;
//								drawLink(i,edge_to_face1[k]);
							} else if(planes[faces[edge_to_face1[k]].plane_id].normal.z==0) {
								if(fullCheck) checkWall(edge_to_face1[k],i,k);
							}
						}
					} else {
						System.err.println("Critical Error: neither face links back to original");
						System.exit(1);
					}
					if(numlinks>=20000) {
						System.err.println("Critical Error: max numlinks exceeded");
						System.exit(1);
					}
				}
//				System.out.println();
			}
		}
		System.out.println(((float)(System.currentTimeMillis()-link_start_time)/1000)+" seconds");

		System.out.print("Writing Faces:");
		outheader.faces.offset=(int)outfile.getFilePointer();
		outheader.faces.entries=inheader.faces.entries;
		System.out.println(" "+inheader.faces.entries);
		for(int i=0;i<inheader.faces.entries;i++) {
			outfile.writeShort(faces[i].plane_id);
			outfile.writeShort(faces[i].side);
			outfile.writeInt(faces[i].ledge_id);
			outfile.writeShort(faces[i].ledge_num);
			outfile.writeInt(faces[i].link_id);
			outfile.writeShort(faces[i].link_num);
			outfile.writeInt(faces[i].floor);
			outfile.writeFloat(faces[i].x);
			outfile.writeFloat(faces[i].y);
			outfile.writeFloat(faces[i].z);
		}

		System.out.print("Writing Links:");
		outheader.links.offset=(int)outfile.getFilePointer();
		outheader.links.entries=numlinks;
		System.out.println(" "+numlinks);
		for(int i=0;i<numlinks;i++) {
			outfile.writeInt(links[i].face);
			outfile.writeInt(links[i].flags);
			outfile.writeFloat(links[i].x);
			outfile.writeFloat(links[i].y);
			outfile.writeFloat(links[i].z);
		}

		outheader.writeHeader();
		outfile.close();

		infile.close();
		System.out.println("Processing Time: "+((float)(System.currentTimeMillis()-start_time)/1000)+" seconds");
	}


	private boolean edgeOverlap(int n,int m) {
		boolean p=false,q=false;
		float x1=verticies[edges[n].vertex0].x;
		float x2=verticies[edges[n].vertex1].x;
		float x3=verticies[edges[m].vertex0].x;
		float x4=verticies[edges[m].vertex1].x;
		float y1=verticies[edges[n].vertex0].y;
		float y2=verticies[edges[n].vertex1].y;
		float y3=verticies[edges[m].vertex0].y;
		float y4=verticies[edges[m].vertex1].y;
		if(x1<=x2) {
			if((x1<=x3 && x3<=x2) || (x1<=x4 && x4<=x2)) {
				p=true;
			}
		} else {
			if((x2<=x3 && x3<=x1) || (x2<=x4 && x4<=x1)) {
				p=true;
			}
		}
		if(y1<=y2) {
			if((y1<=y3 && y3<y2) || (y1<=y4 && y4<=y2)) {
				q=true;
			}
		} else {
			if((y2<=y3 && y3<y1) || (y2<=y4 && y4<=y1)) {
				q=true;
			}
		}
		if(p && q) {
			return true;
		} else {
			return false;
		}
	}

	private float heightBetween(int n,int m) {
		float z1=verticies[edges[n].vertex0].z;
		float z2=verticies[edges[n].vertex1].z;
		float z3=verticies[edges[m].vertex0].z;
		float z4=verticies[edges[m].vertex1].z;
		return ((z3+z4-z1-z2)/2);
	}

	private void checkWall(int wall,int face,int edge) {
		for(int j=0;j<faces[wall].ledge_num;j++) {
			int k=edgelist[j+faces[wall].ledge_id];
			if(k<0) {
				k=-k;
			}
			float height=heightBetween(edge,k);
			if(edgeOverlap(edge,k) && (height<=24)) {
				if(edge_to_face1[k]==wall) {
					if(faces[edge_to_face2[k]].floor==1) {
//						System.out.print(" "+edge_to_face2[k]+",");
						links[numlinks].face=edge_to_face2[k];
						links[numlinks].flags=0;
						links[numlinks].x=(verticies[edges[k].vertex0].x+verticies[edges[k].vertex1].x)/2;
						links[numlinks].y=(verticies[edges[k].vertex0].y+verticies[edges[k].vertex1].y)/2;
						links[numlinks].z=(verticies[edges[k].vertex0].z+verticies[edges[k].vertex1].z)/2;
						faces[face].link_num++;
						numlinks++;
//						drawLink(face,edge_to_face2[k]);
					}
				} else if(edge_to_face2[k]==wall) {
					if(faces[edge_to_face1[k]].floor==1) {
//						System.out.print(" "+edge_to_face1[k]+",");
						links[numlinks].face=edge_to_face1[k];
						links[numlinks].flags=0;
						links[numlinks].x=(verticies[edges[k].vertex0].x+verticies[edges[k].vertex1].x)/2;
						links[numlinks].y=(verticies[edges[k].vertex0].y+verticies[edges[k].vertex1].y)/2;
						links[numlinks].z=(verticies[edges[k].vertex0].z+verticies[edges[k].vertex1].z)/2;
						faces[face].link_num++;
						numlinks++;
//						drawLink(face,edge_to_face1[k]);
					}
				} else {
					System.err.println("Critical Error: neither face links back to original");
					System.exit(1);
				}
				if(numlinks>=20000) {
					System.err.println("Critical Error: max numlinks exceeded");
					System.exit(1);
				}
			}
		}
	}

	private void checkVisList(int n) {
		boolean visible[]=new boolean[hulls[0].numleafs+7];
		int v,q=0,l=1;

		v=bspleaves[n].vislist;
		if(v!=-1) {
			for(l=1;l<hulls[0].numleafs;v++) {
				if(vislist[v]==0) {
					int jump=((int)vislist[v+1])&0xff;
					l+=(8*jump);
					v++;
				} else {
					for(byte bit=1;bit!=0;bit*=2) {
						if((vislist[v]&bit)==bit) {
							visible[l]=true;
						}
						l++;
					}
				}
			}
		}
	}

	private void drawLink(int n,int m) {
		int x0=(int)faces[n].x;
		int y0=(int)faces[n].y;
		int z0=(int)faces[n].z+16;
		int dx=(int)(faces[m].x-faces[n].x);
		int dy=(int)(faces[m].y-faces[n].y);
		int dz=(int)(faces[m].z-faces[n].z);
		int length=(int)Math.sqrt((double)(dx*dx+dy*dy+dz*dz));
		if(length>0) {
			dx=dx*16/length;
			dy=dy*16/length;
			dz=dz*16/length;
			for(int j=0;j<length;j+=32) {
				pts_file.println(" "+x0+" "+y0+" "+z0);
				x0=x0+dx;
				y0=y0+dy;
				z0=z0+dz;
			}
		}
	}

	public boolean traceLine(Vect3D o,Vect3D p) {
		boolean test;
		test=intersect(o,p,hulls[0].rootclipnode,0,1);
		if(test) {
			return false;
		} else {
			return true;
		}
	}

	private boolean intersect(Vect3D o,Vect3D p,int node,float min,float max) {
		float tx,ty,tz;
		float nx,ny,nz;
		float dist,t;
		float temp;
		int near,far;
		int plane_id;
		plane_id=clipnodes[node].plane_id;
		tx=p.x-o.x;
		ty=p.y-o.y;
		tz=p.z-o.z;
		nx=planes[plane_id].normal.x;
		ny=planes[plane_id].normal.y;
		nz=planes[plane_id].normal.z;
		dist=planes[plane_id].dist;
		if(planes[plane_id].type==0) {
			if(tx!=0) {
				t=(nx*dist-o.x)/tx;
			} else {
				t=Float.NaN;
			}
			if((o.x*nx)<dist) {
				near=clipnodes[node].back;
				far=clipnodes[node].front;
			} else {
				near=clipnodes[node].front;
				far=clipnodes[node].back;
			}
		} else if(planes[plane_id].type==1) {
			if(ty!=0) {
				t=(ny*dist-o.y)/ty;
			} else {
				t=Float.NaN;
			}
			if((o.y*ny)<dist) {
				near=clipnodes[node].back;
				far=clipnodes[node].front;
			} else {
				near=clipnodes[node].front;
				far=clipnodes[node].back;
			}
		} else if(planes[plane_id].type==2) {
			if(tz!=0) {
				t=(nz*dist-o.z)/tz;
			} else {
				t=Float.NaN;
			}
			if((o.z*nz)<dist) {
				near=clipnodes[node].back;
				far=clipnodes[node].front;
			} else {
				near=clipnodes[node].front;
				far=clipnodes[node].back;
			}
		} else {
			temp=nx*tx+ny*ty+nz*tz;
			if(temp!=0) {
				t=(dist-o.x*nx-o.y*ny-o.z*nz)/temp;
			} else {
				t=Float.NaN;
			}
			if((o.x*nx+o.y*ny+o.z*nz)<dist) {
				near=clipnodes[node].back;
				far=clipnodes[node].front;
			} else {
				near=clipnodes[node].front;
				far=clipnodes[node].back;
			}
		}
		if((t>=max)||(t<=0)||(Float.isNaN(t))) {
			if(near==-2) {
				return true;
			} else if(near==-1) {
				return false;
			} else {
				return intersect(o,p,near,min,max);
			}
		} else if(t<min) {
			if(far==-2) {
				return true;
			} else if(far==-1) {
				return false;
			} else {
				return intersect(o,p,far,min,max);
			}
		} else {
			boolean test;
			if(near==-2) {
				test=true;
			} else if(near==-1) {
				test=false;
			} else {
				test=intersect(o,p,near,min,t);
			}
			if(test) {
				return true;
			} else {
				if(far==-2) {
					return true;
				} else if(far==-1) {
					return false;
				} else {
					return intersect(o,p,far,t,max);
				}
			}
		}
	}

	public static void main(String args[]) {
		System.out.println();
		System.out.print("Running Java version "+System.getProperty("java.version"));
		System.out.println(" by "+System.getProperty("java.vendor"));
		System.out.print("System is "+System.getProperty("os.name"));
		System.out.print(" "+System.getProperty("os.version"));
		System.out.println(" for "+System.getProperty("os.arch"));
		System.out.println();
		if(args.length==1) {
			try {
				new BSPtoJBM(args[0],"-q");
			} catch(IOException e) {
				System.out.println("An IO exception occured: "+e);
				System.exit(1);
			}
		} else if(args.length==2) {
			try {
				new BSPtoJBM(args[0],args[1]);
			} catch(IOException e) {
				System.out.println("An IO exception occured: "+e);
				System.exit(1);
			}
		} else {
			System.out.println("Usage:");
			System.out.println("  java BSPFile <filename> [-q|-f]");
			System.exit(1);
		}
	}

	private int readIntBigEndian() throws IOException {
		int i;
		i=((int)infile.readUnsignedByte());
		i=i+((int)infile.readUnsignedByte())*256;
		i=i+((int)infile.readUnsignedByte())*65536;
		i=i+((int)infile.readByte())*16777216;
		return i;
	}

	private int readShortBigEndian() throws IOException {
		int i;
		i=((int)infile.readUnsignedByte());
		i=i+((int)infile.readByte())*256;
		return i;
	}

	private int readUnsignedShortBigEndian() throws IOException {
		int i;
		i=((int)infile.readUnsignedByte());
		i=i+((int)infile.readUnsignedByte())*256;
		return i;
	}

	private float readFloatBigEndian() throws IOException {
		int i;
		float f;
		i=((int)infile.readUnsignedByte());
		i=i+((int)infile.readUnsignedByte())*256;
		i=i+((int)infile.readUnsignedByte())*65536;
		i=i+((int)infile.readByte())*16777216;
		f=Float.intBitsToFloat(i);
		return f;
	}
}
