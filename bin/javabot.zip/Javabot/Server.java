import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.Date;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.Font;

class Server implements Runnable {

    // Class Variables

    Thread serverThread=null;
//    Thread proxyThread=null;
    DatagramSocket sock=null;
    String message;
    String version_string="0.69";
    PrintWriter log;
    FileOutputStream demofile;
//    Proxy proxy;
    long start_time;
    InetAddress remote_ip_address;
    InetAddress local_ip_address;
    InetAddress target_ip_address;
    int remote_port;
    int local_port;
    int target_port=26000;
    char hex[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
    boolean logging=false;
    boolean recording=true;

    // Network Variables

    boolean connected=false;
    boolean uptodate=false;
    boolean acknowledged=false;
    int signon=0;
    int reliable_send_order=0;
    int unreliable_send_order=0;
    int reliable_receive_order=0;
    int unreliable_receive_order=0;

    // Constants

    int IT_SHOTGUN =          0x00000001;
    int IT_SUPER_SHOTGUN =    0x00000002;
    int IT_NAILGUN =          0x00000004;
    int IT_SUPER_NAILGUN =    0x00000008;
    int IT_GRENADE_LAUNCHER = 0x00000010;
    int IT_ROCKET_LAUNCHER =  0x00000020;
    int IT_LIGHTNING =        0x00000040;
    int IT_EXTRA_WEAPON =     0x00000080;
    int IT_SHELLS =           0x00000100;
    int IT_NAILS =            0x00000200;
    int IT_ROCKETS =          0x00000400;
    int IT_CELLS =            0x00000800;
    int IT_AXE =              0x00001000;
    int IT_ARMOR1 =           0x00002000;
    int IT_ARMOR2 =           0x00004000;
    int IT_ARMOR3 =           0x00008000;
    int IT_SUPERHEALTH =      0x00010000;
    int IT_KEY1 =             0x00020000;
    int IT_KEY2 =             0x00040000;
    int IT_INVISIBILITY =     0x00080000;
    int IT_INVULNERABILITY =  0x00100000;
    int IT_SUIT =             0x00200000;
    int IT_QUAD =             0x00400000;
    int IT_UNKNOWN1 =         0x00800000;
    int IT_UNKNOWN2 =         0x01000000;
    int IT_UNKNOWN3 =         0x02000000;
    int IT_UNKNOWN4 =         0x04000000;
    int IT_UNKNOWN5 =         0x08000000;
    int IT_RUNE1 =            0x10000000;
    int IT_RUNE2 =            0x20000000;
    int IT_RUNE3 =            0x40000000;
    int IT_RUNE4 =            0x80000000;

    int TYPE_ITEM = 0x01;
    int TYPE_FEAR = 0x02;
    int TYPE_HATE = 0x04;
    int TYPE_ARMOR = 0x08;
    int TYPE_AMMO = 0x10;
    int TYPE_HEAL = 0x20;
    int TYPE_GUN = 0x40;
    int TYPE_COOL = 0x80;

    // Gamestate Variables

    int playerstate[]=new int[32];
    String playernames[]=new String[16];
    int playerfrags[]=new int[16];
    int playercolors[]=new int[16];
    StaticEntity static_entities[]=new StaticEntity[128];
    DynamicEntity entities[]=new DynamicEntity[450];
    int viewlist[]=new int[512];
    int viewlistlength=0;
    int spawnlist[]=new int[512];
    int spawnlistlength=0;
    int self_x,self_y,self_z;
    float time=0;
    int items=0x1001;
    int armorvalue=0;
    int weaponmodel=0;
    int health=100;
    int currentammo=0;
    int ammo_shells=0;
    int ammo_nails=0;
    int ammo_rockets=0;
    int ammo_cells=0;
    int weapon=0;
    int damage_x=0,damage_y=0,damage_z=0;
    int take=0,save=0;
    int StaticEntityCount=0;
    int viewpoint_entity=0;
    int killed_monsters=0;
    int found_secrets=0;
    boolean pause=false;
    int serverversion;
    int maxclients;
    int multi;
    byte mapname[]=new byte[64];
    PrecacheModel precache_models[]=new PrecacheModel[256];
    int nummodels;
    PrecacheSound precache_sounds[]=new PrecacheSound[256];
    int numsounds;

    // Lag-O-Meter

    int pingindex;
    long pingsenttime;
    long pingvalue;
    boolean waitingforping=false;

    // Demo Variables

    float myyaw,mypitch,myroll;
    String centerprintString="0";

    // Constructor

    public Server(String target_ip_address_string) {
        if(logging) {
            try {
                log=new PrintWriter(new FileOutputStream("Packet.log"));
            } catch(IOException e) {
                System.err.println("Can't open log file "+e);
                System.exit(1);
            } catch(SecurityException e) {
                System.err.println("Security problem with log file "+e);
                System.exit(1);
            }
        }
        if(recording) {
            try {
                demofile=new FileOutputStream("javabot.dem");
            } catch(IOException e) {
                System.err.println("Can't open demo file "+e);
                System.exit(1);
            } catch(SecurityException e) {
                System.err.println("Security problem with demo files "+e);
                System.exit(1);
            }
            try {
                byte b[]=new byte[3];
                b[0]=(byte)'-';
                b[1]=(byte)'1';
                b[2]=(byte)'\n';
                demofile.write(b);
            } catch(IOException e) {
                System.err.println("Problem starting demo file "+e);
                System.exit(1);
            }
        }
        try {
            local_ip_address=InetAddress.getLocalHost();
            target_ip_address=InetAddress.getByName(target_ip_address_string);
        } catch(UnknownHostException e) {
            System.err.println("Error getting IP address: "+e);
            return;
        }
        if(sock==null) {
            try {
                sock=new DatagramSocket();
            } catch(SocketException e) {
                System.err.println("Error: Couldn't create socket: "+e);
                return;
            }
            local_port=sock.getLocalPort();
        }
        for(int i=0;i<128;i++) {
            static_entities[i]=new StaticEntity();
        }
        for(int i=0;i<450;i++) {
            entities[i]=new DynamicEntity();
        }
        for(int i=0;i<256;i++) {
            precache_models[i]=new PrecacheModel();
            precache_sounds[i]=new PrecacheSound();
        }
        start_time=System.currentTimeMillis();
        if(logging) {
            message="SERVER SPAWN\n";
            message+=system_time()+"\n";
            message+=clock_time()+"\n";
            message+="-------------------------------------------------------------------\n";
            log.print(message);
        }
/*
        if(q.proxyEnabled) {
            proxy=new Proxy();
            proxyThread=new Thread(proxy);
            proxyThread.setPriority(7);
            proxyThread.start();
        }
*/
        start();
    }

    // Methods

    public synchronized void start() {
        if(serverThread==null) {
            serverThread=new Thread(this);
            serverThread.setPriority(8);
            serverThread.start();
        }
        if(logging) {
            message="SERVER STARTUP\n";
            message+=system_time()+"\n";
            message+=clock_time()+"\n";
            message+="Starting QuakeBot v"+version_string+"\n";
            message+="Local Host:  "+local_ip_address.toString()+"\n";
            message+="Target Host: "+target_ip_address.toString()+"\n";
            message+="-------------------------------------------------------------------\n";
            log.print(message);
        }
    }

    public synchronized void stop() {
        if(serverThread!=null) {
            serverThread.stop();
            serverThread=null;
        }
/*
        if(proxyThread!=null) {
            proxyThread.stop();
            proxyThread=null;
        }
*/
        if(recording) {
            try {
                demofile.close();
            } catch(IOException e) {
                System.err.println("Could not close demo file "+e);
            }
        }
        if(logging) {
            message="SERVER SHUTDOWN\n";
            message+=system_time()+"\n";
            message+=clock_time()+"\n";
            log.print(message);
        }
    }

    public void send(int type,byte m[],int len) {
        byte b[]=new byte[2048];
        int i=0,j=0;
        b[i++]=(byte)((type>>8)&0xff);
        b[i++]=(byte)(type&0xff);
        if(type==0x8000) {
            b[i++]=(byte)(((len+4)>>8)&0xff);
            b[i++]=(byte)((len+4)&0xff);
            System.out.println("Trying...");
        } else if(type==0x0001 || type==0x0009) {
            b[i++]=(byte)(((len+8)>>8)&0xff);
            b[i++]=(byte)((len+8)&0xff);
            b[i++]=(byte)((reliable_send_order>>24)&0xff);
            b[i++]=(byte)((reliable_send_order>>16)&0xff);
            b[i++]=(byte)((reliable_send_order>>8)&0xff);
            b[i++]=(byte)(reliable_send_order&0xff);
        } else if(type==0x0002) {
            b[i++]=(byte)0x00;
            b[i++]=(byte)0x08;
            b[i++]=(byte)((reliable_receive_order>>24)&0xff);
            b[i++]=(byte)((reliable_receive_order>>16)&0xff);
            b[i++]=(byte)((reliable_receive_order>>8)&0xff);
            b[i++]=(byte)(reliable_receive_order&0xff);
        } else if(type==0x0010) {
            b[i++]=(byte)(((len+8)>>8)&0xff);
            b[i++]=(byte)((len+8)&0xff);
            b[i++]=(byte)((unreliable_send_order>>24)&0xff);
            b[i++]=(byte)((unreliable_send_order>>16)&0xff);
            b[i++]=(byte)((unreliable_send_order>>8)&0xff);
            b[i++]=(byte)(unreliable_send_order&0xff);
            unreliable_send_order++;
        }
        while(j<len) {
            b[i++]=m[j++];
        }
        DatagramPacket pack=new DatagramPacket(b,i,target_ip_address,target_port);
        try {
            sock.send(pack);
        } catch(IOException e) {
            System.err.println("Error sending: "+e);
        }
        if(logging) {
            message="SENT\n";
            message+=system_time()+"\n";
            message+=clock_time()+"\n";
            message+="From: "+local_ip_address.toString()+":"+local_port+"\n";
            message+="  To: "+target_ip_address.toString()+":"+target_port+"\n";
            message+=hexdump(b,pack.getLength());
            message+="-------------------------------------------------------------------\n";
            log.print(message);
        }
    }

    public void ping() {
        if(!waitingforping) {
            byte b[]=new byte[1];
            b[0]=(byte)1;
            pingsenttime=System.currentTimeMillis();
            send(0x0009,b,1);
            pingindex=reliable_send_order++;
            waitingforping=true;
        }
    }

    public void run() {
        byte b[]=new byte[2048];
        byte m[]=new byte[8192];
        int s[]=new int[8192];
        int short_length=0;
        int message_length=0;
        int message_index=-1;
        int packet_type=0;
        int packet_length=0;
        while(true) {
            try {
                DatagramPacket pack=new DatagramPacket(b,2000);
                sock.receive(pack);
                remote_ip_address=pack.getAddress();
                remote_port=pack.getPort();
                packet_length=pack.getLength();
            } catch(IOException e) {
                System.err.println("Error receiving: "+e);
            }
            packet_type=b[1];
            while(packet_type<0) packet_type+=256;
            packet_type=packet_type+b[0]*256;
            while(packet_type<0) packet_type+=65536;
            if((packet_type&0x0001)==0x0001) {
                reliable_receive_order=b[7];
                while(reliable_receive_order<0) reliable_receive_order+=256;
                reliable_receive_order=reliable_receive_order+b[6]*256;
                while(reliable_receive_order<0) reliable_receive_order+=65536;
                reliable_receive_order=reliable_receive_order+b[5]*65536;
                while(reliable_receive_order<0) reliable_receive_order+=16777216;
                reliable_receive_order=reliable_receive_order+b[4]*16777216;
                send(0x0002,b,0);
            }
            if(((packet_type&0x00ff)==0x0002) && waitingforping) {
                int temp;
                temp=b[7];
                while(temp<0) temp+=256;
                temp=temp+b[6]*256;
                while(temp<0) temp+=65536;
                temp=temp+b[5]*65536;
                while(temp<0) temp+=16777216;
                temp=temp+b[4]*16777216;
                if(temp==pingindex) {
                    waitingforping=false;
                    pingvalue=(pingvalue*2+(System.currentTimeMillis()-pingsenttime))/3;
                }
            }

            if(logging) {
                if((packet_type&0x0001)==0x0001) {
                    if(reliable_receive_order==(message_index+1)) {
                        message="RECEIVED\n";
                        message+=system_time()+"\n";
                        message+=clock_time()+"\n";
                        message+="From: "+remote_ip_address.toString()+":"+remote_port+"\n";
                        message+="  To: "+local_ip_address.toString()+":"+local_port+"\n";
                        message+=hexdump(b,packet_length);
                        message+="-------------------------------------------------------------------\n";
                        log.print(message);
                    }
                } else {
                    message="RECEIVED\n";
                    message+=system_time()+"\n";
                    message+=clock_time()+"\n";
                    message+="From: "+remote_ip_address.toString()+":"+remote_port+"\n";
                    message+="  To: "+local_ip_address.toString()+":"+local_port+"\n";
                    message+=hexdump(b,packet_length);
                    message+="-------------------------------------------------------------------\n";
                    log.print(message);
                }
            }

            if((packet_type&0x8000)==0x8000) {
                int control_code;
                control_code=b[4];
                if((control_code&0xff)==0x81) {
                    target_port=b[5];
                    while(target_port<0) target_port+=256;
                    target_port=target_port+b[6]*256;
                    while(target_port<0) target_port+=65536;
                    connected=true;
                    System.out.println("Connect");
                } else if((control_code&0xff)==0x82) {
                    connected=false;
                    System.err.println("Connect failed: "+(new String(b,5,packet_length-5)));
                    System.exit(1);
                }
            } else if((packet_type&0x00ff)==0x0001) {
                if(reliable_receive_order==(message_index+1)) {
                    for(int i=8;i<packet_length;i++) {
                        m[message_length++]=b[i];
                    }
                    message_index=reliable_receive_order;
                }
            } else if((packet_type&0x00ff)==0x0009) {
                if(reliable_receive_order==(message_index+1)) {
                    for(int i=8;i<packet_length;i++) {
                        m[message_length++]=b[i];
                    }
                    for(int i=0;i<message_length;i++) {
                        s[i]=((int)m[i])&0xff;
                    }
                    if(recording) {
                        write_demo(m,0,message_length);
                    }
                    parse_message(s,message_length);
                    message_index=reliable_receive_order;
                    message_length=0;
                }
            } else if((packet_type&0x00ff)==0x0002) {
                acknowledged=true;
            } else if((packet_type&0x00ff)==0x0010) {
                for(int i=8;i<packet_length;i++) {
                    s[short_length++]=((int)b[i])&0xff;
                }
                if(recording) {
                    write_demo(b,8,short_length);
                }
                parse_message(s,short_length);
                short_length=0;
                self_x=entities[viewpoint_entity].x;
                self_y=entities[viewpoint_entity].y;
                self_z=entities[viewpoint_entity].z;
                uptodate=true;
//                System.out.print("Health: "+health);
//                System.out.print(" Ammo: "+currentammo);
//                System.out.print("\n");
            }
        }
    }

    private void write_demo(byte b[],int off,int len) {
        byte h[]=new byte[16];
        byte b2[]=new byte[2048];
        char c[];
        String s=new String(centerprintString);
        int b2_len,strlen;
        int my_yaw,my_pitch,my_roll;

        my_yaw=Float.floatToIntBits(myyaw);
        my_pitch=Float.floatToIntBits(mypitch);
        my_roll=Float.floatToIntBits(myroll);

        
        c=s.toCharArray();
        strlen=s.length();
        b2_len=0;
        if(s.compareTo("0")!=0) {
            b2[b2_len++]=(byte)0x1A;
            for(int i=0;i<strlen;i++) {
                b2[b2_len++]=(byte)c[i];
            }
            b2[b2_len++]=(byte)'\n';
            b2[b2_len++]=(byte)'\n';
            b2[b2_len++]=(byte)'\n';
            b2[b2_len++]=(byte)0x00;
        }

        len+=b2_len;

        h[0]=(byte)((len)&0xff);
        h[1]=(byte)((len>>8)&0xff);
        h[2]=(byte)((len>>16)&0xff);
        h[3]=(byte)((len>>24)&0xff);
        h[4]=(byte)((my_pitch)&0xff);
        h[5]=(byte)((my_pitch>>8)&0xff);
        h[6]=(byte)((my_pitch>>16)&0xff);
        h[7]=(byte)((my_pitch>>24)&0xff);
        h[8]=(byte)((my_yaw)&0xff);
        h[9]=(byte)((my_yaw>>8)&0xff);
        h[10]=(byte)((my_yaw>>16)&0xff);
        h[11]=(byte)((my_yaw>>24)&0xff);
        h[12]=(byte)((my_roll)&0xff);
        h[13]=(byte)((my_roll>>8)&0xff);
        h[14]=(byte)((my_roll>>16)&0xff);
        h[15]=(byte)((my_roll>>24)&0xff);
        try {
            demofile.write(h);
            demofile.write(b,off,len-b2_len);
            demofile.write(b2,0,b2_len);
        } catch(IOException e) {
            System.err.println("*** Error writing demo *** "+e);
            System.exit(1);
        }
    }

    private void parse_message(int b[],int len) {
        int i=0;
        viewlistlength=0;
        while(i!=len) {
            if(i>=len) {
                System.err.println("*** Packet Failure ***");
                System.err.println("Size: "+len+"   Pointer: "+i);
                return;
            }
            if(b[i]>=0x80) {
                int mask;
                int entity;
                int effects;
                int x,y,z;
                mask=b[i++]&0x7f;
                if((mask&0x0001)==0x0001) {
                    mask |= (b[i++]<<8);
                }
                entity = ((mask&0x4000)==0x4000) ? b[i++]+b[i++]*256 : b[i++];
                entities[entity].modelindex = ((mask&0x0400)==0x0400) ? b[i++] : entities[entity].default_modelindex;
                entities[entity].frame = ((mask&0x0040)==0x0040) ? b[i++] : entities[entity].default_frame;
                entities[entity].colormap = ((mask&0x0800)==0x0800) ? b[i++] : entities[entity].default_colormap;
                entities[entity].skin = ((mask&0x1000)==0x1000) ? b[i++] : entities[entity].default_skin;
                effects = ((mask&0x2000)==0x2000) ? b[i++] : 0;
                x = ((mask&0x0002)==0x0002) ? b[i++]+b[i++]*256 : entities[entity].x;
                if((mask&0x0100)==0x0100) entities[entity].xa=b[i++];
                y = ((mask&0x0004)==0x0004) ? b[i++]+b[i++]*256 : entities[entity].y;
                if((mask&0x0010)==0x0010) entities[entity].ya=b[i++];
                z = ((mask&0x0008)==0x0008) ? b[i++]+b[i++]*256 : entities[entity].z;
                if((mask&0x0200)==0x0200) entities[entity].za=b[i++];
                entities[entity].newlocation(x,y,z,time);
                viewlist[viewlistlength++]=entity;
                if(viewlistlength>449) viewlistlength=449;
//                System.out.print("Entity #"+entity);
//                System.out.print(" "+entities[entity].modelindex);
//                System.out.println(entity+" "+precache_models[entities[entity].modelindex].name);
            } else if(b[i]==0x00) {
                System.err.println("*** Received BAD Packet ***");
                return;
            } else if(b[i]==0x01) {
                i++;
            } else if(b[i]==0x02) {
                System.out.println("*** Disconnect order received ***");
                System.exit(0);
            } else if(b[i]==0x03) {
                int index;
                int value;
                i++;
                index=b[i++];
                if(index>0x1f) {
                    System.err.println("*** svc_updatestat is invalid ***");
                    return;
                }
                value=b[i++]+b[i++]*256+b[i++]*65536+b[i++]*16777216;
                playerstate[index]=value;
//                System.out.println("Update Stat");
            } else if(b[i]==0x04) {
                int serverprotocol;
                i++;
                serverprotocol=b[i++]+b[i++]*256+b[i++]*65536+b[i++]*16777216;
                if(serverprotocol!=0x0f) {
                    System.err.println("*** server protocol is wrong ***");
                    System.exit(1);
                }
            } else if(b[i]==0x05) {
                i++;
                viewpoint_entity=b[i++]+b[i++]*256;
            } else if(b[i]==0x06) {
                int mask;
                int vol;
                int attenuation;
                int channel;
                int entity;
                int soundnum;
                int x,y,z;
                i++;
                mask=b[i++];
                vol = ((mask&0x01)==0x01) ? b[i++] : 256;
                attenuation = ((mask&0x02)==0x02) ? b[i++] : 64;
                entity=((b[i++]+b[i++]*256)>>3)&0x1fff;
                soundnum=b[i++];
                x=b[i++]+b[i++]*256;
                y=b[i++]+b[i++]*256;
                z=b[i++]+b[i++]*256;
//                System.out.println("TemporarySound");
            } else if(b[i]==0x07) {
                int temp;
                i++;
                temp=b[i++]+b[i++]*256+b[i++]*65536+b[i++]*16777216;
                time=Float.intBitsToFloat(temp);
//                System.out.println("Time: "+time);
            } else if(b[i]==0x08) {
                byte s[]=new byte[2048];
                int j=0;
                i++;
                while(b[i]!=0 && j<2048) {
                    if(b[i]>2) {
                        s[j++]=(byte)(b[i++]&0x7f);
                    } else {
                        i++;
                    }
                }
                i++;
//                System.out.print("Print: "+(new String(s,0,j)));
            } else if(b[i]==0x09) {
                byte s[]=new byte[2048];
                int j=0;
                i++;
                while(b[i]!=0 && j<2048) {
                    if(b[i]>2) {
                        s[j++]=(byte)(b[i++]&0x7f);
                    } else {
                        i++;
                    }
                }
                i++;
            } else if(b[i]==0x0a) {
                int x,y,z;
                i++;
                x=b[i++];
                y=b[i++];
                z=b[i++];
//                System.out.println("SetAngle");
            } else if(b[i]==0x0b) {
                byte s[]=new byte[2048];
                int j=0;
                i++;
                serverversion=b[i++]+b[i++]*256+b[i++]*65536+b[i++]*16777216;
                if(serverversion!=0x0f) {
                        System.err.println("*** server version is wrong ***");
                }
                maxclients=b[i++];
                multi=b[i++];
                while(b[i]!=0 && j<64) {
                    mapname[j++]=(byte)(b[i++]&0x7f);
                }
                i++;
                nummodels=0;
                do {
                    if(++nummodels>255) {
                        System.err.println("*** too many precache models ***");
                        return;
                    }
                    j=0;
                    s[0]=0;
                    while(b[i]!=0 && j<64) {
                        s[j++]=(byte)b[i++];
                    }
                    i++;
                    if(s[0]!=0 && s[0]!=(byte)'*') {
                        precache_models[nummodels].name=new String(s,0,j);
                        String modelname=precache_models[nummodels].name;
                        precache_models[nummodels].type=0;
                        precache_models[nummodels].death_start=0;
                        precache_models[nummodels].death_end=0;
                        precache_models[nummodels].pain_start=0;
                        precache_models[nummodels].pain_end=0;
                        precache_models[nummodels].mask=0;
                        precache_models[nummodels].max_health=255;
                        precache_models[nummodels].max_shells=100;
                        precache_models[nummodels].max_nails=200;
                        precache_models[nummodels].max_rockets=100;
                        precache_models[nummodels].max_cells=200;
                        precache_models[nummodels].respawn_time=60;
                        if(modelname.compareTo("progs/backpack.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_COOL;
                            precache_models[nummodels].value=1000;
                        } else if(modelname.compareTo("progs/end1.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM;
                            precache_models[nummodels].mask=IT_RUNE1|IT_RUNE2|IT_RUNE3|IT_RUNE4;
                            precache_models[nummodels].value=0;
                        } else if(modelname.compareTo("progs/end2.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM;
                            precache_models[nummodels].mask=IT_RUNE1|IT_RUNE2|IT_RUNE3|IT_RUNE4;
                            precache_models[nummodels].value=0;
                        } else if(modelname.compareTo("progs/end3.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM;
                            precache_models[nummodels].mask=IT_RUNE1|IT_RUNE2|IT_RUNE3|IT_RUNE4;
                            precache_models[nummodels].value=0;
                        } else if(modelname.compareTo("progs/end4.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM;
                            precache_models[nummodels].mask=IT_RUNE1|IT_RUNE2|IT_RUNE3|IT_RUNE4;
                            precache_models[nummodels].value=0;
                        } else if(modelname.compareTo("progs/invisibl.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_COOL;
                            precache_models[nummodels].value=1000;
                        } else if(modelname.compareTo("progs/invulner.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_COOL;
                            precache_models[nummodels].value=1000;
                        } else if(modelname.compareTo("progs/quaddama.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_COOL;
                            precache_models[nummodels].value=1000;
                        } else if(modelname.compareTo("progs/suit.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_COOL;
                            precache_models[nummodels].value=1000;
                        } else if(modelname.compareTo("maps/b_bh100.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_HEAL;
                            precache_models[nummodels].value=100;
                        } else if(modelname.compareTo("progs/armor.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_ARMOR;
                            precache_models[nummodels].value=0;
                            precache_models[nummodels].respawn_time=20;
                        } else if(modelname.compareTo("progs/g_light")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_GUN;
                            precache_models[nummodels].mask=IT_LIGHTNING;
                            precache_models[nummodels].max_cells=200;
                            precache_models[nummodels].value=245;
                        } else if(modelname.compareTo("maps/b_batt0.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_AMMO;
                            precache_models[nummodels].mask=IT_LIGHTNING;
                            precache_models[nummodels].max_cells=200;
                            precache_models[nummodels].value=6;
                        } else if(modelname.compareTo("maps/b_batt1.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_AMMO;
                            precache_models[nummodels].mask=IT_LIGHTNING;
                            precache_models[nummodels].max_cells=200;
                            precache_models[nummodels].value=12;
                        } else if(modelname.compareTo("progs/g_nail.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_GUN;
                            precache_models[nummodels].mask=IT_NAILGUN;
                            precache_models[nummodels].max_nails=200;
                            precache_models[nummodels].value=105;
                        } else if(modelname.compareTo("progs/g_nail2.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_GUN;
                            precache_models[nummodels].mask=IT_SUPER_NAILGUN;
                            precache_models[nummodels].max_nails=200;
                            precache_models[nummodels].value=175;
                        } else if(modelname.compareTo("maps/b_nail0.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_AMMO;
                            precache_models[nummodels].mask=IT_NAILGUN|IT_SUPER_NAILGUN;
                            precache_models[nummodels].max_nails=200;
                            precache_models[nummodels].value=25;
                        } else if(modelname.compareTo("maps/b_nail1.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_AMMO;
                            precache_models[nummodels].mask=IT_NAILGUN|IT_SUPER_NAILGUN;
                            precache_models[nummodels].max_nails=200;
                            precache_models[nummodels].value=50;
                        } else if(modelname.compareTo("progs/g_rock.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_GUN;
                            precache_models[nummodels].mask=IT_GRENADE_LAUNCHER;
                            precache_models[nummodels].max_rockets=100;
                            precache_models[nummodels].value=140;
                        } else if(modelname.compareTo("progs/g_rock2.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_GUN;
                            precache_models[nummodels].mask=IT_ROCKET_LAUNCHER;
                            precache_models[nummodels].max_rockets=100;
                            precache_models[nummodels].value=210;
                        } else if(modelname.compareTo("maps/b_rock0.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_AMMO;
                            precache_models[nummodels].mask=IT_GRENADE_LAUNCHER|IT_ROCKET_LAUNCHER;
                            precache_models[nummodels].max_rockets=100;
                            precache_models[nummodels].value=5;
                        } else if(modelname.compareTo("maps/b_rock1.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_AMMO;
                            precache_models[nummodels].mask=IT_GRENADE_LAUNCHER|IT_ROCKET_LAUNCHER;
                            precache_models[nummodels].max_rockets=100;
                            precache_models[nummodels].value=10;
                        } else if(modelname.compareTo("progs/g_shot.mdl")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_GUN;
                            precache_models[nummodels].mask=IT_SUPER_SHOTGUN;
                            precache_models[nummodels].max_shells=100;
                            precache_models[nummodels].value=35;
                        } else if(modelname.compareTo("maps/b_shell0.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_AMMO;
                            precache_models[nummodels].mask=IT_SUPER_SHOTGUN|IT_SHOTGUN;
                            precache_models[nummodels].max_shells=100;
                            precache_models[nummodels].value=20;
                        } else if(modelname.compareTo("maps/b_shell1.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_AMMO;
                            precache_models[nummodels].mask=IT_SUPER_SHOTGUN|IT_SHOTGUN;
                            precache_models[nummodels].max_shells=100;
                            precache_models[nummodels].value=40;
                        } else if(modelname.compareTo("maps/b_bh10.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_HEAL;
                            precache_models[nummodels].max_health=100;
                            precache_models[nummodels].value=15;
                        } else if(modelname.compareTo("maps/b_bh25.bsp")==0) {
                            precache_models[nummodels].type=TYPE_ITEM|TYPE_HEAL;
                            precache_models[nummodels].max_health=100;
                            precache_models[nummodels].value=25;
                        } else if(modelname.compareTo("progs/bolt.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=500;
                        } else if(modelname.compareTo("progs/bolt2.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=500;
                        } else if(modelname.compareTo("progs/bolt3.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=500;
                        } else if(modelname.compareTo("progs/boss.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=0;
                        } else if(modelname.compareTo("progs/grenade.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=400;
                        } else if(modelname.compareTo("progs/k_spike.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/laser.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=200;
                        } else if(modelname.compareTo("progs/lavaball.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/missile.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=800;
                        } else if(modelname.compareTo("progs/spike.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=300;
                        } else if(modelname.compareTo("progs/s_explod.spr")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/s_light.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/s_spike.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/v_spike.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/w_spike.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/zom_gib.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("maps/b_exbox2.bsp")==0) {
                            precache_models[nummodels].type=TYPE_HATE;
                        } else if(modelname.compareTo("maps/b_explob.bsp")==0) {
                            precache_models[nummodels].type=TYPE_HATE;
                        } else if(modelname.compareTo("progs/dog.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].death_start=9;
                            precache_models[nummodels].death_end=26;
                            precache_models[nummodels].pain_start=27;
                            precache_models[nummodels].pain_end=48;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/demon.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/eyes.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/knight.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/ogre.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/player.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].death_start=42;
                            precache_models[nummodels].death_end=103;
                            precache_models[nummodels].pain_start=30;
                            precache_models[nummodels].pain_end=41;
                            precache_models[nummodels].fearvalue=200;
                        } else if(modelname.compareTo("progs/shambler.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/soldier.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].death_start=9;
                            precache_models[nummodels].death_end=29;
                            precache_models[nummodels].pain_start=41;
                            precache_models[nummodels].pain_end=73;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/wizard.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].fearvalue=100;
                        } else if(modelname.compareTo("progs/zombie.mdl")==0) {
                            precache_models[nummodels].type=TYPE_FEAR|TYPE_HATE;
                            precache_models[nummodels].fearvalue=100;
                        }
                    } else {
                        precache_models[nummodels].type=0;
                    }
                } while(s[0]!=0);
                numsounds=0;
                do {
                    if(++numsounds>255) {
                        System.err.println("*** too many precache sounds ***");
                        return;
                    }
                    j=0;
                    s[0]=0;
                    while(b[i]!=0 && j<64) {
                        s[j++]=(byte)b[i++];
                    }
                    i++;
                    if(s[0]!=0) {
                        precache_sounds[numsounds].name=new String(s,0,j);
                    }
                } while(s[0]!=0);
            } else if(b[i]==0x0c) {
                int style;
                byte s[]=new byte[2048];
                int j=0;
                i++;
                style=b[i++];
                while(b[i]!=0 && j<2048) {
                    s[j++]=(byte)b[i++];
                }
                i++;
//                System.out.println("LightStyle");
            } else if(b[i]==0x0d) {
                int player;
                byte s[]=new byte[2048];
                int j=0;
                i++;
                player=b[i++];
                while(b[i]!=0 && j<2048) {
                    s[j++]=(byte)b[i++];
                }
                i++;
                playernames[player]=new String(s,0,j);
//                System.out.println("Name #"+player+" "+playernames[player]);
            } else if(b[i]==0x0e) {
                int player;
                int frags;
                i++;
                player=b[i++];
                frags=b[i++]+b[i++]*256;
                if(frags>32767) {
                    frags-=65536;
                }
                playerfrags[player]=frags;
//                System.out.println("Frags #"+player+" "+playerfrags[player]);
            } else if(b[i]==0x0f) {
                int mask;
                int view_ofs_z;
                int punchangle_x;
                int xa,ya,za;
                int xv,yv,zv;
                int weaponframe;
                i++;
                mask=b[i++]+b[i++]*256;
                view_ofs_z = ((mask&0x0001)==0x0001) ? b[i++] : 22;
                punchangle_x = ((mask&0x0002)==0x0002) ? b[i++] : 0;
                xa = ((mask&0x0004)==0x0004) ? b[i++] : 0;
                xv = ((mask&0x0020)==0x0020) ? b[i++] : 0;
                ya = ((mask&0x0008)==0x0008) ? b[i++] : 0;
                yv = ((mask&0x0040)==0x0040) ? b[i++] : 0;
                za = ((mask&0x0010)==0x0010) ? b[i++] : 0;
                zv = ((mask&0x0080)==0x0080) ? b[i++] : 0;
                items = ((mask&0x0200)==0x0200) ? b[i++]+b[i++]*256+b[i++]*65536+b[i++]*16777216 : 0x1001;
                weaponframe = ((mask&0x1000)==0x1000) ? b[i++] : 0;
                armorvalue = ((mask&0x2000)==0x2000) ? b[i++] : 0;
                weaponmodel = ((mask&0x4000)==0x4000) ? b[i++] : 0;
                health=b[i++]+b[i++]*256;
                if(health>=32768) health-=65536;
                currentammo=b[i++];
                ammo_shells=b[i++];
                ammo_nails=b[i++];
                ammo_rockets=b[i++];
                ammo_cells=b[i++];
                weapon=b[i++];
//                System.out.println("ClientData");
            } else if(b[i]==0x10) {
                int sound;
                i++;
                sound=b[i++]+b[i++]*256;
//                System.out.println("StopSound");
            } else if(b[i]==0x11) {
                int player;
                i++;
                player=b[i++];
                playercolors[player]=b[i++];
//                System.out.println("Color #"+player+" "+playercolors[player]);
            } else if(b[i]==0x12) {
                int x,y,z;
                int xv,yv,zv;
                int color;
                int count;
                i++;
                x=b[i++]+b[i++]*256;
                y=b[i++]+b[i++]*256;
                z=b[i++]+b[i++]*256;
                xv=b[i++]/16;
                yv=b[i++]/16;
                zv=b[i++]/16;
                color=b[i++];
                count=b[i++];
//                System.out.println("Particles");
            } else if(b[i]==0x13) {
                i++;
                save=b[i++];
                take=b[i++];
                damage_x=b[i++]+b[i++]*256;
                damage_y=b[i++]+b[i++]*256;
                damage_z=b[i++]+b[i++]*256;
            } else if(b[i]==0x14) {
                i++;
                if(StaticEntityCount>127) {
                    System.err.println("*** too many static entities ***");
                    return;
                }
                StaticEntityCount++;
                static_entities[StaticEntityCount].default_modelindex=b[i++];
                static_entities[StaticEntityCount].default_frame=b[i++];
                static_entities[StaticEntityCount].default_colormap=b[i++];
                static_entities[StaticEntityCount].default_skin=b[i++];
                static_entities[StaticEntityCount].x=b[i++]+b[i++]*256;
                static_entities[StaticEntityCount].xa=b[i++];
                static_entities[StaticEntityCount].y=b[i++]+b[i++]*256;
                static_entities[StaticEntityCount].ya=b[i++];
                static_entities[StaticEntityCount].z=b[i++]+b[i++]*256;
                static_entities[StaticEntityCount].za=b[i++];
//                System.out.println("SpawnStatic: "+precache_models[static_entities[StaticEntityCount].default_modelindex].name);
            } else if(b[i]==0x15) {
                i++;
                System.err.println("*** illegible server message ***");
                return;
            } else if(b[i]==0x16) {
                int entity;
                int coord;
                i++;
                entity=b[i++]+b[i++]*256;
                if(entity>449) {
                    System.err.println("*** invalid entity number ***");
                    return;
                }
                entities[entity].default_modelindex=b[i++];
                entities[entity].modelindex=entities[entity].default_modelindex;
                entities[entity].default_frame=b[i++];
                entities[entity].frame=entities[entity].default_frame;
                entities[entity].default_colormap=b[i++];
                entities[entity].colormap=entities[entity].default_colormap;
                entities[entity].default_skin=b[i++];
                entities[entity].skin=entities[entity].default_skin;
                coord=b[i++]+b[i++]*256;
                if(coord>32767) {
                    coord-=65536;
                }
                entities[entity].x=coord;
                entities[entity].xa=b[i++];
                coord=b[i++]+b[i++]*256;
                if(coord>32767) {
                    coord-=65536;
                }
                entities[entity].y=coord;
                entities[entity].ya=b[i++];
                coord=b[i++]+b[i++]*256;
                if(coord>32767) {
                    coord-=65536;
                }
                entities[entity].z=coord;
                entities[entity].za=b[i++];
                entities[entity].respawn_time=0;
                spawnlist[spawnlistlength++]=entity;
                if(spawnlistlength>449) spawnlistlength=449;
                System.out.println("SpawnBaseLine: "+entity+" "+precache_models[entities[entity].default_modelindex].name+" ("+entities[entity].x+","+entities[entity].y+","+entities[entity].z+")");
            } else if(b[i]==0x17) {
                TemporaryEntity temp=new TemporaryEntity();
                int entitytype;
                i++;
                entitytype=b[i++];
                temp.entitytype=entitytype;
                if(entitytype>11) {
                    System.err.println("*** bad temp_entity type ***");
                }
                if(entitytype==5 || entitytype==6 || entitytype==9) {
                    temp.creator=b[i++]+b[i++]*256;
                }
                temp.x=b[i++]+b[i++]*256;
                temp.y=b[i++]+b[i++]*256;
                temp.z=b[i++]+b[i++]*256;
                if(entitytype==5 || entitytype==6 || entitytype==9) {
                    temp.xe=b[i++]+b[i++]*256;
                    temp.ye=b[i++]+b[i++]*256;
                    temp.ze=b[i++]+b[i++]*256;
                }
//                System.out.println("SpawnTemp");
            } else if(b[i]==0x18) {
                i++;
                if(b[i++]==1) {
                    pause=true;
//                    System.out.println("Paused");
                } else {
                    pause=false;
//                    System.out.println("Unpaused");
                }
            } else if(b[i]==0x19) {
                i++;
                signon=b[i++];
//                System.out.println("Signon State: "+signon);
            } else if(b[i]==0x1a) {
                byte s[]=new byte[2048];
                int j=0;
                i++;
                while(b[i]!=0 && j<2048) {
                    s[j++]=(byte)b[i++];
                }
                i++;
//                System.out.println("Centerprint: "+(new String(s,0,j)));
            } else if(b[i]==0x1b) {
                i++;
                killed_monsters++;
            } else if(b[i]==0x1c) {
                i++;
                found_secrets++;
            } else if(b[i]==0x1d) {
                int x,y,z;
                int soundnum;
                int vol;
                int attenuation;
                i++;
                x=b[i++]+b[i++]*256;
                y=b[i++]+b[i++]*256;
                z=b[i++]+b[i++]*256;
                soundnum=b[i++];
                vol=b[i++];
                attenuation=b[i++];
//                System.out.println("StaticSound");
            } else if(b[i]==0x1e) {
                i++;
                System.out.println("*** Intermission ***");
                connected=false;
            } else if(b[i]==0x1f) {
                byte s[]=new byte[2048];
                int j=0;
                i++;
                while(b[i]!=0 && j<2048) {
                    s[j++]=(byte)b[i++];
                }
                i++;
                System.out.println("Episode End: "+(new String(s,0,j)));
                connected=false;
            } else if(b[i]==0x20) {
                int fromtrack;
                int totrack;
                i++;
                fromtrack=(byte)b[i++];
                totrack=b[i++];
//                System.out.println("CD track: "+fromtrack+"-"+totrack);
            } else if(b[i]==0x21) {
                i++;
//                System.out.println("Help/Sell Screen");
            }
        }
    }

    public JBMFile open_map() {
        try {
            return (new JBMFile(precache_models[1].name));
        } catch(IOException e) {
            System.out.println("Error: Could not load map");
            System.exit(1);
        }
        return null;
    }

    private String binString(int n) {
        char bits[]=new char[32];
        for(int i=0;i<32;i++) {
            if((n&(1<<i))>0) {
                bits[i]='1';
            } else {
                bits[i]='0';
            }
        }
        return new String(bits);
    }

    private String system_time() {
        Date today=new Date();
        return today.toString();
    }

    private String clock_time() {
        long l=System.currentTimeMillis()-start_time;
        if((l%1000)>=100) {
            return "Time Running: "+(l/1000)+"."+(l%1000)+"s";
        } else {
            return "Time Running: "+(l/1000)+".0"+(l%1000)+"s";
        }
    }

    private String hexdump(byte b[],int len) {
        String s=new String();
        int i;
        s="\n";
        for(i=0;i<len;i++) {
            s+=" "+hex[(b[i]&0xf0)>>4]+hex[(b[i]&0x0f)];
            if((i&0x07)==0x07) s+=" ";
            if((i&0x0f)==0x0f) {
                s+=" ";
                for(int j=i-15;j<=i;j++) {
                    if(b[j]>=0x20 && b[j]<0x80) {
                        s+=(char)b[j];
                    } else {
                        s+=".";
                    }
                }
                s+="\n";
            }
        }
        i--;
        if((len&0x0f)!=0) {
            if((len&0x0f)<0x07) {
                s+="   ";
            } else {
                s+="  ";
            }
            for(int j=i;j<(i|0x000f);j++) {
                s+="   ";
            }
            for(int j=i&0xfff0;j<=i;j++) {
                if(b[j]>=0x20 && b[j]<0x80) {
                    s+=(char)b[j];
                } else {
                    s+=".";
                }
            }
            s+="\n";
        }
        s+="\n";
        return s;
    }
}