class PrecacheModel {
    String name;
    int type;
    int death_start;
    int death_end;
    int pain_start;
    int pain_end;
    int mask;
    int max_health;
    int max_shells;
    int max_nails;
    int max_rockets;
    int max_cells;
    int value;
    int fearvalue;
    int respawn_time;
}