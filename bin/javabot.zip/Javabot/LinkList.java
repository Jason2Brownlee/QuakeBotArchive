class LinkList {
    int num;
    int faces[]=new int[100];
}