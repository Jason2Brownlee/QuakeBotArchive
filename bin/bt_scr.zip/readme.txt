----------------
BOTARENA 1.2
by Vegetous
----------------

Title        : BOTARENA
Filename     : botarena.zip (compiled) and ba_scr.zip (source)
Version      : 1.2
Date         : 16/04/2003 (dd/mm/aaaa)
Author       : vegetous
Web Page     : www.vegetous.cjb.net
Email        : vegetous@brfree.com.br
Thank You's! : iD Software(www.idsoftware.com), Rocket Arena(http://www.planetquake.com/servers/arena), 
               FrikBot(http://www.botepidemic.com/frikbot/) and Spinal(http://www.virtualand.com.br/quakec/)

Type of Mod

Quake C  : yes!
Sound    : yes!
maps     : yes!
MDL      : no!

*Description of the Modification*
This is simple compilation of Rocket Arena and Frikbot for offline games. 


*How to use Modification*
If you know how to play RA, then you already know enough.


*How to Install the Modification*
Unzip patch in "C:\quake\botarena", then run your favourite qw server with the parameter "+gamedir botarena"


*How to Add a Bot* (from frikbot manual)
To add a bot, bring down the console (again with the ~ key) and type "impulse 100" (without the quotes)
and press enter. A new bot combatant will enter the game. The bot you have added will probably be a skill 1 
(Normal skill) bot. If the bot is too difficult for you, type "impulse 102" in the console and press enter.
This will disconnect the bot from the game. Then type "skill 0" to set the game on Easy skill in the console,
then "impulse 100" to add an easy level bot. When you're ready for a greater challenge try skill 2 (Hard) and
skill 3 (Nightmare) bots. 


*The Maps*
There is only one map included in this pak (arenax.bsp)! If you want all Final Arena maps, go to 
http://www.planetquake.com/servers/arena download and put then into ..quake\ID1\maps. So, all your quake modifications
will be able to access them.


*Impulse Quick Reference* (from Final Arena manual)

IMPULSE 68 - shows simple statistics for the current level. Skill = wins / (wins + loses) * 100
IMPULSE 69 - shows your "position" in line
IMPULSE 70 - step out of line for up to 5 minutes
IMPULSE 71 - set status bar text for 320x200
IMPULSE 72 - set status bar text for 320x240 or higher


*Bugs*
1�. The spectator function is not working properly but I don't see how fun could be watching a bot's game.
2� When you remove a bot from game, it's model still's in the map.

If it's annoy you so much, you can download the source and fix it by your self (just keep the credits).

PS.: I'm not a qc fan, so don't wait for new versions because they will probaly not exist!

DISCLAIMER: (READIT !!!)
I made this modification for myself and it shouldn't do anything wrong, but if it cause any (and I realy mean any)
damage to your computer (hardware and software), it's your responsibility, not mine! So, 
if you don't agree with this terms, don't use it !!!


-----------------------------
Compiled wiht frikdos.exe !!!
-----------------------------


PS.: I love Quake :)







//EOF - Brasil 16/04/2003