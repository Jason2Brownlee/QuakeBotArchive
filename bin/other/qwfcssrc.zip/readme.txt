CLIENT EMULATION SERVER SOURCE CODE DISTRIBUTION
------------------------------------------------
AUTHOR:            Rich Whitehouse
CONTACT:           thefatal@telefragged.com
HOMEPAGE:          http://www.telefragged.com/thefatal/
RELEASE NUMBER:    1

This archive comes complete with the server source code and
source code for the example qwprogs.dat bot.

With this, you can easilly create your own full client bot
from QuakeC code within a matter of seconds. To use it, you
don't even need the source for the server and can just use
the server binary (available at my homepage) instead. But,
I'm releasing the source to the server anyway since I must
under the terms of the GPL and because you might want to
change some things or add in features/functions.

Now, onto what you need to compile this mess. First you need
the Quake source code in its entirety (go find it on an FTP
somewhere, it's pretty hard to miss). After that, put all of
the files in the \source folder from this archive into your
QW\Server folder under your Quake source code directory.

After that, you should be able to compile as normal pretty
much, I think. You may have to adjust a few things first, but
I'm not absolutely sure. I've only tried compiling this in
Microsoft Visual C++ 5.0.

To compile the qwprogs.dat code, just copy the files in with
the standard qwprogs.dat code and overwrite anything that
needs to be overwritten, then add bot.qc to the progs.src
file. Compile with any standard QuakeC compiler and you'll
be all set. See the comments at the head of bot.qc for info
on how to pick out what you need from the non-bot.qc files
if you want to port it into a different code base or
something like that.

When/if you distribute your modified source code, note that
it must be distributed under the terms of the GPL as well.
Again, make sure you read gnu.txt for all the information
you need on that. Note that this does NOT include the QuakeC
qwprogs code, as it is not under the terms of the GPL.

-Rich
