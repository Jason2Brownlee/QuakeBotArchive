FULL CLIENT EMULATION SERVER
----------------------------
AUTHOR:            Rich Whitehouse
CONTACT:           thefatal@telefragged.com
HOMEPAGE:          http://www.telefragged.com/thefatal/
RELEASE NUMBER:    1

The source code for this binary distribution is available
from my homepage.

This is a shows what can be done with the client emulation
QW server. It allows you to create a bot using the QuakeC
interface with just a few lines of code. You don't need to
do anything extra, as the bot is already animated and runs
through all the standard player calls. There's also a
physics function call to allow you to set the movement and
button values, so you can have a fully working bot in just
a few lines of code.

The bot included does nothing but run at you and fire, as
it is only an example. The source for the example bot and
the server itself are available on my homepage.

-Rich