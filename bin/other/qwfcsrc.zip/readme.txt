FAKE CLIENT SERVER SOURCE CODE DISTRIBUTION
-------------------------------------------
AUTHOR:            Rich Whitehouse
CONTACT:           thefatal@telefragged.com
HOMEPAGE:          http://www.telefragged.com/thefatal/
RELEASE NUMBER:    1

This source code is distributed under the terms of the
GPL (see gnu.txt for details).

When/if you distribute your modified source code, note that
it must be distributed under the terms of the GPL as well.
Again, make sure you read gnu.txt for all the information
you need on that.

This source code allows you to create an interface between
the progs.dat and server which allows the progs.dat to make
calls to a fakeclient function to create fake clients which
can be manipulated freely in the QuakeC code. The steps to
doing this are relatively simple:

1. Define the function in your defs.qc file, it should be
something like this:
entity() fakeclient = #83;
2. Go into your bot spawning code. Instead of initializing
your bot entity with "spawn", use fakeclient. Example:
bot = fakeclient();

Now you can move it around using velocity just like a real
player. If you wish, you can edit the fake client server
code as well and disable the standard entity physics calls
for bot clients and enable the player physics. You will
probably want to make a way to set the usercmd structure
values from within the progs.dat code as well, which won't
be hard. The reason it isn't like that already is because
I used the Frogbot to build and test this base, and the
Frogbot uses full velocity movement already (I didn't want
to have to rewrite any of the bot itself).

Now, onto what you need to compile this mess. First you need
the Quake source code in its entirety (go find it on an FTP
somewhere, it's pretty hard to miss). After that, put all of
the files in the \source folder from this archive into your
QW\Server folder under your Quake source code directory.

After that, you should be able to compile as normal pretty
much, I think. You may have to adjust a few things first, but
I'm not absolutely sure. I've only tried compiling this in
Microsoft Visual C++ 5.0.

I suppose that's about it. This is based off of the Genebot
code, mainly, so you can refer to it if you want more info.

-Rich