Please read the file ctfbot13.txt for complete documentation.
Do NOT email me for help unless you have read ctfbot13.txt.
