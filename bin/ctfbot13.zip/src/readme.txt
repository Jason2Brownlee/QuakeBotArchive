Please read the readme file (ctfbot13.txt) for important 
information on recompiling the source code!  Do NOT email me 
for help before reading that file!

You *WILL NOT* be able to compile unless you read ctfbot13.txt!

You *WILL* get errors unless you read ctfbot13.txt!

Do *NOT* email me before reading ctfbot13.txt!

