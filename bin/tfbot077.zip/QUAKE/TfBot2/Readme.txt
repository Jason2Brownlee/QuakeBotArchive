          =------------------------------------------------------=
                     TFBOTS v0.76 for TeamFortress v2.5
          =------------------------------------------------------=
Please read README.1ST first!

Expect a new verison of the docs on:
www.lockandload.com/tfbot very soon!
    
                            Installation
                            ------------

---------------------------- Normal Quake ----------------------------

Quake Server or Single Player:

1)  Make sure you have TF v2.5 in your fortress directory.
2)  Make a back-up of your current progs.dat (copy progs.dat progs.bak)
2)  Copy the zip file for the bots into the fortress directory.
3)  Unzip using winzip or pkunzip -d.  Remember to do it with directories.
4)  Run quake using the following line:
    quake -listen 16 +exec bot.cfg -game fortress +map 2fort4
or if you're running a dedicated server:
    quake -dedicated 16 +exec bot.cfg -game fortress +map 2fort4

Please note the -listen/-dedicated parameter has to go first(no idea why!)

Quake client:

1)  Make sure you have TF v2.5 on your hard drive.

---------------------------- Quake World -----------------------------

Please not, I have no idea wether or not this works.  Any feedback
would be appriciated!  

QuakeWorld Server:

1)  Make sure you have TF v2.5 on your hard-drive.
2)  Make a back-up of your current qwprogs.dat (copy qwprogs.dat qwprogs.bak)
2)  Copy the zip file for the bots into the fortress directory.
3)  Unzip using winzip or pkunzip -d.  Remember to do it with directories.
4)  Edit the options.qc file within the quake\fortress\src directory.
5)  Enable QUAKE_WORLD by removing the // infront of it.
6)  In the quake\fortress\src directory, run make.bat
7)  Run quakeworld using the following line:
    qwsv -listen 16 +exec bot.cfg -game fortress +map 2fort4

Please note the -listen/-dedicated parameter has to go first(no idea why!)

QuakeWorld Client:

1)  Make sure you have TF v2.5 or v2.6 on your hard-drive.  Extra files
    should be automatically downloaded.

    Bots count as clients so remember to leave space for them in
the listen parm.  Preferably everyone should connect before the bots are
spawned, but it shouldn't affect them.

                            Configuartion
                            -------------

Remember bots can do their own orders(default).
Also the keys can be mapped to different ones within quake.  The
best thing to do is to set up your own configuration file.

    Rec key Command         Does
    enter   spawnbot        Brings up a menu to select what class bot
                            to spawn.  See below
    '       changeteam      Cycles between teams.  Next spawned bot will
                            be on whatever team it is on.
    n       roam            Tell local bot to roam + think for itself
    m       escort          Tell local bot to escort you
    ,       camp            Tell local bot to camp at your location
    .       attack          Tell local bot to attack
    /       defend          Tell local bot to defend
            --------        Tell local bot to snipe - Hmmmmm(only self-order)

Please note these can be seen in-game by typing in bothelp
These are set in the included bot.cfg

                            Recompiling
                            -----------

I STRONGLY recommend you re-compile the bots so you have them as you want
them.  If you have a faster computer, you can increase the settings to
make the bots act more intelligently.

1)  Goto the quake\fortress\src directory.
2)  Edit the options.qc file.  The the end you'll find the relevant options
Things like BOT_CHEAT can be disabled by putting a // at the beginning of the
line (and visa versa).
3)  Run make.bat  This will start the recompiling process - Note this works
only in Windows 95!

                        Creating a Waypoint System
                        --------------------------

Tired of playing 2FORT4 and have some time on your hands?  Read the
readme.way file to find out how to create waypoints for TF levels.
Warning:    This is quite advanced stuff!

                            Trouble shooting
                            ----------------

1)  The bots don't spawn, or unknown command error.
If when you connected(or started single player) it didn't mention the
bots, it means you haven't installed it properly.
2)  progs/?????.mdl not found
Download the client side pak for TF v2.5 from:
http://www.teamfortress.com
3)  GL-Quake bugs/QW bugs
Check the web-site.  If they are not mentioned, then e-mail me about them.
4)  Read the web page at:
http://www.lockandload.com/tfbot
5)  Finally, e-mail me about it.

                                Credits
                                -------

Me - GentleMan      Just greet me on a server if you see me.  8-)
CTF Bot authors     The Hook code was adapted to my bot.
                    Also prediciton
Alan Kivlin         The code for making the scores show up.  Avaible as
                    QCBOT003.zip on ftp.cdrom.com
Roscoe A. Sincero   New Movement code(currently in testing)
                    btsk23.zip on ftp.cdrom.com.  See btsk23.txt in this zip.
Gyro Gearlose       DeathBubblesSpawn fix.

All rights reserved expect for the ones given out with TeamFortress and id.
No sort of warranty of any kind.  Remember to read readme.1st

Please bug me with any bug reports or suggestions(sensible please!)
at wolfg_l@pro-net.co.uk

