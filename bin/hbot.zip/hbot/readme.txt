HBot - The Human Bot
--------------------

Here is one of my many attempts at a Quake bot, and like a few of them, is drastically unfinished. Eventually I was hoping for it to support features such as auto-mapping of levels, teamplay tactics such as bots moving in formation, bots aiming & fighting realistically (i.e. treating a group of monsters as a group and not just shooting at each one one by one), etc.

Impulses:
---------

99 - Help
100 - Add bot
101 - Remove bot
102 - Make bot walk forward (Operates on the first bot it finds, so may only be reliable when there is only one bot in the level)
103 - Make bot walk backwards
104 - Make bot strafe left
105 - Make bot strafe right
106 - Make bot move up
107 - Make bot move down
108 - Make bot fire
109 - Make bot jump
110 - Make bot turn left
111 - Make bot turn right
112 - Make bot look up
113 - Make bot look down
114 - Change speed of bot
115 - Toggle roaming AI
116 - Toggle grabbing AI
117 - Toggle attack AI
118 - Toggle strafing
119 - Toggle investigating
120 - Bot status

Jeffrey Lee

phlamethrower@quote-egnufeb-quote-greaterthan-colon-hash-comma-underscore-at.info