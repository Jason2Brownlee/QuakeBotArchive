JBot Quake C Patch V0.7
-----------------------

Since I can't think what to write, here's a long list of features:

* Designed for up to 24 bots in deathmatch, more than 24 in coop
* Works in deathmatch, coop, and teamplay
* Looks and sounds like the player
* Moves like the player
* Jumps
* Rocket-jumps
* Swims & drowns
* Avoids rockets, grenades and nails
* Gets knocked round by rockets
* Uses all weapons and powerups
* Has different skill levels, just set the 'skill' variable at console
* Bots automatically change skill if level started with skill 1, or skill 1 at console
* Learns level layouts
* Uses teleporters
* Activates triggers and buttons
* Bot-only team for teamplay games
* Only the server needs the patch (although clients won't have the key bindings or console commands)
* Bots have a frag list and names (30 so far)
* Impulse 100 (P) creates a bot on your team (if teamplay)
* Impulse 101 (X) gets bot status (only good with 1 bot)
* Impulse 102 (H) lists all the impulses
* Impulse 103 (F) gives the human and bot frag list & teamplay bests
* Impulse 104 (B) creates a bot on bot team (if teamplay)
* Impulse 105 (F1) 'Panic button' for teamplay/coop
* Impulse 106 (F5) Cancel panic button
* Impulse 107 (F4) Answer panic button for nearest bot/player
* F6 sets up deathmatch & restarts
* F7 sets up coop & restarts
* F8 sets up teamplay deathmatch & restarts
* F9 sets up deathmatch 2 & restarts
* F10 sets up teamplay deathmatch 2 & restarts
* Console command 'dm' restarts the current level in non-teamplay deathmatch mode
* Console command 'dm2' restarts the current level in non-teamplay deathmatch 2 mode
* Console command 'cp' restarts the current level in teamplay coop mode
* Set up in deathmatch by default
* At the end of the level in coop, you get the bot's items
* At the start of the level in coop, the bot gets your items
* Bots use the panic button
* Bots talk on:
  - Sight of enemy
  - Death of enemy
  - Suicide
  - Death by someone the bot wasn't attacking
  - 'Bored' states - i.e. roaming
* Tries not to cheat, although it does turn pretty fast and notice you a mile off...
* Now gibs when stuck in ground, instead of splashing around
* Gibs in teamplay when the last human on that team leaves the game
* Now has smoother animations, and fast thinking!
  - Each frame the bots 'think', looking for things
  - Each frame the bots move, according to the frame rate (Although they do jump a bit)
  - The animations are unnafected by this
  - The botpaths update quicker now
  - There are virtually no noticeable slow downs because of this!

However, there are a few bugs:

* Jumping looks silly
* Splashy Splashy bug in e1m3! This is Quake being stupid!
* They swarm round you in coop, making it hard to move

But, there are soon going to be improvements: (If you believe this you'll believe anything -
                                               this was last edited in 1999)

* Better teamplay games (They cluster together because they aren't killing each other)
* Better botpath AI (e.g. teleport handling)
* Better bot AI
* Bots moving out the way in coop games

Hopefully you know how to get this thing to work. If not, ask someone
else because I can't be bothered telling you.

Jeffrey Lee
phlamethrower@quote-egnufeb-quote-greaterthan-colon-hash-comma-underscore-at.info