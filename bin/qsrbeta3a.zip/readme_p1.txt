Title    : Hellsmash Beta 3 Patch 1
Filename : qsrbeta3a.zip
Version  : 0.3a
Date     : 02/11/2010
Author   : Dr. Shadowborg.
Email    : prismrifle@gmail.com
Credits  : FrikaC, Sajt, ceriux, Goldenboy, Ijed, leileilol, Lightning Hunter,
           xaGe, Baker, negke, metlslime, c0burn,and the rest of the Quake                   Community.  Also iD, and anybody else who I've managed to forget. 
	   (bug me and remind me what you did to aid in the development of this
            and I'll put you in here.)
Build time: Insanes.  And it's not done yet.

Type of Mod
-----------
Quake C    : yes
Sound      : yes
MDL        : yes
Brush type : yes  


Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (the hell is this?)
context diff  : no (I dunno what this is either.)
.qc files     : No (distributed separately)
.mdl files    : qsrbeta3.zip
sound files   : qsrbeta3.zip
.bsp files    : only in qsrbeta3.zip
gfx.wad       : yes.
.lmp files    : just one to fix the +reload typo.
.cfg files    : hellsmash.cfg, required for proper operation.
progs.dat     : this is what makes it work after all.


Description of the Modification
-------------------------------

From qsrbeta3.zip's readme:
The next exciting installment of hellsmash!  Woooo!

New Weapons, enemies, maps, and a whole slew of other neat things that are
still very much prototypey dwell inside!  But you'll have a blast playing it
nonetheless!  And yes, frikbots are included if deathmatch isn't your thing.

You can play both SP and DM on hse1m1.bsp, skill settings are included for SP.

press f1 ingame to get the gist of what you need to bind, etc.

All standard frikbot X impulse commands also apply.

Patch 1 extras:
Fix for alias issues in qsrbeta3.zip on some operating systems / engines
Fix for gfx.wad with a few leftover ctf thingies.
Fix for help0.lmp with +reload instead of proper reload.

alias / impulse addenda and AIDA / Dynamite usage info.


alias / impulse command info from hellsmash.cfg:
-------------------------------

// Hellsmash QSR SPECIFIC ALIASES AND BINDS
alias +auxfire "impulse 31" // Secondary fire button down (pressed)
alias -auxfire "impulse 32" // Secondary fire button up (not pressed)
alias useaida "impulse 82" // Use AIDA (toggles help computer)
alias useitem "impulse 60" // Use Current Item 
alias dropitem "impulse 88" // Drop current item
alias reload "impulse 46" // Reload your current weapon if applicable.

// Character skin / model aliases

alias ranger "impulse 89"
alias drsborg "impulse 90"
alias frikac "impulse 91"
alias sajt "impulse 92"
alias c0burn "impulse 93"
alias wazat "impulse 94"
alias tomaz "impulse 95"

// FBX
alias addbot "impulse 100" // add a Frikbot

Tips / Info
-------------------------------

Dynamite - To use dynamite, press attack.  If you hold down the button,
           you'll throw it farther.  Press your secondary fire to blow up
	   any active dynamite that belongs to you.  Also, note that                       dynamite will stick to anything destroyable, be it monsters, players,             or parts of the surrounding landscape.  Just throw the dynamite at
	   whatever you think it will stick to, and if it connects and is
	   recognized as being destroyable it will latch on and sound a beep
	   beep noise confirming that it's attached.
		   
AIDA - Your ever helpful info computer.  Use it to see your current rank / 
       experience, view your key item inventory, read logs that you may find,
       and view any primary and secondary objectives.  Note that it has
       submenus, accessable via keys 1-4, and the log screen keys 5-8 will
       show you the log contents, if any.
	   
Boomstick Jumping - if you have the boomstick, you can perform a higher than
                    normal jump, just point it at the ground and press your
		    secondary fire.  (This costs 2 shells however.)
		    Use it to reach normally unreachable areas, or when
		    you can't use or want to save your blast jump charges.

Blast Jump - Your backpack is equipped with a special blast jump device,
             just press jump again at the apex of a regular jump to use it.
	     You'll be catapulted in the direction your currently facing.
	     (this may be locked to the biosuit device in future releases)


How to Install the Modification
-------------------------------

Extract qsrbeta3.zip into your quake folder preferably into a qsr directory.

Extract qsrbeta3a.zip over the top of wherever you chose to extract 
qsrbeta3.zip.  Confirm overwrites.

Start quake engine of your choice with -game qsr commandline with any other
appropriate commandlines.

Enjoy!

Technical Details
-----------------

...


Author Information
------------------

...


Copyright and Distribution Permissions
--------------------------------------

You may distribute this Quake modification in any electronic format as long 
as all the files in this archive remain intact and unmodified and are 
distributed together.

You may also steal any models or whatnot from this mod provided you do not
attempt to sell for profit, or claim credit for something you haven't done.
