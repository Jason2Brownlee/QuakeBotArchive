Title    : FrikBot
Filename : frikbt05.zip
Version  : 0.05
Date     : 6-7-99
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net

Credits  
-------------
Roscoe A. Sincero (legion) for DoomBot movement code (norse_movetogoal)
Alan Kivlin for his rankings.qc
Coffee (http://www.planetquake.com/minion/) for the inspiration
Karel Suhajda a.k.a Kashua for the KasCam
All the people who helped me test this bot and made suggestions!

Type of Mod
-----------
Quake C  : yes
Sound    : yes (silent thud and splash sounds)
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : yes 
progs.dat     : yes


Description of the Modification
-------------------------------

This bot takes a unique approach. Unlike all other bots I've seen, FrikBot actually pretends to be a player. When he fires his weapon, it's the same function that the player uses. It is all done through his button flags. In other words, the bot fakes all client functions, he looks like a Quake client not only to the people in the game, but also to the Quake C. So why did I make him fake client behavior? Well with him using all the player code, he automatically works with hundreds of mods with a few short lines of code added or changed. This bot will play by the game rules of nearly every mod out there. (though he doesn't always know the rules however)
                          
How to Install the Modification
-------------------------------

Make a subdir of your quake directory titled "frikbot" place all files in this archive, using your favorite unzip utility, in that folder. Start quake with the parameter "-game frikbot -listen 8". Choose multiplayer game from the main menu, set up your options and once in the game use "impulse 100" to add a bot.

Impulses
===========
100 Add a bot or add a bot to your team in a team game
101 Add a bot to an enemy team
102 Remove a bot
250 Turn on KasCam

Technical Details
-----------------

Known Bugs
==========
* Bot colors don't appear in GL Quake.
* Bots occasionally over exaggerate their out-of-water jumping (though it's cool to watch). 
* Bots really hate ledges.
* Bots can cause serious slow down on large levels.

More? Email me with your bug finds at frika-c@earthling.net

If you'd like to incorporate this bot into your Deathmatch/Coop mod see bot.qc (located inside the pak) for details.


Revision History
----------------

Changes since v0.04
-------------------
* Implementation of fisible(); a minor improvement over the id standard visible code.
* A bug where in very open levels, the bots would not switch targets upon death, fixed
* Impulse comands moved to a function inside bot.qc, to aid in future updates/changes
* Waypointing disabled in single player
* Bots use client connect again!
* Bots know how to play teamplay deathmatch. Set teamplay to nozero and enjoy!
* KasCam included in progs.dat

Changes since v0.03
-------------------
* Bot targeting moved to a priority system
* Bots now fight in a variety of fight styles (circle strafe, hold distance)
* Bots have a delayed sight time
* Bug involving clients being added/removed after a bot has spawned fixed
* Bots select weapons via impulses, chance of discharge in water lowered
* Copyright permissions, new readme format.

Changes since v0.02
-------------------
* Bot's Water Jumping really works now!
* Improved roaming
* Different chat messages and bot names
* Improved comments throughout the code
* KickABot(); implemented to remove bots from the server
* Numerous bug fixes

Changes since v0.01
-------------------
* Bot's Water Jumping now works.
* Bug where any weapon fired using self.v_angle would fire at the wrong pitch
* Error in the comment telling you how to install fixed
* General improvements in the comment.

Copyright and Distribution Permissions
--------------------------------------
FrikBot, and all functions and code writen by Ryan "Frika C" Smith are copyrighted (C) 1999. You are allowed to use and distribute this mod as long as this text file remains intact and the mod is provided free of charge. You *are* allowed to modify and incorporate this bot into your own mods, as long as adequate credit is given and the end result of your modifications is also provided free of charge. Portions of this bot are copyrighted by other individuals. Please see bot_rank.qc and bot_move.qc  for further details and permissions regarding those portions of the code. If you have questions or comments regarding the bot, the code, or just the universe in general, please write me at frika-c@earthling.net.


Availability
------------

This modification is available from the following places:

Department 187 at http://www.mdqnet.net/dept187/


