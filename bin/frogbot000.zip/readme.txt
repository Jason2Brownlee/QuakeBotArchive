Title     : Frogbot
Filenames : frogbot000.zip, skins.zip
Version   : Beta 0.00
Date      : 9 Mar 1998
Author    : Robert Field
Email     : frog@powerup.com.au
Download  : www.telefragged.com/metro

Build time: Numerous hours



How to Install the Modification
-------------------------------

Create a directory called frogbot as a subdirectory in your Quake
directory and unzip frogbot000.zip into it.
Unzip skins.zip into frogbot/progs (after you have created this
subdirectory of frogbot).


Commands
--------

addbot
add4bots
becomebot
becomeplayer
framerate
nopowerups
powerups
addbot3
addbot4
addbot6
addbot8
addbot10
addbot11
addbot12
addbot13

To spawn a bot with pants color say 3, type addbot3. Note that not all
pants colors are supported for the bots.

teamplay should work with the bots.

deathmatch 1, 2, 3 are supported.

skill is from 0 to 100 (default 100 is the hardest skill).

Note that in this beta version only map dm6 is supported.


Copyright and Distribution Permissions
--------------------------------------

The modifications included in this archive are Copyright 1998, Robert
Field.
The original QuakeC source is Copyright 1996, id software.

You may distribute this Quake modification in any electronic format as
long as all the files in this archive remain intact and unmodified and
are distributed together.


Disclaimer
----------

Software under this agreement is under no kind of warranty. Software
under this agreement is provided as is, and isn't guaranteed in any way
by the mod author. Use this software at your own risk.


Credits
-------

id softare for Quake and QuakeC.

Mustafa K. ATA and the FEAR Team for QcAPE.

Alan Kivlin whose scoreboard code let me understand how to do the
scoreboard for bots.

Mr Elusive for suggesting a better stair climbing method, and for
providing inspiration with his Omicron bot.

The player.mdl file is from the QuakeBot.


Thanks
------

Timm 'Timmi' Stokke and Brent 'Randar' Phillips and the rest of the
private beta test team for being so enthusiastic.
