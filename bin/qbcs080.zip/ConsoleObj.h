#ifndef CONSOLEOBJ_H
#define CONSOLEOBJ_H

#include "ServerObj.h"
#include "AliasObj.h"
#include "EventTableObj.h"


#ifndef __unix__
 #include <conio.h>
 #include <stdarg.h>
#else
 #include <varargs.h>
#endif

#include "RuleObj.h"

const int MaxCommands = 20;


class ServerObj;

class ConsoleObj : virtual public EventHandlerObj {

private:

	boolean EndOfString;
	char OutputBuffer[0xFF], InputBuffer[0xFF], Buffer[0xFF];
	int InputOffset, BufferOffset;
	int OutputOffset;
	EventTableObj *EventTable;
	DataObj *Data;
	void DoHelp(), DoAlias(), DoGame(), DoNet(), DoPlayer(), 
		DoDisconnect(), DoSay(), DoQuit(), DoModel(), DoDynamic(), 
		DoImpulse(), DoStatic(), DoDefined(), DoBF(), DoConnect(),
		DoColor(), DoName(), DoSkin();

	void DoOther(char *);
	int LastCommand;
	char GetChar();

	void InsertCommand(char *, char *, void (ConsoleObj::*Function)());

	char *GetToken();
	struct CommandStruct {
		char *Command; // The ASCII name of the command in the file
		char *Text;
		void (ConsoleObj::*ParseFunction)(void);
	};

	struct CommandStruct Commands[MaxCommands];

#ifndef __unix__
	HANDLE ConsoleHandle;
	CONSOLE_SCREEN_BUFFER_INFO Csbi;
	COORD CursorPosition, PromptPosition;
#endif
	
	void PlayerStatus(PlayerObj *);
	void DisplayAliases();
	char *StringToken();
	char *LineToken();

	int IntToken();
	void GameStatus();
	void NetworkStatus();
	void EntityInformation(EntityObj *);
	void DisplayDefinedEntities();
	void DisplayWeapon(PlayerObj *);
	void DisplayItems(PlayerObj *);
	void DisplayPlayerStatus(PlayerObj *);
	void DecodeColors(int);
	void InsertAlias(char *, char *);
	void ResetPrompt();

	enum States {Idle, Token, Comment, Terminate, Quote, EndQuote, String, Error};

	typedef enum States State;
	boolean ServerConnected;

	// defined values for all present commands

	
public:

	// Registered Events
	void KeyEvent(void *);

	// Object Functions
	void ParseString(char *);
	void DisplayString(char *, ...);             
	void SetServer(ServerObj *);
	void GetString(char *);
	AliasObj Alias;
	ConsoleObj(EventTableObj *, DataObj *);
	void ClearScreen();
	void MessageEvent(ObjectEvent, void *);
	void DeleteCommands();
	~ConsoleObj();

};




#endif

