#include "DataObj.h"

void DataObj::SetServerName(char *Source){

	if(ServerName != NULL)
		free(ServerName);

	ServerName = strdup(Source);
}

void DataObj::SetServerIP(char *Source){

	if(ServerIP != NULL)
		free(ServerIP);

	ServerIP = strdup(Source);
}

void DataObj::SetMapName(char *Source){

	if(MapName != NULL)
		free(MapName);

	MapName = strdup(Source);
}

void DataObj::SetBotName(char *Source){

	if(BotName != NULL)
		free(BotName);

	BotName = strdup(Source);
}

void DataObj::SetLightStyle(int Index, char *String){

	if(LightStyle[Index] != NULL)
		free(LightStyle[Index]);

	LightStyle[Index] = strdup(String);
}

void DataObj::ResetGameVariables() {

	int i;

//	_ftime(&ClientStartTime); // Record start of game
	ClientTimeStamp = (float)0.0;
	StaticEntityCount = 0;
	NumModels = 0;
	NumSounds = 0;
	BotID = 0;

	FreeGameData();
	
	for(i = 0; i < MAX_STATIC_ENTITIES; i++ )  // init baseline array
		StaticEntity[i] = NULL; 

	for(i = 0; i < MAX_STATIC_ENTITIES; i++ )  // init baseline array
		LightStyle[i] = NULL; 


	for(i = 0; i < MAX_BASELINE_ENTITIES; i++ )  // init baseline array
		BaselineEntity[i] = NULL; 

	LastUpdatedEntity = -1;

	for(i = 1; i <= MaxPlayers; i++ ) {
		BaselineEntity[i] = new PlayerObj;
		((PlayerObj *)BaselineEntity[i])->PlayerID = (i - 1);  // Let him know who he is
	}

	// Init Precache Areas
	for(i = 0; i <= MAX_MODELS; i++)
		PrecacheModel[i] = NULL;

	for(i = 0; i <= MAX_SOUNDS; i++)
		PrecacheSound[i] = NULL;


}

//*****************************
//
//  This routine finds the player entity
//  that is a the closest match for the location
//
//*****************************

int DataObj::WhatIsAt(float X, float Y, float Z) {

	float XOffset, YOffset, ZOffset;
	float Result, Distance;
	int Player = -1;
	int i;

	Result = FLT_MAX;
	for(i=0; i < NumberOfPlayers; i++) {

		XOffset = BaselineEntity[i+1]->Location[0] - X;
		YOffset = BaselineEntity[i+1]->Location[1] - Y;
		ZOffset = BaselineEntity[i+1]->Location[2] - Z;
		Distance = (float) sqrt(pow(ZOffset, (float)2.0) 
			+ pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));
		if(Result > Distance) {
			Result = Distance;
			Player = i+1;
		}
	}
	
	return Player;

}


//***************************************************************
//
//  Frees up allocated entities.
//
//***************************************************************

void DataObj::FreeEntities() {

	int i;
	_CrtCheckMemory();

	for(i = 0; i < MAX_BASELINE_ENTITIES; i++) {
		_CrtCheckMemory();
		if(BaselineEntity[i] != NULL) {
			if(i >= 1 && i <= MaxPlayers)
				delete (PlayerObj *)BaselineEntity[i];
			else
				delete BaselineEntity[i];
			BaselineEntity[i] = NULL;
			_CrtCheckMemory();
		}
	}

	for(i = 0; i < MAX_STATIC_ENTITIES; i++) {
		if(StaticEntity[i] != NULL) {
			delete StaticEntity[i];
			StaticEntity[i] = NULL;
		}
	}

	for(i = 0; i < MAX_STATIC_ENTITIES; i++) {
		if(LightStyle[i] != NULL) {
			free(LightStyle[i]);
			LightStyle[i] = NULL;
		}
	}
}

//***************************************************************
//
//  Frees up allocated model and sound strings
//
//***************************************************************

void DataObj::FreePrecache() {

	int i;

	for(i = 0; i < NumModels; i++) {
		if(PrecacheModel[i] != NULL)
			free(PrecacheModel[i]);
	}

	for(i = 0; i < NumSounds; i++) {
		if(PrecacheSound[i] != NULL)
			free(PrecacheSound[i]);

	}
}

//***************************************************************
//
//  Frees up other BS
//
//***************************************************************

void DataObj::FreeMisc() {

	if(ServerIP != NULL)
		free(ServerIP);
	if(ServerName != NULL)
		free(ServerName);
	if(MapName != NULL)
		free(MapName);
	if(BotName != NULL)
		free(BotName);
}


DataObj::DataObj(){

	int i;

	ClientTimeStamp = (float)0.0;
	MapName = strdup("(None)");
	ServerName = NULL;
	ServerIP = NULL;
	BotName = NULL;
	
	NumModels = 0;
	NumSounds = 0;
	NumberOfPlayers = 0;
	MaxPlayers = 0;
	BotID = 0;
	BotEntityIndex = 1;
	sv_gravity = 800;
	sv_friction = -1;
	sv_maxspeed = -1;
	noexit = 1;
	teamplay = 0;
	fraglimit = 0;
	timelimit = 0;
	BotID = 0;
	BotShirtColor = 3;
	BotPantColor = 3;
	LastUpdatedEntity = -1;


	for(i = 0; i < MAX_STATIC_ENTITIES; i++ )  // init baseline array
		StaticEntity[i] = NULL; 

	for(i = 0; i < MAX_STATIC_ENTITIES; i++ )  // init Light Strings
		LightStyle[i] = NULL; 

	for(i = 0; i < MAX_BASELINE_ENTITIES; i++ )  // init baseline array
		BaselineEntity[i] = NULL; 

	for(i = 0; i < MAX_BASELINE_ENTITIES; i++ )  // init baseline array
		UpdatedEntity[i] = -1; 

	_CrtCheckMemory();

}
	
void DataObj::FreeGameData(){
	FreeEntities();
	FreePrecache();
}

DataObj::~DataObj(){		

	_CrtCheckMemory();
	FreeGameData();
	FreeMisc();
}

//***************************************************************
//
//  Find nearest player as the crow flies. -1 if none
//	Will return dead players, SO CHECK!!!!
//
//***************************************************************
int DataObj::NearestPlayerByVector() {

	int i, TargetPlayer;
	float MinDistance, PlayerDistance;		

	//  Find closest player
	MinDistance = FLT_MAX;
	TargetPlayer = -1;
	for(i=0;i < MaxPlayers;i++) {
		if(i != BotID ) {		// Can't be me, dip!
			PlayerDistance = BaselineEntity[BotEntityIndex]->Distance(BaselineEntity[i+1]);
			if(PlayerDistance < MinDistance) {
				MinDistance = PlayerDistance;
				TargetPlayer = i;
			}

		}
	}
	return TargetPlayer;

}

//***************************************************************
//
//  Find nearest ENEMY player as the crow flies. -1 if none
//	Will return dead players, SO CHECK!!!!
//
//***************************************************************
int DataObj::NearestEnemyByVector() {

	int i, TargetPlayer;
	float MinDistance, PlayerDistance;		
	PlayerObj *Bot;

	Bot = (PlayerObj *)BaselineEntity[BotEntityIndex];

	//  Find closest player
	MinDistance = FLT_MAX;
	TargetPlayer = -1;
	for(i=0;i < MaxPlayers;i++) {
		if(i != BotID && !(teamplay 
			&& (Bot->ShirtColor == ((PlayerObj *)BaselineEntity[i+1])->ShirtColor)
			&& (Bot->PantColor == ((PlayerObj *)BaselineEntity[i+1])->PantColor))) {		// Can't be me, dip!
			
			PlayerDistance = ((EntityObj *)Bot)->Distance(BaselineEntity[i+1]);
			if(PlayerDistance < MinDistance) {
				MinDistance = PlayerDistance;
				TargetPlayer = i;
			}

		}
	}
	return TargetPlayer;

}

//***************************************************************
//
//  Find nearest Entity as the crow flies. -1 if none
//
//***************************************************************
int DataObj::NearestEntityByVector(float X, float Y, float Z) {

	int i, TargetEntity;
	
	float MinDistance, EntityDistance;		

	//  Find closest player
	MinDistance = FLT_MAX;
	TargetEntity = -1;
	for(i = MaxPlayers+1; i < MAX_BASELINE_ENTITIES;i++) {
		if(BaselineEntity[i] != NULL ) {		// Don't Pick last one
			EntityDistance = BaselineEntity[i]->Distance(X, Y, Z);
			if(EntityDistance < MinDistance) {
				MinDistance = EntityDistance;
				TargetEntity = i;
			}

		}
	}
	return TargetEntity;

}

//***************************************************************
//
//  Find nearest Entity as the crow flies. -1 if none
// Will ingnore entities with a specificied distance to find next closest
//
//***************************************************************
GameCoord *DataObj::NextEntity(GameCoord *Coord) {

	int i, TargetEntity;
	
	float MinDistance, EntityDistance;		

	//  Find closest player
	MinDistance = FLT_MAX;
	TargetEntity = -1;
	for(i = MaxPlayers+1; i < MAX_BASELINE_ENTITIES;i++) {
		if(BaselineEntity[i] != NULL ) {		// Don't Pick last one
			EntityDistance = BaselineEntity[i]->Distance(Coord->X, Coord->Y, Coord->Z);
			if((PrecacheModel[BaselineEntity[i]->ModelIndex])[0] != '*') { // avoid the *1 entries

				if(EntityDistance < MinDistance && EntityDistance > Coord->Distance) {
					MinDistance = EntityDistance;
					TargetEntity = i;
				}
			}
/*			else
				EventTable->Print("Rejected Distance %f\n", EntityDistance);
*/
		}
	}
	if(TargetEntity == -1 ) // Nothing found
		Coord->Index = -1;
	else {
		Coord->Distance = MinDistance;
		Coord->Index = TargetEntity;
		Coord->X = BaselineEntity[TargetEntity]->Location[0];
		Coord->Y = BaselineEntity[TargetEntity]->Location[1];
		Coord->Z = BaselineEntity[TargetEntity]->Location[2];
	}

	return Coord;

}
