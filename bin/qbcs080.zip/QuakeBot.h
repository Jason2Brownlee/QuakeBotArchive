#ifndef QUAKEBOT_H
#define QUAKEBOT_H

#include <stdlib.h>
#include <stdio.h>
#include <winsock.h>
#include <crtdbg.h>

struct CoordStruct{
	float X, Y, Z, Distance;
	int Index;
};

typedef struct CoordStruct GameCoord;

struct AddressStruct{
	char * IPAddress;
	int Port;
};

 typedef struct AddressStruct Address;

/*enum booleans {True = 1, False = 0};

typedef enum booleans boolean;
*/

enum EventDestinations {edBroadcast, edConsole, edServer, edIBCServer, 
	edAI, edProxyServer}; // Event Destinations

typedef enum EventDestinations EventDest;

enum ObjectEvents {oeConsoleParse, oeConsolePrint, oeAIOn, oeAIOff,
oeServerOnline, oeServerOffline, oeServerConnect, oeRespawn,
oeServerDisconnect, oeSendRuntimePacket, oeSendSay, oeSendRaw}; // Object events

typedef enum ObjectEvents ObjectEvent;

#endif

