#ifndef NAVOBJ_H
#define NAVOBJ_H

#include <float.h>

#include "WaypointObj.h"
#include "EventTableObj.h"
#include "QuakeBot.h"
#include "DataObj.h"

const int MAX_DEATHMATCH_STARTS = 8; // Max number of number of unique places
									// you can start in a DM level
const int MaxStallCount = 10;


class NavObj {

private:

	WaypointObj *GraphEntry[MAX_DEATHMATCH_STARTS]; // These are pointers to
												// each of the deathmatch starts
	float DestinationX, DestinationY, DestinationZ, PreviousDistance;
	int Traveling;
	PlayerObj *Bot;
	DataObj *Data;
	GameCoord BotCoord, StartCoord, EndCoord;
	int StallCount;
	int InsertWaypoint(GameCoord);


public:

	WaypointObj *CurrentWaypoint;
	int Mapping();
	void RandomMove();
	int WaypointSync(GameCoord);
	void InsertEntryPoint(GameCoord);
	WaypointObj *FindWaypoint(WaypointObj *, float, float, float);
	int VacantConnection();
	void AttachWaypoint();
	void SetDestination(GameCoord);
	int AtDestination(GameCoord);
	void InsertBlockedWaypoint(GameCoord);
	int Stalled(GameCoord);
	float DistanceFromDestination(float, float, float);
	void DisplayGraph();
	void DisplayWaypoint(WaypointObj *);
	int IsAttached(GameCoord);


	NavObj(DataObj *ServerData) {
		
		int i;
		for(i = 0; i < MAX_DEATHMATCH_STARTS; i++)
			GraphEntry[i] = NULL;
		CurrentWaypoint = GraphEntry[0];
		DestinationX = (float) 0.0;
		DestinationY = (float) 0.0;
		DestinationZ = (float) 0.0;
		PreviousDistance = FLT_MAX;
		Traveling = 0;
		Data = ServerData;
		Bot = NULL;
		EndCoord.Distance = (float) MAX_RANGE;
	}

	void Reset() {

		EndCoord.Distance = (float) MAX_RANGE;
		Traveling = 0;
	}

};

#endif

