#ifndef CLIENTOBJ_H
#define CLIENTOBJ_H

#include "SocketObj.h"
#include "PacketObj.h"
#include "EntityObj.h"
#include "PlayerObj.h"
#include "QuakeBot.h"
#include "EventTableObj.h"


#include <limits.h>
#include <float.h>
#include <time.h>


#define CCREP_ACCEPT 0x81
#define CCREP_REJECT 0x82

#ifdef __unix__
 #define strnicmp strncmp
 #define stricmp strcmp
 #define Sleep sleep
 #define TRUE 1
 #define FALSE 0
#endif

#define COMMAND_QUERY 0x02
#define COMMAND_CONNECT 0x01
#define COMMAND_RULE 0x04


//#define DECODE

class ClientObj: EventHandlerObj {


private:

	EventTableObj *EventTable;
	void Logon();

	// ***************************************************
	//
	//  Server Timeout routine. Uses Console instead of printf
	//
	// ***************************************************

	static void ClientTimeoutHandler(void) {

//		Console.DisplayString("Receive timed out!!!!\n");
		printf("Receive timed out!!!!\n");

	}

public:

	PacketObj ClientPacket;

	// Server Parameters
	char *ClientName; // Name of server
	char *IPString;
	char *MapName;		// Current Map Name
	char *BotName;
	long ClientVersion;
	char Initialized;
	ClientObj(EventTableObj *, char *, int);

	// Member Functions
	void DecodePacket();
	void DecodeClientPacket();
	void SendGoodbye();
	int QueryClient();
	void SendRuntimePacket(PlayerObj *);
	void SendBroadcastMessage(char *);
	void SendCommand(char *);
	int ConnectClient();

	void BombOut(char *);
	void FreeEntities(), FreePlayers(), FreePrecache(), FreeMisc();

	time_t ClientStartTime;

	~ClientObj() {
		FreePlayers();
		FreeEntities();
		FreePrecache();
		SendGoodbye();
	}

};


#endif