#include "AIObj.h"

extern char VERSION[];

int AIObj::AttackPlayer(int TargetPlayer) {

	float Distance;

	PlayerObj *Bot, *Target;

	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];
	Target = (PlayerObj *)Data->BaselineEntity[TargetPlayer+1];
	if(TargetPlayer == -1) 
		return 0;
	if(Target->Dead()) 
		return 0;
	
	// Aim at Player
	Distance = Bot->Aim(Target);

	if(Distance <= (float)300.0 && Distance > (float) 10.0){
		Bot->SelectSafeWeapon(); 
		Bot->CommandActions |= KEY_ACTION_FIRE;
		Bot->CommandInlineSpeed = 0x1FF;
		return 1;
	} else if (Distance <= (float)10.0) {
		Bot->CommandImpulse = SELECT_WEAPON_AXE;
		Bot->CommandActions |= KEY_ACTION_FIRE;
		Bot->CommandInlineSpeed = 0;
		return 1;
	}
	return 0;
}


void AIObj::Chatter(int Count) {

	char Buffer[50];
	if(Count == 50) {
		sprintf(Buffer, "QuakeBot C/S(c) %s", VERSION);
		EventTable->SendMessage(edServer, oeSendSay, (void *)Buffer);
	}

	if(Count == 100)
		EventTable->SendMessage(edServer, oeSendSay, (void *)"jfrorie@uncc.edu");

}

void AIObj::DisplayMode(int Mode) {

	switch(Mode) {
	case AI_MODE_IDLE:
		EventTable->Print("Bot is IDLE\n");
		break;
	case AI_MODE_ATTACK:
		EventTable->Print("Bot is ATTACKING\n");
		break;
	case AI_MODE_TARGET:
		EventTable->Print("Bot is TARGETING\n");
		break;
	case AI_MODE_EVADE:
		EventTable->Print("Bot is EVADING\n");
		break;
	case AI_MODE_MAP:
		EventTable->Print("Bot is MAPPING\n");
		break;
	case AI_MODE_RETRACE:
		EventTable->Print("Bot is RETRACING\n");
		break;
	case AI_MODE_DEAD:
		EventTable->Print("Bot is DEAD\n");
		break;
	case AI_MODE_STALLED:
		EventTable->Print("Bot is STALLED\n");
		break;
	case AI_MODE_MOVING:
		EventTable->Print("Bot is MOVING\n");
		break;
	case AI_MODE_REACHED:
		EventTable->Print("Bot has found WAYPOINT\n");
		break;
	case AI_MODE_RESPAWNED:
		EventTable->Print("Bot has RESPAWNED\n");
		break;
	default:
		EventTable->Print("Bot is SCREWED UP!!!\n");
	}
}

//*********************************
//
// This function hits once per event cycle
//
//*********************************

void AIObj::CycleEvent(void *Dummy) {

	int Dead = 0, TargetPlayer, MinDistance;
	int StrafeLeft = 0;
	int StrafeCount = 0;

	timeval ShortTime;

	ShortTime.tv_sec = 0;
	ShortTime.tv_usec = 1000;

	if(!Enabled) // AI was turned off
		return;

	// Update who I am for this pass
	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];
	Health = Bot->Health;
	BotCoord.X = Bot->Location[0];
	BotCoord.Y = Bot->Location[1];
	BotCoord.Z = Bot->Location[2];
	BotCoord.Distance = FLT_MAX;

	// Reset Everything
	MinDistance = INT_MAX;
	Bot->CommandActions = KEY_ACTION_NONE;
	Bot->CommandImpulse = 0x0;
	Bot->CommandLateralSpeed = 0x00;
	Count++;

	// Maybe send a message or two......
	Chatter(Count);

	// Find nearest Player
	TargetPlayer = Data->NearestEnemyByVector();

	if(TargetPlayer != -1){
		if(StrafeLeft) {
			Bot->CommandLateralSpeed = 0x080;
			if(StrafeCount++ >= MAX_STRAFECOUNT){
				StrafeCount = 0;
				StrafeLeft = 0;
			}
		} else {
			Bot->CommandLateralSpeed = -0x080;
			if(StrafeCount++ >= MAX_STRAFECOUNT){
				StrafeCount = 0;
				StrafeLeft = 1;
			}
		}
	}

	if(Health <= 0){  // I am dead, deal with it	
		AIMode = AI_MODE_DEAD;
		EventTable->SendMessage(edServer, oeRespawn, (void *)NULL);
		Reset();
		Bot->CommandLateralSpeed = 0x0;
	} else if(OldHealth > Health) { // I took a hit
		if(StrafeLeft) {
			Bot->CommandLateralSpeed = 0x0ff;
			if(StrafeCount++ >= MAX_STRAFECOUNT){
				StrafeCount = 0;
				StrafeLeft = 0;
			}
		} else {
			Bot->CommandLateralSpeed = -0x0ff;
			if(StrafeCount++ >= MAX_STRAFECOUNT){
				StrafeCount = 0;
				StrafeLeft = 1;
			}
		}
		AIMode = AI_MODE_EVADE;
	} else if((OldHealth <= 0 && Health > 0) || StartUp) { // I respawned			
		AIMode = AI_MODE_RESPAWNED;
		if(BotCoord.X == 0 && BotCoord.Y == 0 && BotCoord.Z == 0){
			StartUp = 1;
		} else {
			InsertEntryPoint(BotCoord); 
			StartUp = 0;
		}
	} else if(AttackPlayer(TargetPlayer)) {
		Reset();

		AIMode = AI_MODE_ATTACK;
	} else if(Mapping()) {
		Bot->CommandLateralSpeed = 0x0;
		AIMode = AI_MODE_MAP;
	} else {
		Bot->CommandLateralSpeed = 0x0;
		AIMode = AI_MODE_MOVING;
		RandomMove();
	}

	// If health has changed.
	if(OldHealth != Health) 
		OldHealth = Health;

	if(OldAIMode != AIMode) {
		DisplayMode(AIMode);
		OldAIMode = AIMode;
	}

	//  Send some Data		
	EventTable->SendMessage(edServer, oeSendRuntimePacket, (void *)Bot);
}

void AIObj::MessageEvent(ObjectEvent Event, void *Data) {

	switch(Event) {
	case oeAIOff: // Turn off AI
		EventTable->Print("AI Disabled\n");
		Enabled = FALSE;
		break;
	case oeAIOn: // Turn on AI
		EventTable->Print("AI Enabled\n");
		Enabled = TRUE;
		break;
	}

}
