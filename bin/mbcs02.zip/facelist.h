/*
**  support class for bspFile
**  (c) 1997 mike warren
**
**  this code is *not* freeware. See the file ``README'' or contact
**  mbwarren@acs.ucalgary.ca
**
**  (excuse the rather long ::read() inlined functions, but i didn't feel like
**   having lotsa .cc files :) )
**
*/



#ifndef _FACELIST_H_
#define _FACELIST_H_

#include "defines.h"
#include "mfile.h"

class bspFaceList
{
  unsigned short * facelists;
  int loadedFacelists;

  bspFaceList(){}

public:
  
  bspFaceList( mFile & mf, int n ) { facelists=new unsigned short[ n ]; loadedFacelists=0; read( mf, n ); }
  ~bspFaceList() { delete facelists; }

  void read( mFile & mf, int n ) { for( int i=0; i < n; i++ ) facelists[i]=mf.readLEushort(); loadedFacelists=n; }

  int getFaceList( int x ) { if ( x >= 0 && x < loadedFacelists ) return (int)facelists[x]; else return 0; }
  int getNum() { return loadedFacelists; }

  void dump() { for( int i=0; i < loadedFacelists; i++) printf("%d : %d\n", i, facelists[i]); }

};

#endif
  
