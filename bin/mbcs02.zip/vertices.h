/*
**  support class for bspFile
**  (c) 1997 mike warren
**
**  this code is *not* freeware. See the file ``README'' or contact
**  mbwarren@acs.ucalgary.ca
**
**  (excuse the rather long ::read() inlined functions, but i didn't feel like
**   having lotsa .cc files :) )
**
*/


#ifndef _VERTICES_H_
#define _VERTICES_H_

#include "defines.h"
#include "vector.h"
#include "mfile.h"


class bspVertex
{
  vector position;
  
  bspVertex(){}

public:

  bspVertex( mFile & mf ) { read( mf ); }

  void read( mFile & mf ) { position.setx( mf.readLEfloat() ); position.sety( mf.readLEfloat() ); position.setz( mf.readLEfloat() ); }

  void dump() { position.print(); putchar('\n'); }
};

class bspVertices
{
  bspVertex ** vertices;
  int loadedVertices;
  
  bspVertices(){}

public:
  
  bspVertices( mFile & mf, int x ) { vertices=new bspVertex*[ x ]; loadedVertices=0; for( int i=0; i < x; i++ ) vertices[i]=0; read( mf, x ); }
  ~bspVertices() { for( int i=0; i < loadedVertices; i++ ) delete vertices[i]; delete[] vertices;}

  void read( mFile & mf, int n ) { for( int i=0; i < n; i++ ) vertices[i]=new bspVertex( mf ); loadedVertices=n; }

  int getNum() { return loadedVertices; }
  bspVertex * getVertex( int x ) {  if (x>=0 && x < loadedVertices ) return vertices[x]; else return 0; }

  void dump() { for( int i=0; i < loadedVertices; i++ ) vertices[i]->dump(); }

};



#endif
