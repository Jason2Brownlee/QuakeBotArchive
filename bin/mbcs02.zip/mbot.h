/*
**
**  MBOT class, derived from MBFIRE and MBNAV and MBTALK and MBEARS
**
**  (c) 1997, mike warren
**  mikeBot
**
**
**  this is basically an example/skeleton of how to do your AI code
*/

#ifndef _MBOT_H_
#define _MBOT_H_

#include "mbotbase.h"

class mbot : public mbotbase
{
protected:

  int respawn;			// > 0 iff bot is dead. and should fire
  int verticleSpeed;		// these are the massaged speeds 
  int forwardSpeed;		// after accounting for idealSpeeds
  int strafeSpeed;		// from mbnav and facing from mbfire

public:
  
  mbot();
  ~mbot(){};

  void reinit() { mbotbase::reinit(); }

  int sendMovement();		// impulses, jump, facing, etc.

  void update();		// only function which needs to be called
				// calls qcs::update(), mbfire::update(), etc.
  int setOptsFromFile( char * );// initializes MBOT options from a file
  void changeHate( int i, int x ) { players[i].hate = x; }

};





#endif
