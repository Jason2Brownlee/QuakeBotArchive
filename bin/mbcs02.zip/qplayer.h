/*
**
**  QPLAYER class
**
**  (c) 1997, mike warren
**  mikeBot
**
**  keeps track of players, origin, facing, frags, name, etc.
**
*/

#ifndef _QPLAYER_H_
#define _QPLAYER_H_

#include "defines.h"

//
//  TODO : add some more of the stuff...(like indexs into entity thingy)
//

class qplayer
{
public:

	int index;		// into entitys[] array
	int frags;
	char * name;	
	int hate;		// negative hate level indicates friend
	int shirt;
	int pants;
	qplayer() { index=0; frags=0; name = (char *)0; hate = 0; shirt=0; pants=0; }
	~qplayer() { delete name; }

};


#endif
