
struct cmdFlags
{
  char * filename;		// demo file name. (char *)0 if none
  char * address;		// address specified; (char *)0 if none
  int port;

  cmdFlags( int argc, char **argv );
  ~cmdFlags() { delete filename; delete address; }

private:

  cmdFlags(){}
    
};

