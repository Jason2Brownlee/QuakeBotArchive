/*
**
**  simple info structures : mike warren, 1997
**
*/


#ifndef _QSTRUCTS_H_
#define _QSTRUCTS_H_

#include "defines.h"

struct serverInfo
{
	char * name;		// char *'s 'cause they get info
	char * address;		// from qpacket::readString()
	char * level;
	int players;
	int maxPlayers;
	serverInfo() { name=address=level=(char *)0; players=maxPlayers=0; }
	~serverInfo() { delete name; delete address; delete level; }
};
	

#endif
