/*
**
**  OPTIONS class
**
**  (c) 1997 mike warren
**  mikeBot
**
**
**  hash table class -- used for user-defined flags in mikeBot
**
*/

#ifndef _OPTIONS_H_
#define _OPTIONS_H_

#include "defines.h"
#include <string.h>

#define OPTS_MAX  1024

class options
{
protected:
  int tableSize;
  char ** table;
  int elements;
  int * values;

  int getHashValue( char * );

public:
  options( int size = OPTS_MAX );
  ~options( ) { for( int i=0; i < tableSize; i++ ) delete table[i]; delete[] table; delete[] values; }

  int add( char *, int );
  int remove( char * );
  int find( char *, int * v = NULL );

  int set( char * x, int v ) { return add( x, v ); }
  int get( char * x ) { int r=0; find( x, &r ); return r; }

};


#endif
  
