/*
**
**  STACK
**
**  (c) 1997 mike warren
**  mikeBot
**
**  wheee, its a stack
**
*/


#ifndef _STACK_H_
#define _STACK_H_

#include "defines.h"

template< class T >
class stack
{
  int size;
  T * items;
  int maxSize;
  
public:

  stack( int x=1024 ) { size=0; items = new T[ x ]; maxSize=x; }
  ~stack() { delete[] items; }

  int push( T x ) { if( size>=maxSize) return FALSE; items[size++]=x; return TRUE; }
  T pop() { if( !isEmpty() ) return items[--size]; return 0; }
  T peek() { if( !isEmpty() ) return items[ size ]; return 0; }

  int isEmpty() { return (size==0); }
};


#endif
