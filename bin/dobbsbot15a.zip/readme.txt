Title    : DOBBSbot - A Deathmatch, Teamplay and Cooperative bot
Filename : dobbsbot15.zip
Version  : v1.5a
Date     : 10/7/00
Author   : Stephen Dobbs
Website  : http://www.dobbsnet.co.uk
Email    : stephen.dobbs@btinternet.com
Credits  : The creator of the Tutor Bot and Bot-player

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no


Format of QuakeC
----------------
unified diff  : no
context diff  : no
.qc files     : e-mail me if u really want the source code
progs.dat     : yes

Contents
--------
1. Overview
2. Installation
3. How to use the bot
4. Bot Features
5. Updates
6. Bugs
7. Plans
8. Copyright
9. Availabilty

Overview
--------
The DOBBSbot is a bot designed to mimic the behaviour of a deathmatch 
and coop player. It can use all the weapons and nearly all of the
items. As far as I know, it is one of the best COOP bots which try and
do the level on there on. This version of the bot does NOT use waypoint 
files. However, you can download the DOBBSbot waypoint version as well.
You can have a maximum of 15 bots on a level.

Installation
------------
Extract the zip file with Winzip into a subdirectory inside the Quake
directory called 'dobbsbot' (ie. c:\quake\dobbsbot). Make shortcuts
to the files dm.bat (deathmatch), tp.bat (teamplay) and coop.bat (coop)
and double-click on them to run the required mode of game.

How to use the bot
------------------
The controls are very simple.
PRESS B to create a bot -In teamplay or COOP this will create a team-mate,
			 but in Deathmatch will create an enemy bot.
PRESS N to create a bot on the opposite team -Teamplay only.
PRESS M to view BOTcam - See what the bot's see. A bit dodgy, but fun.

You can change the difficulty of the bot using the "skill" variable.
On skill 1 (default), bots can range from really slow and rubbish aim to very fast and near-perfect aim.
On skill 2, bots run at full speed and are all quite accurate.
On skill 3, bots run at slightly above full speed and aim almost perfectly.

Bot Features
------------
The bot is based on the Tutor bot code and some code from the bplayer bot.
+ The bot fights with its best weapon, and will resort to the axe if it
  needs to!
+ The bot can travel up and down stairs.
+ The bot will check before it jumps (it doesn't jump into lava or slime).
+ The bot will attack in different ways including - strafing
						    backing up
						    charging
					            circling
						    teasing
+ The bot runs for cover when it has low health or is faced with an
  enemy who has explosive weapons (rocket launcher or grenade launcher)
+ The bot will appear on the scoreboard (Even the Reaper bot doesn't do that)
+ The bot will pursue it's enemy for a while if he tries to run away!
+ The bot can use buttons, lifts and switches, just like a real player.
+ The bots have random colours, or team colours in teamplay!
+ Plus many more I can't be bothered to put down.

Updates
-------
v1.0 - DOBBSbot first release!
v1.1 - added ability to use switches, lifts, buttons etc. Fixed a few misc bugs.
v1.2 - Bots can now actually pick up weapons/items and use them properly!
v1.3 - First Public release (first stable version!)
       Bots now use the axe when they have no ammo.
       DOBBSbot doesn't crash anymore at all!
v1.4 - Bots will fight other bots more!
       In teamplay, bots on your team are blue and the other team is red.
       Disabled spawning an enemy team bot in coop.
       Improved aiming routine.
       Improved velocity (speed/movement) code so bots move faster.
       Bots can now recognaise secret doors/switches
       Improved bot's ability to choose it's best weapon depending on it's situation (eg. Will only use exlosive weapons against zombies).
       Improved bot's swimming routines.
       Tidied up the code a little.
v1.5 - Bots now run at full speed (320, same as player running)
       Rewrote aiming routine - Bots have different aiming accuracy (anything from near perfect too really rubbish).
       Bots will strafe into weapons during combat.
       Bots will still fight if they are feeling pain.
v1.5wp - Waypoint version of the DOBBSbot!
v1.5a - On Skill 0 or 1, bots have varying speed levels (from 240-320) and varying accuracy.
	On Skill 2, bots run at full speed (320) and have a lot better aim
	On Skill 3, bots run at 330 speed and have a near perfect aim
	Bots sometimes camp around rocket launchers for 2 minutes
	Bots can now fire nailguns a lot faster. They're deadly when they strafe with nailguns!
	Added hack so that bots will pick up health boxes when they have less than 100 health.
	Bots fire grenade and rocket launcher with less of a delay.
	

Bugs
----
THERE ARE NO MAJOR GAMEPLAY BUGS, but...
+ Bots can't travel in the water very well at all.
+ Bots will not always die in lava.
+ Bots very occasionally get stuck.

Plans
-----
+ Bots will soon be able to talk to you (hurl abuse, talk when bored etc.)

							
Copyright and Distribution Permissions
--------------------------------------

Authors MAY use these modifications as a basis for other
publically available work as long as you mention my name
and include this text file.


Availability
------------

This modification is available from the following places:

FTP   : -none-
WWW   : http://www.dobbsnet.co.uk/quake.htm
