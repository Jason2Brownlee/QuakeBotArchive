Title		: UrreBot
Filename	: ...
Version		: 0.1
Date		: 20050813
Author		: Marko "Urre" Permanto
Email		: imunreal A to the T gmail D to the O to the T com
Website		: http://urre.quakedev.com/
Credits		: LordHavoc for teaching me a lot about QuakeC, for
			mponlyqc, for dpmod (including but not limited
			to havocbot), for DarkPlaces and for endless
			hours of interesting game development
			discussion.
		  FrikaC for achievements and for inspiration.
		  MauveBib for letting me bounce off ideas even during
			his busy times as the QExpo host.
		  id Software for various good things

Type of Mod
-----------
Quake C		: aye!
Sound		: no
MDL		: no
Level		: no
Gfx		: no
Wayboxes	: yes (one (1))

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no
context diff  : no
.qc files     : yes
progs.dat     : yes

Description of the Modification
-------------------------------
Initial release of my deathmatch bots, titled the UrreBot. Currently only
meant as a showcase mod for a "new" (read: rare in the Quake modding
community, supposedly OmikronBots do something similar, and HavocBots
also support it) navigation technique, known as "wayboxes". Instead of
navigating by points placed around on the map ("waypoints"), there are
volumes which cover as much of the open space as possible (anything
that's not solid). This produces faster search initiations (no
tracewalk/walkmove needed to check which waypoint the bot can access,
especially useful on slower map formats such as q2bsp and q3bsp) and
more accurate searching/execution (can cut corners due to volumes).

The bots are currently fairly simple, I will release future versions with
more interesting AI.

Many DarkPlaces extensions are required to run this mod. At the time of
writing only DarkPlaces reports these extensions as existing, but FTEqw
will also work if you remove a few of the extension checks (for some
reason they work even if it doesn't report them as existing). I'll leave
you the pleasure to find out which those are.

To add/remove bots, alter the "bots" cvar, and the mod will add/remove
bots to match that value.

The "bots_strategytime" cvar alters how often in seconds bots re-evaluate
their strategy, default is 0.5.

Known Bugs
----------
1) Bots do sometimes get stuck and look silly.
	Cause: Unknown.
	Solution: Strafe around until the bot looses all of it's ammo.
		  Then approach the bot with your Axe weilded, and win
		  the melee.
2) Bot colors don't update.
	Cause: Unknown.
	Solution: Whine to LordHavoc and Spike.
3) Bot doesn't visually turn in FTEqw.
	Cause: Unknown.
	Solution: Whine to Spike.
4) Banana is green.
	Cause: It is not ripe.
	Solution: Wait.

Legal
-----
Authors MAY use this Quake modification as a basis for other publicly
available work, as long as I am credited. Please send me any modifications
you make.

You may distribute this Quake modification in any electronic format as long
as this description file remains intact and unmodified and is retained along
with all of the files in the archive.

You are not allowed to sell this Quake modification for money without my
permission.

Quake is copyrighted and trademarked, owned by id Software.