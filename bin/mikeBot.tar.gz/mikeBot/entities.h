/*
**  support class for bspFile
**  (c) 1997 mike warren
**
**  this code is *not* freeware. See the file ``README'' or contact
**  mbwarren@acs.ucalgary.ca
**
**  (excuse the rather long ::read() inlined functions, but i didn't feel like
**   having lotsa .cc files :) )
**
*/



#ifndef _ENTITIES_H_
#define _ENTITIES_H_

#include "mfile.h"
#include "defines.h"
#include <fcntl.h>
#include <stdio.h>

class bspEntities
{
  int dataSize;
  char * data;

  bspEntities(){}			// no NULL ctor

public:
  bspEntities( mFile & mf, int x )
  { 
	  dataSize=x;
	  data = (char *)mf.readChunk( x );
  }
  ~bspEntities() { delete data; }

  char * getEntities() { return data; }
  int getNum() { return dataSize; }

  void dump() { for( int i=0; i < dataSize; i++ ) putchar( data[i] ); }

};

#endif
