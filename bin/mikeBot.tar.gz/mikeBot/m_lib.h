/*
**  m_lib
**  mike warren 1997
**
**  Some basic C++ template type, like linked lists, queues, stacks, etc.
**
*/


#ifndef _MLIB_H_
#define _MLIB_H_



#endif
