/*
**  cmdFlags
**  mike warren 1997
**
**  Some proprietary cmd. line parsing things for mikeBot
**
*/



struct cmdFlags
{
  char * filename;		// demo file name. (char *)0 if none
  char * address;		// address specified; (char *)0 if none
  char * configfile;	// name for config file
  char * pakpath;		// path to pak files
  int port;

  cmdFlags( int argc, char **argv );
  ~cmdFlags() 
  { 
	  delete[] filename;
	  delete[] address; 
	  delete[] configfile; 
	  delete[] pakpath; 
  }

private:

  cmdFlags(){}
    
};

