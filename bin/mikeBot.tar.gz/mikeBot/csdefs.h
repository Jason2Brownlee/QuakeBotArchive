/*
**  client-server message types
**
**  (c) 1997, mike warren 
**  mikeBot
**
**  thanks to a.oliber and the Unofficial Quake Network Protocol Specs, 
**  available at:
**
**		http://www.upd.edu.ph/~oliber/quake/
**
*/


#ifndef _CSDEFS_H_
#define _CSDEFS_H_

#define CS_KEEPALIVE  (unsigned char)0x01
#define CS_DISCONNECT  (unsigned char)0x02
#define CS_ACTION  (unsigned char)0x03
#define CS_CONSOLE  (unsigned char)0x04

#define CCREQ_CONNECT			(char)0x01
#define CCREQ_SERVER_INFO		(char)0x02
#define CCREQ_PLAYER_INFO		(char)0x03
#define CCREQ_RULE_INFO			(char)0x04

#endif
