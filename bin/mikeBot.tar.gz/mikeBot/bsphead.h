/*
**  support class for bspFile
**  (c) 1997 mike warren
**
**  this code is *not* freeware. See the file ``README'' or contact
**  mbwarren@acs.ucalgary.ca
**
**  (excuse the rather long ::read() inlined functions, but i didn't feel like
**   having lotsa .cc files :) )
**
*/



#include "defines.h"
#include "mfile.h"

class bspEntry
{
  int offset;
  int size;

public:
  bspEntry() { offset=0; size=0; }
  bspEntry( mFile & mf ) { read( mf ); }

  void read( mFile & mf ) { offset=mf.readLEint(); size=mf.readLEint(); }
  int getOffset() { return offset; }
  int getSize() { return size; }
};
    

class bspHead
{
  int version;
  bspEntry * entries[ 15 ];

  bspHead() {}			// no NULL ctor

public:
  bspHead( mFile & mf ) { read( mf ); }
  ~bspHead()
  {
	  for( int i=0; i < 15; i++ ) delete entries[i];
  }


  void read( mFile & mf )
  { 
	  version = mf.readLEint(); 
	  for( int i=0; i < 15; i++ ) 
		  entries[i]=new bspEntry( mf );
  }

  bspEntry & getEntry( int index ) const { return *entries[ index ]; }

  int getVersion() const { return version; }

};

  
  
