/*
**  polygon
**  mike warren 1997
**
*/


#include "vector.h"

#ifndef _POLYGON_H_
#define _POLYGON_H_

class polygon
{
  int numVertices;
  int maxVertices;
  int oldVertices;
  vector * vertices;

  int pointInWithLine( vector & );
  int pointInByTurning( vector & );
  void realloc();

public:
  polygon();
  ~polygon() { delete[] vertices; }

  void reset() { numVertices=0; }

  vector getOrigin();
  int getNumVertices() { return numVertices; }
  
  void addVertex( vector & x );
  void dumpPoly();
  int pointIn( vector & );

};
  

#endif

  
  
