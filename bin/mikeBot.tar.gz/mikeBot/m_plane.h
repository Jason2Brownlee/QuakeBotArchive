/*
**  m_plane
**  mike warren 1997
**
**  plane class
**
*/


#ifndef _M_PLANE_H_
#define _M_PLANE_H_

#include "vector.h"

class m_plane
{
public:
	enum type_t { unknown, x, y, z };

protected:
	float m_distance;
	vector m_vNormal;

	type_t m_eType;

public:
	m_plane() { m_distance=(float)0.0; m_eType = unknown; }
	~m_plane(){}


				//
				//  some "access" functions
				//

	type_t type() const { return m_eType; }
	void type( type_t t ) { m_eType = t; }

	vector normal() const { return m_vNormal; }
	void normal( vector & n ) { m_vNormal = n; }

	float distance() const { return m_distance; }
	void distance( float x ) { m_distance = x; }

};


#endif