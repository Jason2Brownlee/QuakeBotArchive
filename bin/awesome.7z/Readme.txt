Hi there QuakeHead!

Well, this is my first Pak File, and I reckon it rocks !!!!!!!!

OK, it's actually based heavily on Steven Polge's Warbots v2.0,
which evolved from the good ol' days of the reaper Bot :-)

Check out the Bots in Unreal for more of Steven's awesome work!

Anyway, basically new sounds, and an intense map (bulka.bsp) I 
made with Worldcraft. Included is the readme from Warbots v2.0,
so you can assign all aliases, etc ... Also my config is here
too (bulka.cfg). Have fun, and please feel free to tell me what
you think !

Brett King. <frag@cyberelectric.net.au>
ICQ 9358941