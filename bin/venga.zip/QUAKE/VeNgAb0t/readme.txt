
VERY VERY IMPORTANT: If the addbot command doesnt work type : exec frontend.cfg at the console!!!
That should fix it.


VeNgAb0T V0.01

Mission Statement
-----------------
VeNgAb0T is a natural progression from the Fo0KBoT.

The fookbot was simply a modification of the Frogbot v0.12c by Robert Field.

The Vengabot is going to be a different kettle of fish.

Whereas Fo0K was minor text changes and implementation of existing source,
Venga will consist of major source changes to V0.13 test.

Some of the things I want to implement are :

Everything the Fo0KBoT had plus :
Rocket Jumping (Intelligent not just random)
Advanced roaming and hunting without using waypoints.
Ping simulation.
Bot characteristics such as camping, defensive play etc. Weapon preference etc
Chat (sarky Comments)
Teamplay options using .loc files.
Better bot spawning options.
No text addition files the whole thing should be just 2 files (maybe 3 heh)..Implmented!!!
KT emulation (I dont have source so must guess)
The tiers...add bots by tier!!.
Add bots by team...all KTF ers for example.
more to be added to this list as it occurs to me.


Things I will not be implementing : 
Any other mods or deathmatch options, this thing will be hard coded for 
Deathmatch 3 match play with FFA or Team Play options, powerups on.
That stupid blood thing I had in the Fo0KBoT which was just plain lamb.

WuPP
12/7/99


Change History
--------------

30/7/99 - 20/8/99
Didnt do much actually..played Quake more than developed it.
Hard coded the skins into the system for both NQ and QW.
Did a lot of reading up on Quake C and disabled a lot of
what I can only describe as crap in the Frogbot Code and added a lot of 
crap of my own.

Added the Thrash UKCML 4 peeps. (CCT no longer exists)

KT source donated (thanks Lordy)...now I can get down to some serious shite.


12/7/99 - 30/7/99
Familiarisation with the new 0.13 code.
Hard coded CCT Season 3 names into the system.
Played about with the skill levels and have sorted out who needs what.
Disabled the console and arcade games in 0.13.
Added MOTD (2 screener one)...thanks EraZor. (nicked his code..;\)
Stuck the new botgoals.qc file in.
Faffed about with the .cfg files a bit.


The Tiers
=========

One (Red)
---------
Anarchy
Carp
Joker

Two (Orange)
------------
Overlord.UK
Julio
Skelator
Blitz
Asheesh

Three (Yellow)
--------------
Gizmo
Jilted
Stimpy
Dave
Ash^2

Four (Blue)
-----------
Raptor
Dogers
Nicky
Baj
SRES

Five (Purple)
-------------
Lazygun
Swordsman
Sanjiyan
Firepower
Mr Grumps

Six (Green)
-----------
Ida Noooooo
Mr Jolly
WuPPerTaL
FoulOleRon
Sinner

Seven (Cyan)
------------
Baz
Nosher
Nez
Toxic
><)))'>

Eight (Brown)
-------------
Nightowl
D.Shadow
Vimes
Hypodermic
Robocop

