=========================================================================================
Date		: 24.01.99
Creator		: Rick Law
Nickname	: Skorpion
Website		: Skorpion's Omibot Page
URL		: http://planetquake.com/skorpion
E-mail		: skorpion@planetquake.com
==========================================================================================
	
Type Of File 
-------------
An Omi-Route (.ent) Pak File).


Description Of Omi-Route Pak File.
-----------------------------------
When installed, omicron bot 'waypoints' will be hardcoded into the corresponding maps 
giving the omicron bot preknowledge of the levels and vastly improving bot gameplay. 


Contents Of This archive.
--------------------------
omi-route files (.ents)
txqbsp.exe (QBSP)
install_pak.bat (installation batch file)
This readme.txt


Installation Of The Route Pak
------------------------------
(1) First make sure all corresponding levels (.bsp) are installed in the quake/id1/maps 
directory.
(2) Unzip this entire archive into the same directory as the one containing the target
levels and if prompted to overwrite files, click yes.
(3) Click the batch file (install_pak.bat) located in the same directory. 
(4) Installation will only take a couple of seconds and once complete play the levels 
with omi-bots as usual.
(5) You will have the option of deleting or saving all installation files, just press 
y/n when prompted. (I would recommend saving QBSP, as it is required if other routes are 
to be installed in the future).

NOTE: Installation of Omicron .ent files into .bsp files will 'NOT' affect your game when 
not using the Omicron Mod, or disable you to connect to servers using standard maps.


Omicron Bot Homepage
--------------------
http://www.botepidemic.com/gladiator/obots/obots.html

The Omicron Bot Mod is available from the above URL.
 
============================================================================================

			    
                         

		    






                                 
                        

 				 