		                 'SKORPION'S OMIBOT PAGE'
URL:	                      http://www.planetquake.com/skorpion
E-mail:                            skorpion@planetquake.com
-------------------------------------------------------------------------------------------------
                      		     "Omi-Dapak Mod"
				------------------------
				      Installation:
Unzip all dapak levels into your "quake/omicron/maps" directory. If the directory doesn't exist, create it. All 12 levels have "omi-route" files installed, so as to obtain the very best omibot gameplay possible.
Be sure to install the "mapcycler script" included in this archive.
If you have downloaded this mod, I would love to hear from you regarding your thoughts on it. 
Have fun...Skorpion
-------------------------------------------------------------------------------------------------




																	

			         
			         



 