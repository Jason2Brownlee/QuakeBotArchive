=========================================================================================
Date		: 24.01.99
Creator		: Rick Law
Nickname	: Skorpion
Website		: Skorpion's Omibot Page
URL		: http://www.planetquake.com/skorpion
E-mail		: skorpion@planetquake.com
==========================================================================================
	
Type Of File 
-------------
An Omi-route (ent file).


Description Of Omi-route file.
------------------------------
When installed, omicron bot 'waypoints' are hardcoded into the map giving 
the omicron bot preknowledge of the level and vastly improving bot gameplay. 


Contents Of This archive.
-------------------------
An omi-route file (ent.)
This readme.txt


Installation Of The Route
-------------------------
Unzip this archive into the same directory as the one containing the target
level (usually quake/id1/maps).
Then place QBSP (available from files page on my site) into the same directory also.
Open A DOS window, go to the directory and type after the prompt:  
"txqbsp.exe -onlyents mapname.ent" (minus the quotes, and mapname.ent 
being this .ent file).
Hit ENTER and the route will be hardcoded into the map.

This will only take a couple of seconds and once complete play the levels with omi-bots
as usual.

Installation of Omicron .ent files into .bsp files will 'NOT' affect your game when not
using the Omicron mod, or disable you to connect to servers using standard maps.

If your going to be installing a lot of routes, create a batch file and name it 
install.bat and place it in the same directory.
The command line would look like this: "txqbsp.exe -onlyents mapname.ent"
Then edit "mapname.ent" everytime you install a new route. 
Run the file install.bat to start the installation of the route into the map.


Omicron Bot Homepage
--------------------
http://www.botepidemic.com/gladiator/obots/obots.html

The Omicron Bot Mod is available from the above URL.
 
============================================================================================

			    
                         

		    






                                 
                        

 				 