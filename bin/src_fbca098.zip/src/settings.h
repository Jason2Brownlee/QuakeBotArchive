// Public
//#define QUAKE
//#define MANUAL
#define TALK
#define ARENA // Asdf

// Private
#ifndef QUAKE
#endif
