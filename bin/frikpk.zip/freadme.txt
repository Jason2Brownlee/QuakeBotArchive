Title    : FrikBot in PainKeep v1.11
Filename : frikpk.zip
Version  : 0.09
Date     : 2-26-00
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Alan Kivlin for his rankings.qc and step movement
Frog for releasing the Frogbot code and giving me a good goal
to shoot for.

Additional thanks to Wazat, Asdf and MaNiAc who helped immensly with suggestions, code snipplets and ideas.

A large chunk of thank-yous to the folks over at Team Evolve who put together a really great add-on for Quake. This is one mighty fun little pack!

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : no
progs.dat     : yes (and qwprogs.dat)



Description of the Modification
-------------------------------

Painkeep is one mighty fine deathmatch add on for classic Quake. You know what, though, many people miss out on the shear coolness of the mod simply because there is no single player aspect. Ahh what FrikBot can do! :) This is an update to my old frikpk, which now includes the FrikBot 0.09. Also, I have chosen to update the QuakeWorld version of the mod too, have fun! :)
                          
How to Install the Modification
-------------------------------

You must have the original Painkeep file to use this add on. Painkeep may be found at http://www.teamevolve.com/products/

Copy all files into your Painkeep directory, DO NOT OVERWRITE ANY PAK FILES.



Impulses
===========
100 Add a bot or add a bot to your team in a team game
101 Add a bot to an enemy team
102 Remove a bot
103 Bot Cam cycle. Cycles through the view of all bots & players currently on the server
104 Dump Waypoint data to console


Technical Details
-----------------

Known Bugs
==========
* Bots will not use the special items (bear trap, etc.) They simply don't select them.

For general FrikBot bugs, finger frika-c@mdqnet.net or visit the Dept 187 webpage


Availability
------------

This modification is available from the following places:

Department 187 at http://www.mdqnet.net/dept187/



