This readme should have came in the zip file fbprevw.zip.

Purpose:
The purpose of this program is to allow you to View bot files without the need to load them in a editor.

How to use:
1. Unzip the program in the same directory as FBEdit, or anywhere you want to. 
Run it once, and from that point on when you Right-Click on a bot file in Windows, the option to View the 
bot will be present in the menu. Select View and the details of the bot will be shown to you.

Troubleshooting:
Well, there is no error checking, other than the check for legitatimate values in the bot file. 
If you edited a bot manually, and screwed it up by not following the structure that is needed, then the 
program will probably just not do anything. 
I highly suggest using FBEDit to edit your bot files. It is the easiest and fastest way to create bot files.

Homepage, support, links etc.....
The homepage for FBEdit and FBPrevw is located at http://qnm.telefragged.com
To get the latest version of the Quake mod FROGBOT, go to http://www.telefragged.com/metro
For other Frgobot related news and bot information, go to http://www.telefragged.com/fmods
My email address is bspbuild@telefragged.com. Email me if you have questions or concerns about this
program. To get the Frogbot mod working on your system, you need to go to one of the above links. I just
make the Programs, not the modified Quake bot.

* end of text file *