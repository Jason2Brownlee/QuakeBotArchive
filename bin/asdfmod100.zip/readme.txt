Title    : AsdFMod
Filename : AsdFMod100.zip
Version  : 1.00
Date     : Thursday, February 11, 1999
Author   : Matt McChesney
Email    : mtm07@hotmail.com

Download : http://www.botepidemic.com/fmods/

Credits  : id Software - Quake
	   Robert "Frog" Field - Frogbot
	   Mike "MaNiAc" Turitzin - TONS of help with QuakeC
	   Andrius "Wrecker" Jovaisa - FMods
           All the people who made the map files
	   Everyone else who I forgot to mention


Type of Mod
===========
Quake C  : yes
Sound    : no
MDL      : no  
	

Format of QuakeC (if a Quake C Mod)
===================================
unified diff  : no
context diff  : no
.qc files     : no
progs.dat     : yes


Description
===========
This is a modified version of the Frogbot Quake Mod by Robert "Frog" Field. It makes each bot more customizable and adds some other miscellaneous things like talking bots, drop runes, drop quad/ring, and manual frogbot mode.


New to this version
===================
- bottalk
- teamtalk
- favorite and highest instead of rl_pref
- maxspeed
- probably some other miscellaneous things


Instructions
============
Unzip everything to a folder in your quake directory (eg. quake\asdf\). I suggest putting this in a different directory than the one you use for the frogbot. Your old bot files will not work with this modification. To run the game, this is what I usually do:

c:\quake\glquake -game asdf -listen 16 -zone 2048


Commands
========
Type "commands" in the console for a list of all the commands. 

Here's a description of all the stuff:

rules		: display current map rules (deathmatch, timelimit, etc.)
botsetup	: display current bot setup (name, skill, color, etc.)

addbot		: adds a Frogbot
removebot	: removes one Frogbot
removeallbots	: remove all Frogbots
frogbot		: become a Frogbot (use again to go back to player mode)
kascam		: become an observer (use again to go back to player mode)

+hook		: launch modified grappling hook ("hook" has to be enabled)
drop_rune	: drop current rune ("rune" has to be enabled)
time		: prints current time in match mode
ready		: starts match (match mode only)

map_dm4		: change map to dm4
map_dm6		: change map to dm6
map_ztndm3	: change map to ztndm3

deathmatch_x 	: replace x with 1, 2, 3, 4, 5, or 6 (eg. deathmatch_3)
teamplay_x 	: replace x with 0, 1, 2, 3, 4, or 5 (eg. teamplay_2)
timelimit= 	: followed by impulse x, where x = time in minutes
fraglimit= 	: followed by impulse x, where x = # of frags
bottalk		: toggle whether the bots will talk normal stuff (such as "nice shot!")
teamtalk	: toggle whether the bots will say team messages (for example: "I have QUAD!")
match		: toggle match mode, if enabled, type "ready" to start match
hook		: toggle grappling hook
powerup		: toggle powerups (quad damage, pentogram of protection, etc.)
dropquad	: toggle whether powerups will drop like a backpack when you die
rune		: toggle runes
qwphysics	: toggle quakeworld style physics
qwaim		: you will aim more towards the crosshair
hide		: hide some messages to make it more like a real game (not recommended)
manual		: toggle manual control of the frogbots, see Manual Frogbots
maxspeed	: toggle different maxspeed so you can't zig-zag or wall-strafe to go faster

lettercodes	: prints all the impulses for the different letters (used with name=)
name=		: sets a bot's name, see next section
end		: sets a bot's name, see next section
setname		: set your name to whatever you put in name=

shirt_x 	: replace x with 0-13, or r (r = random)
pants_x		: replace x with 0-13, or r (r = random)
skill_x		: replace x with 0-3, or r (0 = lowest, 3 = highest, r = random)
aimcheat_x 	: replace x with 0, 1, or r (r = random)
lookcheat_x 	: replace x with 0, 1, or r (r = random)
lavacheat_x	: replace x with 0, 1, or r (r = random)
favorite_x 	: replace x with 1-9, or r (1 - 8 = weapon, 9 = rl/shaft como, r = random)
highest_x 	: replace x with 1-8, or r (1 - 8 = weapon, r = random)

msg_x 		: replace x with 0, 1, 2, or 3 (0 prints everything, 3 prints nothing)
noflash		: toggle whether you want the screen to flash when you pickup items or get hurt


Manual Frogbots
===============
This is to let you take control of the Frogbots. You can see how Frog's bot physics compares to the real player physics. I usually go to kascam mode, type "manual", then track a bot. These are the commands you'll have to bind to use this feature: 

+b_forward
+b_back
+b_left
+b_right
+b_moveleft
+b_moveright
+b_lookup
+b_lookdown
+b_jump
+b_attack


New bot files
=============
I only made one example, but this is how they're set up. First type "exec thresh.bot" then type "addbot". Just open thresh.bot up in edit, wordpad, or notepad to see how they are made.

The following is how you would customize a bot.

name=		followed by the characters of the name, then "end".
shirt_x		where x = the color number (0-13) or r for random.
pants_x		same as shirt (x = 0-13 or r)
skill_x		where x = 0, 1, 2, 3, or r
aimcheat_x	where x = 0, 1, or r
lookcheat_x 	where x = 0, 1, or r
lavacheat_x 	where x = 0, 1, or r
favorite_x 	where x = 1-9 or r
highest_x 	where x = 1-8 or r

Again, to see an example of how to use this, look at thresh.bot in a text editor. 

For the characters, open up autoexec.cfg to see some of the different letters you can use. In general, if it is a single letter ("a") it's lowercase. If it's a double letter ("aa") it's capital. If there's a dash after it ("a-") then it will be red colored.

Also note that for teamplay I created 3 bot files: one for blue team (b.bot), one for yellow team (y.bot), and one for red team (r.bot).

Maps
====
These are the maps that "work".

aggressr
aerowalk
dm3
dm4
dm6
e1m2
efdm5
efdm6
efdm8
elorena
fribweb1
frobodm2
newdm
q1_q2dm1
rapture1
spine
spinev2
strafin4
ukooldm2
ukooldm6
unddm2
ztndm1
ztndm2
ztndm3
ztndm4
ztndm5

Go to FMods (http://www.botepidemic.com/fmods/) to figure out who did which maps.


Known Bugs
==========
* When you are in manual frogbot mode, you can make the bots change weapon by doing impulse 1-8, but their frames will get messed up, so in autoexec.cfg I bound 1-8 on the keyboard to impulse_1 - impulse_8. This is just a really ugly hack and I should fix it sometime.

* When you have "maxspeed" enabled, you can't slide along the floor very fast (eg. being pulled by grappling hook).

* When the bots shoot a secret door with rl, if bottalk is enabled, they will say something as if they hurt someone.

* Drop quad/ring makes it crash sometimes. When Frog releases his the next version, I will remove this.

E-mail me if you find any more bugs: mtm07@hotmail.com


Author's Note
=============
This mod is not supported by Frog and it's not my fault if your computer falls out the window, explodes, spontaneously combusts, gets trampled by a herd of buffalo, gets fried because you left the cover off and a stray cat decided to mark his territory while it was on, or anything else for that matter. If you have any problems, questions, comments, etc., e-mail them to mtm07@hotmail.com.


Copyright and Distribution Permissions
======================================
The modifications included in this archive have no copyright! The original Frogbot source is Copyright 1998, Robert Field. The original QuakeC source is Copyright 1996, id software.

You may distribute this Quake modification in any electronic format as long as all the files in this archive remain intact and unmodified and are distributed together.