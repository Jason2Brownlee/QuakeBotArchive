Title      : Kooliobot!!!!!!
Filename   : koolio.zip
Version    : 1.0.0
Author     : Koolio (Robert de Heus)
Email      : vladski@flash.a2000.nl
ICQ	     : 45625330
Web site   : www.botepidemic.com/koolio
Other mods : I did some but they were lost during my last format
Credits    : Coffee for the Tutor bot and his tuts
		 Stalker for the base locational damage code (which I improved not written)
		 and for the new weapons he will be making for the next mod....first up is 
		 a molotov....
		 Frika-C for his colored msg code and a LOT of advice.Tenx dood!
		 DJ for his tuts and info
		 RiEvEr for his tuts.
		 Beginner for some help with my site
		 The authors of the Skins (i couldn't contact them for permission)
		 Anyone else that helped me (there's too many to remember)
             and most of all:ID Software without 'em the Kooliobot would 
		 be kinda useless now would it?


Type of Mod
-----------
 Quake C  : yes
 Sound    : yes
 MDL      : yes


Format of QuakeC
----------------
 unified diff  : no none 2day
 context diff  : no, don't like 'em
 .qc files     : nope
 progs.dat     : yes

Description of the Modification
-------------------------------

NO NEW IMPULSES :) OK I lied there are new impulses hehehe.


This mod gives you the Kooliobot!!Me likes da name but if you don't like it....
well I don't care actually :)
It has some kewl features:

- Locational Damage (shoot them in the head for some fun =D  )
- The regular Shotgun is removed and replaced by a sorta nail firing out of
  the shotgun which travels faster then regular nails
- Nails go faster then usual
- New sounds added to some weapons and all the player sounds are replaced
- They can form simple lines as: "I respect your Authoratah!" out of multiple words
- Have different attack patterns depending on class (which is randomly chosen)
- last man standing: U got 5 frags and lose 1 for dying when U out of frags yer out and have ta watch
- Bomb Squad: Bot's sometimes drop a bomb and U have ta find it within da minute or it is BOOOM and you
  lose all yer frags.If you succeed U get a nice little 5 frags.
- paintball mode: Shoot paint all over yer bots and get 10 frags when U kill 'em.The bots can aim this
  puppy really good so this mode is 4 die-hards only hehehe
- Bots and players have to reload their shotty after 6 shots
- Bot's talk to you when they have something to say like : "I just can't kweek!"
- They have multiple attack pattern wich basicly means that when they have the super shotty they'll 
  chase you wich is very deadly cuz they aim so good and stuff like that
- Bots appear on the scoreboard
- Bloodspat's fly off you as you get shot
- A flashlight
- Multiple difficulties which are randomly chosen
- An offhand graplling hook
- They play co-op mode
- The hanging zombie is changed into a crucified player with an axe hanging out of his
  chest and you can shoot him...
- Maybe some stuff I forgot......Dunno...Tell me if you find anything not listed here 
  (I did so may stuff since first release I don't remember everything I did)


That's about it I guess,OK so now we move on to the impulses and stuff

Impulse commands:

impulse 20:		reload shotty
impulse 30:		toggle flashlight
impulse 100:	add a bot
impulse 101:	add a friendly bot (teamplay mode only)
impulse 102:	teleport bot to your location

impulse 104:	shos the amount of bombs currently dropped
+hook:		throw the hook

Deathmatch modes:

deathmatch 3:	Bomb squad
deathmatch 4:	Paintball
deathmatch 5:	Last man standing


Ok dat's dat!

And now on to the Locational Damage....
I'm very proud of this I don't know of any other bot which has this
It works for anything that bleeds to so you can headshoot an ogre,and the grunts etc....
But beware cuz the nailshooters in levels also give you headshots hehe...
There are three different zones to shoot:the head,the chest and the legs...
If you shot someone in the head he dies almost instantly since this does
whack-ass damage, a chestshot does normal damage and a legshot does a little
less damage than normal (I'm gonna add a slowdown for legshots)


 [what's still left to be done?]
- well...add it so that you and the bot's slow down when leg-shot
- Add some stuff for normal SP too like strafing grunts

Also a new mod which incorporates the Kooliobot will be released soon!
It will feature about 24 new weapons and maybe some other new stuff


Revision history
----------------

 1.0.0 - This release
 0.1.2 - First release



How to Install the Modification
-------------------------------
 Make a sub-directory in quake called 'koolio' or something and unzip all the files into
 it using winzip.

 From directory 'quake' type:
   quake -game koolio	
   if U wan't more than 3 bots add the -listen 16 command making it look like so:
   quake.exe -game koolio -listen 16

 Start a new DM game and there they are, waiting for you to deliver them from their pain >=)

Known Bugs:
-----------

 Dunno, U tell me

Copyright and Distribution Permissions
--------------------------------------

 Authors MAY use these modifications as a basis for other
 publically available work IF you give me $10.000.000
 OR U can make yer own bot with the help from
 Coffee at the AI cafe.heheheh If you do so, please give him CREDIT!

 You may distribute this Quake modification in any electronic
 format as long as this description file remains intact and unmodified
 and is retained along with all of the files in the archive and no fees
 other than the costs of distribution are charged.

