Eliminator Bot for id Software's Quake
--------------------------------------

Archive Version 1.4  (Public Release)
CBOT-Engine Version 1.4

Copyright 1996, Cameron B. Newham.


0) What this is About
1) What's New in this Version
2) Unpacking the Archive
3) Installing the Patch
4) Using the Patch
5) Bugs
6) Legal
7) Credits



0. What this is About
---------------------

The Eliminator Bot package provides you with some decent adversaries
to play Quake against.  Don't have a network connection?  Maybe you
have a $100,000 LAN at home but no friends... Well, here is the
answer to your Deathmatch dreams.  These automated deathmatch opponents
are by no means friendly and they'd just love to kick your sorry
behind all over the place.  What's more, they aren't stupid like
most of the other bots out there.  These know how to fight and know
their way around.

Please note that this is a Deathmatch patch. The Bots are designed
specifically for playing against other deathmatch players - not
monsters.  These Bots are *not* "helper" bots.  Indeed, the only help
you'll get from them is a a rocket in your face.

For updates, see the CBOT homepage:

http://www.iinet.com.au/~cam/quakec.html


Features include:

  * Bots have knowledge of Quake levels (currently only "start" and 
    "e1m5" (Gloom Keep)).
  * Bots are able to pick up all items (health, armour, weapons, 
    ammo, specials).
  * Bots start off with a shotgun and aquire equipment just like a 
    player.
  * Bots know how to swim and can navigate over "broken ground".
  * Bots don't just blindly fire - bots will only attack if they are
    in a position to do so or want to.
  * Bots are able to camp (if they want to).
  * Bots are able to activate all of the triggers on a level (eg:
    buttons, doors, etc).
  * A maximum of 10 bots can be created - each with its own name.
  * You can specify the number of bots to start with in a config file.
  * Bots regenerate at a new Deathmatch location after being killed.
  * Based on the Player model.
  * An Observer Mode is included - watch the bots fight it out
    without getting in the way!
  * Display the bot and player gib scores.
  * Runs on the Quake server allowing it to be used in network games.
  * Ability to use the engine for your own maps - see the Waypoint
    Guide.
  * Bots can use a "skins" MDL to give them visual identities.



1. What's New in this Version
-----------------------------

Version 1.3 -> 1.4

* Fixed some bugs
* Added support for low gravity and proper handling of specials
* Added support for server lock (see below)
* Added circle straf and missile avoidance
* Added possible suicide shootout on very low health

Version 1.2 -> 1.3

* Hopefully fixed the bug that sometimes causes a "cl > cl.maxclients" problem

Version 1.1 -> 1.2

* Changed to using the player model
* Added skins capability (one line change! :)
* Increased the running speed of the cbots
* Added players (clients) to the Gib Score printout
* Gib Score printout is now local (not broadcast to everyone)
* Added better weapons handling AI - cbots now know not to use
  R/L or G/L up close (unless they have very good health), and
  limits use of the G/L over large distances. SNG and LG are
  only used for short/medium range
* Tweaked some parameters
* Fixed a bug in id's code w.r.t attenuated death sounds (cbots ONLY -
  I didn't fix this for players... perhaps I should have)
* Removed an old id debug use for "temp1"

Version 1.0 -> 1.1

* Observer Mode is fixed; Observers are now invisible to other players
* cbots now fight even when they are stuck
* cbots are much more willing to initiate an engagement if they only
  have a shotgun
* START and E1M5 have some small changes/fixes
* Added a startup definition for the number of cbots to generate
  on starting a level (useful for servers)
* fixed priority waypoint detection so it's limited by pitch
* fixed MODE determination for engage and disengage attack
* tweaked targetting
* tweaked a few other parameters
* cleaned up some of the code



2. Unpacking the Archive
------------------------

This archive should include the following files:

README.TXT        - This file
PROGS.DAT         - The compiled Quake C code
START.MAP         - The entities for the start level
E1M5.MAP          - The entities for Gloom Keep (e1m5)
ELIM14.TXT        - Template for FTP sites

Create a directory (eg: "ELIM") in your Quake directory. Also create
a MAPS directory under this.  Unzip the archive in ELIM. Move the
.MAP files to the MAPS directory.



3. Installing the Patch
-----------------------

You'll need a number things to install this patch:

  * An "unpacker" to extract the levels from the Quake PAK file
    I suggest something like "winpack".  Check out a Quake FTP
    site (eg: ftp.cdrom.com) for one.

  * QBSP or a derivative (eg: Power QBSP).  Check out a Quake
    FTP site for a version for your system.  There are also
    entity replacers available - you can also use these.

Unpack the levels from the PAK0.PAK file (in QUAKE\ID1). You only
need to extract START.BSP and E1M5.BSP.  Place these two files
in the your ELIM\MAPS directory.

Now, replace the entities (using QBSP or another entity replacement
program) with the ones defined in this archives MAP files.  For
example, using QBSP and in the ELIM\MAPS directory, you'd type:

  qbsp -onlyents start.map

and

  qbsp -onlyents e1m5.map

Make sure you *type -onlyents*. This will replace *only* the entities
and won't attempt to compile the BSP from the MAP file. If you forget,
you'll probably get an error - the MAP files only contain the entity
information and not the brush details.  If this has gone over your head,
don't worry - just follow the above instructions!

Also note that you don't have to use VIS or LIGHT on the files.

The MAP changes will now have been applied to the BSP files.  All you
have to do now is...

Run Quake.  Use the following command line to run it:

  quake -listen -game elim

This places Quake in Listen mode (Deathmatch) and tells Quake to
use the new PROGS.DAT and the new maps in your ELIM directory tree.

If you wish to use skins, you'll need a skins PLAYER.MDL file - a number
of these are available, one of them being in the Skins Patch.  Place the
PLAYER.MDL file in your QUAKE\ELIM\PROGS directory.

If you don't use skins this patch will still work but the cbots will
all look the same.



4. Using the Patch
------------------

Having started Quake you'll be at the START level - if you want to
try Gloom Keep, pull down the Quake Console and type:

  map e1m5

On either level you can create a cbot by typing

  impulse 166

at the Quake Console.  I suggest you bind this to a key. From the Quake
Console, type:

  bind b "impulse 166"

and then every time you hit the "b" key you'll get a cbot.

The following commands are available:

  impulse 166   - create a cbot (up to a maximum of 10).
  impulse 170   - view the gib scores for the cbots.
  impulse 180   - go to observer mode

Gib Scores include cbots and all humans (clients). An asterix (*)
is printed next to your own name.  If you are in Observer Mode you
won't appear on the list.

Observer Mode - when you enter this mode you won't be able to exit
it unless you change levels or specifically kill yourself using
the "kill" command at the console.  This is to stop people from
using this mode to their advantage in a human deathmatch.

In Observer Mode you can move around the map without affecting
it or other players.  Make sure you remain *inside* rooms to
be able to view other players.

It is possible to define a number of cbots to generate automagically.
If you set the Console Variable "temp1" to a number between 1 and 10
in a Quake Config file (see the Quake TECHINFO.TXT file for details)
this patch will generate that number of cbots when you start Quake.
Eg:  if you had the line

temp1 6

in a config file called CBOT.CFG in your QUAKE\ID1 directory, you'd
get 6 cbots generated on starting Quake with

quake -listen +exec cbot.cfg -game elim


If you add 10 to this number you can lock the number of cbots.
Players within the game will not be able to add more. So if
temp1 set to 15 will give you 5 cbots locked in place.  Players
trying "impulse 166" will get a message telling them its locked.


5. Bugs
-------

The following Bugs are known:

  * cbots occasionally get stuck (this is now a rare event)
  * cbots placed on levels other than those provided will *not* work.
    I haven't stopped creation for non-supported maps because I
    don't believe in restrictions.  With some examination, you should
    be able to work out how to make the cbots work on other levels
    (including your own!).  Note that the *source* code of the
    CBOT Engine isn't necessary for doing this.  BTW, making them
    work for other levels is a coding exercise - best left to those
    with a good grasp of level building and, perhaps, some Quake C
    experience.  See the Waypoint Guide for help.
  * Teams are not supported and would be hard to implement
    effectively.
  * When a cbot dies, the body may appear to move as it hits the 
    ground.
  * Sometimes cbots don't *appear* to lock on to a target completely
    and missiles may miss the intended target.
  * cbots cannot be removed once placed in a level except by changing
    levels.
  * cbots can probably change levels - but I have never seen it happen
    yet.
  * Setting temp1 to more cbots than there are DM entry points may result
    in Quake crashing complaining about out of Edicts. This is because
    the cbots will go into endless telefrags.



6. Legal
--------

Quake is a Tradmark of id Software.

All parts of this software not coded by myself are Copyright
id Software.

The CBOT Engine and associated MAP file components are Copyright 1996,
Cameron Newham.

This software is provided "as is".  There is no warrenty either
expressed or implied.  USE AT YOUR OWN RISK.  The author cannot be
held responsible for any loss or damages incurred from use of
this software.

You are permitted to copy and redistribute this archive AS LONG
AS THIS TEXT FILE and the other files in the archive REMAIN INTACT 
AND UN-ALTERED.

You are NOT permitted to use or modify any of the Engine source code
without express permission from the author.

You are permitted to use the CBOT Engine with other MAP file
information that you create or on any public or private Quake
server.



7. Credits
----------

Thanks to id Software for such an excellent game.

The following people kindly helped me Beta Test the patch:

Roger Bolton
Rowan Crawford ("Sumaleth" on IRC)
Ben Schaffer

Thanks also to

Thane Sherrington - idea of auto-generation of cbots on startup
Rene Post - the first to suggest using skins and asking for the
            player scores to be added to the Gib printout.

Also thanks to a few people who suggested straffing/shooting
and missile avoidance.

Thanks to everyone for helpful comments and suggestions and bug reports!


I hope that you enjoy this patch!

cameron newham (cam@iinet.com.au)

