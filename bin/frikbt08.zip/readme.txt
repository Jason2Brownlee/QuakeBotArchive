Title    : FrikBot
Filename : frikbt08.zip
Version  : 0.08
Date     : 9-19-99
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Alan Kivlin for his rankings.qc and step movement
Frog for releasing the Frogbot code and giving me a good goal
to shoot for.

Additional thanks to Wazat, Asdf and MaNiAc who helped immensly with suggestions, code snipplets and ideas.

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : yes 
progs.dat     : yes


Description of the Modification
-------------------------------

This bot takes a unique approach. Unlike all other bots I've seen, FrikBot actually pretends to be a player. When he fires his weapon, it's the same function that the player uses. It is all done through his button flags. In other words, the bot fakes all client functions, he looks like a Quake client not only to the people in the game, but also to the Quake C. So why did I make him fake client behavior? Well with him using all the player code, he automatically works with hundreds of mods with a few short lines of code added or changed. This bot will play by the game rules of nearly every mod out there. (though he doesn't always know the rules however)
                          
How to Install the Modification
-------------------------------

Make a subdir of your quake directory titled "frikbot" place all files in this archive, using your favorite unzip utility, in that folder. Start quake with the parameter "-game frikbot -listen 8". Choose multiplayer game from the main menu, set up your options and once in the game use "impulse 100" to add a bot.

Impulses
===========
100 Add a bot or add a bot to your team in a team game
101 Add a bot to an enemy team
102 Remove a bot
103 Bot Cam cycle. Cycles through the view of all bots & players currently on the server
104 Dump Waypoint data to console (see below)


The waypoint saving/loading system
==================================
This is a new feature in the v0.08 FrikBot, it's still in early development. Basically, you start quake with the command line parameter -condebug...after wandering around the map enough, you'll have created a whole slew of waypoints. Dump the info using impulse 104, quit the game and locate the qconsole.log in the FrikBot directory. You can then cut the waypoint dump out of the log and make a .way file. Please note, this thing is still being built, it may not work correctly, and I don't recommend the average user to try it. (As the waypoint format will be changed in v0.09). However, if you like to goof off with weird stuff, go ahead.

Any suggestions, please mail me at frika-c@earthling.net


Technical Details
-----------------

Known Bugs
==========
!!IMPORTANT!! BOTS LOVE LAVA! DO NOT MAIL ME SAYING THE BOT FALLS IN THE LAVA A LOT, I KNOW! The movement AI is in it's early stages. This will be improved as new versions are released.

A detailed buglist can be obtained by fingering frika-c@mdqnet.net
More? Email me with your bug finds at frika-c@earthling.net

If you'd like to incorporate this bot into your Deathmatch/Coop mod see bot.qc for details.


Revision History
----------------
Changes since v0.07
-------------------
* Removal of Norse movement. Gone. Started work on new movement AI from scratch.
* scratch1 is no longer valid. Don't use it.
* Implementation of ported Quake physics (don't ask, don't tell is all I will say)
* Bots are now MOVETYPE_WALK. They said it couldn't be done, hah!
* Massive code restructuring, moved code into many files instead of cramming it into three. This was done to really help more with development than anything else.
* Various bug fixes. I can't even remember half of them.
* This is a major rewrite of most of the bot.


Changes since v0.06
-------------------
* Bots viewing angle performed more realistically
* Code restructuring, please pay attention to the upgrade.txt and the new instructions in the comment.
* Finally corrected some troubles with the norse movement, including water jumping and gobs of wasted code.
* Integrated botcam. Use impulse 103 to activate.
* Corrected a bug in the installtion comment
* Bots are thrown around by explosions, I can't believe I missed this before :(
* Bots will switch weapons less often to make some mods less confusing
* Bots will switch to a "close range weapon" sometimes rather than backing off in fightstyles 1 & 3
* New bot roaming method called "Hook Navigation", bugs are still being ironed out on this new roaming concept.
* fisible() improved to work properly with SOLID_BSP objects
* Bots will attack secret doors, & buttons . Helps immensly in some levels.
* Implementation of "scratch1" to adjust bot framerates
* Bots will automatically stagger their think times against other bots so they all don't execute their think at the same time, causing a major slowdown.
* Implementation of check_forward() to improve (ahem) standard roaming.
* Special guest appearance of "JamesBond" as a bot name, in honor of the version number (0.07)
* Misc. other bug fixes


Changes since v0.05
-------------------
* Bot colors show in GL Quake!! Woohoo!!
* Implementation of fov(). Bots now have a limited field of view.
* Bots also have damn good hearing :)
* Bot angles correspond to their view.
* FL_ONGROUND hacks allow better compatibility with some mods.
* Bots have a new fightstyle.
* In teamplay, bots will choose the enemy team with the fewest players when using impulse 101
* Misc. bug fixes and movement hacks.

Changes since v0.04
-------------------
* Implementation of fisible(); a minor improvement over the id standard visible code.
* A bug where in very open levels, the bots would not switch targets upon death, fixed
* Impulse comands moved to a function inside bot.qc, to aid in future updates/changes
* Waypointing disabled in single player
* Bots use client connect again!
* Bots know how to play teamplay deathmatch. Set teamplay to nozero and enjoy!

Changes since v0.03
-------------------
* Bot targeting moved to a priority system
* Bots now fight in a variety of fight styles (circle strafe, hold distance)
* Bots have a delayed sight time
* Bug involving clients being added/removed after a bot has spawned fixed
* Bots select weapons via impulses, chance of discharge in water lowered
* Copyright permissions, new readme format.

Changes since v0.02
-------------------
* Bot's Water Jumping really works now!
* Improved roaming
* Different chat messages and bot names
* Improved comments throughout the code
* KickABot(); implemented to remove bots from the server
* Numerous bug fixes

Changes since v0.01
-------------------
* Bot's Water Jumping now works.
* Bug where any weapon fired using self.v_angle would fire at the wrong pitch
* Error in the comment telling you how to install fixed
* General improvements in the comment.

Copyright and Distribution Permissions
--------------------------------------
FrikBot, and all functions and code writen by Ryan "Frika C" Smith are copyrighted (C) 1999. You are allowed to use and distribute this mod as long as this text file remains intact and the mod is provided free of charge. You *are* allowed to modify and incorporate this bot into your own mods, as long as adequate credit is given and the end result of your modifications is also provided free of charge. If you have questions or comments regarding the bot, the code, or just the universe in general, please write me at frika-c@earthling.net.


Availability
------------

This modification is available from the following places:

Department 187 at http://www.mdqnet.net/dept187/


