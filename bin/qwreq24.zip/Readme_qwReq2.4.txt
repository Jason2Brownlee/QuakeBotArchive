Quakeworld Requiem
2.4 Public Release  -= September 29th 1999 =-



This file covers
*	Installation
*	Changes




Installation_______________________________________________________                                                       

1.	Installing the server.cfg (do to cfg changes, this should be done)

	* Fist thing that should be done is to back up the server's 
	current server.cfg. Do this by simply creating a new 
	folder (labeled "backup") in your requiem directory and 
	move or copy your current cfg to the new folder.

	* Next unzip the new server.cfg file in the Requiem directory.

2.	Installing the qwprogs.dat
	* As before, place a backup of your current qwprogs.dat 
	file in the backup folder.
	* Unzip the new qwprogs.dat file into the Requiem 
	directory.





Changes____________________________________________________________                                                          

1. Fixed bug where server would ignore the localinfo 
and go to start when u were on dm6

2. Fixed teamlock and color lock. for CTF and tag.


3. Fix for client overflows in CTF and tag.


4. Fixed blue flag on e1m4 ''Grizzly Grotto'' level.

5. Player model problems have been fixed. 

6. Sticky fire problems have been fixed for ssg 

7. Safestart changes: 
 a) saftstart now provides protection from fire. 
 b) It now reflects: grapple, clusters, gib gun 
 c) can no longer be frozen in safestart 

8. Pulverisor changes: 
 a) now uses 5 nails per shot. 
 b) Slightly reduced damage per nail. 

9. BFG changes (some still not finished): 
 a) Reduced damage radius to 800 units (note d) 
 b) modified damage to provide the damage multiplier is 
 now 3.0 this is multiplied with the number of cells 
 used. Min damage = 120 pnts (remember this is at 
 ground 0, the damage is also range dependent) max
 damage = 300 pnts. (again at ground 0, note the 
 damage and range both drop off as the charge wears 
 down. c) the damage is now directly tied into the 
 number of cells owned. 
 d) The damage radius increases for 90 cells to 900 
 and 100 to 1000 units. 
 e) The bfg still requires minimum of 40 cells, but will 
 consume all  
 cells possessed. 
 d) The ammo bug (for the BFG) 
  d1) this has been fixed, it now drains all ammo 
  correctly 
  d2) while the bfg is charging the player will not be 
  able to pick up extra cells but will a back pack. 


10. Laser changes: 
 a) the laser's damage has been somewhat reduced. 
 b) Ammo use has increased to 3 cells per shot 
 c) firing speed has increased 
 
11. Lava gun Changes: 
 a) The lag-creating problem of the flame_2 model 
 used in the lava cannon has been addressed. It was 
 determined that the only real way to correct the 
 problem without then requiring a client download was 
 simply to replace the model. So we did just that. The 
 new model is the lavaball model. This model does not 
 produce light, and therefore doesn't have the lag 
 generating effects. 

12. Teleport problem of roxs and runes getting stuck 
    in teleportals has been fixed

 
13. Jumpslide changes (actually these are "slide" specific) 
 a) the jumpslide had a slight advantage; it had a size 
 change to "show" the effect of lying down. This change 
 was inaccurate, as it changed the players (laying down) 
 height from the standard 32 units (roughly six feet) 
 to about 2.5 inches (yea, about at tall as a large paper 
 clip!) This has been corrected to a height of 10 units 
 (laying down), or about 2.2 feet. This will greatly 
 increase the vulnerability of the jumpslide, so beware. 
 b) The jumpslide no longer has a negative influence on 
 the jump, making it smoother and for sliding "up" 
 rough terrain and such, and increasing the distance a 
 small amount by lifting the angle at which we launch 
 from. 

 
14. Grapple changes. 
 a) It now throws the grapple a fair amount faster 
 b) the physics have been completely altered.  
  b1) it is now MUCH more stable when grappled to 
  walls/ceiling, etc. 
  b2) there are a few other differences, but the key 
  one you will notice is that grappling an opponent now 
  results in him being pulled to you. 


15. No more dual telefrags (note**) 
    _____note*: there is a map specific problem that is 
    directly map related (but to requiem) that involves 
    sliding through a teleportal. If attempting to slide 
    through a teleportal, it may not function. The reason is 
    because of a design flaw regarding the placement of 
    the trigger. If the trigger is placed in a manor that 
    leaves a large gap between the bottom of the trigger 
    and the floor, it will not function correctly during a 
    slide. (fairly large, must be at least 10 units, however 
    used to only have to be one (see slide changes below)) 
    When you slide on a good example is on dm4. We tried 
    to correct this, but couldn't do it do to quake engine 
    limitations, or the alternate. 


16. The quad has been fixed, and changed a bit. 
 a) The quad now gets a reduction in power if the player 
 has the power up. If you have the power up you will 
 receive a "double power" rather than a "Quad power" 
 This helps balance out the quad and the powerup, 
 rather than making the power up the end all. 
 b) When in possession of a quad, you can no loner pick 
 up any other super item accept the invirosuit. No 
 longer can you get another quad, the ring of shadows, 
 or invincibility. 
 c) The death messages will now say x got whatever by 
 y's DOUBLE POWERED / QUAD POWERED whatever, 
 depending on weather the player has the power up. 

15. Changes to The ring of shadows  
 a) When in possession of a ring of shadows, you can no 
 loner pick up any other super item except the 
 invirosuit. No longer another ring of shadows, a quad, 
 or invincibility. 

16. Changes to The invincibility.  
 a) When in possession of invincibility, you can no loner 
 pick up any other super item except the invirosuit. No 
 longer another invincibility, a quad, or ring of shadows. 

17. Changed glow colors, they are now: 
 Purple = fairstart 
 red = invinc. 
 Blue = quad 

****************************************************************************************

	There has been so much we have done to this release I feel I should have documented 
	the changes better as I feel that there is fixes missing from here. This however is 
	clean code. Should have most all the bugs you have seen brfore taken care of. While 
	no code is ever "bug free", that remains our goal none the less. 2.5 is already being 
	planned with several feature inhancements in the works. One thing is for sure, it can 
	only get better from here!
	Keep your eyes out for Requiem for Q2, soon to release! Also look for Requiem for Q3a, 
	which promises to be the best mod ever!


More info at www.reqoning.com

****************************************************************************************

The Top Cheese = Requiem
Chief Designer = Demon]0[Spawn
Chief Coder    = Hell]0[


==== Official Home Site ====
http://www.planetquake.com/requiem/

==== Official Support Site ====
http://www.reqoning.com

==== Official Requiem Clan League Site ====
http://qarecar.reqoning.com


