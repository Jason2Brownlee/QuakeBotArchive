The following changes have been made to the original Frikbot X code:

. Improved item pickup AI.
. Improved waypoints for DM1, DM4, DM5 and DM6.
. Included deathmatch 3 mode.
. Included random respawn locations.

Enjoy!

-Igor9

====================================================================

And Jan 2013, made this change:

. Added back the map cycle feature from the original FrikBot X.

- Johnny Law
