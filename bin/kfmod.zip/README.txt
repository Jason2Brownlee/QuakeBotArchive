Combination of mods by Khol for FrogBot 0.12c
---------------------------------------------

This is a combination of a various number of mods i made for the
FrogBot version 0.12c. 
mods:
* RandomPower
* MatchCount
* MiscBan
* StaticQuad
* QuadSound

Also compiled mapsuport for 3 more maps. I dont know who made them.
maps:
* ztndm1	(use map_ztndm1)
* ukooldm2	(use map_ukooldm2)
* fribweb1	(use map_fribweb1)

I noticed that you might need to use -zone 8192 (or more) to make
this mod work. This is because a big amount of aliases used in the
mod. So please, raise your -zone value if the mod craches.

Q: How do i know if the -zone is to low?
A: When you connect to the server, you'll notice that the client
   prints out all aliases in the console, and you might get an
   errormessage like: "teamplay= unknown command" (or something
   like that). Then you might need to raise your -zone in the
   commandline.

I'm not sure how this works in NQ though, since i dont play NQ anymore.

So please notify me if there is any problems in NQ.

Read all the rest of the TXT-files to. The description of my mods
are in the TXT-files:
* MatchCount by Khol.txt
* MiscBan by Khol.txt
* RandomPower by Khol.txt
* StaticQuad and QuadSound by Khol.txt

Do not mail me and ask how the mods should be used if you hav'nt read the
TXT-files.

// Khol - khol@home.se
// http://www.acc.umu.se/~khol/mods.html