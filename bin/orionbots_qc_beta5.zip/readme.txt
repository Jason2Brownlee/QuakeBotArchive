====================================

OrionBots beta 5 - by Orion

====================================


Description:

It's deathmatch bots I made from scratch.
They act pretty well in combat, and they seem to roam the map well too.


Features:

*They follow their enemies.
*They lead target if they're using a non-instant weapon.
*They can get almost all items they see if they're roaming.
*They roam any map pretty well.
*They attack in various styles.
*They do rocket-jumps.
*They have client physics emulation.
*They have 50 different names, and they don't use the same name as another bot.


Commands:

Impulse 100 will add a bot.
Impulse 101 will kick a bot.
scratch1 N will be the number of bots that will be joining automatically, where N is the number of bots, but you must set scratch1 before starting a game. scratch1 will increase automatically if you add bots from impulse 100, and when the level changes, the bots will rejoin the next game automatically.


How to Install:

Create a new directory called "orionbots" at your Quake directory, then create a subdirectory called "src" at orionbots directory, extract the two .qc files in there, follow the instructions at the very top of bot.qc, and have fun!


Knows Bugs:

The bots LOVES lava! =(
I strongly recommend you to don't play on lava maps.
