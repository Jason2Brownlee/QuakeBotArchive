/****************************************************************\
*
*      Simplified UDP Client and Server
*
\*****************************************************************/

#define SYST_WINSOCK   ((SYST_WIN16)||(SYST_WIN32)||(SYST_WIN32CSL))


/****************************************************************\
*
*                 Simplified UDP Server
*    Handles ONLY ONE peer at the time. No memory.
*
\****************************************************************/

/*
** SERVER Server;
**  Declare a server stucture
*/
typedef struct
{
  /*Opaque data, DO NOT MODIFY*/
  char Opaque[0x40];
} SERVER;
typedef SERVER PTR *pSERVER;
/*
** ServerInit(&Server, Port)
**  Prepare to be a local UDP server on the given port
*/
Int32 ServerInit(pSERVER pServer, Int32 Port);
/*
** ServerFree(&Server)
**  Close a server
*/
Int32 ServerFree(pSERVER pServer);
/*
** Send a message to the last peer
*/
Int32 ServerSend(pSERVER pServer, pDTA pDta);
/*
** Get a message from the last peer
*/
Int32 ServerRecv(pSERVER pServer, pDTA pDta);
/*
** Print Server's Local  address in a string
*/
Int32 ServerAdrsPrint(pSERVER pServer,pInt8 String, Int32 StringSz);

/****************************************************************\
*
*                 UDP Client
*
\****************************************************************/

/*
** CLIENT Client;
**  Declare a client stucture
*/
typedef struct
{
  /*Opaque data, DO NOT MODIFY*/
  char Opaque[0x20];
} CLIENT;
typedef CLIENT PTR *pCLIENT;
/*
** ClientInit(&Client, Adrs, Port)
**   Client = CLIENT
**   Adrs = Server Address  (like "192.41.10.23","ftp.hell.gov","local")
**        = Server Address:Port (like "ftp.hell.gov:666")
**   Port = Server port (default, if not specified in Adrs)
**  Create a client, and connect it to the given address and port
*/
Int32 ClientInit(pCLIENT pClient, pInt8 Adrs, Int32 Port);
/*
** ClientSend(&Client, Data);
**  Send Data to the Client's peer
*/
Int32 ClientSend(pCLIENT pClient, pDTA pDta);
/*
** ClientRecv(&Client, Data);
**  Receive data from the client
**  Data must be initialised, but filled with nothing
*/
Int32 ClientRecv(pCLIENT pClient, pDTA pDta);
/*
** Port = ClientGetPort(&CLient)
**  Get the local port number of a client
*/
Int32 ClientGetPort(pCLIENT pCLient);
/*
** ClientSetPeer(&Client, Adrs, Port);
**   Adrs = Server Address  (like "192.41.10.23","ftp.hell.gov","local")
**        = Server Address:Port (like "ftp.hell.gov:666")
**   Port = Server port (default, if not specified in Adrs)
**  Forget the current server, and connect to this one.
*/
Int32 ClientSetPeer(pCLIENT pClient, pInt8 Adrs, Int32 Port);
/*
** ClientSetPeerPort(&Client, Port);
**  Connect to this specific UDP port. This is needed when an UDP server
**  dedicates a specific UDP port to talk to a given client.
*/
Int32 ClientSetPeerPort(pCLIENT pClient, Int32 Port);
/*
** ClientReInit(&Client);
**  Reconnect to original server peer port. This is needed if for some reason
**  the server stopped using the dedicated port.
*/
Int32 ClientReInit(pCLIENT pClient);
/*
** Print Client's Peer address in a string
*/
Int32 ClientPeerAdrsPrint(pCLIENT pClient, pInt8 String, Int32 StringSz);
/*
** ClientFree(&Client)
**  Close a client
*/
Int32 ClientFree(pCLIENT pClient);
/*
** ClientCopyPeer(&Server, pSADR_IN pSadr)
**  Copy to pSadr the last peer address of a server
*/
Int32 ClientCopyPeer(pCLIENT pClient, pSERVER pServer);

/****************************************************************\
*
*            Call Back functions with context
*
\****************************************************************/

/*
** Call Back
*/
typedef struct
{
  Int32 (*Function) (pVoid Context, pDTA Dta);
  pVoid Context;
} MESSAGECB;
typedef MESSAGECB PTR *pMESSAGECB;
/*
** Set Callback
*/
void CbSet(pMESSAGECB pCb, Int32(*Function) (pVoid Context, pDTA Dta), pVoid Context);
/*
** Int32 CbCall(pMESSAGECB pCb, pDTA Dta);
*/

/****************************************************************\
*
*   Dispatcher
*   an UDP client
*   an UDP server (and a special "client" to send streams to others)
*   with associated callbacks, including a callback for keyboard input. 
*
\****************************************************************/


typedef struct
{
  Int32 IddleTime; /* Seconds*100*/
  /*Callback for Iddle (time outs while waiting)*/
  MESSAGECB IddleCb;
  /*Callback for Client's Peer messages */
  MESSAGECB ClientCb;
  /*Callback for Stdin messages, Useless with WinSock */
  MESSAGECB StdinCb;
  /*Callback for Peer messages */
  MESSAGECB ServerCb;
  /*Callback for Peer messages */
  MESSAGECB WorldCb;
  /*
  ** File descriptors
  */
  Int32 StdinFd; /*file descriptor*/
  Int32 ClientFd;
  Int32 ServerFd;
  Int32 WorldFd;
  /*
  ** UDP data
  */
  CLIENT Client;  /* Client's Socket and Peer Address*/
  SERVER Server;  /* Server's Socket, Peer, Last Peer */
  CLIENT World;   /* World's Socket and Peer */
} DISPATCH;
typedef DISPATCH PTR *pDISPATCH;
/*
** DISPATCH Disp;
** DispatchInit(&Disp)
**  Init Dispatch and all contents (clients...)
*/
Int32 DispatchInit(pDISPATCH pDisp,pInt8 ServerHost, Int32 ServerPort, Int32 MyPort);
/*
** Disp.ClientCb = function
** Disp.ClientContext = function context
** Disp.StdinCb  = function
** Disp.StdinContext = function context
** Disp.IddleTime = 20, in seconds
** Disp.IddleCb  = function
** Disp.IddleContext = function context
** DispatchRun(&Disp, timeout);
**  If a message is received from client, call:
**    pClient->Cb.PeerCb(pClient->Cb.PeerContext,pDta)
**  If a message is received from Stdin, call:
**    pClient->Cb.StdinCb(pClient->Cb.StdinContext,pDta)
**  If those functions are NULL, they are not called.
*/
Int32 DispatchRun(pDISPATCH pDisp);
/*
** DispatchFree(&Disp)
**  Free Dispatch and all contents (clients...)
*/
Int32 DispatchFree(pDISPATCH pDisp);




/*
**
** These functions are required by Winsock
**
*/
#if SYST_WINSOCK
void ClientWSAStartup(void); /*First function to call in a program*/
void ClientWSACleanup(void); /*Last function to call in a program*/
#endif
