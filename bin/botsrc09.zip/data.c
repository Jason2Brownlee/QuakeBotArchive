/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy 
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/


#include "defines.h"
#include <stdio.h>
#if (SYST_WIN16)||(SYST_WIN32)||(SYST_WIN32CSL)||(SYST_DOS)
#include <io.h>
#endif
#include <ctype.h>
#include "common.h"
#include "data.h"
/****************************************************\
*
*  DTA, Implementation of a safe buffer structure
*
\****************************************************/


/*
** Structure that is used both for swapping data and
** to avoid addressing Int32 on non-aligned addresses
** (which causes bus errors on some machines)
*/
static union { Int8 x[4]; Int16 s; Int32 l; Float32 f;} DtaSwap,DtaSwap2;
/*
** Dta = DtaInit(MaxSize)
**   MaxSize in Int8
** Returns Null if fails, pData otherwise
*/
Int32 DtaInit(pDTA pDta, Int32 MaxSize)
{
  /**/
  if((pDta==NULL)||(MaxSize<=0)) return -1;
  pDta->MaxSize = MaxSize;
  pDta->Data = Malloc(pDta->MaxSize*sizeof(Int8));
  if(pDta->Data==NULL) pDta->MaxSize = -1; /*safety*/
  pDta->CurrRd = 0;
  pDta->Size   = 0;
  return pDta->MaxSize;
}
/*
** DtaFree(Data)
*/
Int32 DtaFree(pDTA pDta)
{
  
  if(pDta==NULL) return -1;
  if(pDta->Data!=NULL) Free(pDta->Data);
  pDta->Data = NULL;
  return 1;
}
/*
** DtaClear(&Data)
**  Clear buffer, restart from scratch
*/
Int32 DtaClear(pDTA pDta)
{
  
  if(pDta==NULL) return -1;
  pDta->Size=0;
  pDta->CurrRd=0;
  return 1;
}

/****************************************************\
*
*  Put strings and values in a buffer
*
\****************************************************/
/*
**  Copy pSrcDta, from current read position, into pDta
**  at current write position. Rewind pSrcDta if you need
**  to copy the whole packet.
*/
Int32 DtaPutDta(pDTA pDta, pDTA pSrcDta)
{
  Int32 sz;
  if(pSrcDta==NULL)
  { return 0; }
  /* Check that doesn't copy on itself*/
  if(pDta == pSrcDta) 
  { return ERRfault(ERR_BUG);} 
  /* put bytes*/
  pSrcDta->CurrRd = max(0, pSrcDta->CurrRd);
  pSrcDta->Size = min(pSrcDta->Size,pSrcDta->MaxSize);
  sz = pSrcDta->Size - pSrcDta->CurrRd;
  if(sz<=0) return 1;
  return DtaPut(pDta, &(pSrcDta->Data[pSrcDta->CurrRd]),sz);
}
/*
** DtaPut(Dta, Buffer, BufferSz)
**  Copy into data buffer, at current write position
*/
Int32 DtaPut(pDTA pDta, pInt8 Buffer, Int32 BufferSz)
{
  
  Int32 sz;
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;
  if((Buffer==NULL)||(BufferSz<=0)) return -1;
  pDta->Size = min(pDta->MaxSize, pDta->Size);
  pDta->Size = max(0, pDta->Size);
  sz = pDta->MaxSize - pDta->Size; /*sz>0*/
  sz = min( sz , BufferSz);
  Memcpy(&(pDta->Data[pDta->Size]), Buffer, sz);
  pDta->Size += sz;
  return pDta->Size;
}
/*
** DtaPutStr(Dta, Buffer)
*/
Int32 DtaPutStr(pDTA pDta, pInt8 Str)
{
  Int8 end='\0';
  DtaPut(pDta, Str, Strlen(Str,0x1000));
  return DtaPut(pDta, &end, sizeof(end)); /* Add a zero at the end */
}
Int32 DtaPutInt8(pDTA pDta, Int8 Val)
{ 
  DtaSwap2.x[0]=Val;
  return DtaPut(pDta, &DtaSwap2.x[0], sizeof(Int8));
}
Int32 DtaPutInt16BE(pDTA pDta, Int16 Val)
{ 
#if SYST_BIGENDIAN
  DtaSwap2.s = Val;
#else /*Processor is little endian*/
  DtaSwap.s = Val;
  DtaSwap2.x[0] = DtaSwap.x[BYTE0BE16];
  DtaSwap2.x[1] = DtaSwap.x[BYTE1BE16];
#endif
  return DtaPut(pDta, &DtaSwap2.x[0], sizeof(Int16));
}
Int32 DtaPutInt16LE(pDTA pDta, Int16 Val)
{ 
#if SYST_BIGENDIAN  /*Processor is big endian*/
  DtaSwap.s = Val;
  DtaSwap2.x[0] = DtaSwap.x[BYTE1BE16];
  DtaSwap2.x[1] = DtaSwap.x[BYTE0BE16];
#else
  DtaSwap2.s=Val;
#endif
  return DtaPut(pDta, &DtaSwap2.x[0], sizeof(Int16));
}
Int32 DtaPutInt32BE(pDTA pDta, Int32 Val)
{ 
#if SYST_BIGENDIAN
  DtaSwap2.l = Val;
#else  /*Processor is little endian*/
  DtaSwap.l = Val;
  DtaSwap2.x[0] = DtaSwap.x[BYTE0BE32];
  DtaSwap2.x[1] = DtaSwap.x[BYTE1BE32];
  DtaSwap2.x[2] = DtaSwap.x[BYTE2BE32];
  DtaSwap2.x[3] = DtaSwap.x[BYTE3BE32];
#endif
  return DtaPut(pDta, &DtaSwap2.x[0], sizeof(Int32)); 
}
Int32 DtaPutInt32LE(pDTA pDta, Int32 Val)
{ 
#if SYST_BIGENDIAN  /*Processor is big endian*/
  DtaSwap.l = Val;
  DtaSwap2.x[0] = DtaSwap.x[BYTE3BE32];
  DtaSwap2.x[1] = DtaSwap.x[BYTE2BE32];
  DtaSwap2.x[2] = DtaSwap.x[BYTE1BE32];
  DtaSwap2.x[3] = DtaSwap.x[BYTE0BE32];
#else
  DtaSwap2.l= Val;
#endif
  return DtaPut(pDta, &DtaSwap2.x[0], sizeof(Int32)); 
}

Int32 DtaPutFloat32BE(pDTA pDta, Float32 Val)
{ 
#if SYST_BIGENDIAN
  DtaSwap2.f = Val;
#else  /*Processor is little endian*/
  DtaSwap.f = Val;
  DtaSwap2.x[0] = DtaSwap.x[BYTE0BE32];
  DtaSwap2.x[1] = DtaSwap.x[BYTE1BE32];
  DtaSwap2.x[2] = DtaSwap.x[BYTE2BE32];
  DtaSwap2.x[3] = DtaSwap.x[BYTE3BE32];
#endif
  return DtaPut(pDta, &DtaSwap2.x[0], sizeof(Float32)); 
}
Int32 DtaPutFloat32LE(pDTA pDta, Float32 Val)
{ 
#if SYST_BIGENDIAN  /*Processor is big endian*/
  DtaSwap.f = Val;
  DtaSwap2.x[0] = DtaSwap.x[BYTE3BE32];
  DtaSwap2.x[1] = DtaSwap.x[BYTE2BE32];
  DtaSwap2.x[2] = DtaSwap.x[BYTE1BE32];
  DtaSwap2.x[3] = DtaSwap.x[BYTE0BE32];
#else
  DtaSwap2.f = Val;
#endif
  return DtaPut(pDta, &DtaSwap2.x[0], sizeof(Float32)); 
}
/****************************************************\
*
*  Get strings and values from buffer
*
\****************************************************/
/*
** pInt8 DtaPeek(pDta, size)
**  Get a pointer to size bytes, or NULL
**  Do not move to next positions
*/
pInt8 DtaPeek(pDTA pDta, Int32 Size)
{
  Int32 next;
  if((pDta==NULL)||(pDta->Data==NULL)) return NULL;
  pDta->Size = min(pDta->Size,pDta->MaxSize); /*Security*/
  pDta->CurrRd = max(0,pDta->CurrRd);
  if(Size<=0) return NULL;
  next    = pDta->CurrRd+Size;
  if(next > pDta->Size) return NULL;
  return &(pDta->Data[pDta->CurrRd]);
}
/*
** pInt8 DtaGet(pDta, size)
**  Get a pointer to size bytes, or NULL
*/
pInt8 DtaGet(pDTA pDta, Int32 Size)
{
  
  Int32 current, next;
  if((pDta==NULL)||(pDta->Data==NULL)) return NULL;
  pDta->Size = min(pDta->Size,pDta->MaxSize); /*Security*/
  pDta->CurrRd = max(0,pDta->CurrRd);
  if(Size<=0) return NULL;
  current  = pDta->CurrRd;
  next    = pDta->CurrRd+Size;
  if(next>pDta->Size) return NULL;
  pDta->CurrRd = next;
  return &(pDta->Data[current]);
}
/*
** pInt8 DtaGetStr(size)
**  Get a pointer to a string. returns NULL if no string.
*/
pInt8 DtaGetStr(pDTA pDta)
{
  
  pInt8 Str;
  Int32 sz;
  if((pDta==NULL)||(pDta->Data==NULL)) return NULL;
  pDta->Size = min(pDta->Size,pDta->MaxSize); /*Security*/
  /* Don't read beyond the end*/
  if(pDta->CurrRd>=pDta->Size) return NULL;
  /* attempt to read string */
  Str=&(pDta->Data[pDta->CurrRd]);
  for(sz=0; Str[sz]!='\0'; sz++)
  {
    /* Check that string ends with a zero*/
    if((pDta->CurrRd+sz)>= pDta->Size)
    { return NULL; }
  }
  pDta->CurrRd += sz+1; /* skip last '\0' */
  return Str;
}
/*
** pInt8 DtaGetStrM(size)
**  Get a string into a buffer (possibly too small)
*/
Int32 DtaGetStrM(pDTA pDta, pInt8 Str, Int32 StrSz)
{
  
  pInt8 P;
  Int32 next,sz;
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;
  pDta->Size = min(pDta->Size,pDta->MaxSize); /*Security*/
  if((Str==NULL)||(StrSz<=0)) return -1;
  next = pDta->CurrRd;  
  sz = 0;
  for(P = &(pDta->Data[next]); next< pDta->Size; next++, P+=1)
  {
    if(*P=='\0'){ next++; break;}
    if(sz<StrSz-1) { Str[sz] = *P; sz++; }
  }
  Str[sz]='\0';
  pDta->CurrRd = next;
  return sz;
}
/*
** Get Int(8,16,32)
*/  
Int8 DtaGetInt8(pDTA pDta)
{ 
  pInt8 P=DtaGet(pDta, sizeof(Int8));
  if(P==NULL) return 0; /*should be an exception*/
  return P[0];
}
Int16 DtaGetInt16BE(pDTA pDta)
{ 
  pInt8 P= DtaGet(pDta, sizeof(Int16));
  if(P==NULL) return 0; /*should be an exception*/
  DtaSwap.x[0]= P[BYTE0BE16];
  DtaSwap.x[1]= P[BYTE1BE16];
  return DtaSwap.s;
}
Int16 DtaGetInt16LE(pDTA pDta)
{ 
  pInt8 P= DtaGet(pDta, sizeof(Int16));
  if(P==NULL) return 0; /*should be an exception*/
  DtaSwap.x[0]= P[BYTE1BE16];
  DtaSwap.x[1]= P[BYTE0BE16];
  return DtaSwap.s;
}
Int32 DtaGetInt32BE(pDTA pDta)
{ 
  pInt8 P= DtaGet(pDta, sizeof(Int32));
  if(P==NULL) return 0; /*should be an exception*/
  DtaSwap.x[0]= P[BYTE0BE32];
  DtaSwap.x[1]= P[BYTE1BE32];
  DtaSwap.x[2]= P[BYTE2BE32];
  DtaSwap.x[3]= P[BYTE3BE32];
  return DtaSwap.l;
}
Int32 DtaGetInt32LE(pDTA pDta)
{ 
  pInt8 P= DtaGet(pDta, sizeof(Int32));
  if(P==NULL) return 0; /*should be an exception*/
  DtaSwap.x[0]= P[BYTE3BE32];
  DtaSwap.x[1]= P[BYTE2BE32];
  DtaSwap.x[2]= P[BYTE1BE32];
  DtaSwap.x[3]= P[BYTE0BE32];
  return DtaSwap.l;
}

Float32 DtaGetFloat32BE(pDTA pDta)
{ 
  pInt8 P= DtaGet(pDta, sizeof(Float32));
  if(P==NULL) return (Float32)0.0; /*should be an exception*/
  DtaSwap.x[0]= P[BYTE0BE32];
  DtaSwap.x[1]= P[BYTE1BE32];
  DtaSwap.x[2]= P[BYTE2BE32];
  DtaSwap.x[3]= P[BYTE3BE32];
  return DtaSwap.f;
} 
Float32 DtaGetFloat32LE(pDTA pDta)
{ 
  pInt8 P= DtaGet(pDta, sizeof(Float32));
  if(P==NULL) return (Float32)0.0; /*should be an exception*/
  DtaSwap.x[0]= P[BYTE3BE32];
  DtaSwap.x[1]= P[BYTE2BE32];
  DtaSwap.x[2]= P[BYTE1BE32];
  DtaSwap.x[3]= P[BYTE0BE32];
  return DtaSwap.f;
} 


/****************************************************\
*
*  Input/Outputs   
*
\****************************************************/

/*
** DtaRead(&Dta, fd)
**   fd= file descriptor
** Encapsulate a call to Read()
*/
Int32 DtaRead(pDTA pDta, Int32 fd)
{
  Int32 sz;
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;  
  pDta->CurrRd = 0; /*read from start*/
  sz = read((Int)fd, &pDta->Data[pDta->CurrRd], (UInt)pDta->MaxSize);
  pDta->Size = min(sz, pDta->MaxSize);
  pDta->Size = max(0, pDta->Size);
  return sz;
}
/*
** DtaWrite(&Dta, fd)
**   fd= file descriptor
** Encapsulate a call to Write()
*/
Int32 DtaWrite(pDTA pDta, Int32 fd)
{
  Int32 sz;
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;  
  pDta->Size = min(pDta->Size, pDta->MaxSize);
  sz = write((Int)fd, pDta->Data, (UInt)pDta->Size);
  return sz;
}
/*
** Dump a buffer to Stdin
** Does not affect read or write position
*/
Int32 DtaPrintDump(pDTA pDta, Bool All)
{
  Int32 pos, end, nb,j;
  Int8 c;
  UInt val;
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;
  /* Dump all bytes of message*/
  pos = (All==TRUE)? 0: pDta->CurrRd;
  end = min(pDta->Size, pDta->MaxSize);
  printf("-------------- Data Dump --------------\n");
  for(; pos<end; pos+=16)
  {
    printf("0x%04.4x ", (int)pos);
    nb = min( end-pos, 16);
    for(j=0;j<16;j++)
    {
      if(j<nb)
      {
        val = (UInt8)(pDta->Data[pos+j]);
        printf("%02x", (int)((int)val)&0xFF);
      }
      else
        printf("  ");
    }
    printf("  ");
    for(j=0;j<nb;j++)
    {
      c = pDta->Data[pos+j];
      printf("%c", isprint(c)? c: '.');
    }
    printf("\n");
  }
  printf("---------------------------------------\n");
  return 1;
}


/****************************************************\
*
*  Miscellaneous advanced functions (DO NOT USE)
*
\****************************************************/
/*
** Get size of data
*/
Int32 DtaSize(pDTA pDta)
{ 
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;
  pDta->Size = min(pDta->Size,pDta->MaxSize);
  return pDta->Size;
}
/*
** Set size of data. Do NOT USE.
*/
Int32 DtaSetSize(pDTA pDta, Int32 Size)
{ 
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;
  pDta->Size = min(Size,pDta->MaxSize);
  pDta->Size = max(0,pDta->Size);
  pDta->CurrRd= min(pDta->Size, pDta->CurrRd);
  return pDta->Size;
}
/*
** Get max size of data
*/
Int32 DtaMaxSize(pDTA pDta)
{ 
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;
  /*pDta->Size = min(pDta->Size,pDta->MaxSize);*/
  return pDta->MaxSize;
}
/*
** Get Pointer to data
*/
pInt8 DtaData(pDTA pDta)
{ 
  if((pDta==NULL)||(pDta->Data==NULL)) return NULL;
  /*pDta->Size = min(pDta->Size,pDta->MaxSize);*/
  return pDta->Data;
}
/*
** Rewind buffer to start, do not empty it
*/
Int32 DtaRewind(pDTA pDta)
{  
  if((pDta==NULL)||(pDta->Data==NULL)) return -1;
  pDta->Size = max(0,min(pDta->Size,pDta->MaxSize));
  pDta->CurrRd=0;
  return 1;
}
/*
** Int32 DtaRemaining(pDta)
**  Returns remaining size to read
*/
Int32 DtaRemaining(pDTA pDta)
{ 
  Int32 remn;
  if((pDta==NULL)||(pDta->Data==NULL)) return 0;
  remn = min(pDta->Size, pDta->MaxSize);
  remn -= pDta->CurrRd;
  return max(0, remn);
}
