/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"  /*Always first to be included*/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>  /*variable lenght arguments*/
#include <ctype.h>
#include "common.h"
#include "data.h"     /*Useless, except for type*/
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkpto.h"    /*Useless, except for type*/
#include "qkent.h"    /*Entity and model lists*/
#include "qkbot.h"    /*Bot inteface*/
#include "qkentbot.h" /*Entity list, for bot */
#include "qkpak.h"    /*Pak files*/

#define DEBUG  1
/*
** Static data
*/
BOT2 Bot2;


void BotModelSoundReInit(void)
{
  Int i;
  /*
  ** Precaches Models and sounds
  */
  for(i=0;i<MODELSMAX;i++)
  {
    Bot2.Models[(Int)i].ETyp=EFLAG_NONE;
    Bot2.Models[(Int)i].File[0]='\0';
  }
  for(i=0;i<SOUNDSMAX;i++)
  {
    Bot2.Sounds[(Int)i].File[0]='\0';
  }
}
/*
** Set model and type from file
*/
void BotModelSet(Int32 Index, pInt8 Name)
{
  if((Index<0)||(Index>=MODELSMAX))
  { return ;}
  if(Name==NULL) {Name="default.mdl";}
  Strncpy(Bot2.Models[(Int)Index].File, Name, sizeof(Bot2.Models[(Int)Index].File)-1);
  Bot2.Models[(Int)Index].ETyp = DBfileType(Bot2.Models[(Int)Index].File);
  /* check that file exists */
  if(Bot2.Models[(Int)Index].File[0]!='*')
  {
    if(DBcheck(Bot2.Models[(Int)Index].File)!=TRUE)
    { printf("Unknown model %s\n", Bot2.Models[(Int)Index].File);}
  }
}
/*
** Get pointer to model file, or NULL if not valid
*/
pInt8 BotModelGet(Int32 Index)
{
  if((Index<0)||(Index>=MODELSMAX))
  { return NULL;}
  if(Bot2.Models[(Int)Index].File[0]=='\0')
  { return NULL;}
  return &(Bot2.Models[(Int)Index].File[0]);
}
/*
** Set a sound file
*/
void BotSoundSet(Int32 Index, pInt8 Name)
{
  if((Index<0)||(Index>SOUNDSMAX)) return;
  if(Name==NULL) { Name = "default.wav"; }
  Strncpy(&(Bot2.Sounds[(Int)Index].File[0]), "sound/", sizeof(Bot2.Sounds[(Int)Index].File)-1);
  Strncpy(&(Bot2.Sounds[(Int)Index].File[6]), Name,     sizeof(Bot2.Sounds[(Int)Index].File)-1-6);
  /* check that file exists */
  if(DBcheck(Bot2.Sounds[(Int)Index].File)!=TRUE)
  { printf("Unknown sound %s\n", Bot2.Sounds[(Int)Index].File);}
}
/*
** Get pointer to sound file, or NULL if not valid
*/
pInt8 BotSoundGet(Int32 Index)
{
  if((Index<0)||(Index>=SOUNDSMAX))
  { return NULL;}
  if(Bot2.Sounds[(Int)Index].File[0]=='\0')
  { return NULL;}
  return &(Bot2.Sounds[(Int)Index].File[0]);
}


#if DEBUG
static Int8 DBuff[16];
static pInt8 BotETypDebug(ETYPE ETyp)
{
  sprintf(DBuff,"%02x %c%c%c%c",
      (Int)(ETyp&ETYPE_MASK),
      (ETyp & EFLAG_WORLD)?  'W':' ',
      (ETyp & EFLAG_DANGER)? 'D':' ',
      (ETyp & EFLAG_PLAYER)? 'P':' ',
      (ETyp & EFLAG_GOODIE)? 'G':' ');
  return DBuff;
}

void BotModelDebug(void)
{
  Int i;
  printf("BotModels\n");
  for(i=0;i<MODELSMAX;i++)
  {
    if(Bot2.Models[i].File[0]=='\0') continue;
    printf("Model:%5d  %s  File:%s\n",
      (int)i,
      BotETypDebug(Bot2.Models[i].ETyp),
      &(Bot2.Models[i].File[0]));
  }
}
#endif

/****************************************************\
*
*         Entities and Static entities
*
\****************************************************/

/*
** Reinit static entities
*/
void BotEntiReInit(void)
{
  Int32 enti;
  pELIVING Ent;
  /* static */
  Bot2.EStaticNb =0;
  for(Ent=&(Bot2.EStatic[0]), enti=0; enti<ESTATICMAX; enti++, Ent+=1)
  {
    Ent->Me = -enti-1; /*static*/
    Ent->ETyp=EFLAG_NONE;
    Ent->pPlay=NULL;
  }
  /* non-static */
  for(Ent=&(Bot2.ELiving[0]), enti=0; enti<ELIVINGMAX; enti++, Ent+=1)
  {
    Ent->Me = enti;
    Ent->ETyp=EFLAG_NONE;
    Ent->pPlay=NULL;
  }
}
/*
** Get pointer to a new static entity
*/
pELIVING BotEntiStaticNew(void)
{
  ENTITY enti;
  if(Bot2.EStaticNb>=ESTATICMAX)
  {
    ERRwarn("Too many static entities");
    return NULL;
  }
  enti = Bot2.EStaticNb; Bot2.EStaticNb++;
  return &(Bot2.EStatic[(int)enti]);
}

/*
** Get pointer to a static entity
*/
pELIVING BotEntiStaticGet(ENTITY Enti)
{
  if(Enti>=ESTATICMAX)
  { return NULL; }
  if((Enti<0)||(Enti>=Bot2.EStaticNb))
  { return NULL; }
  return &(Bot2.EStatic[(int)Enti]);
}
/*
** Get pointer to living entity
*/
pELIVING BotEntiGet( ENTITY Enti)
{
  if((Enti<0)||(Enti>=ELIVINGMAX))
  { return NULL;}
  return &(Bot2.ELiving[(int)Enti]);
}
pInt8 BotEntiGetModel(ENTITY Enti)
{
  Int16 Model;
  if((Enti<0)||(Enti>=ELIVINGMAX))
  { return NULL;}
  Model = Bot2.ELiving[(int)Enti].Model;
  if((Model<0)||(Model>=MODELSMAX))
  { return NULL;}
  if(Bot2.Models[Model].File[0]=='\0')
  { return NULL;}
  return &(Bot2.Models[Model].File[0]);
}
/*
** Find closest entity of a given type
**  if ETyp & EFLAG_MASK !=0, check that all flags are up
**  if ETyp & ETYPE_MASK !=0, consider only that type
**  EntSkip = entity that must be skipped (typically, Self)
** returns NULL if nothing found
*/
pELIVING BotEntiFindClosest(pVEC3 pOrigin, ETYPE ETyp, pELIVING EntSkip)
{
  pELIVING Ent, Ent0=NULL;
  SCALAR Dist, Dist0= (SCALAR)100000.0;
  Int32 Enti;
  ETYPE flag= ETyp &EFLAG_MASK;
  ETYPE etyp= ETyp &ETYPE_MASK;
  for(Enti=0; Enti<ELIVINGMAX; Enti++)
  {
    Ent = BotEntiGet(Enti);
    if((Ent==NULL)||(Ent==EntSkip)) continue;
    /* check that EFLAG, if defined,  is the same */
    if((flag!=0)&&((Ent->ETyp&flag)!=flag)) continue;
    /* check that ETYP, if defined, is the same */
    if((etyp!=0)&&((Ent->ETyp&ETYPE_MASK)!=etyp)) continue;
    Dist= VecDiff(&(Ent->Origin), pOrigin);
    if(Dist<Dist0)
    { Ent0=Ent; Dist0=Dist; }
  }
  /*NULL, if not found*/
  return Ent0;
}
#if DEBUG
void BotEntiDebugPos(ETYPE Flag)
{
  Int enti;
  pELIVING Ent;
  pInt8 Name;
  printf("Tilt   Yaw     X      Y      Z       Model\n");
  for(enti=0; enti<ELIVINGMAX; enti++)
  {
    Ent = BotEntiGet(enti);
    if(Ent==NULL) continue;
    if(!(Ent->ETyp&Flag)) continue;
    if(Ent->pPlay!=NULL)
    { Name = Ent->pPlay->Name; }
    else
    { Name= BotEntiGetModel(enti);}
    if(Name==NULL) continue;
    printf("%5.1f %5.1f  (%6.1f %6.1f %6.1f)  %.32s\n",
             (float)ANGLE2DEG(Ent->Angles.Tilt),
             (float)ANGLE2DEG(Ent->Angles.Yaw),
             (float)Ent->Origin.X, (float)Ent->Origin.Y, (float)Ent->Origin.Z,
             Name);
  }
}
void BotEntiDebug(ETYPE Flag)
{
  Int enti;
  pELIVING Ent;
  pInt8 Name;
  printf("Entity     Flags   Attack  Frame  Model\n");
  for(enti=0; enti<ELIVINGMAX; enti++)
  {
    Ent = BotEntiGet(enti);
    if(Ent==NULL) continue;
    if(!(Ent->ETyp&Flag)) continue;
    Name= BotEntiGetModel(enti);
    if(Name==NULL) continue;
    printf("%5d   %s   %3d  %3d %s\n",
       (int)enti,
       BotETypDebug( (ETYPE) Ent->ETyp),
       (int)Ent->Attack,
       (int)Ent->Frame,
       Name);
  }
}
#endif



/****************************************************\
*
*         Players
*
\****************************************************/

void BotPlayerReInit(void)
{
  Int32 i;
  pEPLAYER pPlay;
  for(pPlay=&(Bot2.EPlayers[0]), i=0; i<MAXPLAYERS; i++, pPlay+=1)
  { pPlay->Name[0]='\0';
    pPlay->Hate = 0;   /* peace and love */
    pPlay->Frags=0;
  }
}
/*
** Determine if a player exists
*/
Bool BotIsPlayer(pBOT pBot, ENTITY Player)
{
  /* Players start at 1*/
  /* Check player id */
  if((Player<=0)||(Player>MAXPLAYERS)) return FALSE;
  if(Player>pBot->Players) return FALSE;
  return TRUE;
}
/*
** Get a player definition
*/
pEPLAYER BotPlayerGet(pBOT pBot, ENTITY Player)
{
  if( BotIsPlayer(pBot,Player)!=TRUE) return NULL;
  /* Return player structure */
  return &(Bot2.EPlayers[(int)Player]);
}
/*
** Set player name
*/
Int32 BotPlayerSetName(pBOT pBot, ENTITY Player, pInt8 Name)
{
  pEPLAYER pPlay;
  pPlay = BotPlayerGet(pBot, Player);
  if(pPlay==NULL) return -1;
  if(Name==NULL)
  {
    Strncpy(&(pPlay->Name[0]),"Unconncected",sizeof(pPlay->Name)-1);
    return 0;
  }
#if 0 /*works fine*/
  printf("Player %d name: %s\n",(int)player, name);
#endif
  StrClean(&(pPlay->Name[0]),Name,sizeof(pPlay->Name)-1);
  pPlay->Name[sizeof(pPlay->Name)-1]='\0';
  return 1;
}
/*
** Get any player by name (except the bot itself)
** returns NULL if no player was found
*/
pELIVING BotPlayerGetByName(pBOT pBot, pInt8 Name, Int32 NameSz)
{
  ENTITY Player;
  pEPLAYER pPlay;
  Int8 name[32];
  /*Cleanup*/
  StrClean(name,Name, min(sizeof(name),NameSz));
  /*Find*/
  for(Player=1; Player<=pBot->Players; Player++)
  {
    /* refuse to consider bot itself */
    if(Player==pBot->Me) continue;
    /* check that is a player */
    pPlay=BotPlayerGet(pBot, Player);
    if(pPlay==NULL) continue;
    /* compare name (don't use a hash, this is not strict)*/
    if(Strncmpi(name,pPlay->Name, min(NameSz,sizeof(pPlay->Name)))>0)
    { return BotEntiGet(Player); }
  }
  return NULL;
}
/*
** Modify hate toward a player.
**  Player= player id. if invalid, modify hate toward all players.
*/
Int32 BotPlayerHate(pBOT pBot, ENTITY Player, Int32 AddedHate)
{
  pEPLAYER pPlay;
  pPlay = BotPlayerGet(pBot, Player);
  if(pPlay!=NULL)
  {
    pPlay->Hate += AddedHate;
    return pPlay->Hate;
  }
  /* Hate all players */
  for(Player=1; Player<=pBot->Players; Player++)
  {
    /* refuse to consider bot itself */
    if(Player==pBot->Me) continue;
    /* check that is a player */
    pPlay=BotPlayerGet(pBot, Player);
    if(pPlay==NULL) continue;
    /* Hate*/
    pPlay->Hate += AddedHate;
  }
  return 0;
}
#if DEBUG
void BotPlayerDebug(pBOT pBot)
{
  Int i;
  pEPLAYER pPlay;
  printf("Player Hate  Frags    Name                           Colors\n");
  /*       **  ******  ****  ********************************  *:*  */
  for(i=1; i<=MAXPLAYERS; i++)
  {
    pPlay = BotPlayerGet(pBot,i);
    if(pPlay==NULL) continue;
    printf("%3d  %6d  %4d  %-32.32s  %1x:%1x\n",
       (int)i,
       (int)(pPlay->Hate),
       (int)pPlay->Frags,
       &(pPlay->Name[0]),
       (int)(pPlay->Shirt),
       (int)(pPlay->Pants));
  }
}
#endif


/**************************************************************\
**
**   List of entities seen by the bot
**
\**************************************************************/
#define SEENLISTSZ  128
static pELIVING SEENlist[SEENLISTSZ]; /*should be a bit mask*/
static Int32  SEENtop;
void SEENclear(void)
{
  SEENtop=0;
}
/*
** Put entity in list
*/
void SEENput(ENTITY Enti)
{
  pELIVING Ent=BotEntiGet(Enti);
  if(Ent==NULL) return;
  if(SEENtop>=SEENLISTSZ) return;
  SEENlist[(Int)SEENtop] = Ent;
  SEENtop+=1;
}
/*
** Returns next entity in list, or <0 if end of list. Then cycles.
*/
ppELIVING SEENgetList(pInt32 ListSz)
{
  *ListSz = SEENtop;
  return &(SEENlist[0]);
}
