/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "common.h"
#include "data.h"
#include "udp.h"
#include "qkpto.h"
#include "qkptomsg.h"  /*Protocol machine init/free*/
#include "qkdefs.h"   /*Quake Defs*/
#include "qkpak.h"    /*Quake pak stuff */
#include "qkbotpto.h" /*Bot init*/

#define DEBUG 0

/*
** 129.199.96.11 (dmi)
*/
#define DEFAULTPORT (26000)
#define MYPORT      (26000)
#if 1
#define DEFAULTHOST "161.104.10.137:26000"
#else
#define DEFAULTHOST  "LOCAL:26000"
#endif

/****************************************************\
*
*  Quake client
*
\****************************************************/
static DISPATCH Disp;   /* Dispatcher*/
static PTO      Pto;    /* Quake client Protocol machine */
static PTO      PtoW;   /* Quake world protocol machine */
/**/
int Run(pInt8 ServerHost, Int32 ServerPort, Int32 MyPort, pInt8 BotName, Int16 BotColor, Bool Auto)
{
  /*
  ** Print status
  */
  printf(" Pants=%2d Shirt=%2d    Name=%.32s\n",
			 (int)BotColor&0xF,(int)((BotColor>>4)&0xF),BotName);
  /*
  ** Init dispatcher
  */
  if(Auto==TRUE){ MyPort=0; }
  if(DispatchInit(&Disp,ServerHost, ServerPort, MyPort)<0)
  { return -1; }
  /* print peer */
  if(ClientPeerAdrsPrint(&(Disp.Client), Buff, sizeof(Buff)-1)>0)
  { printf(" Quake Server is: %s.\n",Buff); }
  if(Auto!=TRUE)
  { printf(" Proxy listening on port: %ld.\n",(long)MyPort); }
  /*
  ** Pto: Protocol machine for messages from Client
  ** Assoc: normal messages to PtoW, controls to Disp.Server
  */
  if(PtoInit(&Pto, &(Disp.Client), &PtoW, &(Disp.Server))<0)
  { return -1; }
  /*
  ** PtoW: Protocol machine for messages from World
  ** Assoc: normal messages to Pto, controls to NULL
  */
  if(PtoInit(&PtoW, &(Disp.World), &Pto, NULL)<0)
  { return -1; }
  /*
  ** Init the bot
  */
  BotInit(&Pto,&PtoW, BotName, BotColor, Auto);
  /*
  ** Prepare the callbacks in the dispatcher structure
  */
  /* Callback for messages from keyboard */
  CbSet(&Disp.StdinCb, PtoReceiveStdin, &Pto);
  /* Callback for server messages */
  CbSet(&Disp.ClientCb, PtoReceive, &Pto);
  /* Callback for Iddle times */
  CbSet(&Disp.IddleCb, PtoIddle, &Pto);
  Disp.IddleTime = 10; /*one 10th of second*/
  /* Callback for messages from real client to fake world */
  CbSet(&Disp.WorldCb, PtoReceive, &PtoW);
  /* Callback for messages from real client to fake server */
  CbSet(&Disp.ServerCb, PtoReceiveServer, &Pto);
  /*
  ** Start game, if needed
  */
  if(Auto==TRUE)
  {
	 printf("Sending Ask Info request\n");
	 PtoSendAskInfos(&Pto);
	 printf("Sending Connect request\n");
	 PtoSendConnect(&Pto);
  }
  /* Run */
  DispatchRun(&Disp);
  printf("Bot Exited\n");
  /*
  ** Free the Protocol machines
  */
  PtoFree(&Pto);
  PtoFree(&PtoW);
  /*
  ** Free the bot
  */
  BotFree();
  /*
  ** End dispatcher
  */
  DispatchFree(&Disp);
  return 1;
}
/*
** Messages
*/
void PrintBanner(void)
{
  printf("=================================================\n");
  printf("       Quake Proxy Bot   Version %d.%d\n", BOTMAJOR, BOTMINOR);
  printf("  Copyright (c)1996 Olivier.Montanuy@wanadoo.fr\n");
  printf("=================================================\n");
  printf("  To print the command line, type:  bot -help\n");
}
void PrintHelp(void)
{
  printf("\nCommand line:\n");
  printf("  bot SERVER_IP_ADDRESS:SERVER_PORT \n");
  printf("Options:\n");
  printf("    -port  BOT_PORT   Port for proxy mode (default is 26000)\n");
  printf("    -auto             Automatic, proxy mode off.\n");
  printf("    -game  DIRECTORY  Directory for custom files (id1)\n");
  printf("    -name  NAME       Name of the bot\n");
  printf("    -color P S        Color numbers, for the pants and shirt.\n");
  printf("Example:\n");
  printf("  bot choke.tax.gov:26000 -auto  -game theft \n\n");
  printf("If this proxy bot is run from the same directory as Quake.exe,\n");
  printf("it will check that each model and sounds is really available.\n");
  printf("\n");
  printf("Once the bot is started, you can connect to it as if it was a\n");
  printf("genuine Quake server. But you can also let it play in automatic.\n");
}

int main(int argc, char **argv)
{
  pInt8 GameDir = "id1";
  pInt8 ServerHost = DEFAULTHOST;
  Int32 ServerPort = DEFAULTPORT;
  Int32 MyPort = MYPORT;
  pInt8 BotName = BOTNETNAME;
  Int16 BotColor = BOTNETCOLOR;
  Bool Auto= FALSE;
  Int i;
  PrintBanner();
#if SYST_WINSOCK
  /*Start Winsock*/
  ClientWSAStartup();
#endif
  /*
  ** Decode command line arguments
  */
  for(i=1; i<argc; i++)
  {
	 if(argv[i]==NULL) break;
	 if(argv[i][0]=='\0') continue;
	 if((argv[i][0]!='-')&&(argv[i][0]!='/'))
	 { ServerHost = argv[i]; }
	 else
	 {
		switch(tolower(argv[i][1]))
		{
		  case 'a': /* -auto*/
			 Auto = TRUE;
			 break;
		  case 'n': /* -name <bot name>*/
			 if(((++i)<argc)&&(argv[i]!=NULL)) BotName = argv[i];
			 break;
		  case 'c': /* -color <pants> <shirt>*/
			 if((++i)<argc) BotColor = (Int16)( atoi(argv[i])&0xF);
			 if((++i)<argc) BotColor|= (Int16)((atoi(argv[i])<<4)&0xF0);
			 break;
		  case 'p': /* -port */
			 if((++i)<argc) MyPort= atoi(argv[i]);
			 break;
		  case 'g': /* -game */
			 if((++i)<argc) GameDir= argv[i];
			 break;
		  case 'h': case '?': /* -help*/
			 PrintHelp();
			 return 0;
		  default:
			 ERRwarn("Unknown command %s", &(argv[i][1]));
			 break;
		}
	 }
  }
  /*
  ** Init file database. The list must end with NULL.
  */
  DBinit(GameDir,"id1/pak0.pak","id1/pak1.pak", NULL);
  /*
  ** Run client
  */
  Run(ServerHost, ServerPort, MyPort, BotName, BotColor, Auto);
  /*
  ** Free file database
  */
  DBfree();
#if SYST_WINSOCK
  /*Stop Winsock*/
  ClientWSACleanup();
#endif
  return 1;
}

