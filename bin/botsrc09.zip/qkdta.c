/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include <math.h>
#include "defines.h"
#include "common.h"
#include "data.h"     /*Dta handling */
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkdta.h"    /*Quake types in game packets*/

#define DEBUG 0

#if DEBUG
#include <stdio.h>   /*printf*/
#endif
/*
** Times
*/
TIME DtaGetTime(pDTA pDta)
{ return (TIME)DtaGetFloat32BE(pDta);}
Int32 DtaPutTime(pDTA pDta, TIME Time)
{ return DtaPutFloat32BE(pDta,(Float32)Time);}

#define SPECIALNEG  1   /*invert special angle (player move) */
#define CAMERANEG   1   /*invert camera tilt angle */

/*
** Angles
*/
#if RADIANTS
#define YAW2INT  (128.0/M_PI)
#define INT2YAW  (M_PI/128.0)
#define TSPE2INT (56.0/M_PI_2) /*(25.0/M_PI_2)*/
#define INT2TSPE (M_PI_2/56.0) /*(M_PI_2/25.0)*/
#else
#define YAW2INT  (128.0/180.0)
#define INT2YAW  (180.0/128.0)
#define TSPE2INT (16.5/90.0)
#define INT2TSPE (90.0/16.5)
#endif
/*
** Tilt angle, trivially coded on an Int8
** +127 maps to +90 deg.
** -128 maps to -90 deg.
*/
ANGLE DtaGetAngleTilt(pDTA pDta)
{ return (ANGLE)((ANGLE)DtaGetInt8(pDta) * INT2YAW); }
/**/
Int32 DtaPutAngleTilt(pDTA pDta, ANGLE Angle)
{
  Int32 val = (Int32)(Angle * YAW2INT);
  return DtaPutInt8(pDta, (Int8)(val&0xFF));
}
/*
** Yaw angle, trivially coded on an UInt8
*/
ANGLE DtaGetAngle(pDTA pDta)
{ return (ANGLE)((ANGLE)DtaGetUInt8(pDta) * INT2YAW); }
/**/
Int32 DtaPutAngle(pDTA pDta, ANGLE Angle)
{
  Int32 val = (Int32)(Angle * YAW2INT);
  return DtaPutUInt8(pDta, (val&0xFF));
}
/*
** Angles
*/
Int32 DtaGetAngles(pDTA pDta, pANGLES pAngles)
{
  pAngles->Tilt = DtaGetAngleTilt(pDta);
  pAngles->Yaw  = DtaGetAngle(pDta);
  pAngles->Flip = DtaGetAngle(pDta);
  return 1;
}
Int32 DtaPutAngles(pDTA pDta, pANGLES pAngles)
{
  DtaPutAngleTilt(pDta, pAngles->Tilt);
  DtaPutAngle(pDta, pAngles->Yaw );
  return DtaPutAngle(pDta, pAngles->Flip);
}
/*
** Tilt angle, sent by game client.
** They are limited to Int8=+15? -49?  = +21deg. for 86deg. up
**                     Int8=-18? +56?  = -25deg. for 90deg. down
** with mean value at -2 (0deg, when reseting view)
*/
Int32 DtaGetAnglesSpecial(pDTA pDta, pANGLES pAngles)
{
  Int32 val;
  val = DtaGetInt8(pDta);
#if SPECIALNEG
  pAngles->Tilt = (ANGLE)(-((ANGLE)val) * INT2TSPE);
#else
  pAngles->Tilt = (ANGLE)(((ANGLE)val) * INT2TSPE);
#endif
  pAngles->Yaw  = DtaGetAngle(pDta);
  pAngles->Flip = DtaGetAngle(pDta);
#if DEBUG
  printf("Tilt: B=%8d > T=%8.3f\n", (int)val, (float)ANGLE2DEG(pAngles->Tilt));
#endif
  return 1;
}
Int32 DtaPutAnglesSpecial(pDTA pDta, pANGLES pAngles)
{
#if SPECIALNEG
  Int32 val = -(Int32)(pAngles->Tilt * TSPE2INT);
#else
  Int32 val = (Int32)(pAngles->Tilt * TSPE2INT);
#endif
#if DEBUG
  printf("Tilt: B=%8d < T=%8.3f\n", (int)val, (float)ANGLE2DEG(pAngles->Tilt));
#endif
  DtaPutInt8(pDta, (Int8)(val&0xFF));;
  DtaPutAngle(pDta, pAngles->Yaw );
  return DtaPutAngle(pDta, pAngles->Flip);
}
/*
** Put angles, for player's camera view
*/
Int32 DtaPutAnglesCamera(pDTA pDta, pANGLES pAngles)
{
#if CAMERANEG
  DtaPutAngle(pDta, -pAngles->Tilt );
#else
  DtaPutAngle(pDta, pAngles->Tilt );
#endif
  DtaPutAngle(pDta, pAngles->Yaw );
  return DtaPutAngle(pDta, pAngles->Flip);
}

/*
** Coordinates
*/
#define COORD2INT (1/8.0)
#define INT2COORD (8.0)

SCALAR DtaGetCoord(pDTA pDta)
{ return (SCALAR)((SCALAR)DtaGetInt16BE(pDta)*COORD2INT); }
Int32 DtaPutCoord(pDTA pDta, SCALAR Coord)
{
  Int32 val = (Int32)floor(Coord*INT2COORD);
  return DtaPutInt16BE(pDta, (Int16)(val));
}
/*
** Vec3
*/
Int32 DtaGetCoords(pDTA pDta, pVEC3 Coords)
{
  Coords->X = DtaGetCoord(pDta);
  Coords->Y = DtaGetCoord(pDta);
  Coords->Z = DtaGetCoord(pDta);
  return 1;
}
Int32 DtaPutCoords(pDTA pDta, pVEC3 Coords)
{
  DtaPutCoord(pDta, Coords->X);
  DtaPutCoord(pDta, Coords->Y);
  return DtaPutCoord(pDta, Coords->Z);
}

