
/*
** Init
*/
void BSPinit(void);
/*
** Load a Bsp file
**  Lmp, LmpSz = BSP lump
*/
Int32 BSPreInit(pInt8 Lmp, Int32  LmpSz);
/*
** Free
*/
void BSPfree(void);
/*
** Trace a line in BSP
**   pHit   = if not NULL, returns hit position.
**   pDirec = if not NULL, returns direction of trace
**   pLen = Length of line. if NULL, skip
**   returns flags saying what was found
*/
#define AREA_INVOID  0x0000
#define AREA_INWALL  0x0001
#define AREA_INWATER 0x0002
#define AREA_INLAVA  0x0004
#define AREA_INSLIME 0x0008
#define AREA_INSKY   0x0010 /*with diamonds*/
Int32 BSPtrace(pVEC3 pHit, pVEC3 pDirec, pSCALAR pLen, pVEC3 pOrigin, pVEC3 pEnd);
/*
** Find leaf
**  pLeaf = returns leaf number. if NULL, skip.
**  return flags
*/
Int32 BSPpointInLeaf(pInt32 pLeaf, pVEC3 pOrigin);
/*
**  Give the center of the leaf's bound box
**   pOrigin = returns center of the leaf's bound box
**   returns TRUE if center was found
*/
Bool BSPleafGet(pVEC3 Origin, pInt32 pFlag, Int32 Leaf);
/*
** Test if a point is really inside a leaf
** returns <=0.0 if inside
** else returns max distance to plane, > 0.0.
*/
SCALAR BSPleafPointInside(Int32 Leaf, pVEC3 pOrigin);

/*
** Find leaves, according to bounding boxes
**  Used = Table of size UsedNb
*/
Int32 BSPleafFindInBound(pInt8 Used, Int32 UsedNb, pBOUNDBOX pBound);
/*
** Trace a line in BSP without leaving the current leaf
**   Leaf = leaf inside which the trace is meant to remain
**   pOrigin, pEnd = origin and end of trace
**   pHit   = returns hit position, at the bound of current leaf
*/
Int32 BSPtraceInLeaf(pVEC3 pHit, pVEC3 pOrigin, pVEC3 pEnd, Int32 Leaf);

/*
** Find close leaves
*/
pInt32 BSPleafListWays(pInt32 pWaysNb, Int32 Leaf);
