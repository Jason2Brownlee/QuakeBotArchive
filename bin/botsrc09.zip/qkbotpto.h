/****************************************************\
*
*  Functions needed to init the bot
*   Used only by the quake client
*
\****************************************************/
/*
** Initialise the bot
*/
Int32 BotInit(pPTO pPto, pPTO pPtoW, pInt8 Name, Int16 Color, Bool Auto);
/*
** Free the bot
*/
void BotFree(void);
/****************************************************\
*
*  Functions needed to invoke bot actions
*   Used only by the protocol machine
*
\****************************************************/
/*
** bot received no messages for a long time
*/
void BotIddle(void);
/*
** bot becomes passive. A real client is about to take over
*/
void BotPassive(void);
/*
** bot receives a message
*/
void BotReceive(pDTA pDta, Bool Reliable);
/*
** Bot receives message from player  (intercepts)
*/
void BotReceivePlayer(pDTA pDta);
/*
** bot receives a message from keyboard
*/
void BotReceiveStdin(pDTA pDta);


