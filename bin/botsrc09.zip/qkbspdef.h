/*
**
** These are the Quake BSP structures, as found in .BSP files
**
*/

/*
** BSP header list
*/
typedef struct
{
  Int32 Start;      /*big endian*/
  Int32 Size;       /*big endian*/
}QKBSPE;
#define QKBSPVERSION (0x1D)
#define QKBSPDIRNB (0xF)
typedef struct
{ Int32 Id; /*0x1D*/
  QKBSPE Dir[QKBSPDIRNB];
}QKBSPHEAD;
typedef QKBSPHEAD PTR *pQKBSPHEAD;
#if SYST_BORLAND
#if sizeof(QKBSPHEAD)!= 0x7C
#error Wrong side for BSPHEAD
#endif
#endif
/*
** Plane
*/
/* 0-2 are axial planes */
#define	PLANE_X			0
#define	PLANE_Y			1
#define	PLANE_Z			2
/* 3-5 are non-axial planes snapped to the nearest*/
#define	PLANE_ANYX		3
#define	PLANE_ANYY		4
#define	PLANE_ANYZ		5
typedef struct
{
  VEC3    Normal;
  Float32 Dist;
  Int32   Type;
}QKPLANE;
typedef QKPLANE PTR *pQKPLANE;
#if SYST_BORLAND
#if sizeof(QKPLANE)!= 0x14
#error Wrong size for Planes
#endif
#endif
/*
** Texture lump header
*/
typedef struct
{
  Int32 Nb;
  Int32 Start[1];
}QKTEXLIST;
typedef QKTEXLIST PTR *pQKTEXLIST;
/*
** Texture header
*/
typedef struct
{ Int8   Name[16];   /*Name of the texture */
  Int32  SzX;        /* width of picture, must be a multiple of 8 */
  Int32  SzY;        /* height of picture, must be a multiple of 8 */
  Int32  Offs[4];    /* pointer to Pix[width*height/(2^(2*n))] */
} QKMIPTEX;
typedef QKMIPTEX PTR *pQKMIPTEX;
typedef pQKMIPTEX PTR *ppQKMIPTEX;
/*
** Vertex
*/
typedef VEC3   QKVERTEX;
typedef QKVERTEX PTR *pQKVERTEX;
/*
** Nodes
**
** if DotProduct(Origin,Plan.Normal) > Plan.Dist , then Front
** if DotProduct(Origin,Plan.Normal) < Plan.Dist , then Back
*/
#define NODE_ISLEAF(child) ((child)&0x8000)
#define NODE_MKLEAF(child) ((~(child))&0x7FFFL)
#define NODE_MKNODE(child) ((~(child))&0xFFFFL)
typedef struct
{ UInt32   Plan;    /*Split plane of the node*/
  UInt16   Front;   /*if(!(child&0x8000)) :  child = Node*/
  UInt16   Back;    /*if(child&0x8000)    : child^0xFFFF = Leaf*/
  PACKEDBBOX Bound; /* Bounding box of node and all childs*/
  UInt16   Face;    /*first face laying in split plane*/
  UInt16   FaceNb;  /*nb of faces, counting both sides*/
}QKNODE;
typedef QKNODE PTR *pQKNODE;
#if SYST_BORLAND
#if sizeof(QKNODE)!= 0x18
#error Wrong size for Nodes
#endif
#endif
/*
** Leaves
*/
#define LEAF_SOLID     (0)  /*leaf 0 is always solid*/
#define CONTENTS_EMPTY (-1)
#define CONTENTS_SOLID (-2)
#define CONTENTS_WATER (-3)
#define CONTENTS_SLIME (-4)
#define CONTENTS_LAVA  (-5)
#define CONTENTS_SKY   (-6)
typedef struct
{ Int32  Content;  /* Type of leaf: CONTENT_XXXX */
  Int32  Visi;     /* -1 or Begining of visibility lists*/
  PACKEDBBOX Bound; /* Bounding box of the leaf*/
  UInt16 LFac;     /* First item of the list of poly*/
  UInt16 LFacNb;   /* Number of poly in the list */
  UInt8  SndWater; /* sound level*/
  UInt8  SndSky;   /* sound level*/
  UInt8  SndSlime; /* sound level*/
  UInt8  SndLava;  /* sound level*/
}QKLEAF;
typedef QKLEAF PTR *pQKLEAF;
#if SYST_BORLAND
#if sizeof(QKLEAF)!=0x1C
#error Wrong size for Leaf
#endif
#endif
/*
** Texture info
*/
typedef struct
{ VEC3    S;    /*S vector*/
  SCALAR  Sofs;
  VEC3    T;    /*T vector*/
  SCALAR  Tofs;
  UInt32  Texu;     /*Texture*/
  UInt32  Anim;     /*1 for water texture*/
}QKTEXINFO;
typedef QKTEXINFO PTR *pQKTEXINFO;
#if SYST_BORLAND
#if sizeof(QKTEXINFO)!= 0x28
#error Wrong size for Texture Info
#endif
#endif
/*
** Face info
*/
typedef struct
{ UInt16  Plan;    /*Plane id*/
  UInt16  Side;    /*0=front 1=back*/
  UInt32  LEdg;    /*First item in list of edges*/
  UInt16  LEdgNb;  /*Number of edges in list*/
  UInt16  Tinf;    /*Texture info*/
  UInt8   LType;   /* light type -1=no light maps*/
  UInt8   Shadow;  /* base light level for the surface */
  UInt8   Lite1;   /* more light models*/
  UInt8   Lite2;   /* more light models*/
  Int32   LiteMap; /* pointer in lightmap */
}QKFACE;
typedef QKFACE PTR *pQKFACE;
#if SYST_BORLAND
#if sizeof(QKFACE)!= 0x14
#error Wrong size for Face
#endif
#endif
/*
** Clip Node
**  Front, Back: negative numbers are CONTENTS
*/
typedef struct
{ Int32  Plan;
  Int16  Front;   /*if(child>0) child*/
  Int16  Back;    /*if(child==CONTENTS_EMPTY) inside*/
                  /*if(child==CONTENTS_SOLID) outside*/
}QKCLIPNOD;
typedef QKCLIPNOD PTR *pQKCLIPNOD;
#if SYST_BORLAND
#if sizeof(QKCLIPNOD)!= 0x8
#error Wrong size for Clip Nodes
#endif
#endif
/*
** List of surfaces
*/
typedef UInt16 QKLFACE;
typedef QKLFACE PTR *pQKLFACE;
/*
** Edge
*/
typedef struct
{ UInt16 Vrtx[2];  /*index of vertex*/
}QKEDGE;
typedef QKEDGE PTR *pQKEDGE;
#if SYST_BORLAND
#if sizeof(QKEDGE)!=0x4
#error Wrong size of edge
#endif
#endif
/*
** List of edges
*/
typedef Int32 QKLEDGE;
typedef QKLEDGE PTR *pQKLEDGE;

/*
** Int16 Edge  if >0, Edge= index of edge
**             if <0, -Edge = index of edge
** Edge=0 is never used
*/
/*
** Model
*/
typedef struct
{ BOUNDBOX Bound;   /* The bounding box of the Hull */
  VEC3     Origin;  /* Origin of model */
  UInt32   Node;    /* id of top Hull internal BSP node */
  UInt32   Clip;    /* id of first top Hull Bound BSP node */
  UInt32   Clip2;   /* id of second top Hull Bound BSP node */
  UInt32   Clip3;   /* = 0 */
  UInt32   LeafNb;  /* number of Hull BSP leaves, not including leaf 0*/
  UInt32   Face;    /* id of first faces */
  UInt32   FaceNb;  /* number faces */
}QKMODEL;
typedef QKMODEL PTR *pQKMODEL;
#if SYST_BORLAND
#if sizeof(QKMODEL)!= 0x40
#error Wrong size for Model
#endif
#endif


#define QBSP_ENTI 0
#define QBSP_PLAN 1
#define QBSP_TEXU 2
#define QBSP_VRTX 3
#define QBSP_VISI 4
#define QBSP_NODE 5
#define QBSP_TINF 6
#define QBSP_FACE 7
#define QBSP_LITE 8
#define QBSP_CLIP 9
#define QBSP_LEAF 10
#define QBSP_LFAC 11
#define QBSP_EDGE 12
#define QBSP_LEDG 13
#define QBSP_MODL 14

