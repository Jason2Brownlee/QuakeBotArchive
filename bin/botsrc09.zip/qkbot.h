/****************************************************\
*
*  Informations about the Bot
*
\****************************************************/


typedef struct
{
  TIME  Time;        /* Current time*/
  Int32 Touch;       /* Current touch state (+1 at each update) */
  Int32 Signon;      /* Current Signon state */
  Bool  Paused;      /* TRUE if paused*/
  Bool  TheEnd;      /* TRUE if game ended*/
  /*
  ** World
  */
  Int16 Players;     /* Number of players*/
  Bool  Multi;       /* TRUE if Multiplayer*/
  Int8  MapName[32]; /* Name of the current map (for information only) */
  /*
  ** Bot Specific
  */
  ANGLES Angles;     /* Camera Orientation angles (unreliable)*/
  VEC3   Velocity;   /* Camera velocity (unreliable)*/
  Int8   Name[32];   /* Bot's name*/
  Int32  Items;      /* Flags: see ITEMS in qkdefs.h*/
  pELIVING Self;     /* Pointer to bot Entity */
  ENTITY Me;         /* The index of the bot entity (according to set view)*/
  Int16  Color;      /* Bot's color*/
  Int16  ViewHeight; /* Offset: Height above entity origin*/
  Int16  ViewFlip;   /* Offset: Angle of view*/
  /*
  ** those global variables are known to the game
  */
  Int32 Health;        /*Remaining health*/
  Int32 Unkn;          /*?*/
  Int32 Weaponmodel;   /*Index of weapon model, in model table */
  Int32 Ammo;          /*reamining current ammo*/
  Int32 Armor;         /*Armor Value*/
  Int32 Weaponframe;   /*number*/
  Int32 Shells;        /*remaining shell ammo */
  Int32 Nails;         /*remaining nails ammo */
  Int32 Rockets;       /*remaining rockets ammo */
  Int32 Cells;         /*remaining cell ammo */
  Int32 Weapon;        /* see CURRENT WEAPON in qkdefs.h */
  Int32 Total_secrets;    /*count*/
  Int32 Total_monsters;   /*count*/
  Int32 Found_secrets;    /*count*/
  Int32 Killed_monsters;  /*count*/
} BOT;
typedef BOT PTR *pBOT;

/****************************************************\
*
*  Bot actions
*
\****************************************************/
/*
** Toggle bot's authorisation to set speed and angles
*/
void BotActionAllowedToggle(void);
/*
** Send movement order (only one is sent per round)
*/
#define BOT_NONE   (0)
#define BOT_FIRE   (0x1)  /*Flag for Fire*/
#define BOT_JUMP   (0x2)  /*Flag for Jump*/
#define BOT_MASK   (0xFFL)/*Mask for Impulse*/
void BotActionMove(pBOT pBot, pANGLES Angles, pVEC3 Speeds, UInt16 Flags, UInt16 Impulse);
/*
** Send a text message to all players
** formatted like printf
*/
void BotActionPrintf(pBOT pBot, pInt8 Text, ...);
/*
** Send a disconnect command to server
*/
void BotActionDisconnect(pBOT pBot);
/*
** Send a console command to server
** formatted like printf
*/
void BotActionConsole(pBOT pBot, pInt8 Text, ...);
/*
** Send a message to player
*/
#define NORMAL      0
#define HIGHLIGHT   1
#define CENTERED    2
void BotLocalPrintf(pBOT pBot, Int32 How, pInt8 Message, ...);
/*
** Create a particle in the player's view
**  Origin = origin of particle.
*/
#define BOT_PARTICLE_RED   (-1)
#define BOT_PARTICLE_GREEN (-2)
#define BOT_PARTICLE_GREY  (-3)
#define BOT_PARTICLE_GOLD  (-4)
void BotLocalParticle(pBOT pBot, pVEC3 Origin, pVEC3 Velocity, Int16 Color, Int16 Nb);
/*
** create a fake entity on local display
**  Typ = See TEMPORARY ENTITIES in qkdefs.h
*/
void BotLocalEntity(pBOT pBot, Int32 Typ, pVEC3 Origin, pVEC3 TraceEnd);

/****************************************************\
*
*  Should in ent.h
*
\****************************************************/

/*
** Modify hate toward a player.
**  Player= player id. if invalid, modify hate toward all players.
*/
Int32 BotPlayerHate(pBOT pBot, ENTITY Player, Int32 AddedHate);
/*
** Set player name
*/
Int32 BotPlayerSetName(pBOT pBot, ENTITY Player, pInt8 Name);


