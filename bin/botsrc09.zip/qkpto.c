/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"  /*Always first to be included*/
#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "data.h"     /*Data storage*/
#include "udp.h"      /*Generic UDP*/
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake maths*/
#include "qkpto.h"    /*Protocol machine*/
#include "qkptomsg.h" /*Protocol machine*/
#include "qkmsg.h"    /*Quake Message parsing*/
#include "qkent.h"    /*Quake entities*/
#include "qkbot.h"    /*External Bot interface*/
#include "qkbotpto.h" /*Bot interface to Protocol machine*/

#include "time.h"     /*time()*/

#define CTLMSG_DURING_PLAY 1

#define SECURE       1
#define DEBUG        0
#define DEBUGCTRLMSG 0
#define DEBUGPACKETS 0


#define MAXPACKSIZE (0x400)


/****************************************************\
*
*  Protocol statistics
*
\****************************************************/

#if DEBUG
#define PtoIncRecvTotal(pPto2, Size)  PtoIncRecvTotal2(pPto2, Size,__LINE__)
#define PtoIncSendTotal(pPto2, Size)  PtoIncSendTotal2(pPto2, Size,__LINE__)
static void PtoIncRecvTotal2(pPTO2 pPto2, Int32 Size, Int32 Line)
{
  if(Size<0)
  {
    printf("Received %d bytes (line %d)",(int)Size,(int)Line);
    return;
  }
  pPto2->RecvTotal+= Size;
}
static void PtoIncSendTotal2(pPTO2 pPto2, Int32 Size, Int32 Line)
{
  if(Size<0)
  {
    printf("Send %d bytes (line %d)",(int)Size,(int)Line);
    return;
  }
  pPto2->SendTotal+= Size;
}
#else
#define PtoIncRecvTotal(pPto2, Size)  pPto2->RecvTotal+= ((Size)>0)?(Size):0
#define PtoIncSendTotal(pPto2, Size)  pPto2->SendTotal+= ((Size)>0)?(Size):0
#endif

/****************************************************\
*
*  Protocol Machine: Init/ReInit/Free
*
\****************************************************/
/*
** Init protocol machine. Do this first.
*/
Int32 PtoInit(pPTO pPto, pCLIENT pClient, pPTO pAssocPto ,pSERVER pAssocServer)
{
  pPTO2 pPto2 = (pPTO2)pPto;
  /* Check validity of sizes */
#if !(SYST_BORLAND)
  if(sizeof(PTO2)>sizeof(PTO))
    return ERRfault(ERR_BUG); /*PTO size is too small*/
#endif
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
  pPto2->pClient = pClient;
  pPto2->AssocPto2 = (pPTO2)pAssocPto;    /*if NULL, invalid*/
  pPto2->AssocSrv = pAssocServer; /*if NULL, invalid*/
  /*
  ** Decide if Pto is a fake client, or a fake world (server)
  ** A fake client has an associated fake server, a fake world not.
  */
  pPto2->IsClient = (pAssocServer!=NULL)? TRUE:FALSE;
  /*
  ** Declare that we don't know if we play automatic or not
  */
  pPto2->IsAuto= 0; /*not decided if Automatic or not */
  /*
  ** Init data structures
  */
  DtaInit(&(pPto2->SendDta),((Int32)MAXPACKSIZE)<<6);
  DtaInit(&(pPto2->RecvDta),((Int32)MAXPACKSIZE)<<6);
  DtaInit(&(pPto2->SDta),   MAXPACKSIZE + 0x10);
  DtaInit(&(pPto2->TmpDta), MAXPACKSIZE);
  /*
  ** Restart connection from scratch
  */
  pPto2->IsConnected=FALSE;
  PtoReInit((pPTO)pPto2, NULL);
  return 1;
}
/*
** Free a protocol machine.
** Don't use it after that.
*/
Int32 PtoFree(pPTO pPto)
{
  pPTO2 pPto2 = (pPTO2)pPto;
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
  PtoReInit((pPTO)pPto2,NULL);
  pPto2->pClient=NULL;
  pPto2->AssocPto2=NULL;
  pPto2->AssocSrv=NULL;
  /*
  ** Free data
  */
  DtaFree(&(pPto2->SendDta));
  DtaFree(&(pPto2->RecvDta));
  DtaFree(&(pPto2->SDta));
  DtaFree(&(pPto2->TmpDta));
  return 1;
}
/*
** Restart protocol machine from scratch
** (disconnect from server if was connnected)
*/
Int32 PtoReInit(pPTO pPto, pInt8 Adrs)
{
  pPTO2 pPto2 = (pPTO2)pPto;

  if((Adrs!=NULL)&&(Adrs[0]!='\0'))
  { /*Change the name of the server*/
	 ClientSetPeer(pPto2->pClient, Adrs, 26000);
  }
  /* Reconnect to the server */
  ClientReInit(pPto2->pClient);
  /**/
  pPto2->SendReliable=0;
  pPto2->SendUnreliable=0;
  pPto2->RecvReliable=0;
  pPto2->RecvUnreliable=0;
  pPto2->RecvTotal=0;
  pPto2->SendTotal=0;
  /* If was connected, disconnect */
  if(pPto2->IsConnected==TRUE)
  {
    DtaClear(&(pPto2->TmpDta));
    DtaPutInt8(&(pPto2->TmpDta), QPLAY_DISCONNECT);
    PtoSendUnreliable((pPTO)pPto2, &(pPto2->TmpDta));
  }
  /* Disconnect*/
  pPto2->IsConnected=FALSE;
  /* Clear all buffers*/
  DtaClear(&(pPto2->SendDta));  /*restart from scratch*/
  DtaClear(&(pPto2->RecvDta));   /*restart from scratch*/
  DtaClear(&(pPto2->SDta));   /*restart from scratch*/
  pPto2->PackComplete=FALSE;
  return 1;
}
/*
** Say if Pto is connected
*/
Bool PtoIsConnected(pPTO pPto)
{
  pPTO2 pPto2 = (pPTO2)pPto;
  return pPto2->IsConnected;
}


/*
** Print protocol statistics
*/
static Int32 RecvLast=0; /* last printed  received total */
static Int32 SendLast=0; /* last printed  send total */
static Int32 TimeLast=0; /* should be =time(NULL)*/
Int32 PtoPrintStats(pPTO pPto)
{
  Int32 Time, DeltaT, DeltaRecv, DeltaSend;
  pPTO2 pPto2 = (pPTO2)pPto;
  /*Get current time in seconds*/
  Time = (Int32)time(NULL);
  DeltaT = Time - TimeLast;
  DeltaRecv = pPto2->RecvTotal-RecvLast;
  DeltaSend = pPto2->SendTotal-SendLast;
#if 0
  printf("Total  Recv: %10lu  Sent: %10lu\n",(long)pPto2->RecvTotal, (long)pPto2->SendTotal);
#endif
  printf("Last   Recv: %10lu  Sent: %10lu\n", (long)DeltaRecv, (long)DeltaSend);
  if(DeltaT>=1)
    printf("        b/s: %10lu   b/s: %10lu\n", (long)((DeltaRecv*8)/DeltaT), (long)((DeltaSend*8)/DeltaT));
  TimeLast=Time;
  RecvLast=pPto2->RecvTotal;
  SendLast=pPto2->SendTotal;
  return 1;
}
/****************************************************\
*
*  Protocol Machine: sending packets
*
\****************************************************/
/*
** These functions all use pPto2->SDta as temporary packet
** They don't use pPto2->TmpDta
*/
/*
** Fake client sends a control packet via the fake server
**  pDta is copied from begining to end
**
*/
static Int32 PtoSendControlAssoc(pPTO2 pPto2, pDTA pDta)
{
  /* WARNING: DO NOT USE pPto2->TmpDta HERE */
#if CTLMSG_DURING_PLAY
#else
  if(pPto2->IsConnected==TRUE)
  { ERRwarn("Can't send control messages when connected"); return 0;}
#endif
  /* Controls can be sent only by a fake client */
  if(pPto2->IsClient!=TRUE)
  { return 0;}
  /* Create packet */
  QPckMakPacket(&(pPto2->SDta), QPCK_CONTROL, 0, DtaData(pDta), DtaSize(pDta));
#if DEBUGCTRLMSG
  printf("#Ctrl    %s\n", ((pPto2->IsClient==TRUE)?"FakeServer->Client":"?"));
#endif
#if DEBUGPACKETS
  QPckDump(&(pPto2->SDta));
#endif
  /* Send packet */
  return ServerSend(pPto2->AssocSrv,&(pPto2->SDta));
}
/*
** Fake Send a control packet
**  pDta is copied from begining to end
*/
static Int32 PtoSendControl(pPTO2 pPto2, pDTA pDta)
{
  /* WARNING: DO NOT USE pPto2->TmpDta HERE */
#if CTLMSG_DURING_PLAY
#else
  if(pPto2->IsConnected==TRUE)
  { ERRwarn("Can't send control messages when connected"); return 0;}
#endif
  /* Controls can be sent only by a fake client */
  if(pPto2->IsClient!=TRUE) { return 0;}
  /* Create packet */
  QPckMakPacket(&(pPto2->SDta), QPCK_CONTROL, 0, DtaData(pDta), DtaSize(pDta));
#if DEBUGCTRLMSG
  printf("#Ctrl    %s:\n", ((pPto2->IsClient==TRUE)?"FakeClient->Server":"FakeWorld->Client"));
#endif
#if DEBUGPACKETS
  QPckDump(&(pPto2->SDta));
#endif
  /* Send packet */
  return ClientSend(pPto2->pClient, &(pPto2->SDta));
}


/*
** Attempt to send a packet fragment, once again
** returns 0 if nothing sent, >0 if sent something
*/
static Int32 PtoFragAttempt(pPTO2 pPto2)
{
  Int32 remn,ContentSz, typ;
  pInt8 Content;
  /* Check if something must be sent */
  remn = DtaRemaining(&(pPto2->SendDta));
  /* Nothing to send. Finished or pending?*/
  if(remn<=0)
  { /* Check if finished*/
    if(pPto2->PackComplete == TRUE)
    { /*finished*/
      DtaClear(&(pPto2->SendDta));
      pPto2->PackComplete = FALSE;
    }
    return 0;
  }
  /* Calculate packet size and type */
  typ = (remn<=MAXPACKSIZE)? QPCK_LMEND:QPCK_LMPART;
  ContentSz = min(remn, MAXPACKSIZE);
  /* Peek sz bytes into current message*/
  Content = DtaPeek(&(pPto2->SendDta),ContentSz);
  if(Content==NULL) return -1;
  /* Create packet */
  QPckMakPacket(&(pPto2->SDta), typ, pPto2->SendReliable, Content, ContentSz);
  /* Add to count*/
  PtoIncSendTotal(pPto2,DtaSize(&(pPto2->SDta)));
#if DEBUG
  switch(typ)
  {
    case QPCK_LMPART:
      printf("#LMsg Part  %s: %ld\n", ((pPto2->IsClient==TRUE)?"FakeClient->Server":"FakeWorld->Client"),(long)pPto2->SendReliable);
      break;
    case QPCK_LMEND:
      printf("#LMsg End   %s: %ld\n", ((pPto2->IsClient==TRUE)?"FakeClient->Server":"FakeWorld->Client"),(long)pPto2->SendReliable);
      break;
  }
#endif
#if DEBUGPACKETS
  QPckDump(&(pPto2->SDta));
#endif
  /* Send packet*/
  ClientSend(pPto2->pClient, &(pPto2->SDta));
  return 1;
}
/*
** Received an ack for the last sent frag
*/
static Int32 PtoFragSuccess(pPTO2 pPto2)
{
  Int32 remn, ContentSz;
  /* Check if something was beeing sent */
  remn = DtaRemaining(&(pPto2->SendDta));
  /* Nothing being sent. Erroneous Ack*/
  if(remn<=0)
  { return 0; }
  /* Skip previously sent packet */
  ContentSz = min(remn, MAXPACKSIZE);
  DtaGet(&(pPto2->SendDta),ContentSz);
  /* Move to next packet */
  pPto2->SendReliable +=1;
  /* Try to send next packet */
  return PtoFragAttempt(pPto2);
}
/*
** Send a reliable message fragment
**  pDta = message fragment, copied from current read position
**  Last = TRUE if last fragment (i.e. if QPCK_LMEND was received)
** returns <0  if fragment could not be sent (then, do not ack)
*/
static Int32 PtoSendReliableFrag(pPTO2 pPto2, pDTA pDta, Bool Last)
{
  Int32 ContentSz;
  pInt8 Content;
  /* Check is a previous message is being sent*/
  if(pPto2->PackComplete==TRUE)
  { return -1;}
  /* Previous message still not complete, can add to it */
  /* So add remains of pDta to the current packet */
  ContentSz = DtaRemaining(pDta);
  Content= DtaPeek(pDta, ContentSz);
  if(Content==NULL)
  { return -1;}
  DtaPut(&(pPto2->SendDta), Content, ContentSz);
  /* Declare if last message */
  pPto2->PackComplete = ((Last==TRUE)? TRUE:FALSE);
  /* Try to send next packet */
  return PtoFragAttempt(pPto2);
}

/*
** Send a reliable message
**  pDta = complete message, copied from the current read position
*/
Int32 PtoSendReliable(pPTO pPto, pDTA pDta)
{
  Int32 ContentSz;
  pInt8 Content;
  pPTO2 pPto2 = (pPTO2)pPto;
  /* WARNING: DO NOT USE pPto2->TmpDta HERE */
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
  if(pPto2->IsConnected!=TRUE) /*MUST RETURN 1*/
  { return 1;} /*Can't send messages when not connected */
  ContentSz = DtaRemaining(pDta);
  Content = DtaPeek(pDta, ContentSz);
  if(Content==NULL) { return -1;}
  /* Check is a previous message is being sent*/
  if(pPto2->PackComplete==TRUE)
  { return -1;} /* Cannot send packet, due to pending ones */
  /* Can send pack, so clear buffer */
  DtaClear(&(pPto2->SendDta));
  /* Put the whole new packet into the buffer */
  DtaPut(&(pPto2->SendDta),Content, ContentSz);
  /* Declare that it's a complete packet */
  pPto2->PackComplete=TRUE;
#if DEBUG
  printf("#Begin Msg %s.\n", ((pPto2->IsClient==TRUE)?"FakeClient->Server":"FakeWorld->Client"));
#endif
#if DEBUGPACKETS
  DtaPrintDump(&(pPto2->SendDta), TRUE);
#endif
  /* Try to send next packet */
  return PtoFragAttempt(pPto2);
}
/*
** Send an Acknowledge of a Reliable packet
*/
static Int32 PtoSendAcknowledge(pPTO2 pPto2, Int32 Order)
{
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
  if(pPto2->IsConnected!=TRUE)
  { return ERRfault(ERR_BUG); }
  /* Create acknowledge packet */
  QPckMakPacket(&(pPto2->SDta), QPCK_LMACK, Order,NULL,0);
  /* add to count */
  PtoIncSendTotal(pPto2,DtaSize(&(pPto2->SDta)) );
  /* Send packet */
  ClientSend(pPto2->pClient, &(pPto2->SDta));
#if DEBUG
  printf("#LMsg Ack  %s: %ld\n", ((pPto2->IsClient==TRUE)?"FakeClient->Server":"FakeWorld->Client"),(long)Order);
  /*QPckDump(&(pPto2->SDta)); */
#endif
  return 1;
}
/*
** Send an Unreliable packet
**  pDta = message, copied from the last read position, until the end.
*/
Int32 PtoSendUnreliable(pPTO pPto, pDTA pDta)
{
  Int32 ContentSz;
  pInt8 Content;
  pPTO2 pPto2 = (pPTO2) pPto;
  /* WARNING: DO NOT USE pPto2->TmpDta HERE */
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
  if(pPto2->IsConnected!=TRUE) /*MUST RETURN 1*/
  { return 1;} /* Can't send updates when not connected */
  /* Create packet */
  ContentSz = DtaRemaining(pDta);
  Content = DtaPeek(pDta, ContentSz);
  if(Content==NULL) { return -1;}
  QPckMakPacket(&(pPto2->SDta), QPCK_UPDATE, pPto2->SendUnreliable, Content, ContentSz);
  /* add to count */
  PtoIncSendTotal(pPto2,DtaSize(&(pPto2->SDta)) );
  /* Send packet */
  ClientSend(pPto2->pClient, &(pPto2->SDta));
#if DEBUG
  printf("#Msg Updte %s: %ld\n", ((pPto2->IsClient==TRUE)?"FakeClient->Server":"FakeWorld->Client"),(long)pPto2->SendUnreliable);
#endif
#if DEBUGPACKETS
  QPckDump(&(pPto2->SDta));
#endif
  /* Increase count */
  pPto2->SendUnreliable +=1;
  return 1;
}
/****************************************************\
*
*  Protocol Machine: Handle packets received
*
\****************************************************/
/*
** Callback invoked when no messages were received for some time
*/
Int32 PtoIddle(pVoid pPtoV, pDTA pDta)
{
  static Int16 IddleS,IddleW; /*count, to reduct print frequency*/
  pPTO2 pPto2 = (pPTO2)pPtoV; /*pPtoV MUST BE OF TYPE pPTO*/
  (void)pDta; /*pDta is always NULL in this callback.*/
  /* Try to re-send pending secure messages*/
  if(PtoFragAttempt(pPto2)>0)
  { IddleS++; if((IddleS&0xF)==0)printf("Repeating packet to Server.\n");}
  /* COMPENSATE A BUG IN QUAKE (CAUSES DELAYS) */
  /* Repeat pending messages on assoc, if needed */
  if(pPto2->AssocPto2!=NULL)
  { if(PtoFragAttempt(pPto2->AssocPto2)>0)
    { IddleW++; if((IddleW&0xF)==0)printf("Repeating packet to Client.\n");}
  }
  /* if fake client, then call BotIddle */
  if(pPto2->IsClient==TRUE)
  { BotIddle(); }
  return 1;
}
/*
** Call back invoked when a message is received from real server
*/
Int32 PtoReceive(pVoid pPtoV, pDTA pDta)
{
  pPTO2 pPto2 = (pPTO2)pPtoV; /*pPtoV MUST BE OF TYPE pPTO*/
  Int32 typ,sz, order;
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
  /* Decode Quake message, if invalid, ignore it*/
  sz=QPckGetHeader(pDta, &typ, &order);
  if(sz<0) return 1;
  /* Detect if control message*/
  if(typ & QPCK_CONTROL)
  {
#if DEBUGCTRLMSG
    printf("@Ctrl    %s\n", ((pPto2->IsClient==TRUE)?"Server->FakeClient":"Client->FakeWorld"));
#endif
    /* Dispatch to the right PtoRecvXxxx, depending on message */
    QCtlInterpret(pPto2, pDta);
#if CTLMSG_DURING_PLAY
#else
    if(pPto2->IsConnected==TRUE)
    { ERRwarn("Received a control message while connected"); }
#endif
    return 1;
  }
  if(pPto2->IsConnected!=TRUE)
  { ERRwarn("Received a message while not connected"); }
  /* Increase count of received data*/
  PtoIncRecvTotal(pPto2,DtaSize(pDta));
#if DEBUG
  switch(typ)
  {
    case QPCK_LMPART:
      printf("@LMsg Part %s: %ld\n", ((pPto2->IsClient==TRUE)?"Server->FakeClient":"Client->FakeWorld"),(long)order);
      break;
    case QPCK_LMEND:
      printf("@LMsg End  %s: %ld\n", ((pPto2->IsClient==TRUE)?"Server->FakeClient":"Client->FakeWorld"),(long)order);
      break;
    case QPCK_LMACK:
      printf("@LMsg Ack  %s: %ld\n", ((pPto2->IsClient==TRUE)?"Server->FakeClient":"Client->FakeWorld"),(long)order);
      break;
    case QPCK_UPDATE:
      printf("@Msg Updte %s: %ld\n", ((pPto2->IsClient==TRUE)?"Server->FakeClient":"Client->FakeWorld"),(long)order);
      break;
  }
#endif
#if DEBUGPACKETS
  DtaPrintDump(pDta, FALSE); /*dump from current read position*/
#endif
  /* process packet*/
  switch(typ)
  {
    case QPCK_LMPART:
    case QPCK_LMEND:
      /*check order*/
      if(order<pPto2->RecvReliable)
      {
        /* Acknowledge this message */
        PtoSendAcknowledge(pPto2, order);
      }
      else if(order==pPto2->RecvReliable)
      {
#if SECURE
        /* Wait for complete message before sending it*/
        /*do not ack before we are sure to transmit*/
#else
        /* fast but risky way to send reliable message. forward as soon as possible*/
        /* attempt to forward message*/
        if(pPto2->AssocPto!=NULL)
        {
          if(PtoSendReliableFrag(pPto2->AssocPto,pDta, ((typ==LM_END)? TRUE:FALSE))<0)
          { return 0;} /*could not forward message*/
        }
        /* if it fails, stop right now, do not acknowledge or store */
        /* The message will be repeated if not acknowledged, anyway*/
        /* Acknowledge this message */
        PtoSendAcknowledge(pPto2, order);
#endif /*SECURE*/
        /* Add remains to long buffer RecvDta */
        DtaPutDta(&(pPto2->RecvDta), pDta);
        /* Process message if needed */
#if SECURE
        if(typ==QPCK_LMEND)
        {
          /* Send complete message*/
          if(pPto2->AssocPto2!=NULL)
          {
            DtaRewind(&(pPto2->RecvDta)); /*set read pointer to zero*/
            if(PtoSendReliable((pPTO)(pPto2->AssocPto2),&(pPto2->RecvDta))<0)
            { /*cancel last part of message, that will be sent again, because not ack-ed*/
              DtaSetSize(&(pPto2->RecvDta),DtaSize(&(pPto2->RecvDta))-sz);
              return 0; /*server went too fast, do not ack*/
            }
          }
        }
#endif
        /* Increase count, to avoid duplicates */
        pPto2->RecvReliable +=1;
#if SECURE
        /* Now we are sure we can acknowledge this message */
        PtoSendAcknowledge(pPto2, order);
#endif
        if(typ==QPCK_LMEND)
        {
          /* Interpret messages */
          DtaRewind(&(pPto2->RecvDta)); /*set read pointer to zero*/
          /*
          ** If fake client, then call BotReceive() to let
          ** the bot take a look at the message.
          */
          if(pPto2->IsClient==TRUE)
          { BotReceive(&(pPto2->RecvDta), TRUE); }
          /*
          ** Otherwise... could let the bot intercept message
          */
          /*
          ** Clear RecvDta, to prepare for next message part
          */
          DtaClear(&(pPto2->RecvDta));
        }
      }
      else
      { /* Dammit, server went too fast */
        ERRwarn("Lost synch with server!");
      }
      break;
    /*
    ** Got an acknowledge
    */
    case QPCK_LMACK:
      /*ckeck order*/
      if(order==pPto2->SendReliable)
      {
        /* If currently sending long message, continue*/
        PtoFragSuccess(pPto2);
      }
      break;
    /*
    ** Got an update
    */
    case QPCK_UPDATE:
      /*check order*/
      if(order>=pPto2->RecvUnreliable)
      {
        /*
        ** If fake client, and not automatic, then forward message
        ** to client, via the associated Pto (fake world)
        */
        if((pPto2->IsClient==TRUE)&&(pPto2->IsAuto<0))
        { PtoSendUnreliable((pPTO)(pPto2->AssocPto2),pDta);}
        /*
        ** Increase count, to avoid duplicate messages
        ** Note that lost updates are ignored
        */
        pPto2->RecvUnreliable = order + 1;
        /*
        ** If fake client, the bot must interpret the server message
        */
        if(pPto2->IsClient==TRUE)
        { /*interpret server message*/
          BotReceive(pDta, FALSE);
        }
        /*
        ** If pPto2 is fake world, and
        */
        else if(pPto2->IsAuto<0) /* Only if not automatic */
        { /*handle player messages*/
          BotReceivePlayer(pDta);
        }
      }
      break;
    default:
      ERRwarn("Invalid packet type: %04d",(Int)typ);
      break;
  }
  return 1;
}

/*
** Call back invoked when a message is received from real client
*/
Int32 PtoReceiveServer(pVoid pPtoV, pDTA pDta)
{
  pPTO2 pPto2 = (pPTO2)pPtoV; /*pPtoV MUST BE OF TYPE pPTO*/
  Int32 typ,sz, order;
  /* if not client, ignore orders */
  if(pPto2->IsClient!=TRUE)
  { return 0;}
  /*Send along to real server*/
  /* Decode Quake message, if invalid, ignore it*/
  sz=QPckGetHeader(pDta, &typ, &order);
  if(sz<0) return 1;
  /* Detect if control message*/
  if(typ & QPCK_CONTROL)
  {
#if DEBUGCTRLMSG
    printf("@Ctrl    Client->FakeServer\n");
#endif
    /* interpret control messages*/
#if 1
    /* Dispatch to the right PtoRecvXxxx, depending on message */
    if(QCtlInterpret(pPto2, pDta)>0)
    /*
    ** Forward the control packet to it's destination.
    ** That packet is assumed to be valid.
    */
    { ClientSend(pPto2->pClient,pDta);}

    /* forward control message, through fake client*/
#else /*OBSOLETE*/
    order = DtaGetUInt8(pDta);
    /*
    ** If a real client attempted to connect, the Pto is assumed
    ** to be in NON-automatic mode.
    */
    if(order==QCTL_CONNECT) /*01=CONNECT*/
    {
      printf("Received a connection request.\n");
      /* unless already automatic, force non-automatic mode*/
      if(pPto2->IsAuto<=0)
      { pPto2->IsAuto= -1; /* Now cannot become automatic */
        if(pPto2->AssocPto!=NULL) { pPto2->AssocPto->IsAuto = pPto2->IsAuto;}
        /* The bot must become passive */
        BotPassive();
      }
    }
    /*
    ** Forward the control packet to it's destination.
    ** That packet is assumed to be valid.
    */
    if(pPto2->IsAuto<=0)
    { ClientSend(pPto2->pClient,pDta);}
#endif
  }
  else
  { /* only handle control messages*/
    ERRwarn("Received a non-control message on server");
  }
  return 1;
}

/****************************************************\
*
*  Protocol Machine: Handle control message received
*  those functions return >0 if message is okay, and cab be forwarded
*
\****************************************************/
/*
** Receive messages from Client, or from other Bot on the net.
*/
Int32 PtoRecvConnect(pPTO2 pPto2, const pInt8 Game, Int32 version)
{
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
  printf("@ Connect request. Game=%s\n",((Game==NULL)?(pInt8)"None":Game));
#endif
  if(Game==NULL) { return 0;}
  /* Check if received a quake bot info message*/
  if(Strncmp(Game, "QUAKE",5)<0) { return 0; }
  /* unless already automatic, force non-automatic mode*/
  if(pPto2->IsAuto<=0)
  { pPto2->IsAuto= -1; /* Now cannot become automatic */
    if(pPto2->AssocPto2!=NULL) { pPto2->AssocPto2->IsAuto = pPto2->IsAuto;}
    /* The bot must become passive */
    BotPassive();
  }
  (void)version;
  /* if bot is automatic, do not forward connect requests */
  if(pPto2->IsAuto>0)
  { return 0; }
  return 1;
}
Int32 PtoRecvAskInfos(pPTO2 pPto2, const pInt8 Game, Int32 version)
{
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
 printf("@ Ask Infos. Game=%s\n", (Game==NULL)? (pInt8)"None": Game);
#endif
  (void)version;
  if(Game==NULL) { return 0;}
  /* Check if received a quake bot info message*/
  if(Strncmp(Game, "QUAKEBOT",8)>0)
  {
    printf("A QuakeBot Info message was received.\n");
    /*
    ** Should reply to this with bot parameters
    */
    return 0;
  }
  return 1;
}
Int32 PtoRecvAskPlayer(pPTO2 pPto2, Int32 player)
{
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
 printf("@ Ask Player %d\n",(int)player);
#endif
 (void)pPto2; (void)player;
 return 0; /*do not forward*/
}
Int32 PtoRecvAskRule(pPTO2 pPto2, const pInt8 Rule)
{
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
 printf("@ Ask Rule %s\n", (Rule==NULL)? (pInt8)"None":Rule);
#endif
 (void)pPto2; (void)Rule;
 return 0; /*do not forward*/
}

/*
** Receive an Accept CTRL message
*/
Int32 PtoRecvAccept(pPTO2 pPto2, Int32 Port)
{
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
  printf("@ Accept connection. Port=%d\n", (int)Port);
#endif
  /*
  ** Avoid double connection acceptance
  */
  if(pPto2->IsConnected==TRUE)
  {
#if CTLMSG_DURING_PLAY
    /*attempt to remove huge delays in connecting */
    /*by allowing successive accepts, returning same value*/
#else
    ERRwarn("Received an accept while already connected");
    return 0;
#endif
  }
  if(pPto2->IsConnected!=TRUE)
  {
    printf("Server port is now %d\n", (int) Port);
    /* Change fake client's peer port */
    if(ClientSetPeerPort(pPto2->pClient, Port)<0)
    /*fake client Didn't accept to connect to new port*/
    { ERRwarn("Cannot use port %d", (Int)Port); return -1;}
  }
  /* Forward message to world, only if client, and automatic */
  if((pPto2->IsClient==TRUE)&&(pPto2->IsAuto<0))
  {
    if((pPto2->AssocPto2==NULL)||(pPto2->AssocSrv==NULL))
    { return ERRfault(ERR_BUG);}
    if(pPto2->IsConnected!=TRUE)
    {
      /* Bug: if another dude talks to the server, he will take over*/
      /* Declare that the fake world's peer is the last who talked to the fake server*/
      if(ClientCopyPeer(pPto2->AssocPto2->pClient,pPto2->AssocSrv)<0)
      /* World didn't accept to connect to real client */
      { return ERRwarn("Cannot connect to client");}
    }
    /*Get the world port */
    Port = ClientGetPort(pPto2->AssocPto2->pClient);
    /* Forward the port number through the fake server*/
    QCtlMakAccept(&(pPto2->TmpDta), Port);
    PtoSendControlAssoc(pPto2,&(pPto2->TmpDta));

#if DEBUGCTRLMSG
    printf("#Accept -> Client. Port=%d\n", (int)Port);
#endif
#if 0
    /* Reply twice to client, for confirmation*/
    /* Otherwise the game init takes a lot of time */
    /* Alas, it doesn't work.*/
    PtoSendControlAssoc(pPto2,&(pPto2->TmpDta));
#endif
    /* Declare connected */
    pPto2->AssocPto2->IsConnected = TRUE;
  }
  /* If has no real client, then client is automatic*/
  if(pPto2->IsAuto==0)
  {
    pPto2->IsAuto=1;
    if(pPto2->AssocPto2!=NULL) { pPto2->AssocPto2->IsAuto = pPto2->IsAuto;}
  }
  pPto2->IsConnected = TRUE;
  return 1;
}
/*
** Receive a Refuse CTRL message
*/
Int32 PtoRecvRefuse(pPTO2 pPto2, const pInt8 Reason)
{
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
  printf("@ Refuse connection.\n");
#endif
  /* WARNING: Text should be copied to a safe place*/
  if(pPto2->IsConnected==TRUE)
  { ERRwarn("Received a refusal while already connected"); }
  printf("Connection refused: %s\n", (Reason==NULL)? (pInt8)"No reason":Reason);
  /*confirm*/
  pPto2->IsConnected=FALSE;
  /*Send to Assoc */
  QCtlMakRefuse(&(pPto2->TmpDta), Reason);
  PtoSendControlAssoc(pPto2,&(pPto2->TmpDta));
  return 1;
}
/*
** Receive Game infos
*/
Int32 PtoRecvGameInfos(pPTO2 pPto2, const pInt8 Adrs, const pInt8 Host, const pInt8 Map, Int16 Players, Int16 Playmax, Int16 Version)
{
  static Int8 MyAdrs[0x20];
  static Int8 MyMap[0x20];
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
 printf("@ Game Infos. Adrs=%s\n", (Adrs==NULL)? (pInt8)"None":Adrs);
#endif
  /*WARNING: copy all pInt8 to a safe place if needed later*/
  Strncpy(MyMap, Map, sizeof(MyMap)-1);
  /* Reply to Assoc */
  if((pPto2->IsClient==TRUE)&&(pPto2->IsAuto<=0))
  {
    if((pPto2->AssocPto2==NULL)||(pPto2->AssocSrv==NULL))
    { return ERRfault(ERR_BUG);}
    ServerAdrsPrint(pPto2->AssocSrv, MyAdrs, sizeof(MyAdrs));
    QCtlMakGiveInfos(&(pPto2->TmpDta), MyAdrs, BOTNETNAME, MyMap, Players, Playmax, Version);
    PtoSendControlAssoc(pPto2,&(pPto2->TmpDta));
  }
  /*Print game informations*/
  printf("Game Informations (version %d)\n", (int)Version);
  if(Adrs!=NULL) printf("  Address:  %s\n",Adrs);
  if(Host!=NULL) printf("  Host:     %s\n",Host);
  if(Map!=NULL)  printf("  MapName:  %s\n",MyMap);
  printf("  Players:  %d / %d\n",(int)Players, (int)Playmax);
  /* DO NOT EVER send ask player now, it spoils the list.*/
  return 1;
}
/*
** Receive player infos, ask the next ones
** Player = 1... Playermax
*/
Int32 PtoRecvPlayerInfos(pPTO2 pPto2, Int32 Player, const pInt8 Name, const pInt8 Adrs, Int32 Color, Int32 Frags, Int32 Time)
{
  /*WARNING: copy all pInt8 to a safe place if needed later*/
  Int16 Shirt, Pants;
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
  printf("@ Player Infos. Player=%d\n", (int)Player);
#endif
  Player &= 0x3FL;
  Shirt = (Int16)((Color>>4)&0xFL);
  Pants = (Int16)((Color)&0xFL);
  printf("Informations on player %d\n", (int)Player);
  if(Name!=NULL) printf("  Name:     %s\n",Name);
  if(Adrs!=NULL) printf("  Address:  %s\n",Adrs);
  printf("  Shirt      %2d     Pants  %2d\n", (int)Shirt, (int)Pants);
  printf("  Frags:    %ld\n", (long)Frags);
  printf("  PlayTime: %ld seconds\n",(long)Time);
  if(Color&0xFFFFFF00L) printf("Unknown: %8lx",(long)Color);
  /*send player info request for the next one*/
  PtoSendAskPlayer((pPTO)pPto2, Player+1);
  return 1;
}
/*
** Receive rule infos, ask the next one
*/
Int32 PtoRecvRuleInfos(pPTO2 pPto2,const pInt8 Name,const pInt8 Value)
{
  /*WARNING: copy all pInt8 to a safe place if needed later*/
  static Int8 Rule[32];
  if(pPto2==NULL)
  { return ERRfault(ERR_BUG); }
#if DEBUGCTRLMSG
  printf("@ Rule info. Rule=%s\n", (Name==NULL)? (pInt8)"None":Name);
#endif
  /* Check if no more rules*/
  if(Name==NULL) return 1;
  Strncpy(Rule, Name, sizeof(Rule));
  printf("Rule  %s = %s\n", Rule, (Value==NULL)? ((pInt8)"None"): Value);
  /* Ask for the next rule*/
  PtoSendAskRule((pPTO)pPto2, Rule);
  return 1;
}

/****************************************************\
*
*  Protocol Machine: Send control messages
*
\****************************************************/
/*
** Send a connect request (control message)
*/
Int32 PtoSendConnect(pPTO pPto)
{
  pPTO2 pPto2 = (pPTO2)pPto;
  QCtlMakConnect(&(pPto2->TmpDta));
  return PtoSendControl(pPto2, &(pPto2->TmpDta));
}

/*
** Send a give info request (control message)
*/
Int32 PtoSendAskInfos(pPTO pPto)
{
  pPTO2 pPto2 = (pPTO2)pPto;
  QCtlMakAskInfos(&(pPto2->TmpDta));
  return PtoSendControl(pPto2, &(pPto2->TmpDta));
}
/*
** Send a player info request (control message)
**  Player = 1...Playermax
*/
Int32 PtoSendAskPlayer(pPTO pPto, Int32 Player)
{
  pPTO2 pPto2 = (pPTO2)pPto;
  QCtlMakAskPlayer(&(pPto2->TmpDta), Player);
  return PtoSendControl(pPto2, &(pPto2->TmpDta));
}
/*
** Send a rule info request (control message)
** If Rule==NULL, send first rule
*/
Int32 PtoSendAskRule(pPTO pPto, pInt8 Rule)
{
  pPTO2 pPto2 = (pPTO2)pPto;
  QCtlMakAskRule(&(pPto2->TmpDta), Rule);
  return PtoSendControl(pPto2, &(pPto2->TmpDta));
}


/****************************************************\
*
*  Protocol Machine: Interpret commmands from Stdin
*
\****************************************************/
/*
** Receive Message from Stdin
*/
Int32 PtoReceiveStdin(pVoid pPtoV, pDTA pDta)
{
  pPTO2 pPto2 = (pPTO2)pPtoV; /*pPtoV MUST BE OF TYPE pPTO*/
  if(pPto2->IsClient==TRUE) BotReceiveStdin(pDta);
  return 1;
}


