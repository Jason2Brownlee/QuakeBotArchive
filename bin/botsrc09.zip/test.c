#include <stdio.h>
#include <stdlib.h>
#include "defines.h"
#include "common.h"
#include "data.h"
#include "qkdefs.h"
#include "qkmath.h"
#include "qkent.h"
#include "qkbot.h"
#include "qkpak.h"
#include "qkbsp.h"
#include <math.h>




#include <time.h>

void TestBsp(void)
{
  VEC3 Direction, Hit, Origin, End;
  SCALAR Len;
  Int32 res, Leaf, Leaf2;
  pInt8 Lmp; Int32 LmpSz;
  time_t Time;

  pInt8 File = "maps/start.bsp";
  DBinit("id1/pak0.pak", "id1/pak1.pak",NULL);
  BSPinit();
  Lmp= DBget(&LmpSz, File);
  /**/
  printf("Initialise %s\n",File);
  Time = time(NULL);
  BSPreInit(Lmp,LmpSz);
  printf("Duration=%ld\n",(long)(time(NULL)-Time));
  /**/
#if 0
  for(Leaf=0; Leaf<1148; Leaf++)
  {
	 if(BSPleafGet(&Origin, &res, Leaf)!=TRUE)
	 { continue; }
  }
  /* Test PointInLEaf*/
  Leaf=10;
  if(BSPleafGet(&Origin, &res, Leaf)!=TRUE){ printf("Error\n");}
  printf("Origin Leaf = %8d   Flags=%8x\n", (int)Leaf, (int)res);
  res = BSPpointInLeaf(&Leaf, &Origin);
  printf("Origin Leaf = %8d   Flags=%8x\n", (int)Leaf, (int)res);
  Leaf=120;
  if(BSPleafGet(&End, &res, Leaf)!=TRUE){ printf("Error\n");}
  printf("End Leaf =    %8d   Flags=%8x\n", (int)Leaf, (int)res);
  res = BSPpointInLeaf(&Leaf, &End);
  printf("End Leaf =    %8d   Flags=%8x\n", (int)Leaf, (int)res);
 /* TestTrace*/
  res= BSPtrace(&Hit, &Direction, &Len, &Origin, &End);
  printf("Len = %8.3f   Flags=%8x\n", (float)Len, (int)res);
  printf("Hit at %8.3f %8.3f %8.3f\n", (float)Hit.X,(float)Hit.Y,(float)Hit.Z);
#endif
  BSPfree();
  DBfree();
}


void TestGeometry(void)
{
  ANGLES A1;
  ANGLES A2;
  VEC3 V1,V2,V3;
  Int32 i;


#if 1 /*test of cross product*/
  V1.X=0.0; V1.Y=1.0; V1.Z=0.0;
  V2.X=0.0; V2.Y=0.0; V2.Z=1.0;
  VecCrossProduct(&V3,&V1,&V2);
  printf("V1 ^ V2 = %8.3f %8.3f %8.3f\n",(float)V3.X,(float)V3.Y,(float)V3.Z);

  A1.Tilt = DEG2ANGLE(-98.0);  A1.Yaw=DEG2ANGLE(290.0); A1.Flip=DEG2ANGLE(18.0);
  printf("Angles %8.3f %8.3f %8.3f\n",ANGLE2DEG(A1.Tilt), ANGLE2DEG(A1.Yaw),ANGLE2DEG(A1.Flip));
  Ang2Vec(&V3,&A1);
  printf("V3   = %8.3f %8.3f %8.3f\n",V3.X,V3.Y,V3.Z);
  Vec2Angles(&A2,&V3);
  printf("Angles %8.3f %8.3f %8.3f\n",ANGLE2DEG(A2.Tilt), ANGLE2DEG(A2.Yaw),ANGLE2DEG(A2.Flip));
#endif

#if 1 /*test of vec2angles*/
  VecSet(&V1, 0.0, 1.0, 0.0);
  Vec2Angles(&A1,&V1);
  printf("V1     = %8.3f  %8.3f  %8.3f\n",V1.X,V1.Y,V1.Z);
  printf("  Angles %8.3ft %8.3fy %8.3f\n",ANGLE2DEG(A1.Tilt), ANGLE2DEG(A1.Yaw),ANGLE2DEG(A1.Flip));
  VecSet(&V1, 3.0, 4.0, -1.0);
  Vec2Angles(&A1,&V1);
  printf("V1     = %8.3f  %8.3f  %8.3f\n",V1.X,V1.Y,V1.Z);
  printf("  Angles %8.3ft %8.3fy %8.3f\n",ANGLE2DEG(A1.Tilt), ANGLE2DEG(A1.Yaw),ANGLE2DEG(A1.Flip));
  VecSet(&V1, 5.0, -7.0, 4.0);
  Vec2Angles(&A1,&V1);
  printf("V1     = %8.3f  %8.3f  %8.3f\n",V1.X,V1.Y,V1.Z);
  printf("  Angles %8.3ft %8.3fy %8.3f\n",ANGLE2DEG(A1.Tilt), ANGLE2DEG(A1.Yaw),ANGLE2DEG(A1.Flip));
  VecSet(&V1, 0.0, 0.0, 4.0);
  Vec2Angles(&A1,&V1);
  printf("V1     = %8.3f  %8.3f  %8.3f\n",V1.X,V1.Y,V1.Z);
  printf("  Angles %8.3ft %8.3fy %8.3f\n",ANGLE2DEG(A1.Tilt), ANGLE2DEG(A1.Yaw),ANGLE2DEG(A1.Flip));
#endif

#if 1 /*test of vec2yaw*/
  V1.X=13.0; V1.Y=15.0; V1.Z=10.0;
  printf("||V1|| = %8.3f\n", VecNorm(&V1));
  VecNormalise(&V1);
  printf("||V1|| = %8.3f\n", VecNorm(&V1));
  printf("Angle = %8.3f\n",ANGLE2DEG(Vec2Yaw(10.0,10.0)));
  printf("Angle = %8.3f\n",ANGLE2DEG(Vec2Yaw(5.0,10.0)));
  printf("Angle = %8.3f\n",ANGLE2DEG(Vec2Yaw(-5.0,10.0)));
  printf("Angle = %8.3f\n",ANGLE2DEG(Vec2Yaw(-5.0,-10.0)));
  printf("Angle = %8.3f\n",ANGLE2DEG(Vec2Yaw(5.0,-10.0)));
#endif

#if 1  /*test of angle diff*/
  printf("Angle Differences\n");
  A1.Tilt=DEG2ANGLE(20);  A1.Yaw=DEG2ANGLE(30); A1.Flip=DEG2ANGLE(80);
  printf("Ref %8.3f %8.3f %8.3f\n",
    ANGLE2DEG(A1.Tilt), ANGLE2DEG(A1.Yaw),ANGLE2DEG(A1.Flip));
  A2.Tilt=DEG2ANGLE(40);  A2.Yaw=DEG2ANGLE(40); A2.Flip=DEG2ANGLE(120);
  printf("Try %8.3f %8.3f %8.3f :  %8.3f==%8.3f\n",
    ANGLE2DEG(A2.Tilt), ANGLE2DEG(A2.Yaw),ANGLE2DEG(A2.Flip),
    ANGLE2DEG(AngDiff(&A1,&A2)),ANGLE2DEG(AngDiff(&A2,&A1))
	 );
  A2.Tilt=DEG2ANGLE(0);  A2.Yaw=DEG2ANGLE(20); A2.Flip=DEG2ANGLE(80);
  printf("Try %8.3f %8.3f %8.3f :  %8.3f==%8.3f\n",
    ANGLE2DEG(A2.Tilt), ANGLE2DEG(A2.Yaw),ANGLE2DEG(A2.Flip),
    ANGLE2DEG(AngDiff(&A1,&A2)),ANGLE2DEG(AngDiff(&A2,&A1))
    );
  A2.Tilt=DEG2ANGLE(-80);  A2.Yaw=DEG2ANGLE(350); A2.Flip=DEG2ANGLE(80);
  printf("Try %8.3f %8.3f %8.3f :  %8.3f==%8.3f\n",
    ANGLE2DEG(A2.Tilt), ANGLE2DEG(A2.Yaw),ANGLE2DEG(A2.Flip),
    ANGLE2DEG(AngDiff(&A1,&A2)),ANGLE2DEG(AngDiff(&A2,&A1))
    );
  A2.Tilt=DEG2ANGLE(20);  A2.Yaw=DEG2ANGLE(250); A2.Flip=DEG2ANGLE(80);
  printf("Try %8.3f %8.3f %8.3f :  %8.3f==%8.3f\n",
    ANGLE2DEG(A2.Tilt), ANGLE2DEG(A2.Yaw),ANGLE2DEG(A2.Flip),
    ANGLE2DEG(AngDiff(&A1,&A2)),ANGLE2DEG(AngDiff(&A2,&A1))
    );
  A1.Tilt=DEG2ANGLE(90);  A1.Yaw=DEG2ANGLE(180); A1.Flip=DEG2ANGLE(80);
  printf("Ref %8.3f %8.3f %8.3f\n",
    ANGLE2DEG(A1.Tilt), ANGLE2DEG(A1.Yaw),ANGLE2DEG(A1.Flip));
  A2.Tilt=DEG2ANGLE(-90);  A2.Yaw=DEG2ANGLE(20); A2.Flip=DEG2ANGLE(120);
  printf("Try %8.3f %8.3f %8.3f :  %8.3f==%8.3f\n",
    ANGLE2DEG(A2.Tilt), ANGLE2DEG(A2.Yaw),ANGLE2DEG(A2.Flip),
    ANGLE2DEG(AngDiff(&A1,&A2)),ANGLE2DEG(AngDiff(&A2,&A1))
    );
#endif
#if 1  /*test of random values*/
  for(i=0;i<40;i++)
  {
    printf("rand  %8.3f  %8d\n", RandF(-200,200), (int)RandI(-200,200));
  }
#endif
 return;
}

int main(int argc, char **argv)
{
#if 1 /*test of BSP*/
  TestBsp();
#endif
#if 0
  TestGeometry();
#endif
 (void) argc;
 (void) argv;
 return 1;
}
