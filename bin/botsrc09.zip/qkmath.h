/*
** Quake general definitions, and maths
*/
/*
** Time
*/
typedef Float32      TIME;
typedef TIME PTR   *pTIME;
/*
** if true, use radians for angles, otherwise degrees
*/
#define RADIANTS 1
/*
**
*/
#ifndef M_PI
#define M_PI        3.14159265358979323846
#endif
#ifndef M_PI_2
#define M_PI_2      1.57079632679489661923
#endif
/*
** Those macro ensure we always print degrees
**  ANGLE2DEG(a) converts-+ angle to degree
**  DEG2ANGLE(a) converts degree to angle
**
** Beware that those angles will be in the trigo sense,
** which is opposite to the geographic sense.
*/
#if RADIANTS
/* Radiants to Degree = 180.0/M_PI*/
#define ANGLE2DEG(a) (Float32)((a) * 57.29577953)
/* Degree to Radiants = M_PI/180.0*/
#define DEG2ANGLE(a) (ANGLE)((a) * 0.01745329252)
#else
/* Degree */
#define ANGLE2DEG(a) (Float32)(a)
/* Degree */
#define DEG2ANGLE(a) (ANGLE)(a)
#endif

/*
** Angle
*/
typedef Float32      ANGLE;
typedef ANGLE PTR  *pANGLE;
/*
** Angle Vector storing [TILT YAW SPLIT]
*/
typedef struct{ ANGLE Tilt; ANGLE Yaw; ANGLE Flip;} ANGLES;
typedef ANGLES PTR *pANGLES;
/*
** Vector
*/
typedef Float32      SCALAR;
typedef SCALAR PTR *pSCALAR;
typedef struct { SCALAR X; SCALAR Y; SCALAR Z;} VEC3;
typedef VEC3 PTR   *pVEC3;
/*
** Operations on angles
*/
/* Absolute difference between angles (except flip) */
ANGLE AngDiff(pANGLES pDest, pANGLES pSrc);
/* Make two angles equal */
void AngCpy(pANGLES pDest, pANGLES pSrc);
/* Conversion from angles to vector */
void Ang2Vec(pVEC3 Direction, pANGLES Angles);
/* Get Front, Right, Up from angles*/
void Ang2Orient(pVEC3 Front, pVEC3 Right, pVEC3 Up, pANGLES Angles);
/*
** Operations on vectors
*/
/* clear vector */
#define  VecClear(Dest)       (Dest)->X=0.0;(Dest)->Y=0.0;(Dest)->Z=0.0
/* initialise a vector */
void VecSet(pVEC3 pDest, SCALAR X, SCALAR Y, SCALAR Z);
/* absolute value of max difference between two vectors*/
SCALAR VecDiff(pVEC3 pDest, pVEC3 pSrc);
/* Make two vectors equal */
void VecCpy(pVEC3 pDest, pVEC3 pSrc);
/* Add Source to Dest*/
void VecAdd(pVEC3 Dest, pVEC3 Source);
/* Substract source to dest*/
void VecSub(pVEC3 Dest, pVEC3 Source);
/* scale Dest */
void VecScale(pVEC3 Dest, SCALAR Source);
/* Add scaled Source to Dest*/
void VecAddScale(pVEC3 Dest, pVEC3 Source, SCALAR Scale);
/* negate Dest */
void VecNeg(pVEC3 Dest);
/* Dot product*/
SCALAR VecDotProduct(pVEC3 Dest, pVEC3 Scale);
/* Plane distance. plane = (Normal,Distance) */
SCALAR VecPlaneDist(pVEC3 Origin, pVEC3 Normal, SCALAR Distance);
/* Calculate square norm of vector */
SCALAR VecNorm2(pVEC3 Dest);
/* Calculate norm of vector */
SCALAR VecNorm(pVEC3 Dest);
/* Normalise vector */
void VecNormalise(pVEC3 Dest);
/* Cross product */
void VecCrossProduct(pVEC3 Dest, pVEC3 Src1, pVEC3 Src2);
/* Vec to yaw, calculate yaw angle, from X,Y */
ANGLE Vec2Yaw(SCALAR X, SCALAR Y);
/* Vector to angles */
void Vec2Angles(pANGLES Angles, pVEC3 Src);
/*
**
** Bounding Boxes
**
*/
typedef struct
{
  Float32 MinX;
  Float32 MinY;
  Float32 MinZ;
  Float32 MaxX;
  Float32 MaxY;
  Float32 MaxZ;
} BOUNDBOX;
typedef BOUNDBOX PTR *pBOUNDBOX;
/* Copy Boundbox*/
void BBOXcpy(pBOUNDBOX pDest, pBOUNDBOX pSrc);
/* Extend a bound box by a certain value */
void BBOXextend(pBOUNDBOX pDest,  SCALAR X, SCALAR Y, SCALAR Z);
/* Test if pSrc is empty (one coordinate below tolerancy) */
Bool BBOXisEmpty(pBOUNDBOX pSrc);
/* Test if point pOrigin is inside pSrc */
Bool BBOXisInside(pBOUNDBOX pSrc, pVEC3 pOrigin);
/* pDest = pSrc1 union pSrc2 */
void BBOXunion(pBOUNDBOX pDest, pBOUNDBOX pSrc1, pBOUNDBOX pSrc2);
/* pDest = pSrc1 intersect pSrc2 */
void BBOXinter(pBOUNDBOX Dest, pBOUNDBOX Src1, pBOUNDBOX Src2);
/*
** Packed bounding box
*/
typedef struct
{
  Int16 MinX;
  Int16 MinY;
  Int16 MinZ;
  Int16 MaxX;
  Int16 MaxY;
  Int16 MaxZ;
} PACKEDBBOX;
typedef PACKEDBBOX PTR *pPACKEDBBOX;
