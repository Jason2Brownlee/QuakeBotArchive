/*
** Prepare an entity for further calculations
**  Origin = bot origin
**  Time   = current bot time
*/
void MOVEprepare(pELIVING Ent, pVEC3 pOrigin);
/*
** Guess position of an entity, DeltaT seconds later
** pOrigin = result
** DeltaT = position forecast in DeltaT seconds
** Time = current time
*/
void MOVEguessPosition(pVEC3 pOrigin, TIME Time, pELIVING Ent, TIME DeltaT);
/*
** Give the position of an entity,
** relatively to Origin and Angles
*/
void MOVEgetRelativePos(pVEC3 pResult, pVEC3 pOrigin, pANGLES pAngles, pELIVING Ent);
/*
** Print the relative position
*/
pInt8 MOVEprintRelativePos(pVEC3 pResult);
/*
** Get the best course to avoid an entity
**  Ent = entity to be avoided
**  assumes Ent->Delta = Self->Origin - Ent->Origin
**  assumes Ent->Norm2 = norm(Self->Origin - Ent->Origin)^2
**  returns Course
*/
Bool MOVEavoid(pVEC3 Course, pELIVING Ent, SCALAR Range);
/*
** Avoid a certain angle around line of sight
** This method is rather stupid.
*/
Bool MOVEavoid1(pVEC3 Course, pELIVING Ent);
/*
** Get the best course to avoid a line of sight
**  Ent = entity to be avoided
**  assumes Ent->Delta = Self->Origin - Ent->Origin
**  assumes Ent->Norm2 = norm(Self->Origin - Ent->Origin)^2
**  returns desired Course (not normalised)
**  Method = maximise increase in relative angles, because that's
**  the quickest way to get out of a line of sight.
**  Note that it's not the best way to avoid a real-life missile.
*/
Bool MOVEavoid2(pVEC3 Course, pELIVING Ent);

/*
** Aim at an entity
**  Ent   = entity to aim at
**  assumes Ent->TmpVec = Self->Origin - Ent->Origin
**  Angles = result
*/
Bool MOVEaimEntity(pANGLES pAngles, pELIVING Ent);
/*
** Aim at a Target, from Origin
*/
Bool MOVEaimPoint(pANGLES pAngles, pVEC3 pOrigin, pVEC3 pTarget);
/*
** Move an entity along the desired course, by changing angles
** (assuming angles can be instantaneously changed)
*/
void MOVEalongCourseA(pVEC3 pSpeed, pANGLES pAngles, pVEC3 pCourse);
/*
** Move an entity along the desired course
** Without changing the angles
*/
void MOVEalongCourse(pVEC3 pSpeed, pANGLES pAngles, pVEC3 pCourse);
