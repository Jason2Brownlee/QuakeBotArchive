/*
** FILE functions
*/
#define FILECREATE (1) /*Mode W*/
#define FILEMODIFY (3) /*Mode R/W*/
#define FILEREAD   (2) /*Mode R*/
typedef struct
{ 
  Int32 Fd;
  pInt8 Name;
  Int16 Mode;
}FILE;
typedef FILE PTR *pFILE;

  /*
  ** Open a file, ONE at the time, for reading
  */
Int32 FILEinit(pFILE pFile, pInt8 Path,Int32 Mode);
  /*
  ** Read data from opened file to buffer
  **  Data = buffer
  **  Start = position (-1 means last position)
  **  Size = size of buffer
  */
Int32 FILEread(pFILE pFile, pInt8 Data, Int32 Start, Int32 Size);
  /*
  ** Read into Data buffer. Dta->Size bytes (or all, if 0)
  */
Int32 FILEreadDta(pFILE pFile, pDTA pDta, Int32 Start);
  /*
  ** Write data from buffer to opened file
  **  Data = buffer
  **  Start = position (-1 means last position)
  **  Size = size of buffer
  */
Int32 FILEwrite(pFILE pFile, pInt8 Data,Int32 Start,Int32 Size);
  /*
  ** Write from Data buffer, Dta->Size bytes
  */
Int32 FILEwriteDta(pFILE pFile, pDTA pDta, Int32 Start);
  /*
  ** close file
  */
Int32 FILEfree(pFILE pFile);
  /*
  ** atomic read: open file, read data, close
  */
Int32 FILEreadDta(pDTA pDta, Int32 Start, pInt8  File);
Int32 FILEreadText(pDTA pDta, Int32 Start, pInt8  File);
  /*
  ** atomic write: open file, write data, close 
  */
Int32 FILEwriteDta(pDTA pDta, Int32 Start, pInt8  File);
Int32 FILEwriteText(pDTA pDta, Int32 Start, pInt8  File);
  /*
  ** Get the file time stamp.
  */
Int32 FILEgetTime(pInt8  File);
  /*
  ** Set the file time stamp.
  */
void FILEsetTime(pInt8  File, Int32 Time);
  /*
  ** Get the size of the file
  */
Int32 FILEgetSize(pInt8  File);
  /*
  ** Set the size of the file
  */
Int32 FILEsetSize(pInt8  File, Int32 Size);
/*
** Path Handling
*/
typedef struct
{
  Int8 Dir[0x100];
  Int8 Name[0x40];
  Int8 Ext[0x10];
  Int8 Drive;
} PATHSPLIT;
typedef PATHSPLIT PTR *pPATHSPLIT;
  /*
  ** if not Dir return >0 if file exists
  ** if Dir return >0 if directory exist
  */
Bool PATHexists(pInt8 Path, Bool Dir);
  /*
  ** Join paths  Dir + / + File
  */
Int32 PATHjoin(pInt8 Path, Int32 PathSz, pInt8 Dir, pInt8 File);
  /*
  ** Split paths
  */
Int32 PATHsplit(pPATHSPLIT Split, pInt8 Path);
