/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"  /*Always first to be included*/
#include <stdlib.h>
#include <math.h>
#include <stdio.h>    /*sprintf()*/
#include "common.h"
#include "data.h"
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkent.h"    /*Entity and model lists*/
#include "qkbot.h"    /*Bot inteface*/
#include "qkmove.h"
/**************************************************************\
**
**   Bot aims and moves
**
\**************************************************************/
#if 1
#define BOTMOVEMAX 250.0  /*bot move per second*/
#else
#define BOTMOVEMAX 400.0  /*bot move per second*/
#endif

/*
** Give the position of an entity,
** relatively to Origin and Angles
*/
void MOVEgetRelativePos(pVEC3 pResult, pVEC3 pOrigin, pANGLES pAngles, pELIVING Ent)
{
  /*Note: should use a Matrix transform*/
  VEC3 Front, Right, Up;
  VEC3 Delta;
  if((Ent==NULL)||(pResult==NULL)) return;
  VecCpy(&Delta, &(Ent->Origin));
  if(pOrigin!=NULL) VecSub(&Delta, pOrigin);
  if(pAngles==NULL)
  { VecCpy(pResult, &Delta); }
  else
  { /* get orientation vectors */
    Ang2Orient(&Front, &Right, &Up, pAngles);
    /* project vector on orientations */
    pResult->X = VecDotProduct(&Front, &Delta);
    pResult->Y = VecDotProduct(&Right, &Delta);
    pResult->Z = VecDotProduct(&Up, &Delta);
  }
}
/*
** Print the relative position
*/
pInt8 MOVEprintRelativePos(pVEC3 pResult)
{
  static Int8 Text[64];
  int F,R,U;
  pInt8  Fr,Rg,Up;
  /* divide position by 10, for more realisme */
  F = (int)(pResult->X/10.0);
  R = (int)(pResult->Y/10.0);
  U = (int)(pResult->Z/10.0);
  if(F>=0) { Fr = "Frn";} else{ Fr="Bck"; F=-F;}
  if(R>=0) { Rg = "Rgt";} else{ Rg="Lft"; R=-R;}
  if(U>=0) { Up = "Up ";} else{ Up="Dwn"; U=-U;}
  sprintf(Text,"%4d%s %4d%s %4d%s ", (int)F,Fr, (int)R,Rg, (int)U,Up);
  return Text;
}

/*
** Move an entity along the desired course
** Without changing the angles
*/
void MOVEalongCourse(pVEC3 pSpeed, pANGLES pAngles, pVEC3 pCourse)
{
  /*Note: should use a Matrix transform*/
  VEC3 Front, Right, Up;
  /* Normalise the course direction */
  VecNormalise(pCourse);
  VecScale(pCourse,BOTMOVEMAX);
  /* Dir = f(Angles) */
  Ang2Orient(&Front, &Right, &Up, pAngles);
  /* Desired Speeds, expressed in the entity referential */
  pSpeed->X = VecDotProduct(&Front, pCourse);
  pSpeed->Y = VecDotProduct(&Right, pCourse);
  pSpeed->Z = VecDotProduct(&Up, pCourse);
}
/*
** Move an entity along the desired course, by changing angles
** (assuming angles can be instantaneously changed)
*/
void MOVEalongCourseA(pVEC3 pSpeed, pANGLES pAngles, pVEC3 pCourse)
{
  /* Normalise Course*/
  VecNormalise(pCourse);
  /* Angles */
  pAngles->Tilt=0;
  pAngles->Yaw = Vec2Yaw(pCourse->X, pCourse->Y);
  pAngles->Flip=0;
  /* Speeds */
  pSpeed->X = BOTMOVEMAX; /*full front*/
  pSpeed->Y = 0;   /*nothing right*/
  pSpeed->Z = pCourse->Z * BOTMOVEMAX; /* up/down if needed */
}

/*
** Prepare an entity for further calculations
**  Origin = bot origin
**  Time   = current bot time
*/
void MOVEprepare(pELIVING Ent, pVEC3 pOrigin)
{
  if(Ent==NULL) return;
  /*
  ** Delta to the Origin (= the bot)
  */
  /* Ent->Delta = pBot->Self->Origin - Ent->Origin*/
  VecCpy(&(Ent->Delta), pOrigin);
  VecSub(&(Ent->Delta), &(Ent->Origin));
  /* Ent->DeltaNorm2 = norm(Ent->TmpVec)^2*/
  Ent->DeltaNorm2 = VecNorm2(&(Ent->Delta));
}

/*
** Guess position of an entity, DeltaT seconds later
** pOrigin = result
** DeltaT = position forecast in DeltaT seconds
** Time = current time
*/
void MOVEguessPosition(pVEC3 pOrigin, TIME Time, pELIVING Ent, TIME DeltaT)
{
  VEC3 GuessSpeed;
  TIME dt;
  if((pOrigin==NULL)||(Ent==NULL)) return;
  /*
  ** Guess the speed
  */
  dt = Ent->Time - Ent->Time1;
  if((dt<=0)||(Ent->Time==0.0))
  { /* if inverted time, or unknown time, Speed is null */
    VecSet(&GuessSpeed,0.0,0.0,0.0);
  }
  else
  { /* Ent.GuessSpeed = (Ent.Origin - Ent.Origin1)/(Ent.Time-Ent.Time1) */
    VecCpy(&GuessSpeed,&(Ent->Origin));
    VecSub(&GuessSpeed,&(Ent->Origin1));
    VecScale(&GuessSpeed, (1.0/dt));
  }
  /*
  ** Predict position
  */
  dt = DeltaT;
  /* correction, for outdated positions */
  if(Time>Ent->Time) dt += (Time - Ent->Time);
  /* Ent.GuessOrigin +=  dt * Ent.GuessSpeed */
  VecCpy(pOrigin,&(Ent->Origin));
  VecAddScale(pOrigin,&GuessSpeed, dt );
}
/*
** Get the best course to avoid an entity
**  Ent = entity to be avoided
**  assumes Ent->Delta = Self->Origin - Ent->Origin
**  assumes Ent->Norm2 = norm(Self->Origin - Ent->Origin)^2
**  returns Course
*/
Bool MOVEavoid(pVEC3 Course, pELIVING Ent, SCALAR Range)
{
  static VEC3 Delta, Dir, Hit;
  SCALAR proj,norm;
  if(Ent==NULL)
  { return FALSE; }
  /* Delta = Origin - Ent->Origin */
  VecCpy(&Delta, &(Ent->Delta));
  /* Dir = direction of Ent->Angles*/
  Ang2Vec(&Dir, &(Ent->Angles));
  /* proj = proj of Delta on Dir */
  proj = VecDotProduct(&Delta, &Dir);
  /* check if entity oriented toward origin */
  if(proj<0)
  { return FALSE; }
  /* Hit = Delta - proj.Dir*/
  VecCpy(&Hit,&Dir);
  VecScale(&Hit, -proj);
  VecAdd(&Hit, &Delta);
  /* norm = |Hit| */
  norm = VecNorm(&Hit);
  /* check if norm < Radius of danger */
  if(norm>Range)
  { return FALSE; }
  /* check if hit is really too close */
  if(norm<0.1)
  { /* do some random move...*/
    VecSet(Course, RandF(-BOTMOVEMAX,BOTMOVEMAX), RandF(-BOTMOVEMAX,BOTMOVEMAX), 0.0);
  }
  else
  { /* Run along Hit */
    VecScale(&Hit, 1/norm);
    VecCpy(Course, &Hit);
  }
  return TRUE;
}
/*
** Avoid a certain angle around line of sight
** This method is rather stupid.
*/
Bool MOVEavoid1(pVEC3 Course, pELIVING Ent)
{
  static VEC3 Delta, Dir, Hit;
  SCALAR proj,norm;
  if(Ent==NULL)
  { return FALSE; }
  /* Delta = Origin - Ent->Origin */
  VecCpy(&Delta, &(Ent->Delta));
  /* Dir = direction of Ent->Angles*/
  Ang2Vec(&Dir, &(Ent->Angles));
  /* proj = proj of Delta on Dir */
  proj = VecDotProduct(&Delta, &Dir);
  /* check if entity oriented toward origin */
  if(proj<0)
  { return FALSE; }
  /* Hit = Delta - proj.Dir*/
  VecCpy(&Hit,&Dir);
  VecScale(&Hit, -proj);
  VecAdd(&Hit, &Delta);
  /* norm = |Hit| */
  norm = VecNorm(&Hit);
  /* check if norm2 < factor. distance */
  if(norm> proj* (0.5)) /* angle = arcsin(0.5) */
  { return FALSE; }
  /* check if hit is really too close */
  if(norm<0.1)
  { /* do some random move...*/
    VecSet(Course, RandF(-1,1), RandF(-1,1), RandF(-1,1));
    VecNormalise(Course);
  }
  else
  { /* Run along Hit */
    VecScale(&Hit, 1/norm);
    VecCpy(Course, &Hit);
  }
  return TRUE;
}
/*
** Get the best course to avoid a line of sight
**  Ent = entity to be avoided
**  assumes Ent->Delta = Self->Origin - Ent->Origin
**  assumes Ent->Norm2 = norm(Self->Origin - Ent->Origin)^2
**  returns desired Course (not normalised)
**  Method = maximise increase in relative angles, because that's
**  the quickest way to get out of a line of sight.
**  Note that it's not the best way to avoid a real-life missile.
*/
Bool MOVEavoid2(pVEC3 Course, pELIVING Ent)
{
  static VEC3  D,DO; /* D and D orthogonal*/
  static VEC3  Dir;  /*direction of sight of entity*/
  SCALAR  a,b;   /* Course = a.D + b.DO */
  if(Ent==NULL)
  { return FALSE; }
  /* Dir = direction of Ent->Angles*/
  Ang2Vec(&Dir, &(Ent->Angles));
  /*check that dir is oriented toward bot*/
  if(VecDotProduct(&Dir,&(Ent->Delta))<=0)
  { return FALSE; }
  /* D = Origin - Ent->Origin */
  VecCpy(&D, &(Ent->Delta));
  /* DO = VecCrossProduct(D, Z=(0,0,-1)) */
  VecSet(&DO, -(D.Y), (D.X), 0);
  /* if far enough, radius of move sphere = BOTMOVEMAX */
  if((Ent->DeltaNorm2)> (1.2*BOTMOVEMAX*BOTMOVEMAX))
  { a = (BOTMOVEMAX*BOTMOVEMAX)/(Ent->DeltaNorm2);  b = sqrt(a*(1-a));}
  /* if a bit too close (<100.0), radius of move sphere = 0.7 Dnorm*/
  else if((Ent->DeltaNorm2)>10000.0)
  { a = 0.49; b = 0.5; } /* b= sqrt(a*(1-a));*/
  /* if real close, force orthogonal move */
  else
  { a = 0.0; b = 1.0;}
  /*
  ** between the two possible vectors, take the one
  ** that is maximally opposite to the direction
  */
  if( VecDotProduct(&Dir,&DO) > 0.0) { b = -b; }
  /*
  ** Set course =  (-a.D + b.DO)
  */
  VecCpy(Course, &DO);
  VecScale(Course, b);
  if(a!=0.0) VecAddScale(Course, &D, -a);
  VecNormalise(Course);
  return TRUE;
}
/*
** Aim at an entity
**  Ent   = entity to aim at
**  assumes Ent->TmpVec = Self->Origin - Ent->Origin
**  Angles = result
*/
Bool MOVEaimEntity(pANGLES pAngles, pELIVING Ent)
{
  VEC3 Delta;
  if((Ent==NULL)||(pAngles==NULL))
  { return FALSE; }
  /* Delta = Ent->Origin - Origin */
  VecCpy(&Delta, &Ent->Delta); VecNeg(&Delta);
  /* Orientation */
  Vec2Angles(pAngles, &Delta);
  return TRUE; /*turned*/
}
/*
** Aim at a Target, from Origin
*/
Bool MOVEaimPoint(pANGLES pAngles, pVEC3 pOrigin, pVEC3 pTarget)
{
 VEC3 Delta;
 if((pAngles==NULL)||(pOrigin==NULL)||(pTarget==NULL))
 { return FALSE; }
 /* Delta = Target - Origin */
 VecCpy(&Delta, pTarget);
 VecSub(&Delta, pOrigin);
 /* Orientation */
 Vec2Angles(pAngles, &Delta);
 return TRUE; /*turned*/
}

