/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include <stdio.h>   /*NULL*/
#include <math.h>
#include "defines.h"
#include "common.h"
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/

/*
** absolute value of max difference between two angles
*/
ANGLE AngDiff(pANGLES pDest, pANGLES pSrc)
{
  ANGLE maxi,val;
  maxi = pDest->Tilt - pSrc->Tilt;
  if(maxi<0) maxi=-maxi;
#if RADIANTS
  val = fmod(pDest->Yaw - pSrc->Yaw, 2*M_PI);
  if(val<0)    val = -val;
  if(val>M_PI) val = 2*M_PI-val; /*abs val*/
#else
  val = fmod(pDest->Yaw - pSrc->Yaw, 2*180);
  if(val<0)   val = -val;
  if(val>180) val = 2*180-val;   /*abs val*/
#endif
  return max(maxi,val);
}
/*
** Make angle equal
*/
void AngCpy(pANGLES pDest, pANGLES pSrc)
{
  Memcpy(pDest, pSrc, sizeof(*pDest));
}
/*
** Conversion form angles to vector
*/
void Ang2Vec(pVEC3 Direction, pANGLES Angles)
{
#if RADIANTS
  SCALAR  costilt;
  costilt = cos(Angles->Tilt);
  Direction->X= cos(Angles->Yaw)*costilt;
  Direction->Y= sin(Angles->Yaw)*costilt;
  Direction->Z= sin(Angles->Tilt);
#else
  SCALAR  costilt;
  ANGLE   yaw,tilt;
  yaw  = (Angles->Yaw) *  (M_PI/180);
  tilt = (Angles->Tilt) * (M_PI/180);
  costilt = cos(tilt);
  Direction->X= cos(yaw)*costilt;
  Direction->Y= sin(yaw)*costilt;
  Direction->Z= sin(tilt);
#endif
  return;
}
/*
** Get Front, Right, Up from angles
*/
void Ang2Orient(pVEC3 Front, pVEC3 Right, pVEC3 Up, pANGLES Angles)
{
  static SCALAR  costilt, sintilt, cosyaw, sinyaw, cosflip, sinflip;
#if RADIANTS
  costilt = cos(Angles->Tilt);
  sintilt = sin(Angles->Tilt);
  cosyaw  = cos(Angles->Yaw);
  sinyaw  = sin(Angles->Yaw);
  cosflip = cos(Angles->Flip);
  sinflip = sin(Angles->Flip);
#else
  costilt = cos(Angles->Tilt *  (M_PI/180));
  sintilt = sin(Angles->Tilt *  (M_PI/180));
  cosyaw  = cos(Angles->Yaw  *  (M_PI/180));
  sinyaw  = sin(Angles->Yaw  *  (M_PI/180));
  cosflip = cos(Angles->Flip *  (M_PI/180));
  sinflip = sin(Angles->Flip *  (M_PI/180));
#endif
  Front->X= cosyaw  * costilt;
  Front->Y= sinyaw  * costilt;
  Front->Z=           sintilt;
  Right->X= sinyaw  * cosflip;
  Right->Y= -cosyaw * cosflip;
  Right->Z=           sinflip;
  /* Up = Right ^ Front */
  VecCrossProduct(Up, Right, Front);
  return;
}

/*
** absolute value of max difference between two vectors
*/
SCALAR VecDiff(pVEC3 pDest, pVEC3 pSrc)
{
  SCALAR maxi,val;
  maxi = pDest->X - pSrc->X;
  if(maxi<0) maxi=-maxi;
  val = pDest->Y - pSrc->Y;
  if(val<0) val=-val;
  maxi = max(maxi,val);
  val = pDest->Z - pSrc->Z;
  if(val<0) val=-val;
  return max(maxi,val);
}

void VecCpy(pVEC3 pDest, pVEC3 pSrc)
{
  Memcpy(pDest, pSrc, sizeof(*pDest));
}
void VecSet(pVEC3 pDest, SCALAR X, SCALAR Y, SCALAR Z)
{ pDest->X=X; pDest->Y=Y; pDest->Z=Z; }
/*
**  Add two vectors    (increase)
*/
void VecAdd(pVEC3 Dest, pVEC3 Source)
{
  Dest->X +=Source->X; Dest->Y +=Source->Y; Dest->Z +=Source->Z;
}
/*
**  Substract vectors Source to Dest   (decrease)
*/
void VecSub(pVEC3 Dest, pVEC3 Source)
{
  Dest->X -=Source->X; Dest->Y -=Source->Y; Dest->Z -=Source->Z;
}
/*
**  Scale one vector
*/
void VecScale(pVEC3 Dest, SCALAR Scale)
{
  Dest->X *= Scale;  Dest->Y *= Scale;  Dest->Z *= Scale;
}
/* Add scaled Source to Dest*/
void VecAddScale(pVEC3 Dest, pVEC3 Source, SCALAR Scale)
{
  Dest->X += Source->X * Scale;
  Dest->Y += Source->Y * Scale;
  Dest->Z += Source->Z * Scale;
}
/*
**  Negate a vectors (scale by -1)
*/
void VecNeg(pVEC3 Dest)
{
  Dest->X = -Dest->X;
  Dest->Y = -Dest->Y;
  Dest->Z = -Dest->Z;
}
/*
** Dot product
*/
SCALAR VecDotProduct(pVEC3 Dest, pVEC3 Source)
{
  return (Dest->X * Source->X)+(Dest->Y * Source->Y)+(Dest->Z * Source->Z);
}
/*
** calculate square norm
*/
SCALAR VecNorm2(pVEC3 Dest)
{
  return (Dest->X * Dest->X)+(Dest->Y * Dest->Y)+(Dest->Z * Dest->Z);
}
/*
** calculate the norm
*/
SCALAR VecNorm(pVEC3 Dest)
{
  return sqrt((Dest->X * Dest->X)+(Dest->Y * Dest->Y)+(Dest->Z * Dest->Z));
}
/*
** Normalise
*/
void VecNormalise(pVEC3 Dest)
{
  SCALAR norm=sqrt((Dest->X * Dest->X)+(Dest->Y * Dest->Y)+(Dest->Z * Dest->Z));
  if(norm<=0.0) return;
  norm = 1.0/norm;
  Dest->X *= norm; Dest->Y *= norm; Dest->Z *= norm;
}
/*
** Vectorial product Dest = Src1 ^ Src2
*/
void VecCrossProduct(pVEC3 Dest, pVEC3 Src1, pVEC3 Src2)
{
  Dest->X = Src1->Y * Src2->Z -  Src1->Z * Src2->Y;
  Dest->Y = Src1->Z * Src2->X -  Src1->X * Src2->Z;
  Dest->Z = Src1->X * Src2->Y -  Src1->Y * Src2->X;
}
/*
** Plane distance
**  Normal = plane normal
**  Distance = plane distance
*/
SCALAR VecPlaneDist(pVEC3 Origin, pVEC3 Normal, SCALAR Distance)
{
#if 1   /*WARNING: random error of about 1.E-8 is added*/
  return (Normal->X * Origin->X)
      +  (Normal->Y * Origin->Y)
      +  (Normal->Z * Origin->Z)
      - Distance;
#else
  /* Could be optimised by pre-calculating plane types*/
  double val= -Distance;
  if(Normal->X!=0.0)
  {
    if(Normal->X==1.0) val += Origin->X;
    else               val += (Normal->X * Origin->X);
  }
  if(Normal->Y!=0.0)
  {
    if(Normal->Y==1.0) val += Origin->Y;
    else               val += (Normal->Y * Origin->Y);
  }
  if(Normal->Z!=0.0)
  {
    if(Normal->Z==1.0) val += Origin->Z;
    else               val += (Normal->Z * Origin->Z);
  }
  return (SCALAR)val;
#endif
}
/*
** Calculate yaw angle, from any X and Y
*/
ANGLE Vec2Yaw(SCALAR X, SCALAR Y)
{
  ANGLE yaw;
#if 1
  Bool flipv=TRUE, fliph=TRUE;
  if(Y<0) Y=-Y; else flipv=FALSE;
  if(X<0) X=-X; else fliph=FALSE;
  if(X<Y)        yaw = M_PI_2 - atan(X/Y);
  else if(X>0.0) yaw = atan(Y/X);
  else           yaw = 0;
  if(fliph==TRUE) yaw = M_PI - yaw;
  if(flipv==TRUE) yaw = -yaw;
  yaw = fmod(yaw, 2*M_PI);
#else
  yaw = (((X==0.0)&&(Y==0.0))? 0.0 : (SCALAR)atan2(Y, X));
#endif
  if(yaw<0) yaw += (2*M_PI);
#if RADIANTS
  return yaw;  /* 0<yaw <M_PI */
#else
  return (180/M_PI) * yaw;  /* 0<yaw <180 */
#endif
}
/*
** Calculate tilt angle, from sqr(X�+Y�)>=0 and Z
*/
ANGLE Vec2Tilt(SCALAR X, SCALAR Z)
{ /* X is assumed >= 0*/
  ANGLE tilt;
#if 1
  Bool flipv=TRUE;
  if(Z<0) Z=-Z; else flipv=FALSE;
  if(X<0) X=-X;
  if(X<Z)        tilt = M_PI_2 - atan(X/Z);
  else if(X>0.0) tilt = atan(Z/X);
  else           tilt = 0;
  if(flipv==TRUE) tilt = -tilt;
  /*tilt = fmod(tilt, 2*M_PI);*/
#else
  tilt = (((X==0.0)&&(Z==0.0))? 0.0 : (SCALAR)atan2(Z, X));
#endif
#if RADIANTS
  return tilt;  /* -M_PI_2 < tilt < +M_PI_2 */
#else
  return (180/M_PI) * tilt;  /* -90< tilt < +90 */
#endif
}
/*
** Vector to angles
*/
void Vec2Angles(pANGLES Angles, pVEC3 Src)
{
  Angles->Tilt = Vec2Tilt( sqrt((Src->X*Src->X)+(Src->Y*Src->Y)) ,Src->Z);
  Angles->Yaw =  Vec2Yaw(Src->X, Src->Y);
  Angles->Flip = 0;
}

/*
**
** Bounding Boxes
**
*/
#define EPSILON   (0.1)
/* Test if empty */
Bool BBOXisEmpty(pBOUNDBOX pSrc)
{
  if(pSrc==NULL) return TRUE;
  if( pSrc->MinX+EPSILON >= pSrc->MaxX) return TRUE;
  if( pSrc->MinY+EPSILON >= pSrc->MaxY) return TRUE;
  if( pSrc->MinZ+EPSILON >= pSrc->MaxZ) return TRUE;
  return FALSE;
}
/* Test if point pOrigin is inside pSrc */
Bool BBOXisInside(pBOUNDBOX pSrc, pVEC3 pOrigin)
{
  if((pSrc==NULL)||(pOrigin==FALSE)) return FALSE;
  if( pOrigin->X < pSrc->MinX) return FALSE;
  if( pOrigin->X > pSrc->MaxX) return FALSE;
  if( pOrigin->Y < pSrc->MinY) return FALSE;
  if( pOrigin->Y > pSrc->MaxY) return FALSE;
  if( pOrigin->Z < pSrc->MinZ) return FALSE;
  if( pOrigin->Z > pSrc->MaxZ) return FALSE;
  return TRUE;
}
/* Copy Boundbox*/
void BBOXcpy(pBOUNDBOX pDest, pBOUNDBOX pSrc)
{ 
  Memcpy(pDest, pSrc, sizeof(BOUNDBOX));
}
/* Extend a bound box by a certain value */
void BBOXextend(pBOUNDBOX pDest, SCALAR X, SCALAR Y, SCALAR Z)
{
  pDest->MinX -= X; pDest->MaxX += X;
  if((X<0.0)&&(pDest->MinX>pDest->MaxX)) /*keep valid*/
  { pDest->MinX = pDest->MaxX = (pDest->MaxX+pDest->MinX)/2.0; }
  /**/
  pDest->MinY -= Y; pDest->MaxY += Y;
  if((Y<0.0)&&(pDest->MinY>pDest->MaxY)) /*keep valid*/
  { pDest->MinY = pDest->MaxY = (pDest->MaxY+pDest->MinY)/2.0; }
  /**/
  pDest->MinZ -= Z; pDest->MaxZ += Z;
  if((Z<0.0)&&(pDest->MinZ>pDest->MaxZ)) /*keep valid*/
  { pDest->MinZ = pDest->MaxZ = (pDest->MaxZ+pDest->MinZ)/2.0; }
}
/* Intersect */
void BBOXinter(pBOUNDBOX pDest, pBOUNDBOX pSrc1, pBOUNDBOX pSrc2)
{
  SCALAR m,M;
  m = max(pSrc1->MinX, pSrc2->MinX);
  M = min(pSrc1->MaxX, pSrc2->MaxX);
  if(m>=M) { m=0.0; M=0.0; }
  pDest->MinX=m; pDest->MaxX=M;
  m = max(pSrc1->MinY, pSrc2->MinY);
  M = min(pSrc1->MaxY, pSrc2->MaxY);
  if(m>=M) { m=0.0; M=0.0; }
  pDest->MinY=m; pDest->MaxY=M;
  m = max(pSrc1->MinZ, pSrc2->MinZ);
  M = min(pSrc1->MaxZ, pSrc2->MaxZ);
  if(m>=M) { m=0.0; M=0.0; }
  pDest->MinZ=m; pDest->MaxZ=M;
}

