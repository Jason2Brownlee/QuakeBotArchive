
/*
** PTO = Quake Protocol State
*/
typedef struct _PTO
{
  Int8 Opaque[0x80];
} PTO;
typedef PTO PTR *pPTO;





/****************************************************\
*
*  Functions to post messages via a protocol machine
*
\****************************************************/
/*
** Send reliable message
*/
Int32 PtoSendUnreliable(pPTO pPto, pDTA pDta);
/*
** Send Unreliable message
*/
Int32 PtoSendReliable(pPTO pPto, pDTA pDta);
/*
** Reinit, Disconnect from server
**  Adrs: if NULL or zero-length, ignore
**        else "address:port" of the server.
*/
Int32 PtoReInit(pPTO pPto, pInt8 Adrs);
/*
** Say if Pto is connected
*/
Bool PtoIsConnected(pPTO pPto);
/*
** Send various control messages
*/
/* Connection request */
Int32 PtoSendConnect(pPTO pPto);
/* Game info request */
Int32 PtoSendAskInfos(pPTO pPto);
/* Player info request (Player = 0 to 15) */
Int32 PtoSendAskPlayer(pPTO pPto, Int32 Player);
/* Rule info request (If Rule==NULL, send first rule)*/
Int32 PtoSendAskRule(pPTO pPto, pInt8 Rule);
/*
** Print statistics
*/
Int32 PtoPrintStats(pPTO pPto);



