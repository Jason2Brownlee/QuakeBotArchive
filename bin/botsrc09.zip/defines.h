/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy 
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/
#ifdef __cplusplus
extern "C" {            /* Assume C declarations for C++ */
#endif  /* __cplusplus */

/*
** Select system
*/
#define SYST_WIN32CSL  0 /* Win32 Console*/
#define SYST_WIN32     0
#define SYST_WIN16     0
#define SYST_DOS       0
#define SYST_UNIX      0 /* Unix: Standard */
#define SYST_AIX       0 /* Unix: AIX */
#define SYST_LINUX     0 /* Unix: Linux for PC */
#define SYST_BORLAND   0 /* Borland. allow sizeof() in #defines*/
#define SYST_MSVCPP    0 /* Visual C++*/
/*
** Microsoft Visual C++
*/
#if (defined _WIN32)
#undef  SYST_MSVCPP
#define SYST_MSVCPP    1
#undef  SYST_WIN32CSL
#define SYST_WIN32CSL  1 /* assume console */
/*
** Borland C++
*/
#elif (defined __WIN32__)||(defined __WINDOWS__)||(defined __DOS__)
#undef  SYST_BORLAND
#define SYST_BORLAND   1
#if     (defined __CONSOLE__)
#undef     SYST_WIN32CSL
#define    SYST_WIN32CSL  1
#elif   (defined __WIN32__)
#undef     SYST_WIN32
#define    SYST_WIN32     1
#elif (defined __WINDOWS__)||(defined _Windows)
#undef  SYST_WIN16
#define SYST_WIN16     1
#elif (defined __DOS__)
#undef  SYST_DOS
#define SYST_DOS       1
#endif
/*
** Gcc, for various flavors of Unix
*/
#else
#undef  SYST_UNIX
#define SYST_UNIX      1
  /* LINUX */
#if (defined __linux__)
#undef SYST_LINUX
#define SYST_LINUX 1
  /* AIX */
#elif (defined _AIX)||(defined _AIX32)
#undef SYST_AIX
#define SYST_AIX 1
#endif
#endif /*compilers*/
/*
** Big Endian or little endian?
*/
#define SYST_BIGENDIAN  ((SYST_DOS)||(SYST_WIN16)||(SYST_WIN32)||(SYST_WIN32CSL)||(SYST_LINUX))
/*
** Windows DLL specific
*/
#if (SYST_WIN16)&&( defined __DLL__)
#define EXPORT   _far PASCAL _export
#define _WINDLL
#elif (SYST_WIN32)||(SYST_WIN32CSL)
#define EXPORT
#else
#define EXPORT
#define PASCAL _pascal
#endif
/*
** Huge pointer  for 16-bit DOS/Windows
*/
#if (SYST_DOS)||(SYST_WIN16)
#define PTR huge
#else
#define PTR
#endif
/*
** Type definitions, assume 32 bit processor
*/
typedef char 		      Int8;
typedef unsigned char 	UInt8;
typedef short 		      Int16;
typedef unsigned short 	UInt16;
typedef long 		      Int32;
typedef unsigned long 	UInt32;
typedef float           Float32;
typedef double          Float64;
typedef void   PTR    * pVoid;
typedef Int8   PTR    * pInt8;
typedef UInt8  PTR    * pUInt8;
typedef Int16  PTR    * pInt16;
typedef UInt16 PTR    * pUInt16;
typedef Int32  PTR    * pInt32;
typedef UInt32 PTR    * pUInt32;
typedef Float32 PTR   * pFloat32;
typedef Float64 PTR   * pFloat64;
/*
** To resolve conflicts with Windoze API
*/
typedef char            Char;
typedef unsigned char   UChar;
typedef char   PTR    * pChar;     /* char FAR* */
typedef short  PTR    * pShort;
typedef unsigned short  UShort;
typedef int             Int;       /* default int, for %d*/
typedef int    PTR    * pInt;      /* int FAR * */
typedef unsigned int    UInt;      /* default int, for %d*/
typedef long            Long;      /* default long, for %ld*/
typedef long   PTR    * pLong;
/*
**  Special types
*/
typedef short 		Bool;
#define TRUE 		((Bool)1)
#define FALSE 		((Bool)0)

#define max(a,b)    (((a) > (b)) ? (a) : (b))
#define min(a,b)    (((a) < (b)) ? (a) : (b))

#ifdef __cplusplus
}            /* Assume C declarations for C++ */
#endif  /* __cplusplus */

