/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include <math.h>
#include <stdio.h>    /*NULL*/
#include "defines.h"
#include "common.h"
#include "data.h"     /*Dta handling */
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkbspdef.h" /*Quake BSP definitions*/
#include "qkbspprt.h" /*Quake BSP parts*/
#include "qkbsp.h"    /*Quake BSP functions*/
/*
**  Contents Translater
*/
static Int32 BSPleafContentI(Int32 Content)
{
  switch(Content)
  {
	 case CONTENTS_EMPTY: return AREA_INVOID;
	 case CONTENTS_LAVA:  return AREA_INLAVA;
	 case CONTENTS_SLIME: return AREA_INSLIME;
	 case CONTENTS_WATER: return AREA_INWATER;
	 case CONTENTS_SKY:   return AREA_INSKY;
	 case CONTENTS_SOLID: return AREA_INWALL;
  }
  ERRwarn("BSP Leaf: invalid content %ld",(long)Content);
  return AREA_INWALL;
}


/****************************************************\
*
*
* Quake entities
*
*
\****************************************************/

Int32 BSPentiInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
 if((Bsp==NULL)||(Lmp==NULL)||(LmpSz<=0))
 { return ERR_BUG; }
 Bsp->EntiSz= LmpSz;
 /*Calloc(Bsp->EntiSz, sizeof(Int8));*/
 Bsp->Enti=(pInt8)Malloc(LmpSz);
 if(Bsp->Enti==NULL)
 { return ERR_MEM;}
 Memcpy(Bsp->Enti,Lmp,LmpSz);
 return 1;
}
/*
** Check entities
*/
Int32 BSPentiCheck(pBSPDEF Bsp)
{ Int32 n,bracket;
  pInt8 Str;
  bracket=0;
#if DEBUG
  printf("Checking Entities");
#endif
  for(Str=Bsp->Enti,n=0; n<Bsp->EntiSz; n++,Str+=1)
  { switch(*Str)
	 { case '{': bracket++;break;
		case '}': bracket--;break;
	 }
  }
  if(bracket==0)
  { return 1;}
  if(bracket<0)
  { printf(" Too many '}'");}
  else /* bracket>0 */
  { printf(" Too many '{'");}
  return -1;
}
/****************************************************\
*
*
* Quake Planes
*
*
\****************************************************/

Int32 BSPplanInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKPLANE DPlan;
  pQKPLANE TPlan;
  Int32 n, type;
  if(Bsp==NULL)
  { return -1;}
  /**/
  Bsp->PlanNb= LmpSz/sizeof(QKPLANE);
  if(TBLinit(Bsp->Plan, Bsp->PlanNb)==NULL)
  { return ERR_MEM;}
  DPlan = (pQKPLANE) Lmp;
  for(n=0, TPlan=Bsp->Plan; n< Bsp->PlanNb; n++, TPlan+=1, DPlan+=1)
  { /* TPlan = TBLelem(Bsp->Plan, n) */
    TPlan->Normal.X = Float32BE(DPlan->Normal.X);
    TPlan->Normal.Y = Float32BE(DPlan->Normal.Y);
    TPlan->Normal.Z = Float32BE(DPlan->Normal.Z);
    TPlan->Dist     = Float32BE(DPlan->Dist);
    /* ensure that vector is normalised, or zero*/
    VecNormalise(&(TPlan->Normal));
    /*check type, according to normal*/
    type     = Int32BE(DPlan->Type);
    switch(type)
    {
      case PLANE_X:
        if((TPlan->Normal.Y!=0.0)||(TPlan->Normal.Z!=0.0))
        { type = PLANE_ANYX; }
        break;
      case PLANE_Y:
        if((TPlan->Normal.X!=0.0)||(TPlan->Normal.Z!=0.0))
        { type = PLANE_ANYY; }
        break;
      case PLANE_Z:
        if((TPlan->Normal.X!=0.0)||(TPlan->Normal.Y!=0.0))
        { type = PLANE_ANYZ; }
        break;
      case PLANE_ANYX:
      case PLANE_ANYY:
      case PLANE_ANYZ:
        break;
      default: /*invalid type*/
        ERRwarn("BSP Plane %ld: invalid type %ld",(long)n,(long)type);
        type = PLANE_ANYX;
    }
    TPlan->Type = type;
  }
  return 1;
}



/****************************************************\
*
*
* Quake Vertices
*
*
\****************************************************/

Int32 BSPvrtxInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKVERTEX DVrtx;
  Int32 n;
  Bsp->VrtxNb= LmpSz/sizeof(QKVERTEX);
  if(TBLinit(Bsp->Vrtx,Bsp->VrtxNb)==NULL)
  { return ERR_MEM;}
  DVrtx = (pQKVERTEX)Lmp;
  for(n=0; n<Bsp->VrtxNb; n++, DVrtx+=1)
  {
    TBLelem(Bsp->Vrtx,n).Origin.X = Float32BE(DVrtx->X);
    TBLelem(Bsp->Vrtx,n).Origin.Y = Float32BE(DVrtx->Y);
    TBLelem(Bsp->Vrtx,n).Origin.Z = Float32BE(DVrtx->Z);
    TBLelem(Bsp->Vrtx,n).Tag      = 0;
  }
  return 1;
}
/*
** Set tags
*/
Int32 BSPvrtxSetTags(pBSPDEF Bsp, Int32 Value)
{
  Int32 n;
  pQVERTEX TVrtx;
  if((Bsp==NULL)||(Bsp->Vrtx==NULL))
  {return -1;}
  for(n=0,TVrtx= Bsp->Vrtx; n< Bsp->VrtxNb; n++, TVrtx+=1)
  { TVrtx->Tag=Value; }
  return 1;
}
/****************************************************\
*
*
* Quake Visibility Lists
*
*
\****************************************************/
/*
** Paint visilist
*/
static void BspVisiUnpack(pInt8 Visi, Int32 VisiLen, pInt8 Packed, Int32 PackedSz)
{
  Int32 v,p,nb;
  /*
  ** Visilists are run-length encoded.
  ** zero is followed by the number of time it is used
  */
  for(v=0,p=0; (p<PackedSz)&&(v<VisiLen) ; p++)
  {
    if(Packed[p]==0) /*code zero*/
    {
      p++; if(p>=PackedSz) break;
      /*nb = how many times zero */
      for(nb= Packed[p]; (nb>0)&&(v<VisiLen); nb--, v++)
      { Visi[v]=0; }
    }
    else
    { Visi[v]=Packed[p];  v++; }
  }
}
/*
** Init
*/
Int32 BSPvisiInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
#if 0
  Bsp->VisiSz= LmpSz;
  /*Calloc(Bsp->VisiSz, sizeof(Int8));*/
  Bsp->Visi=(pInt8)Malloc(Bsp->VisiSz);
  if(Bsp->Visi==NULL) { return ERR_MEM;}
  Memcpy(Bsp->Visi,Lmp,Bsp->VisiSz);
#else
  Int32 n, pos, visi, visimaxsz;
  Int32 VisiNb, VisiLen;
  if((Bsp==NULL)||(Bsp->Leaf==NULL))
  { return ERRfault(ERR_BUG);}
  VisiNb=0;
  for(n=0; n<Bsp->LeafNb; n++)
  {
    if(TBLelem(Bsp->Leaf,n).Visi>=LmpSz)
    {
      ERRwarn("BSP Leaf %ld: bad visibility list",(long)n);
      TBLelem(Bsp->Leaf,n).Visi = -1; /*cancel the visilist*/
    }
    if(TBLelem(Bsp->Leaf,n).Visi<0) continue; /* no visilist*/
    /*increase the number of visilists*/
    VisiNb++;
  }
  VisiLen = ((Bsp->WorldLeaves-1)+7)>>8;
  Bsp->VisiSz= VisiNb * VisiLen;
  /*Calloc(Bsp->VisiSz, sizeof(Int8));*/
  if(TBLinit(Bsp->Visi,Bsp->VisiSz)==NULL)
  { return ERR_MEM;}
  /* decompress the visibility lists */
  pos = 0;
  for(n=0; n<Bsp->LeafNb; n++)
  {
    visi =  TBLelem(Bsp->Leaf,n).Visi;
    if(visi<0) { continue; } /* no visilist*/
    if(pos+VisiLen>= Bsp->VisiSz) { continue; } /*security*/
    /*decompress*/
    visimaxsz = LmpSz-visi;
    if(visimaxsz<=0) { continue; } /* security */
    BspVisiUnpack(&(Bsp->Visi[pos]), VisiLen, &(Lmp[visi]), visimaxsz);
    /*fix the leaf*/
    TBLelem(Bsp->Leaf,n).Visi = pos;
    /* next position */
    pos += VisiLen;
  }
  /*check that all leaves see themselves*/
#endif
  return 1;
}
/*
** Say if LeafOrigin can see LeafTarget
*/
Bool BspVisiCanSee(pBSPDEF Bsp, Int32 LeafOrigin, Int32 LeafTarget)
{
  Int32 visi,leaf;
  if((LeafTarget<1)||(LeafTarget>=Bsp->WorldLeaves))
  { return FALSE; }
  leaf = LeafTarget-1; /*there is no visi bit, for leaf 0*/
  if((LeafOrigin<0)||(LeafOrigin>= Bsp->LeafNb))
  { return FALSE; }
  visi = Bsp->Leaf[LeafOrigin].Visi;
  if(visi<0) return TRUE;
  visi += leaf>>8;
  if(visi>=Bsp->VisiSz) return TRUE;
  return (Bsp->Visi[visi] & (1<<((int)(leaf&0x7))))? (Bool)TRUE: (Bool)FALSE;
}
/****************************************************\
*
*
* Quake Bsp Node Leaves
*
*
\****************************************************/


Int32 BSPleafInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKLEAF DLeaf;
  pQNODE  TLfNode;
  pQLEAF  TLeaf;
  Int32 n;
  UInt16 lfac, lfacnb;
  if((Bsp==NULL)||(Bsp->LEdg==NULL)||(Bsp->LEdg<=0))
  { return -1;}
  if((Bsp->Plan==NULL)||(Bsp->PlanNb<=0)||(Bsp->Vrtx==NULL)||(Bsp->VrtxNb<=0))
  { return -1;}

  /**/
  Bsp->LeafNb= LmpSz/sizeof(QKLEAF);
  if(TBLinit(Bsp->Leaf, Bsp->LeafNb)==NULL)
  { return ERR_MEM;}
  DLeaf = (pQKLEAF)Lmp;
  for(n=0, TLeaf=Bsp->Leaf; n<Bsp->LeafNb; n++, TLeaf+=1, DLeaf+=1)
  { /* TLeaf = TBLelem(Bsp->Leaf, n)*/
    /* Faces */
	 lfac  = UInt16BE(DLeaf->LFac);
    lfacnb= UInt16BE(DLeaf->LFacNb);
    if((lfacnb>=0x4000)||(lfac+lfacnb > Bsp->LFacNb))
    { /*note: in 16bit, segment alignment error can cause this problem */
      ERRwarn("BSP Leaf %ld: invalid list of faces",(long)n);
      lfac=0; lfacnb=0;
    }
	 TLeaf->LFac=    &(TBLelem(Bsp->LFac, lfac));
	 TLeaf->LFacNb = lfacnb;
	 /*sounds*/
	 TLeaf->SndWater= DLeaf->SndWater; /* sound level*/
	 TLeaf->SndSky  = DLeaf->SndSky;   /* sound level*/
	 TLeaf->SndSlime= DLeaf->SndSlime; /* sound level*/
	 TLeaf->SndLava = DLeaf->SndLava;
	 /*do not check visibility list*/
	 TLeaf->Visi = Int32BE(DLeaf->Visi);
	 /*init waypoints*/
	 TLeaf->Qway=0;
	 TLeaf->QwayNb=0;
	 /*inits*/
	 TLeaf->Flow=0;
    TLeaf->Threat=0;
  }
  /*
  ** Create nodes for leaves
  */
  Bsp->LfNodeNb = Bsp->LeafNb;
  if(TBLinit(Bsp->LfNode,Bsp->LfNodeNb)==NULL)
  { return -1; }
  DLeaf = (pQKLEAF)Lmp;
  for(n=0, TLfNode=Bsp->LfNode; n<Bsp->LfNodeNb; n++, TLfNode+=1, DLeaf+=1)
  { /* TLfNode= TBLelem(Bsp->LfNode, n)*/
    TLfNode->Content = BSPleafContentI(Int32BE(DLeaf->Content));
    /**/
    TLfNode->Leaf = n; /*Node is a leaf*/
    TLfNode->Father = NULL;
	 TLfNode->Front = NULL;
    TLfNode->Back = NULL;
    /* Bound Box */
    TLfNode->Bound.MinX = (SCALAR)Int16BE(DLeaf->Bound.MinX);
    TLfNode->Bound.MinY = (SCALAR)Int16BE(DLeaf->Bound.MinY);
    TLfNode->Bound.MinZ = (SCALAR)Int16BE(DLeaf->Bound.MinZ);
    TLfNode->Bound.MaxX = (SCALAR)Int16BE(DLeaf->Bound.MaxX);
    TLfNode->Bound.MaxY = (SCALAR)Int16BE(DLeaf->Bound.MaxY);
    TLfNode->Bound.MaxZ = (SCALAR)Int16BE(DLeaf->Bound.MaxZ);
    /* Normal = Origin*/
    TLfNode->Normal.X = (TLfNode->Bound.MinX + TLfNode->Bound.MaxX)/(SCALAR)2.0;
    TLfNode->Normal.Y = (TLfNode->Bound.MinY + TLfNode->Bound.MaxY)/(SCALAR)2.0;
    TLfNode->Normal.Z = (TLfNode->Bound.MinZ + TLfNode->Bound.MaxZ)/(SCALAR)2.0;
    /* Unused */
    TLfNode->Dist = (SCALAR)0.0;
    TLfNode->Face=0;
    TLfNode->FaceNb =0;
  }
  /* ensure that leaf zero is solid*/
  if(!(TBLelem(Bsp->LfNode, LEAF_SOLID).Content & AREA_INWALL))
  {
    ERRwarn("BSP Leaf zero is not solid");
    TBLelem(Bsp->LfNode, LEAF_SOLID).Content = AREA_INWALL;
  }
  return 1;
}



/****************************************************\
*
*
* Quake Nodes
*
*
\****************************************************/
/*
** Init the father of a node, and checks consistency
*/
static void BSPnodeSetFather(pQNODE Node)
{
  /* front child*/
  if(Node->Front!=NULL)
  {
	 if(Node->Front->Father!=NULL)
	 { ERRwarn("BSP Node(F): invalid loop in BSP tree"); }
	 if(Node->Front->Leaf!=LEAF_SOLID) /*Leaf 0 has no fathers*/
	 { Node->Front->Father = Node;}
	 BSPnodeSetFather(Node->Front);
  }
  /* back child */
  if(Node->Back!=NULL)
  {
	 if(Node->Back->Father!=NULL)
    { ERRwarn("BSP Node(B): invalid loop in BSP tree"); }
	 if(Node->Back->Leaf!=LEAF_SOLID) /*Leaf 0 has no fathers*/
	 { Node->Back->Father = Node; }
    BSPnodeSetFather(Node->Back);
  }
  /* security check */
  if((Node->Leaf<0)&&((Node->Back==NULL)||(Node->Front==NULL)))
  { ERRwarn("BSP Node: invalid child node");}
}
/*
** Init Child of a node
**  supposes that Bsp->LfNode and Bsp->Node have been allocated.
*/
static pQNODE BSPnodeChildInit(pBSPDEF Bsp, UInt32 Child)
{
  if(NODE_ISLEAF(Child)) /* leaf */
  {
	 Child = NODE_MKLEAF(Child);
	 if(Child>=Bsp->LfNodeNb)  /*invalid leaf*/
    { return &(TBLelem(Bsp->LfNode, LEAF_SOLID)); } /*leaf 0, is solid*/
    return &(TBLelem(Bsp->LfNode, Child));
  }
  if(Child>= Bsp->NodeNb) /*invalid node*/
  { return &(TBLelem(Bsp->LfNode, LEAF_SOLID)); }   /*leaf 0, is solid*/
  return &(TBLelem(Bsp->Node,Child));
}
/*
** Init Node
*/
Int32 BSPnodeInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKNODE DNode;
  pQNODE TNode;
  Int32 n;
  UInt32 node, plan;
  UInt16 face,facenb;
  if((Bsp==NULL)||(Bsp->LfNode==NULL)||(Bsp->LfNodeNb<=0)||(Bsp->Plan==NULL)||(Bsp->PlanNb<=0))
  { return -1;}
  /*
  ** Create nodes
  */
  Bsp->NodeNb= LmpSz/sizeof(QKNODE);
  if(TBLinit(Bsp->Node, Bsp->NodeNb)==NULL)
  { return ERR_MEM;}
  DNode = (pQKNODE) Lmp;
  for(n=0, TNode=Bsp->Node; n<Bsp->NodeNb; n++, TNode+=1, DNode+=1)
  { /* TNode = TBLelem(Bsp->Node,n)*/
    TNode->Father = NULL;
#if 1 /*Debug*/
    TNode->Leaf   = -(100000L+n); /*Debug info:  -node id*/
#else
    TNode->Leaf   = -1;          /* Node is not a leaf */
#endif
    TNode->Content = AREA_INVOID;
    /* faces list */
    face =   UInt16BE(DNode->Face);
    facenb = UInt16BE(DNode->FaceNb);
    if((facenb>=0x8000)||(face+facenb> Bsp->FaceNb))
    { /*In 16 bit, segment alignment error can cause this problem*/
      ERRwarn("BSP Node %ld: invalid list of faces",(long)n);
      face=0; facenb=0;
    }
    TNode->Face=   face;
    TNode->FaceNb= facenb;
    /* Bound Box */
    TNode->Bound.MinX = (SCALAR)Int16BE(DNode->Bound.MinX);
    TNode->Bound.MinY = (SCALAR)Int16BE(DNode->Bound.MinY);
    TNode->Bound.MinZ = (SCALAR)Int16BE(DNode->Bound.MinZ);
    TNode->Bound.MaxX = (SCALAR)Int16BE(DNode->Bound.MaxX);
    TNode->Bound.MaxY = (SCALAR)Int16BE(DNode->Bound.MaxY);
    TNode->Bound.MaxZ = (SCALAR)Int16BE(DNode->Bound.MaxZ);
    /* Plane */
    plan = Int32BE(DNode->Plan);
    if(plan>= Bsp->PlanNb)
    {
      ERRwarn("BSP Node %ld: invalid plane",(long)n);
      plan=0;
    }
    VecCpy(&(TNode->Normal), &(TBLelem(Bsp->Plan, plan).Normal));
    TNode->Dist = TBLelem(Bsp->Plan, plan).Dist;
    /* init childs*/
    TNode->Front = BSPnodeChildInit(Bsp,UInt16BE(DNode->Front));
    TNode->Back  = BSPnodeChildInit(Bsp,UInt16BE(DNode->Back));
  }
  /*
  ** Calculate father node
  */
  for(n=0; n<Bsp->ModlNb; n++)
  {
    node = TBLelem(Bsp->Modl,n).Node;
    BSPnodeSetFather(&(TBLelem(Bsp->Node,node)));
  }
  return 1;
}







/****************************************************\
*
*
* Quake  TexInfo
*
*
\****************************************************/


Int32 BSPtinfInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
 pQKTEXINFO DTinf;
 Int32 n;
 /**/
 if(Bsp==NULL)
 { return -1;}
 /**/
 Bsp->TinfNb= LmpSz/sizeof(QKTEXINFO);
 if(TBLinit(Bsp->Tinf, Bsp->TinfNb)==NULL)
 { return ERR_MEM;}
 /*convert*/
 DTinf=(pQKTEXINFO) Lmp;
 for(n=0; n< Bsp->TinfNb; n++, DTinf+=1)
 {
   /*s vector */
   TBLelem(Bsp->Tinf,n).S.X = Float32BE(DTinf->S.X);
   TBLelem(Bsp->Tinf,n).S.Y = Float32BE(DTinf->S.Y);
   TBLelem(Bsp->Tinf,n).S.Z = Float32BE(DTinf->S.Z);
   TBLelem(Bsp->Tinf,n).Sofs= Float32BE(DTinf->Sofs);
   /*t vector */
   TBLelem(Bsp->Tinf,n).T.X = Float32BE(DTinf->T.X);
   TBLelem(Bsp->Tinf,n).T.Y = Float32BE(DTinf->T.Y);
   TBLelem(Bsp->Tinf,n).T.Z = Float32BE(DTinf->T.Z);
   TBLelem(Bsp->Tinf,n).Tofs= Float32BE(DTinf->Tofs);
   /*should check texture*/
   TBLelem(Bsp->Tinf,n).Texu= UInt32BE(DTinf->Texu);
   TBLelem(Bsp->Tinf,n).Anim= UInt32BE(DTinf->Anim); /*1 for water texture*/
 }
 return 1;
}
/*
** Check TexInfo
*/
Int16 BSPtinfCheck(pBSPDEF Bsp)
{ Int32 n,dum; Int16 res;
  pQKTEXINFO TTinf;
  res=1;
#if DEBUG
  printf("Checking TexInfo\n");
#endif
  for(TTinf=Bsp->Tinf,n=0; n<Bsp->TinfNb; n++,TTinf+=1)
  {
	 /*S vector+off*/
	 /*T vector+off*/
	 /*check texu*/
	 dum=((Int32)TTinf->Texu)&0xFFL;
	 if(dum> Bsp->TexuNb)
	 {
		printf(" Tinf %ld: bad texture index\n",(long)n);
		res=-1;
	 }
  }
  return res;
}


/****************************************************\
*
*
* Quake  Faces
*
*
\****************************************************/


Int32 BSPfaceInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKFACE DFace;
  Int32 n;
  UInt32 plan, ledg, ledgnb, tinf, lite;
  /**/
  if((Bsp==NULL)||(Bsp->LEdg==NULL)||(Bsp->LEdgNb<=0))
  { return -1; }
  if((Bsp->Plan==NULL)||(Bsp->PlanNb<=0))
  { return -1; }
  if((Bsp->Tinf==NULL)||(Bsp->TinfNb<=0))
  { return -1; }
  if((Bsp->Lite==NULL)||(Bsp->LiteSz<=0))
  { return -1; }
  /**/
  Bsp->FaceNb= LmpSz/sizeof(QKFACE);
  if(TBLinit(Bsp->Face,Bsp->FaceNb)==NULL)
  { return ERR_MEM;}
  /*convert*/
  DFace = (pQKFACE)Lmp;
  for(n=0; n<Bsp->FaceNb; n++, DFace+=1)
  {
    /* plan */
    plan    = Int16BE(DFace->Plan);
    if(plan>= Bsp->PlanNb) { plan=0; }
    TBLelem(Bsp->Face,n).Plan  = &(TBLelem(Bsp->Plan, plan));
    TBLelem(Bsp->Face,n).Side  = Int16BE(DFace->Side);
    /* list of edges */
    ledgnb  = Int16BE(DFace->LEdgNb);
    ledg    = Int32BE(DFace->LEdg);
    if((ledg +ledgnb > Bsp->LEdgNb)||(ledgnb>=0x4000))
    {
      ERRwarn("BSP face %ld: invalid list of edges",(long)n);
      ledg =0; ledgnb=0;
    }
    TBLelem(Bsp->Face,n).LEdg  = &(TBLelem(Bsp->LEdg, ledg));
    TBLelem(Bsp->Face,n).LEdgNb= (UInt16)ledgnb;
    /* texture info */
    tinf    = Int16BE(DFace->Tinf);
    if(tinf>= Bsp->TinfNb)
    {
      ERRwarn("BSP face %ld: invalid texture info",(long)n);
      tinf=0;
    }
    TBLelem(Bsp->Face,n).Tinf=   &(TBLelem(Bsp->Tinf, tinf));
    /* litemaps */
    lite    = Int32BE(DFace->LiteMap);
    if((lite==0xFFFFFFFFL)||(lite>=Bsp->LiteSz))
    { TBLelem(Bsp->Face,n).LiteMap= NULL; }
    else
    { TBLelem(Bsp->Face,n).LiteMap= &(Bsp->Lite[lite]); }
    /*light models*/
    TBLelem(Bsp->Face,n).LType  =DFace->LType;
    TBLelem(Bsp->Face,n).Shadow =DFace->Shadow;
    TBLelem(Bsp->Face,n).Lite1  =DFace->Lite1;
    TBLelem(Bsp->Face,n).Lite2  =DFace->Lite2; /*usually, 0xFF*/
  }
  return 1;
}

/****************************************************\
*
*
* Quake Lite
*
*
\****************************************************/


Int32 BSPliteInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  Bsp->LiteSz= LmpSz;
  /*Calloc(Bsp->LiteSz, sizeof(Int8));*/
  Bsp->Lite=(pInt8)Malloc(LmpSz);
  if(Bsp->Lite==NULL) { return ERR_MEM;}
  Memcpy(Bsp->Lite,Lmp,LmpSz);
  return 1;
}

/****************************************************\
*
*
* Quake Bounding Nodes
*
*
\****************************************************/
Int16 BSPclipChildInit(pBSPDEF Bsp, Int16 Child)
{
    if(Child>=0)
    {
      if(Child>= Bsp->ClipNb) /*invalid node*/
      { Child=CONTENTS_SOLID; }
    }
    else switch(Child)
    { case CONTENTS_SOLID: break;
      case CONTENTS_EMPTY: break;
      default: Child = CONTENTS_SOLID;break;
    }
    return Child;
}

Int32 BSPclipInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKCLIPNOD DClip;
  Int32 n, plan;
  /**/
  if((Bsp==NULL)||(Bsp->Plan==NULL)||(Bsp->PlanNb<=0))
  { return -1;}
  /**/
  Bsp->ClipNb= LmpSz/sizeof(QKCLIPNOD);
  if(TBLinit(Bsp->Clip, Bsp->ClipNb)==NULL)
  { return ERR_MEM;}
  DClip = (pQKCLIPNOD)Lmp;
  for(n=0; n<Bsp->ClipNb; n++, DClip+=1)
  {
    plan  = Int32BE(DClip->Plan);
    if((plan<0)||(plan >= Bsp->PlanNb))
    {
      ERRwarn("BSP ClipNode %ld: bad plane",(long)n);
      plan = 0;
    }
    TBLelem(Bsp->Clip,n).Plan = plan;
    TBLelem(Bsp->Clip,n).Front = BSPclipChildInit(Bsp, Int16BE(DClip->Front));
    TBLelem(Bsp->Clip,n).Back  =  BSPclipChildInit(Bsp, Int16BE(DClip->Back));
  }
  return 1;
}




/****************************************************\
*
*
* Quake List of faces
*
*
\****************************************************/


Int32 BSPlfacInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
 pQKLFACE DLFac;
 Int32 n;
 UInt32 face;
 if((Bsp==NULL)||(Bsp->Face==NULL)||(Bsp->FaceNb<=0))
 { return -1;}
 Bsp->LFacNb= LmpSz/sizeof(QKLFACE);
 if(TBLinit(Bsp->LFac,Bsp->LFacNb)==NULL)
 { return ERR_MEM;}
 DLFac= (pQKLFACE) Lmp;
 for(n=0; n<Bsp->LFacNb; n++, DLFac+=1)
 {
   face =  Int16BE(*DLFac);
   if(face>= Bsp->FaceNb)
   {
     ERRwarn("BSP List Faces %ld: invalid face",(long)n);
     face=0;
   }
   TBLelem(Bsp->LFac,n) = &(TBLelem(Bsp->Face, face));
 }
 return 1;
}


/****************************************************\
*
*
* Quake Edges
*
*
\****************************************************/


Int32 BSPedgeInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKEDGE DEdge;
  Int32 n;
  UInt16 vrtx;
  if((Bsp==NULL)||(Bsp->Vrtx==NULL)||(Bsp->VrtxNb<=0))
  { return -1; }
  Bsp->EdgeNb= LmpSz/sizeof(QKEDGE);
  if(TBLinit(Bsp->Edge,Bsp->EdgeNb)==NULL)
  { return ERR_MEM;}
  DEdge = (pQKEDGE)Lmp;
  /* Convert */
  for(n=0; n<Bsp->EdgeNb; n++, DEdge+=1)
  {
    vrtx = UInt16BE(DEdge->Vrtx[0]);
    if(vrtx>= Bsp->VrtxNb)
    {
      ERRwarn("BSP edge %ld: bad vertex", (long)n);
      vrtx=0;
    }
    TBLelem(Bsp->Edge, n).Vrtx[0] = vrtx;
    vrtx = UInt16BE(DEdge->Vrtx[1]);
    if(vrtx>= Bsp->VrtxNb)
    {
      ERRwarn("BSP edge %ld: bad vertex", (long)n);
      vrtx=0;
    }
    TBLelem(Bsp->Edge, n).Vrtx[1] = vrtx;
  }
  return 1;
}

/****************************************************\
*
*
* Quake List Edges
*
*
\****************************************************/


Int32 BSPledgInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKLEDGE DLEdg;
  Int32 n;
  Int32 edge, vrtx;
  Int8 first, second;
  /* Requires Vertices and Edges*/
  if((Bsp==NULL)||(Bsp->Edge==NULL)||(Bsp->EdgeNb<=0)||(Bsp->Vrtx==NULL)||(Bsp->VrtxNb<=0))
  { return -1; }
  Bsp->LEdgNb= LmpSz/sizeof(QKLEDGE);
  if(TBLinit(Bsp->LEdg, Bsp->LEdgNb)==NULL)
  { return ERR_MEM;}
  DLEdg = (pQKLEDGE) Lmp;
  for(n=0; n<Bsp->LEdgNb; n++, DLEdg+=1)
  {
    edge = Int32BE(*DLEdg);
    if(edge<0) { first= 1; second= 0; edge= -edge; }
    else       { first= 0; second= 1; }
    /* Note: edge=0 is an invalid edge */
    if(edge>= Bsp->EdgeNb) { edge=0; }
    /* pointer to first vertex */
    vrtx = TBLelem(Bsp->Edge, edge).Vrtx[first];
    if(vrtx>= Bsp->VrtxNb) vrtx=0;
    TBLelem(Bsp->LEdg, n).Vtx0 = &(TBLelem(Bsp->Vrtx,vrtx));
    /* pointer to second vertex */
    vrtx = TBLelem(Bsp->Edge, edge).Vrtx[second];
    if(vrtx>= Bsp->VrtxNb) vrtx=0;
    TBLelem(Bsp->LEdg, n).Vtx1 = &(TBLelem(Bsp->Vrtx,vrtx));
  }
  return 1;
}


/****************************************************\
*
*
* Quake Modls
*
*
\****************************************************/


Int32 BSPmodlInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz)
{
  pQKMODEL DModl;
  pQMODEL TModl;
  Int32 n;
  UInt32 face;
  if((Bsp==NULL)||(Bsp->Face==NULL)||(Bsp->FaceNb<=0))
  { return -1; }
  Bsp->ModlNb= LmpSz/sizeof(QKMODEL);
  if(TBLinit(Bsp->Modl, Bsp->ModlNb)==NULL)
  { return ERR_MEM;}
  DModl = (pQKMODEL)Lmp;
  for(n=0, TModl=Bsp->Modl; n<Bsp->ModlNb; n++, TModl+=1, DModl+=1)
  {
    TModl->Bound.MinX = Float32BE(DModl->Bound.MinX);
    TModl->Bound.MinY = Float32BE(DModl->Bound.MinY);
    TModl->Bound.MinZ = Float32BE(DModl->Bound.MinZ);
    TModl->Bound.MaxX = Float32BE(DModl->Bound.MaxX);
    TModl->Bound.MaxY = Float32BE(DModl->Bound.MaxY);
    TModl->Bound.MaxZ = Float32BE(DModl->Bound.MaxZ);
    TModl->Origin.X   = Float32BE(DModl->Origin.X);
    TModl->Origin.Y   = Float32BE(DModl->Origin.Y);
    TModl->Origin.Z   = Float32BE(DModl->Origin.Z);
    TModl->Node       = UInt32BE(DModl->Node);
    TModl->Clip       = UInt32BE(DModl->Clip);
    TModl->Clip2      = UInt32BE(DModl->Clip2);
    TModl->Clip3      = UInt32BE(DModl->Clip3);
    TModl->LeafNb     = UInt32BE(DModl->LeafNb);
    /* face list */
    TModl->FaceNb     = UInt32BE(DModl->FaceNb);
    face              = UInt32BE(DModl->Face);
    if((face + TModl->FaceNb) > Bsp->FaceNb)
    { TModl->Face     = NULL; }
    else
    { TModl->Face     = &(TBLget(Bsp->Face, face));}
  }
  Bsp->WorldNode  = Bsp->Modl[0].Node;
  Bsp->WorldLeaves= Bsp->Modl[0].LeafNb+1; /*including leaf 0*/
  return 1;
}



