/*
** Give the type of an entry, from file name
*/
ETYPE DBfileType(pInt8 Name);
/*
** Init file database
**  Path0 = name of a .PAK file
**  The following arguments are names of .PAK files or game directory.
**  their type is the same as Path0.
**  The list of arguments MUST END WITH NULL (or it crashes)
*/
Int32 DBinit(pInt8 Path0, ...);
/*
** Free file Database
*/
Int32 DBfree(void);
/*
** Check that file name is correct, according to Database
** if not database, then return TRUE (to keep quiet)
*/
Bool DBcheck(pInt8 File);
/*
** Tell if a file exists in the database
*/
Bool DBexists(pInt8 File);
/*
** Get the content of a file in the database
*/
pInt8 DBget(pInt32 pSize, pInt8 File);

