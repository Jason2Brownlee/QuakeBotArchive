/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include <math.h>
#include <stdio.h>    /*NULL*/
#include "defines.h"
#include "common.h"
#include "data.h"     /*Dta handling */
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkbspdef.h"    /*Quake BSP definitions*/
#include "qkbspprt.h"    /*Quake BSP definitions*/
#include "qkbspway.h" /*Quake BSP way points*/
#include "qkbsp.h"    /*Quake BSP level*/

#define DEBUG   0
/*
** Max allowed depth for a BSP tree
*/
#define MAXBSPDEPTH 64
/*
** Crude approximation of the rounding error.
*/
#define ROUNDING_ERROR  (0.0001)

/*
** Static data
*/
static BSPDEF Level;

/*
** Init
*/
void BSPinit(void)
{
  pBSPDEF Bsp= &Level;
  Bsp->Ok= FALSE;
  Bsp->WorldNode=0;
  Bsp->WorldLeaves=0;
  Bsp->Enti= NULL; Bsp->EntiSz= 0;
  Bsp->Plan= NULL; Bsp->PlanNb= 0;
  Bsp->Texu= NULL; Bsp->TexuNb= 0;
  Bsp->Vrtx= NULL; Bsp->VrtxNb= 0;
  Bsp->Visi= NULL; Bsp->VisiSz= 0;
  Bsp->Node= NULL; Bsp->NodeNb= 0;
  Bsp->Tinf= NULL; Bsp->TinfNb= 0;
  Bsp->Face= NULL; Bsp->FaceNb= 0;
  Bsp->Lite= NULL; Bsp->LiteSz= 0;
  Bsp->Clip= NULL; Bsp->ClipNb= 0;
  Bsp->Leaf= NULL; Bsp->LeafNb= 0;
  Bsp->LFac= NULL; Bsp->LFacNb= 0;
  Bsp->Edge= NULL; Bsp->EdgeNb= 0;
  Bsp->LEdg= NULL; Bsp->LEdgNb= 0;
  Bsp->Modl= NULL; Bsp->ModlNb= 0;
  /**/
  Bsp->LfNode= NULL;
  Bsp->QWay  = NULL; Bsp->QWayNb=0;
}
/*
** Free
*/
void BSPfree(void)
{
  pBSPDEF Bsp= &Level;
  /*
  ** Release data
  */
  if(Bsp->Enti!=NULL) Free(Bsp->Enti);
  TBLfree(Bsp->Plan);
#if 0
  BSPtexuFree(Bsp);
#endif
  TBLfree(Bsp->Vrtx);
  if(Bsp->Visi!=NULL) Free(Bsp->Visi);
  TBLfree(Bsp->Node);
  TBLfree(Bsp->Tinf);
  TBLfree(Bsp->Face);
  TBLfree(Bsp->Lite);
  TBLfree(Bsp->Clip);
  TBLfree(Bsp->Leaf);
  TBLfree(Bsp->LFac);
  TBLfree(Bsp->Edge);
  TBLfree(Bsp->LEdg);
  TBLfree(Bsp->Modl);
  /**/
  TBLfree(Bsp->LfNode);
  TBLfree(Bsp->QWay);
}
/*
** Load a Bsp file
**  Lmp, LmpSz = BSP lump
*/
Int32 BSPreInit(pInt8 Lmp, Int32  LmpSz)
{
  pBSPDEF Bsp= &Level;
  pQKBSPHEAD Head;
  Int32 n;
  /**/
  if((Lmp==NULL)||(LmpSz<=0))
  { return -1; }
  /*
  ** free previous data
  */
  BSPfree();
  /*
  ** read header
  */
  Head=(pQKBSPHEAD) Lmp;
  /*
  ** Check validity of BSP header
  */
  if(Int32BE(Head->Id)!=QKBSPVERSION)
  {
    ERRwarn("Bad BSP version: %d\n", (int)Head->Id);
    Free(Lmp); return -1;
  }
  for(n=0;n<QKBSPDIRNB;n++)
  { /* convert */
#if SYST_BIGENDIAN
#else  /*Processor is not big endian*/
    Head->Dir[(int)n].Start = Int32BE(Head->Dir[(int)n].Start);
    Head->Dir[(int)n].Size  = Int32BE(Head->Dir[(int)n].Size);
#endif
    if((Head->Dir[(int)n].Start<0)||(Head->Dir[(int)n].Start+Head->Dir[(int)n].Size>LmpSz))
    {
      ERRwarn("Invalid BSP entry %d\n", (int)n);
      Free(Lmp); return -1;
    }
  }
  /*read vertices*/
  BSPvrtxInit(Bsp,&Lmp[Head->Dir[QBSP_VRTX].Start],Head->Dir[QBSP_VRTX].Size);
  /*read planes*/
  BSPplanInit(Bsp,&Lmp[Head->Dir[QBSP_PLAN].Start],Head->Dir[QBSP_PLAN].Size);
  /*read edges, after vertices */
  BSPedgeInit(Bsp,&Lmp[Head->Dir[QBSP_EDGE].Start],Head->Dir[QBSP_EDGE].Size);
  /*read list edges, after edges */
  BSPledgInit(Bsp,&Lmp[Head->Dir[QBSP_LEDG].Start],Head->Dir[QBSP_LEDG].Size);
  /*read texinfo*/
  BSPtinfInit(Bsp,&Lmp[Head->Dir[QBSP_TINF].Start],Head->Dir[QBSP_TINF].Size);
  /*read light*/
  BSPliteInit(Bsp,&Lmp[Head->Dir[QBSP_LITE].Start],Head->Dir[QBSP_LITE].Size);
  /*read face, after texinfo and lights */
  BSPfaceInit(Bsp,&Lmp[Head->Dir[QBSP_FACE].Start],Head->Dir[QBSP_FACE].Size);
  /*read models, after faces */
  BSPmodlInit(Bsp,&Lmp[Head->Dir[QBSP_MODL].Start],Head->Dir[QBSP_MODL].Size);
  /*read list of faces*/
  BSPlfacInit(Bsp,&Lmp[Head->Dir[QBSP_LFAC].Start],Head->Dir[QBSP_LFAC].Size);
  /*read leaf, after planes, list of faces */
  BSPleafInit(Bsp,&Lmp[Head->Dir[QBSP_LEAF].Start],Head->Dir[QBSP_LEAF].Size);
  /*read node, after leaves, planes, faces */
  BSPnodeInit(Bsp,&Lmp[Head->Dir[QBSP_NODE].Start],Head->Dir[QBSP_NODE].Size);
  /*read entities*/
  BSPentiInit(Bsp,&Lmp[Head->Dir[QBSP_ENTI].Start],Head->Dir[QBSP_ENTI].Size);
  /*read visilists after leaves*/
  BSPvisiInit(Bsp,&Lmp[Head->Dir[QBSP_VISI].Start],Head->Dir[QBSP_VISI].Size);
#if 0
  /*read textures*/
  BSPtexuInit(Bsp,&Lmp[Head->Dir[QBSP_TEXU].Start],Head->Dir[QBSP_TEXU].Size);
#endif
  /*read clip nodes*/
  BSPclipInit(Bsp,&Lmp[Head->Dir[QBSP_CLIP].Start],Head->Dir[QBSP_CLIP].Size);
  /*
  ** Make leaf maze
  */
#if USEWAYS
  BSPwayInit(Bsp);
#endif
  /*
  ** Validate level
  */
  Bsp->Ok= TRUE;
  return 1;
}




/*
** Trace a line in BSP
**   pHit   = returns hit position
**   pFlags = returns flags saying what was found
**   returns Length of line
**
** Should check against monsters
** Should report vector
*/
Int32 BSPtrace(pVEC3 pHit, pVEC3 pDirec, pSCALAR pLen, pVEC3 pOrigin, pVEC3 pEnd)
{
  SCALAR  e,s;
  VEC3    Start, End;
  pQNODE  pQNode, pQNodeEnd, pQNodeStart;
  pBSPDEF Bsp= &Level;
  Int32   Flags= AREA_INVOID;   /*no leaf crossed yet*/
  /*stack*/
  static int StackTop=0;
  static struct
  { VEC3   End;
	 pQNODE pQNode;
  } Stack[MAXBSPDEPTH];
  /* Check */
  if((pOrigin==NULL)||(pEnd==NULL))
  { return AREA_INWALL; }
  if((Bsp->Node==NULL)||(Bsp->LfNode==NULL))
  { /*if no BSP, then no walls */
    VecCpy(&Start, pEnd);
  }
  else  /* There is a Bsp*/
  { /* Init */
    StackTop=0;             /*clear stack*/
    VecCpy(&Start,pOrigin);
    VecCpy(&End, pEnd);
    pQNode = &(TBLelem(Bsp->Node, Bsp->WorldNode)); /*first node in world*/
    while(1)
	 {
      if(pQNode==NULL)
      { break; } /*should pop*/
      if(pQNode->Leaf<0)
      { /* Node*/
        s = VecPlaneDist(&Start, &(pQNode->Normal), pQNode->Dist);
        e = VecPlaneDist(&End,   &(pQNode->Normal), pQNode->Dist);
        pQNodeEnd  = (e>0.0)? pQNode->Front : pQNode->Back;
        pQNodeStart= (s>0.0)? pQNode->Front : pQNode->Back;
        /* Check if not on the same side */
        /* if((pQNodeStart!=pQNodeEnd)&&(s!=e)) */
        if(((s<-ROUNDING_ERROR)&&(e>ROUNDING_ERROR))||((s>ROUNDING_ERROR)&&(e<-ROUNDING_ERROR)))
        { /* Push end node*/
          if(StackTop< MAXBSPDEPTH)
          {
             VecCpy(&(Stack[StackTop].End), &End);
				 Stack[StackTop].pQNode = pQNodeEnd;
             StackTop+=1; /* point to empty area */
          }
          /* End = Intersection point of Start-End and Split plane */
          /* End = ( s.End -e.Start) / (s-e) */
          VecScale(&End, s);
          VecAddScale(&End,&Start, (-e));
          VecScale(&End, 1/(s-e)); /* s!=e */
#if DEBUG
          e = VecPlaneDist(&End, &(pQNode->Normal), pQNode->Dist);
          if(e!=0.0)
          { printf("Point off split plane: %8.6f units\n", (float)e); }
#endif
        }
        pQNode = pQNodeStart; /*continue*/
      }
		else
      { /*leaf*/
        Flags|= pQNode->Content;
        /* Check if hit the wall*/
        if(Flags & AREA_INWALL)
        { break; }
        /* Continue with next leaf */
        VecCpy(&Start,&End);
        /* Pop pQNode and End from the stack */
        if(StackTop>= MAXBSPDEPTH)
        { StackTop = MAXBSPDEPTH; }
        if(StackTop<=0)
        { StackTop=0; pQNode=NULL;}
        else
        { StackTop-=1; /* point to empty area */
          VecCpy(&End, &(Stack[StackTop].End));
			 pQNode= Stack[StackTop].pQNode;
        }
      }
    }
  }
  /* Hit point */
  if(pHit!=NULL)
  { VecCpy(pHit,&Start); }
  /* Return distance to hit point */
  if(pLen!=NULL)
  {
    VecSub(&Start,pOrigin);
    *pLen = VecNorm(&Start);
  }
  if(pDirec!=NULL)
  { /*returns vector normal, direction of fire */
	 VecCpy(pDirec, pEnd);
    VecSub(pDirec, pOrigin );
    VecNormalise(pDirec);
  }
  return Flags;
}
/*
** Find in which leaf a point really is.
**   pLeaf  = returns leaf number
**   returns flags saying what was found
*/
Int32 BSPpointInLeaf(pInt32 pLeaf, pVEC3 pOrigin)
{
  pQNODE  pQNode;
  SCALAR  dist;
  pBSPDEF Bsp= &Level;
  Int32 Flags;
  if(pLeaf != NULL)
  { *pLeaf = 0; }
  /* Check */
  if((Bsp->Node==NULL)||(pOrigin==NULL))
  { return AREA_INVOID; }
  /* Init */
  Flags = AREA_INVOID;
  pQNode = &(TBLelem(Bsp->Node,Bsp->WorldNode)); /*first node in world*/
  while(1)
  {
    if(pQNode==NULL)
    { break; }
    if(pQNode->Leaf<0)
    { /* Node*/
      dist = VecPlaneDist(pOrigin, &(pQNode->Normal), pQNode->Dist);
		pQNode = ( dist>0.0)? pQNode->Front : pQNode->Back;
    }
    else
    { /*leaf*/
      Flags |= pQNode->Content;
      break;
    }
  }
  if((pLeaf != NULL)&&(pQNode!=NULL)&&(pQNode->Leaf>=0))
  { *pLeaf = pQNode->Leaf; }
  return Flags;
}

/*
**  Give the center of the leaf's bound box
**   pOrigin = returns center of the leaf's bound box
**   returns TRUE if center was found
*/
Bool BSPleafGet(pVEC3 pOrigin, pInt32 pFlag, Int32 Leaf)
{
  pBSPDEF Bsp= &Level;
  /* Check */
  if(Bsp->LfNode==NULL)
  { return FALSE; }
  if((Leaf<0)||(Leaf>Bsp->WorldLeaves))
  { return FALSE; }
  if(pOrigin!=NULL)
  { VecCpy(pOrigin, &(TBLelem(Bsp->LfNode,Leaf).Normal)); }
  if(pFlag!=NULL)
  { *pFlag = TBLelem(Bsp->LfNode,Leaf).Content;}
  return TRUE;
}



/*
** Find leaves, according to bounding boxes
**  Used = Table of size UsedNb
*/
Int32 BSPleafFindInBound(pInt8 Used, Int32 UsedNb, pBOUNDBOX pBound)
{
  static int StackTop;
  static struct
  { BOUNDBOX Bound;
    pQNODE pQNode;
    Int32  Dummy; /*Padding*/
  } Stack[MAXBSPDEPTH];
  BOUNDBOX Bound;
  pQNODE pQNode;
  pBSPDEF Bsp= &Level;
  /* if(UsedNb<= Bsp->LfNode), no good */
  TBLclear(Used,UsedNb);
  StackTop=0;
  pQNode = &(TBLelem(Bsp->Node, Bsp->WorldNode)); /*first node in world*/
  BBOXcpy(&Bound, pBound);
  while(1)
  {
    if(pQNode==NULL)
    { break; }
    BBOXinter(&Bound, &Bound, &(pQNode->Bound));
    if(pQNode->Leaf<0)
    { /*Node is not a leaf*/
      if(BBOXisEmpty(&Bound)!=TRUE)
      {
		  if((StackTop< MAXBSPDEPTH)&&(pQNode->Back!=NULL))
        { /* preserve the back node and current bound box */
          BBOXcpy(&(Stack[StackTop].Bound),&Bound);
          Stack[StackTop].pQNode = pQNode->Back;
          StackTop++;
        }
        if(pQNode->Front!=NULL)
        { /* restart with front node */
          pQNode = pQNode->Front;
          continue;
        }
      }
    }
    else
    { /* Node is a leaf*/
      if(BBOXisEmpty(&Bound)!=TRUE)
		{ /* indicate that leaf is used */
        if(pQNode->Leaf< UsedNb)
        { TBLelem(Used, pQNode->Leaf) = 1;}
      }
    }
    /* restore node and current bound from stack*/
    if(StackTop<=0) { break; } /*empty*/
    StackTop--;
    BBOXcpy(&Bound, &(Stack[StackTop].Bound));
    pQNode = Stack[StackTop].pQNode;
  }
  return 1;
}
/*
** Test point against all planes of a given leaf
**  Leaf = leaf id
**  pOrigin = point
*/
SCALAR BSPleafPointInside(Int32 Leaf, pVEC3 pOrigin)
{
  pQNODE Father;
  pQNODE Child, Child2;
  pQNODE pQNode;
  SCALAR dist, maxdist;
  pBSPDEF Bsp= &Level;
  if((Bsp==NULL)||(Bsp->LfNode==NULL)||(pOrigin==NULL))
  { return (SCALAR)0.0; }
  if((Leaf<=0)||(Leaf>=Bsp->LfNodeNb))
  { return (SCALAR)0.0; }
  pQNode = &(TBLelem(Bsp->LfNode,Leaf));
  maxdist = (SCALAR)0.0;
  /**/
  for(Child = pQNode ; Child!=NULL; Child= Child->Father )
  {
    Father= Child->Father;
    if((Father==NULL)||(Father->Leaf>=0)) continue; /*invalid or top node*/
    dist = VecPlaneDist(pOrigin, &(Father->Normal), Father->Dist);
    Child2 = ((dist>0.0)? Father->Front: Father->Back);
    /* detect if wrong choice */
    if(Child != Child2)
    { /* update max distance*/
      dist = (dist>=0.0)? dist: -dist;
      maxdist = max(maxdist, dist);
    }
  }
  /**/
  return (maxdist<ROUNDING_ERROR)? (SCALAR)0.0: maxdist;
}

/*
** Trace a line in BSP without leaving the current leaf
**   Leaf = leaf inside which the trace is meant to remain
**   pOrigin, pEnd = origin and end of trace
**   pHit   = returns hit position, at the bound of current leaf
*/
Int32 BSPtraceInLeaf(pVEC3 pHit, pVEC3 pOrigin, pVEC3 pEnd, Int32 Leaf)
{
  SCALAR  e,s;
  pQNODE Father;
  pQNODE Child, Child2;
  pQNODE pQNode;
  VEC3 Start, End;
  pBSPDEF Bsp= &Level;
  if((Bsp==NULL)||(Bsp->LfNode==NULL)||(pOrigin==NULL))
  { return -1; }
  if((Leaf<=0)||(Leaf>=Bsp->LfNodeNb))
  { return -1; }
  pQNode = &(TBLelem(Bsp->LfNode,Leaf));
  VecCpy(&Start,pOrigin);
  VecCpy(&End,pEnd);
  /**/
  for(Child = pQNode ; Child!=NULL; Child= Child->Father )
  {
    Father= Child->Father;
	 if((Father==NULL)||(Father->Leaf>=0)) continue; /*invalid or top node*/
    s = VecPlaneDist(&Start, &(Father->Normal), Father->Dist);
    e = VecPlaneDist(&End, &(Father->Normal), Father->Dist);
    /**/
	 Child2 = ((s>0.0)? Father->Front: Father->Back);
	 /* Make s>0 */
	 if(s<0) { s=-s; e=-e;}
    /* detect if Start is not in leaf of choice */
    if(Child != Child2)
    { /* Hit = Start */
      if(s>ROUNDING_ERROR) /* Not in the right place */
      { VecCpy(&End, &Start); break; }
      s = (SCALAR)0.0; /*cancel the error*/
    }
    /* pStart is in leaf, now where is the hit?*/
    if(e<-ROUNDING_ERROR)/* and s > 0 */
	 { /*s!=e*/
      VecScale(&End, s);
		VecAddScale(&End,&Start, (-e));
		VecScale(&End, 1/(s-e)); /* s!=e */
	 }
  }
  /**/
  VecCpy(pHit, &End);
  return 1;
}
/*
** Find close leaves
**  Note: this code doesn't work yet
*/
pInt32 BSPleafListWays(pInt32 pWaysNb, Int32 Leaf)
{
#if USEWAYS
  pBSPDEF Bsp= &Level;
  Int32 Qway, QwayNb,n;
  static Int32 Qways[32];
  if((Bsp==NULL)||(Bsp->Leaf==NULL))
  { return NULL; }
  if((Leaf<0)||(Leaf>= Bsp->LeafNb))
  { return NULL; }
  if((Bsp->QWay==NULL)||(pWaysNb==NULL))
  { return NULL; }
  /**/
  QwayNb= TBLelem(Bsp->Leaf,Leaf).QwayNb;
  Qway  = TBLelem(Bsp->Leaf,Leaf).Qway;
  if(QwayNb>=32) QwayNb=32;
  for(n=0; n<QwayNb; n++)
  {
	 Qways[n] = TBLelem(Bsp->QWay, Qway+n).Leaf;
  }
  *pWaysNb = QwayNb;
  return &Qways[0];
#else  /*USEWAYS*/
  (void)Leaf;
  (void)pWaysNb;
  return NULL;
#endif /*USEWAYS*/
}
