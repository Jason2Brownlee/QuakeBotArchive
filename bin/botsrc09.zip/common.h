/*
** Color palettes in WADs or PODs: RGB[256]
*/
typedef struct { Int8 R; Int8 G; Int8 B;} RGB;
typedef RGB PTR *pRGB;
/*
** Big Endian and Little Endian
**
** Detect if system is big endian or little endian
** Rule is: Intel is Big endian (DOS,WIN,LINUX)
**          Sparc and AIX are little endian
** In all other cases, the rule will fail. 
*/
#if SYST_BIGENDIAN
#define UInt32BE(a)  (a)
#define UInt16BE(a)  (a)
#define Int32BE(a)   (a)
#define Int16BE(a)   (a)
#define Float32BE(a) (a)
#define UInt32LE(a)  (UInt32)SwapInt32((Int32)(a))
#define UInt16LE(a)  (UInt16)SwapInt16((Int16)(a))
#define Int32LE(a)   SwapInt32(a)
#define Int16LE(a)   SwapInt16(a)
#define Float32LE(a) SwapFloat32(a)
#define BYTE0BE16 0
#define BYTE1BE16 1
#define BYTE0BE32 0
#define BYTE1BE32 1
#define BYTE2BE32 2
#define BYTE3BE32 3
#else /* Little endian*/
#define UInt32LE(a)  (a)
#define UInt16LE(a)  (a)
#define Int32LE(a)   (a)
#define Int16LE(a)   (a)
#define Float32LE(a) (a)
#define UInt32BE(a)  (UInt32)SwapInt32((Int32)(a))
#define UInt16BE(a)  (UInt16)SwapInt16((Int16)(a))
#define Int32BE(a)   SwapInt32(a)
#define Int16BE(a)   SwapInt16(a)
#define Float32BE(a) SwapFloat32(a)
#define BYTE0BE16 1
#define BYTE1BE16 0
#define BYTE0BE32 3
#define BYTE1BE32 2
#define BYTE2BE32 1
#define BYTE3BE32 0
#endif
/*
** Swap byte halves. Should be optimised...
*/
Int16   SwapInt16(Int16 Val);
Int32   SwapInt32(Int32 Val);
Float32 SwapFloat32(Float32 Val);
/*
** This string is used as a single temp name buffer
** in every function. Don't rely on the contents of Path.
*/
#define MAXBUFFSZ (0x1000)
extern Int8 Buff[MAXBUFFSZ];	/*sizeof(Buff)*/
/*
** Memory Handling
*/
  /*
  ** Malloc (GlobalAlloc, Locked)
  */
pVoid Malloc(Int32 Size);
  /*
  ** Malloc for sndPlaySound under Windoze (MEM_MOVEABLE)
  */
pVoid MallocSpecial(Int32 Size);
  /*
  ** Calloc (GlobalAlloc, Fixed, Cleared)
  */
pVoid Calloc(Int32 Nb, Int32 Size);
  /*
  ** Realloc (GlobalRealloc, Fixed)
  */
pVoid Realloc(pVoid Data,Int32 Size);
  /*
  ** Free (GlobalFree), returns NULL
  */
pVoid Free(pVoid Data);
  /*
  ** Get the size of the memory object
  */
#if (SYST_WIN16)||(SYST_WIN32)||(SYST_WIN32CSL)
Int32 Memsize(pVoid Data);
  /*
  ** Unlock memory, so that it can be swapped
  */
Int32 Unlock(pVoid Data);
  /*
  ** Lock memory, so that it can be swapped
  */
pVoid Lock(Int32 DataH);
#endif
  /*
  ** Copy memory (MUST NOT BE OVERLAPPING)
  */
Int32 Memcpy(pVoid Data,pVoid Src,Int32 Size);
  /*
  ** Set Memory
  */
Int32 Memset(pVoid Data,Int8 Src,Int32 Size);
  /*
  ** Set Memory, 4 bytes at the time
  */
Int32 MemsetL(pVoid Data,Int8 Src,Int32 Size);
/*
** Tables
*/
/* define*/
#define TBLdefine(name, type)        struct{ Int32 Nb; type T;} name
/* init */
#define TBLinit(ptr, indexes)        ((ptr)=Calloc((indexes), sizeof(*(ptr))))
/* clear */
#define TBLclear(ptr, indexes)       Memset((ptr),0,(indexes)*sizeof(*(ptr)))
/* table[index].element*/
#define TBLelem(ptr, index)           ((ptr)[(index)])
/* table[index]=value */
#define TBLset(ptr, index, value)    (ptr)[(index)] = (value)
/* table[index] */
#define TBLget(ptr, index)           (ptr)[(index)]
/* free */
#define TBLfree(ptr)                 if((ptr)!=NULL) ptr=Free(ptr)
/* copy */
#define TBLcopy(ptr2, ptr, indexes)  Memcpy(ptr2, ptr,(indexes)*sizeof(*(ptr)))

/*
** String handling
*/
  /*
  ** Find a string Match inside Data
  **  returns index>=0, or <0 if error.
  */
Int32 Strfind(pInt8 Data,pInt8 Match,Int32 Size);
  /*
  ** String matching, case insensitive
  **   Size = max lenght compared
  ** returns >0 if start of Data is like Match
  */
Int32 Strmatch(pInt8 Data,pInt8 Match,Int32 Size);
  /*
  ** String comparison, case insensitive
  **   Size= max length compared
  ** returns >0 if strings Data and Match are the same
  */
Int32 Strncmpi(pInt8 Data,pInt8 Match,Int32 Size);
  /*
  ** String comparison, case sensitive
  **   Size= max length compared
  ** returns >0 if strings Data and Match are the same
  */
Int32 Strncmp(pInt8 Data,pInt8 Match,Int32 Size);
  /*
  ** Copy string, of fixed length
  **  Dest = Buffer
  **  Src = Source string
  **  Size = size of buffer, INCLUDES ending '\0'
  */
pInt8 Strncpy(pInt8 Dest, pInt8 Src, Int32 Size);
  /*
  ** Copy string
  */
pInt8 Strcpy(pInt8 Dest, pInt8 Src);
  /*
  ** Append string
  */
pInt8 Strcat(pInt8 Dest, pInt8 Src);
  /*
  ** Append Number
  */
pInt8 StrcatNum(pInt8 Dest, Int32 Nb, Int32 Base);
  /*
  ** Length of string
  **  Max = max length tolerated.
  */
Int32 Strlen(pInt8 Src, Int32 Max);
  /*
  ** String to Integer. returns 0 if cannot convert.
  */
Int32 Strval(pInt8 Src);
/*
** Normalise text entries
*/
  /*
  ** Cleanup a name, remove spaces and non-printables
  ** Pad with zeroes, return size
  **  Text[TextSz]
  */
Int32 StrClean(pInt8 Text, pInt8 Src, Int32 TextSz);
  /*
  ** Cleanup name
  ** Pad with white space, return size
  ** Text[TextSz]
  */
Int32 StrCleanS(pInt8 Dest,pInt8 Src,Int32 TextSz);
  /*
  ** print a 4-digit number, space padded, return size
  ** Text[4+1]
  */
Int32 StrCleanN(pInt8 Text,Int32 nb);


/*
** FILE functions
*/
  /*
  ** Open a file, ONE at the time, for reading
  */
Int32 FILEopen(pInt8 File,Int32 Mode);
#define FCREATE (0) /*Mode*/
#define FMODIFY (1) /*Mode*/
#define FREAD   (2) /*Mode*/
  /*
  ** Read data from opened file to buffer
  **  Data = buffer
  **  Start = position (-1 means last position)
  **  Size = size of buffer
  */
Int32 FILEread(pInt8 Data,Int32 Start,Int32 Size);
  /*
  ** Write data from buffer to opened file
  **  Data = buffer
  **  Start = position (-1 means last position)
  **  Size = size of buffer
  */
Int32 FILEwrite(pInt8 Data,Int32 Start,Int32 Size);
  /*
  ** close file
  */
Int32 FILEclose(void);
  /*
  ** atomic read: open file, read data, close
  */
Int32 FILEreadData(pInt8 Data,Int32 Start,Int32 Size, pInt8  File);
Int32 FILEreadText(pInt8 Data,Int32 Start,Int32 Size, pInt8  File);	
  /*
  ** atomic write: open file, write data, close 
  */
Int32 FILEwriteData(pInt8 Data,Int32 Start,Int32 Size, pInt8  File);
Int32 FILEwriteText(pInt8 Data,Int32 Start,Int32 Size, pInt8  File);
  /*
  ** Get the file time stamp.
  */
Int32 FILEgetTime(pInt8  File);
  /*
  ** Set the file time stamp.
  */
void FILEsetTime(pInt8  File, Int32 Time);
  /*
  ** Get the size of the file
  */
Int32 FILEgetSize(pInt8  File);
  /*
  ** Set the size of the file
  */
Int32 FILEsetSize(pInt8  File, Int32 Size);
/*
** Path Handling
*/
typedef struct
{
  Int8 Dir[0x100];
  Int8 Name[0x40];
  Int8 Ext[0x10];
  Int8 Drive;
} PATHSPLIT;
typedef PATHSPLIT PTR *pPATHSPLIT;
  /*
  ** if Dir==FALSE, return >0 if file exists
  ** if Dir==TRUE,  return >0 if directory exist
  */
Bool PATHexists(pInt8 File, Bool Dir);
  /*
  ** Join paths  Dir + / + File
  */
Int32 PATHjoin(pInt8 Path, Int32 PathSz, pInt8 Dir, pInt8 File);
  /*
  ** Split paths
  */
Int32 PATHsplit(pPATHSPLIT Split, pInt8 Path);
/*
** Hash table
*/
  /*
  **  Get hash key (DataSz in byte)
  */
Int32 HASHkey(pVoid Data, Int32 DataSz);
  /*
  **  Get hash key of a string
  */
Int32 HASHkeyS(pInt8 String);
/*
** Random number
*/
  /*
  ** Random uniformly distributed over [Min...Max]
  ** beware: only 15 random bytes under DOS/WINDOWS
  */
Float32 RandF(Float32 Min, Float32 Max);
Int32   RandI(Int32 Min, Int32 Max);

/*
** ErrorHandling
*/
  /*
  ** Warning  (same format as printf)
  */
Int32  ERRwarn(pInt8 Format, ...);
	 /*
	 ** ordinary error macro
	 */
#define ERRfault(a) ERRfaultI(__LINE__,a,__FILE__)
	 /*
	 ** To be used only by the error macro.
	 */
Int32 ERRfaultI(Int32 Line,Int32 Type, pInt8 Module);
	 /*
	 ** Control error reporting
	 ** ok = if TRUE, stop error report
	 **      if FALSE, report errors
	 */
void ERRquiet(Bool ok);
	 /*
	 ** To be used only by error handlers
	 */
Int32 ERRdeclare(Int8 **Txt,Int32 Type,Int32 Line, pInt8 Module);
	 /*
	 ** To be used only by GetThis()
	 */
void ERRsetWnd(Int32 Wnd);
/*
** Common Error Types
*/
#define FINISHED   -1
#define ERR_SURE   -2
#define ERR_BUG    -3
#define ERR_MEM    -4
#define ERR_CORR   -5
#define ERR_OPENW  -6
#define ERR_OPENR  -7
#define ERR_FREAD  -8
#define ERR_FSEEK  -9
#define BAD_WIN    -10
#define ERR_OBJREF -11
#define BAD_SIZE   -12
#define BAD_FILE   -13
#define BAD_HEAD   -14
#define BAD_ENTRY  -15
#define BAD_DATA   -16
#define BAD_PARM   -17
