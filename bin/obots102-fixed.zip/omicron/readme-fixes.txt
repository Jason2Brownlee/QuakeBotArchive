Some fixes to help Omicron bots work properly in various situations:

* Recapitalized the names of files to fix the progs behavior and the documentation webpage, when running in a case-sensitive filesystem.

* Re-created the "silent" wav files dland2.wav and h2ohit1.wav to have a few (silent) samples in them. Some modern Quake engines wig out and keep printing error messages if a sound file has no samples.

* Moved CONFIG.CFG to mrelusive-config.cfg. Probably you don't want this config to automatically be used, if you have your own config.



Joel Baxter, August 2020
