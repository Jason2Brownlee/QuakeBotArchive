Title      : Squirt Bot
Filename   : squirt12.zip
Version    : 1.2
Date       : 29.10.1999
Author     : Michael 'Squirt' Buettner
Email      : Squirt@gmx.net 
URL	   : http://www.geocities.com/TimesSquare/Hangar/8961/

*******************************************************************
			Quick Start
*******************************************************************

	- Extract the file into a new folder named 'squirt12'
	  in your Quake directory (make sure you use the folder names)
	- Start Quake like this:
		C:\Quake\Quake.exe -game squirt12 -listen 16 
	- Load a nice wide map and press 'b' to spawn some bots
	- If you want to play another mode, type
          helpme in your console.

*******************************************************************
			Features
*******************************************************************

	- gun arena, a great new deathmatch mode
	- deathmatch 4
	- lavaman
	- last man standing
	- better swimming AI
	- visible weapons !
	- better enemy selection
	- better weapon selection
	- female bots
	- better naming system
	- bots will now learn the map from player
	- bots won't strafe into lava
	- added teamplay support, bots can follow you
	- option to auto-adjust the skill
	- different skill levels (0 - 3) 
		(change the skill before spawning a bot)
	- bot decides when to attack and when to flee
	- intelligent rocket aiming
	- smoother velocity movement
	- good jumping AI, will not jump into lava
	- bot can use buttons and doors
	- bot will pick up items while in combat
	- good roaming AI
	- bots will talk
	- bots come up on the scoreboard
	- bots can use all special items
	- bot will not suicide with the rocket launcher
	- more realistic aiming
	- corpses will stay like in real deathmatch	
	- impulse to see the frags for each team

*******************************************************************
			Hotkeys
*******************************************************************

	key	function	
	-------------------
	b	spawn a bot	(On your team in teamplay)
	n	spawn a bot on bot-team 
	q	print scores	(You only need this in teamplay)
	s	toggle auto-adjusting skill
	f	tell all visible teammates to follow you
	r	tell all teammates to continue roaming
	g	start gun arena competition

	type 'helpme' to see all hotkeys

*******************************************************************
			Deathmatch modes
*******************************************************************
	To start any of the following modes, set deathmatch
	to one of the following values, and restart.

	deathmatch	mode
	--------------------
	1		normal deathmatch
	4		Deathmatch 4
	5		Last man standing
	8		Lavaman
	10		Gun Arena

*******************************************************************
			Gun Arena
*******************************************************************

	This is an arena mode where you have to buy your weapons.
	You can play this mode on any deathmatch map.
	(But you better should choose a small one)
	To start a competition, there have to be at least 3 players
	(bots included). So, if you play as the only 'human' player,
	you will have to spawn 2 bots.
	Then press 'G' to start a competition.
	Every player(and bot) can walk around as an observer,
	while two guys are fighting.
	Observers have white pants and shirts, and can not get hit.
	They are blocking, like a normal player, but the will not
	block grenades or rockets.
	After one of the two opponents is killed, the looser gets 1
	frags and is respawned as an observer. The winner will 
	get two frags and full health.
	Then one player will be selected and respawned as a new 
	challenger.
	While you are an observer, you can buy ammo and weapons.
	You will have a menu in the middle of the screen, that
	shows you the price for each weapon.
	If you have enough frags, just press the number of
	the weapon you want to purchase, and you'll get it.
	If you already have a weapon, you can buy ammo for it.
	Just press the number of a weapon you already have,
	and you'll get a specific amount of ammo for 1 frag.
	If you die or if you are respawned, your weapons
	and ammo stay always the same.

*******************************************************************
			Lavaman ?
*******************************************************************

	This is similar to CTC or Holywars .
	At the beginning a lavaball is spawned .
	The player who get's that ball will have to
	fight against against all .
	He also gets Quad Damage forever to have
	a chance against all the players
	If you haven't got the ball you will get:
		-1 frag if you kill a player
		+5 frags if you kill the lavaman
	If you are the lavaman :
		+1 frag for every player you kill

	Look at the demo to see how to play this mode
	(It should start automatically)

*******************************************************************
			Credits
*******************************************************************
	- Coffee for the tutor bot and his tutorials
		www.planetquake.com/minion
	- Quest for the gun arena idea
	- Jesse Walker for some nice ideas and suggestions
	- FrikaC for his Botsay() code
		www.mdqnet.net/dept187
	- Koolio
		www.botepidemic.com/koolio
	- idsoftware for making this high-adjustable game

*******************************************************************
			Copyrights
*******************************************************************
	(C) Copyright 1999, Michael 'Squirt' Buettner. All rights
	reserved. This MOD may be distributed only if
	unchanged and for free.