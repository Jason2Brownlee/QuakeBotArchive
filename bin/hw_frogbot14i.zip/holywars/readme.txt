Title      : Holy Wars Frogbot Edition
Filename   : hw_frogbot14h.zip
Version    : 1.4i Frogbot Edition
Date       : Jan 28, 2001
Authors    : Gerard "numb" Ryan, Paolo "Nusco" Perrotta, Robert "Frog" Field
Email      : numb@macquakeinfinity.com // nusco@planetquake.com // frog@powerup.com.au
WWW page   : http://www.planetquake.com/holywars/
*OR*       : http://numb.macquakeinfinity.com
Credits    : Look near the end of this file.

Type of Mod
-----------  
Quake C  : yes
Sound    : yes 
MDL      : yes 
 
Format of QuakeC
----------------
unified diff    : no
context diff    : no
.qc files       : wh00p!
qwprogs.dat     : yep
progs.dat       : uh-huh!


RECENT CHANGES
--------------

> Water support!
> Included teamplay in the new enemy code.
> - Now teamplay works properly. Defend your team's Saint!


#0. INTRO
    -----

Take it easy, you don't need to read all this stuff. Give a quick glance at the #1 
and #2 sections, call some friends, calmly launch a server on your local network 
and GET DOWN LIKE A SEX MACHINE. 



#1. THE GAME
    --------


1.1. What is Holy Wars
     -----------------

Holy Wars is a deathmatch/teamplay mod for a minimum of 3 players. It's very simple 
to install, learn and use, although it provides a completely different kind of 
deathmatch. Holy Wars can be a refreshing diversion after some hours of CTF, or 
TF, or <insert your favourite heavyweigth mod here>. 

This mod is strongly oriented towards mayhem and carnage, rather than subtle 
strategy and tactical reasoning. Who needs strategy, btw? GORE! WE WANT MORE GORE! 

Holy Wars includes some custom sounds'n'stuff, but these are not central to the 
game and can be left out if desired. That is, it can act indifferently as a server 
or client-side mod. 

Any comments will be very welcome. 



1.2. The rules
     ---------

A Holy Wars level contains a luminous, *blue-sparkling entity called the Halo.
If a player gets the Halo, she'll become a Saint and receive some armour, health
and weapons. The Halo will follow the Saint around. The sparks of the Halo will 
become golden to indicate that the Halo cannot be picked up anymore, until the 
current owner dies. New to the Frogbot Edition: The halo will remain invisible 
when it's owner is holding the Ring of Shadows.

Normally, players can frag each other happily, but won't score frags for doing 
so. The Saint is the only player in the game who scores frags by killing other 
"normal" players. The players should avoid killing each other and concentrate on 
killing the Saint, their common enemy. 

If a player kills the Saint, the Halo will fall to the ground for the sinners to
skirmish over. If, after 30 seconds, the halo is not retrieved, it will transport
itself back to its starting position. 

The idea is that everybody must try to kill the Saint and steal the Halo. In 
deathmatch, the game is always a furious "The Saint vs. The Rest of the World". 
In teamplay games, the Saint's team is should defend him from the other team. 
If a fallen Halo is unreachable because it fell into lava or in some other 
unhealthy place, you'd better hurry to the base to be there when it reappers. 

That's all. The result will hopefully be total carnage. 

*NOTE: QuakeWorld has no particle effect, the halo glows purple-- without sparklies.  


1.3. Score system
     ------------

If you're a normal player: 

 0  points for killing another player; 
 3  points for killing the Saint; 
 2  points for getting the Halo and becoming the Saint. 

If you're the Saint: 

 1 point per frag. Watch your score grow! 

When a player is sanctified, he/she will receive an amount of armour and 
health proportional to the number of enemies into the game (minus the number 
of friends if teamplay is on). A full inventory of weapons and ammo will also 
be awarded to the Sanctified One.

At the end of a game, statistics for every player will be printed on the console. 
You can scroll the text using the PageUp and PageDown keys. These statistics have 
proven able to break long-lasting friendships.




#2. INSTALLATION AND BASIC USE
    --------------------------


2.1. Installation
     ------------

You must have the registered version of Quake to install Holy Wars. To install 
the patch, just make a HOLYWARS directory under your QUAKE directory and unzip 
the hw_frogbot13.zip file in it (remember to keep all subdirectories).

Start Quake by typing: "quake -listen 16 -zone 1024 -game holywars +maxplayers x" 
where 'x' is the number of players allowed on the server. You may also include
any other useful parameters, such as map, teamplay, deathmatch preferences, etc.



2.2. Maps
     ----

Holy Wars Frogbot Edition includes three maps from Adriano "Escher" Lorenzini (all 
of them were released as "normal deathmatch" levels in the past). The maps are directly 
supported by the mod's code - this means that you can play these maps in Holy Wars 
simply by launching them.

Here are them:

HOLY1 (De Bello Quakero) - The most strikingly beautiful Quake1 DM map around. Period. 
HOLY2 (UltraViolence)    - Incredibly fast and funny, higher-than-professional-quality map. 
HOLY3 (The Messy Base)   - Not messy at all. My favourite DM map ever. 

*HolyWars Frogbot has waypoints for all.

To launch a map, just use the command MAP on the console. For example, if you want to 
play Razzi Amari, type: 

  MAP HOLY4

All of id's original Quake maps are also directly supported - just start any Quake map and 
play. See sections #3.5 and #3.6 for information on using other maps in HW. 

Please note: If you use any non-standard Quake map (included the HOLYx maps), 
Holy Wars won't work as a server-side mod anymore - the maps will have to be copied 
on the clients as well as the server. If a client doesn't find the map, it will refuse 
to connect.



#3. ADVANCED USE
    ------------


3.1. Holy Wars environment settings
     ------------------------------

The settings of Holy Wars are stored into the 'samelevel' console variable. 
The 'samelevel' variable has been used as a set of flags. To activate 
the desired options, take note of each option number, add all the numbers 
together and assign the resulting value to samelevel (an example follows the 
list of options). This must be done *before* launching a map, or it might 
not work as desired.

Here are the possible options:

 Option      | Option number |     Use
---------------------------------------------------------------------------------
HOLYWARS     |     131072    | DEFAULT must be active to enable holywars gammode
---------------------------------------------------------------------------------
 LAG         |     262144    | When this option is on, the Halo moves smoothly,
             |               | with a nice "inertia" effect, following its
             |               | owner around and emitting colourful particles.
             |               | This nice animation comes at the
             |               | price of a noticeable net lag. If you're
             |               | playing on the Internet, you'd better keep this
             |               | option off and be happy with faster animation.
             |               | 
             |               | The default is ON.
             |               | The values are _switched_ for QW. The default is OFF
---------------------------------------------------------------------------------
 CLIENT-SIDE |     524288    | When this option is on, the client-side files (the
             |               | new sounds and models) are used. This is nice,
             |               | but it also prevents a player from entering a
             |               | game if he doesn't have Holy Wars installed on
             |               | his system. Turn this option OFF if you're setting
             |               | up an Internet server, or if you couldn't install 
             |               | HW on each machine on a LAN for some reason. This
             |               | way, everyone can play HW without installing any
             |               | file on his own computer.
             |               | This option is ON by default.
             |               |
---------------------------------------------------------------------------------

An example: let's say we want to enable "LAG" and "CLIENT-SIDE" (this is the typical 
Internet server setting). By adding together 262144 (for LAG) and 524288 (for CLIENT-SIDE) 
we arrive at 786432, which is the new value for samelevel. Just type: 

samelevel 786432

on the console, *before* launching a map.

*** see holywars.cfg for a better example.

The default value for samelevel (set into the HOLYWARS.CFG file) is 'samelevel 655360', 
meaning that all the options are on (for normal, netquake). 



3.2. Adding skins
     ------------

Holy Wars Frogbot Edition supports skins through the Frogbot UI. See the Frogbot readme 
for more info on this feature.


3.3. Holy Wars impulses
     ------------------

Here is the list of new impulses (none of which is needed for playing - this means 
that you can safely ignore these if you're not curious), and the aliases to which 
the new impulses are bound. You can use these easy mnemonic aliases on the console 
instead of the impulses. To change the aliases, edit the HOLYWARS.CFG file. 

IMPULSE 80        Gives the position of the player on the console. Used for 
                  map-modifying purposes. See the "Adapting existing maps" 
                  section. Aliased to POS. 

IMPULSE 81        Gives the environment settings for Holy Wars on the console. 
                  Aliased to SERVER. 
                  
IMPULSE 82        Gives basic instructions for Holy Wars on the console. 
                  Aliased to INSTRUCTIONS. 

IMPULSE 83        Gives the statistics during the game (the "Halo possession" 
                  statistic is only updated when a Saint dies). Aliased to 
                  STATS. 



3.4. Enhanced Bot Features
     ---------------------
     
This is the official Holy Wars merge with Robert "Frog" Field's quakec "opus," the 
Frogbot. The bot is a revolutionary step forward in both movement and ai designs. 
PLEASE NOTE: HOLY WARS FROGBOT is an UNSUPPORTED PROJECT. The frogbot author will 
not answer any questions regarding the bot in other modifications. If you have any 
questions, direct them to the email address above. 

The bots will autoload into levels they are programmed to play (whose maps are 
waypointed) IF the cvar 'scratch1' is enabled. For an example of scratch1, open 
up the autoexec.cfg file in the holywars directory and see the line:

scratch1    X.Y

'X', in this example, is the number of bots you would like autoloaded, and 'Y' is 
timed interval (in minutes) that you want until a bot connects/disconnects. So, the
scratch1 value 3.25 would spawn 3 bots, of which 1 would disconnect after 2 minutes
and 30 seconds. 

To maually spawn a bot, simply type 'addbot' at the console. 

  Frogbot v0.13 bug fixes and enhancements:
  
  - NaN velocity fix
  - Bot goal fixes
  - Player pitch angles
  - Platform enhancement
  - Minimal water support
  - Dm6 door re-enabled
  - Reduced "NULL function" fatalities
  - Conditional arguments for "oldsolid" hack
  - Bots will pause while chatting, just 
    like real players. turn off chatting with 
    the 'nochat' command
  - Bots will auto-load and disconnect, 
    reconnecting at 'will'
  - Bots have a 'ping' time in QuakeWorld
  - QW Skill setting approximates 'ping' 

*** Please read the original Frogbot readme if you're unfamiliar with starting a 
    game with the frogbot. To begin a game of holywars, start with the normal command 
    line parameters for starting a frogbot server, drop the console, and type "holywars". 
    This will enable holywars mode for the next level. 

    QUICKSTART: Start quake with this in the command line:
        
    C:\Quake\Quake.exe -listen 16 -zone 2048 -game holywars +maxplayers 4 + map holy1
    
    This, of course, assumes that you're running win9x, and your Quake dir is at the
    uppermost level of your C drive. And of course you're using normal Quake.exe =)
    
    *MacIntosh Users* use the same command line parameters above, except delete
    the paths! 
    
    -listen 16 -zone 2048 -game holywars +maxplayers 4 + map holy1
                        
  * See autoexec.cfg, holywars.cfg and the frogbot readme files for the full list of 
    options, and the default holywars settings.
    
Map support for the frogbot is available at:

http://www.botepidemic.com/fmods/maps.htm


Bots have ping time and packetloss in QuakeWorld. You can change their ping/pl by 
addding the line:

localinfo botping modem

to your server.cfg (if you're running a qw server), or, you can change bot ping
remotely, by using rcon. There's three possible values for ping/pl: LAN, modem, 
or digital. OFF is the default. These values are purely cosmetic, however, 
I've added some code which supports skill and response time values. This code 
will approximate "ping" and "packetloss" conditions. To enable it in QuakeWorld,
uncomment the "#define SKILL" line in settings.h and recompile the source.



3.5. Using other maps
     ----------------

Holy Wars also directly supports HIPDM1, the Hipnotic deathmatch map from Mission 
Pack #1. Holy Wars will automatically take away all the new Hipnotic weapons and 
powerups from the map and substitute them with mundane Quake stuff (I'm 
sorry about this, but keeping the new stuff in would require a completely 
different version of the progs.dat just on purpose). To use this map, 
you'll need a pack processor (like Xpak, which you can find at 
ftp://ftp.cdrom.com/pub/quake/utils/bsp_pak_tools/xpak041.zip) to extract 
a it from Hipnotic's *.pak file (and copy it into HOLYWARS/MAPS). Alternatively,
this version of Holywars has a dynamic halo spawning feature which will "place"
a halo inside an unsupported map.



3.6. Adapting existing maps
     ----------------------

It's fairly easy to adapt existing maps for use with Holy Wars. 
To do this you must be able to use a map entity extractor (like Mapent), 
and QBSP (with the "-onlyents" switch) to put the entities back in. Here 
are the addresses where you can find the files: 

ftp://ftp.cdrom.com/pub/quake/utils/level_edit/bsp_builders/mapent.zip 
ftp://ftp.cdrom.com/pub/quake/utils/level_edit/bsp_builders/qbsp_dos.zip 

To adapt a map, you must add a new entity to it: 

{ 
"classname" "item_holywars_halo" 
"origin" "x y z" 
} 

Where x, y and z are the three coordinates of the Halo's base. To find a good 
position for the Halo, you can launch the map  and use "IMPULSE 80" - this will 
print the current position of the player on the console. Use "FLY" or "NOCLIP" 
to move around freely and find a good spot. When you've patched the map, put it 
under QUAKE/HOLYWARS/MAPS. Each client should have a copy of the map, but the 
copies on the clients don't need to be patched. However, in order for bots to play
new maps, they must be provided with markers. Visit http://www.botepidemic.com/fmods
for new map files, and directions for compiling them into the code. 

The Holy Wars Frogbot also supports dynamic halo spawning. If there isn't a 
precompiled spot to spawn the halo, the code will attempt to load the halo into
one of 'info_player_deathmatch' spots.



#4. DISTRIBUTION NOTES
    ------------------

4.1. Client-side stuff
     -----------------

I added the client-side files in a hurry. I know that the sound of the Saint shooting 
is bad - it's just a modification of one of Quake's existing sounds. Besides, I didn't 
find any player skins that were freely usable, good, and on topic, so I didn't include 
player skins at all. And the halo MDL is just something that I threw together in 3 
minutes. This means that the client files are not "professional" at all, apart from 
a couple of sounds and the head gib skin. This will change with the next release 
(Holy Wars 2.0 for Quake 2). 


4.1. Source availability and technical notes
     ---------------------------------------

You can easily modify the teamplay and deathmatch default values by editing 
the holywars.cfg file. This configuration file is auto-started when you 
launch Quake + Holy Wars. In order to accomplish changes for the frogbot and maps,
or any other source code changes, you must recompile the source with Mr. Elusive's
Meqcc. I've included the most recent release to date, version 1.4 (in the utils
directory). You should execute Meqcc from the command line, running it from within 
the 'src' directory. This will generate a file named progs.dat in your 'holywars' 
directory.



4.2. Copyright and Distribution Permissions
     --------------------------------------

The Frogbot is copyright Robert Field, 1998. 
http://www.telefragged.com/metro/

Quake is copyright by id Software. 

The "universal head giblet" is copyrighted by Dan Bickell (danbickell@loop.com). 
Adriano Lorenzini and Walter Sammarchi are copyrighted by themselves. 

The rest of this patch is copyrighted by:

Paolo "Nusco" Perrotta 
(nusco@planetquake.com) 
and 
Gerard "numb" Ryan 
(numberino@bigfoot.com)

You can do what you want with this patch, excluded: 

1) strip out this copyright notice from it; 
2) make money from it in any form without asking for the author's permission 
first. 

"In any form" means: "No, you cannot pick up this stuff and put it on a 
commercial CD. If you ask me, I could give you the permission to do so - if 
you don't have the permission, you can't". 

Any non-commercial use is allowed and welcome. You can redistribute this 
patch at your own leisure. Letting me know of any use of this patch 
(appearances on web pages or in compilations, modifications, etc.) would 
be polite, but is not required. If you use any part of the HW source inside 
your own project, then you must make available the source of your project to 
others.

The strange language that I used to write this document is my own version 
of English, and it's copyright of myself. 

I don't make any implicit or explicit guarantees about this patch: you're 
using it at your own risk. I bet it won't explode, BTW. 



4.3. Availability
     ------------

The official Holy Wars web page (including news and updated versions) is at: 

	http://www.planetquake.com/holywars/ 



4.4. Known bugs:
     -----------

They're not bugs: they're miracles. 

The only miracle that I know of is that the Halo can fly out of the level after 
the Saint dies. This happens rarely, and doesn't ruin the game at all - and BTW, 
it looks like it's a limit of the game engine, not my mod. The Halo will reappear 
at the base after the usual 30 seconds. 



4.5. Credits:
     --------

Very many thanks to Robert Field for releasing his code base while still "in-progress."
Adriano "Escher" Lorenzini (a.lorenzini@iol.it) makes maps that kick ass. 
Walter Sammarchi (pec1063@iperbole.bologna.it) did the sounds. 
Paolo "Earthbreaker" Petrini supported this mod on Quake Italia 
(http://quake.shiny.it/).
John Spickes (jspickes@eng.umd.edu) for The Complete Enhanced Teamplay patch, 
which is included in HW. 
Dan Bickell (danbickell@loop.com) made the universal head giblet skin. You're 
leet, man. I mean it. Those skins of yours are the very best around. 
id and Hipnotic did you-know-what. 
And to all the friends, betatesters and people helping, commenting and giving 
suggestions: 

                                Thanks, guys. 



4.6. Version History:
     ----------------

* 1.4i Frogbot Edition (1/28/2001) 

-> Water support!
-> Included teamplay in the new enemy code
   - Now teamplay works properly. Defend your team's Saint!
   - DOH!

* 1.4h Frogbot Edition (1/05/2001) 

-> Fixed enemy heuristics for sinner - sinner attacks!

     It's now a toggled feature. Works like this:

     DEFAULT: a free-for-all skirmish occurs until someone
              gets the halo - then it's saint vs. sinners only.

     TOGGLE:  by typing "noplay" at the console, bots will ONLY
              kill saint. If no saint, then no attack. type "noplay
              again to resume default mode.

* 1.4f Frogbot Edition (10/25/2000) 

-> Bots will ONLY attack the saint
-> ripped out evasive saint code

* 1.4 Frogbot Edition (3/13/2000) 

Minor tweaks and bug-fixes
Added "bot helping" feature for teamplay
 
* 1.3c Frogbot Edition (11/30/99)  

-> Bot Saints use evasive strategies when pursued
-> Improved chat functions
-> Miscellaneous bug-fixes
    
* 1.3 Frogbot Edition (11/21/99) 

-> HolyWars Frogbot brought up to 0.13 source
-> Enhanced Holy Wars features
-> Enhanced server features
-> Enhanced Frogbot features
-> Source code included. 

* 1.5 Special Edition (26/01/98) 

-> 5 maps from Escher included!
-> Source code included. 


* 1.4 (11/04/97) 

-> All the stuff from 1.3internal that the world didn't have a chance to see before. 
-> Built-in support for some new maps. 


* 1.3internal (07/18/97 - never distributed) 

-> Client-side support: new sounds and models. 
-> Support for skins. 
-> No-lag option for Internet servers. 
-> Minor stuff. 


* 1.2 (06/04/1997) 

-> Statistics at the end of the game and with IMPULSE 60. 
-> Support for all of id's maps. 
-> The Halo is now teleported with the owner, to avoid the previous 
   impossibility to recognize the Saint soon after a teleportation. 
-> The Halo shines blue particles when it's free, to improve visibility 
   (exp. on GLQuake). 
-> Deleted unnecessary messages ("You have taken some ammo" and other such 
   useless stuff). 
-> "What to do" message at respawning. 
-> Random respawn spots. 
-> Optimized Halo movement function (now almost twice as fast, useful on 
   slow systems). 
-> Other very minor things and bug fixes. 


* 1.01 (05/19/1997) 

-> Corrected a bug that generated "Unknown entities" when starting certain maps. 


* 1.0 (05/15/1997) 

-> First publicly distributed version with a lot of changes. 


* 1.0b (02/22/1997, unreleased) 

-> First semi-working version for betatesters. 

