#include <conio.h>
#include <stdio.h>
#include <math.h>
#include <process.h>
#include <ctype.h>
#include <float.h>

#include "QuakeBot.h"
#include "PlayerObj.h"
#include "ServerObj.h"
#include "NavObj.h"

char VERSION[] = "V.75";

const unsigned char AI_MODE_IDLE = 0;
const unsigned char AI_MODE_TARGET = 1;
const unsigned char AI_MODE_ATTACK = 2;
const unsigned char AI_MODE_MAP = 3;
const unsigned char AI_MODE_RETRACE = 4;
const unsigned char AI_MODE_DEAD = 5;
const unsigned char AI_MODE_EVADE = 6;
const unsigned char AI_MODE_STALLED = 7;
const unsigned char AI_MODE_RESPAWNED = 8;
const unsigned char AI_MODE_MOVING = 9;
const unsigned char AI_MODE_REACHED = 10;

const unsigned char MAX_STRAFECOUNT = 20;



int AttackPlayer(ServerObj *QuakeServer, int TargetPlayer) {

	float Distance;

	if(TargetPlayer == -1) 
		return 0;
	if(QuakeServer->Player[TargetPlayer]->Dead()) 
		return 0;
	
	// Aim at Player
	Distance = QuakeServer->Player[QuakeServer->BotID]->Aim(QuakeServer->Player[TargetPlayer]);

	if(Distance <= (float)300.0 && Distance > (float) 10.0){
		QuakeServer->Player[QuakeServer->BotID]->SelectSafeWeapon(); 
		QuakeServer->Player[QuakeServer->BotID]->CommandActions |= KEY_ACTION_FIRE;
		QuakeServer->Player[QuakeServer->BotID]->CommandInlineSpeed = 0x1FF;
		return 1;
	} else if (Distance <= (float)10.0) {
		QuakeServer->Player[QuakeServer->BotID]->CommandImpulse = SELECT_WEAPON_AXE;
		QuakeServer->Player[QuakeServer->BotID]->CommandActions |= KEY_ACTION_FIRE;
		QuakeServer->Player[QuakeServer->BotID]->CommandInlineSpeed = 0;
		return 1;
	}
	return 0;


}


void Chatter(ServerObj *QuakeServer, int Count) {

	char Buffer[50];
	if(Count == 50) {
		sprintf(Buffer, "QuakeBot C/S(c) %s", VERSION);
		QuakeServer->SendBroadcastMessage(Buffer);
	}

	if(Count == 100)
		QuakeServer->SendBroadcastMessage("jfrorie@uncc.edu");

}

void DisplayMode(int Mode) {

	switch(Mode) {
	case AI_MODE_IDLE:
		Console.DisplayString("Bot is IDLE\n");
		break;
	case AI_MODE_ATTACK:
		Console.DisplayString("Bot is ATTACKING\n");
		break;
	case AI_MODE_TARGET:
		Console.DisplayString("Bot is TARGETING\n");
		break;
	case AI_MODE_EVADE:
		Console.DisplayString("Bot is EVADING\n");
		break;
	case AI_MODE_MAP:
		Console.DisplayString("Bot is MAPPING\n");
		break;
	case AI_MODE_RETRACE:
		Console.DisplayString("Bot is RETRACING\n");
		break;
	case AI_MODE_DEAD:
		Console.DisplayString("Bot is DEAD\n");
		break;
	case AI_MODE_STALLED:
		Console.DisplayString("Bot is STALLED\n");
		break;
	case AI_MODE_MOVING:
		Console.DisplayString("Bot is MOVING\n");
		break;
	case AI_MODE_REACHED:
		Console.DisplayString("Bot has found WAYPOINT\n");
		break;
	case AI_MODE_RESPAWNED:
		Console.DisplayString("Bot has RESPAWNED\n");
		break;
	default:
		Console.DisplayString("Bot is SCREWED UP!!!\n");
	}
}

//*********************************
//
// For right now, this is where the AI goes
//
//*********************************

void RuntimeThread(void *Dummy) {

	int i, Dead = 0, PacketLength, TargetPlayer, MinDistance;
	int OldFrame = 0, Health, OldWeaponCount=0, RespawnMode = 0, OldHealth = 0;
	int AIMode, OldAIMode, Count, StrafeLeft = 0;
	int Traveling = 0, StartUp = 0;
	int StrafeCount = 0;

	//float OldX, OldY, OldZ;

	GameCoord BotCoord, StartCoord, EndCoord;

//	EntityObj *TargetEntity;

	NavObj Navigate;

	ServerObj *QuakeServer;

	PlayerObj *Bot;
	EntityObj *BotEntity;

	QuakeServer = (ServerObj *)Dummy;

	Navigate.SetServer(QuakeServer);

	timeval ShortTime;

	ShortTime.tv_sec = 0;
	ShortTime.tv_usec = 1000;

	AIMode = AI_MODE_IDLE;
	OldAIMode = -1;
	Count = 0;


	while(QuakeServer->GameMode != 5) {
		

//		for(i = 0; i < QuakeServer->MaxPlayers; i++)	// Mark them all out of view before
//			QuakeServer->Player[i]->Dormant = 1;		// decode
 		
		// Get some data
		if((PacketLength = QuakeServer->ServerPacket.GetMessage()) > 0 )
			QuakeServer->DecodePacket();

		// Update who I am for this pass
		Bot = QuakeServer->Player[QuakeServer->BotID];
		BotEntity = (*Bot->PlayerEntity);
		Health = Bot->Health;
		BotCoord.X = BotEntity->Location[0];
		BotCoord.Y = BotEntity->Location[1];
		BotCoord.Z = BotEntity->Location[2];
		BotCoord.Distance = FLT_MAX;

		// Reset Everything
		MinDistance = INT_MAX;
		Bot->CommandActions = KEY_ACTION_NONE;
		Bot->CommandImpulse = 0x0;
		Count++;

		// Maybe send a message or two......
//		Chatter(QuakeServer, Count);

		// Find nearest Player
		TargetPlayer = QuakeServer->NearestPlayerByVector();
		
		if(Health <= 0){  // I am dead, deal with it	
			AIMode = AI_MODE_DEAD;
			QuakeServer->Respawn();
			Navigate.Reset();
			Bot->CommandLateralSpeed = 0x0;
		} else if(OldHealth > Health) { // I took a hit
			if(StrafeLeft) {
				Bot->CommandLateralSpeed = 0x1ff;
				Console.DisplayString("Left\n");
				if(StrafeCount++ >= MAX_STRAFECOUNT){
					StrafeCount = 0;
					StrafeLeft = 0;
				}
			} else {
				Bot->CommandLateralSpeed = -0x1ff;
				Console.DisplayString("Right\n");
				if(StrafeCount++ >= MAX_STRAFECOUNT){
					StrafeCount = 0;
					StrafeLeft = 1;
				}
			}
			AIMode = AI_MODE_EVADE;
		} else if((OldHealth <= 0 && Health > 0) || StartUp) { // I respawned			
			AIMode = AI_MODE_RESPAWNED;
			if(BotCoord.X == 0 && BotCoord.Y == 0 && BotCoord.Z == 0){
				StartUp = 1;
			} else {
				Navigate.InsertEntryPoint(BotCoord); 
				StartUp = 0;
			}

		} else if(AttackPlayer(QuakeServer, TargetPlayer)) {
			Navigate.Reset();
			AIMode = AI_MODE_ATTACK;
		} else if(Navigate.Mapping()) {
			Bot->CommandLateralSpeed = 0x0;
			AIMode = AI_MODE_MAP;
		} else {
			Bot->CommandLateralSpeed = 0x0;
			AIMode = AI_MODE_MOVING;
			Navigate.RandomMove();
		}

//#ifdef DEBUG
		// If health has changed.
		if(OldHealth != Health) {
			OldHealth = Health;
	//		Console.DisplayString("Health : %d\n", QuakeServer->Player[QuakeServer->BotID]->Health);
		
		}

		if(OldAIMode != AIMode) {
			DisplayMode(AIMode);
			OldAIMode = AIMode;
		}

//#endif

		// Check for extra data
		if(QuakeServer->ServerPacket.Socket.IsData(ShortTime)) {  // Quick check for more data
			QuakeServer->ServerPacket.GetMessage();
			QuakeServer->DecodePacket();
		}

		//  Send some Data		
		QuakeServer->SendRuntimePacket(QuakeServer->Player[QuakeServer->BotID]);

	}


}