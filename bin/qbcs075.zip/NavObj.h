#ifndef NAVOBJ_H
#define NAVOBJ_H

#include <float.h>

#include "WaypointObj.h"
#include "ConsoleObj.h"
#include "QuakeBot.h"

extern ConsoleObj Console;

const int MAX_DEATHMATCH_STARTS = 8; // Max number of number of unique places
									// you can start in a DM level
class NavObj {

private:


	WaypointObj *GraphEntry[MAX_DEATHMATCH_STARTS]; // These are pointers to
												// each of the deathmatch starts
	ServerObj *QuakeServer;

	float DestinationX, DestinationY, DestinationZ, PreviousDistance;
	int Traveling;
	PlayerObj *Bot;
	EntityObj *BotEntity;
	GameCoord BotCoord, StartCoord, EndCoord;

public:

	WaypointObj *CurrentWaypoint;
	void InsertWaypoint(GameCoord);
	void SetServer(ServerObj *);
	int Mapping();
	void RandomMove();
	int WaypointSync(GameCoord);
	void InsertEntryPoint(GameCoord);
	WaypointObj *FindWaypoint(WaypointObj *, float, float, float);
	int VacantConnection();
	void AttachWaypoint();
	void SetDestination(GameCoord);
	int AtDestination(GameCoord);
	void InsertBlockedWaypoint(GameCoord);
	int Stalled(GameCoord);
	float DistanceFromDestination(float, float, float);
	void DisplayGraph();
	void DisplayWaypoint(WaypointObj *);
	int IsAttached(GameCoord);


	NavObj() {
		int i;
		Console.DisplayString("Instantiating Graph\n");
		for(i = 0; i < MAX_DEATHMATCH_STARTS; i++)
			GraphEntry[i] = NULL;
		CurrentWaypoint = GraphEntry[0];
		DestinationX = (float) 0.0;
		DestinationY = (float) 0.0;
		DestinationZ = (float) 0.0;
		PreviousDistance = FLT_MAX;
		Traveling = 0;
		Bot = NULL;
		BotEntity = NULL;
		EndCoord.Distance = (float) MAX_RANGE;
	}

	void Reset() {

		EndCoord.Distance = (float) MAX_RANGE;
		Traveling = 0;
	}

};

#endif

