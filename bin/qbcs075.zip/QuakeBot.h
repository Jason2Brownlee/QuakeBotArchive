#ifndef QUAKEBOT_H
#define QUAKEBOT_H

struct CoordStruct{
	float X, Y, Z, Distance;
	int Index;
};

typedef struct CoordStruct GameCoord;

#endif

