#ifndef CONSOLEOBJ_H
#define CONSOLEOBJ_H

#include "ServerObj.h"
#include "AliasObj.h"

#ifndef __unix__
 #include <conio.h>
 #include <stdarg.h>
#else
 #include <varargs.h>
#endif

#include "RuleObj.h"

class ServerObj;

class ConsoleObj {

private:

	char OutputBuffer[0xFF];
	ServerObj *QuakeServer;

#ifndef __unix__
	HANDLE ConsoleHandle;
	CONSOLE_SCREEN_BUFFER_INFO Csbi;
	COORD CursorPosition, PromptPosition;
#endif
	
	void PlayerStatus(PlayerObj *);
	void DisplayAliases();
	char *StringToken();
	char *LineToken();

	int IntToken();
	void GameStatus();
	void NetworkStatus();
	void EntityInformation(EntityObj *);
	void DisplayDefinedEntities();
	void DisplayWeapon(PlayerObj *);
	void DisplayItems(PlayerObj *);
	void DisplayPlayerStatus(PlayerObj *);
	void DecodeColors(int);
	void InsertAlias(char *Variable, char *Value); 

public:

	int ParseString(char *);
	void DisplayString(char *, ...);             
	void SetServer(ServerObj *);
	void GetString(char *);
	AliasObj Alias;

	ConsoleObj() {

#ifndef __unix__
		ConsoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
//		hinst = GetModuleHandle (NULL);
//		hwnd = GetFocus();
		SetConsoleTitle("QuakeBot C/S");
#endif
		ClearScreen();
	}
	
	void ClearScreen() {
#ifndef __unix__
		DWORD ConsoleSize, Written;

		CursorPosition.X = 0;
		CursorPosition.Y = 0;
		GetConsoleScreenBufferInfo(ConsoleHandle, &Csbi);
		ConsoleSize = Csbi.dwSize.X * Csbi.dwSize.Y;
 
		/* fill the entire screen with blanks */
 
		FillConsoleOutputCharacter( ConsoleHandle, (TCHAR) ' ', 
			ConsoleSize, CursorPosition, &Written );

		CursorPosition.X = 0;
		CursorPosition.Y = 22;
		SetConsoleCursorPosition( ConsoleHandle, CursorPosition);

#endif

	}
};


#endif

