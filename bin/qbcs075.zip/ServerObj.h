#ifndef SERVEROBJ_H
#define SERVEROBJ_H

#include "SocketObj.h"
#include "PacketObj.h"
#include "EntityObj.h"
#include "PlayerObj.h"
#include "ConsoleObj.h"
#include "QuakeBot.h"

#include <limits.h>
#include <float.h>
#include <time.h>

//#include "QuakeBot.h"
#include "ConsoleObj.h"

#define QUITSTRING "No bots"

#define CCREP_ACCEPT 0x81
#define CCREP_REJECT 0x82

#ifdef __unix__
 #define strnicmp strncmp
 #define stricmp strcmp
 #define Sleep sleep
 #define TRUE 1
 #define FALSE 0
#endif

#define COMMAND_QUERY 0x02
#define COMMAND_CONNECT 0x01
#define COMMAND_RULE 0x04


#define MAX_MODELS 255
#define MAX_SOUNDS 255

#define MAX_BASELINE_ENTITIES 450
#define MAX_STATIC_ENTITIES 128
#define GAME_STATE_PRESPAWN 1
#define GAME_STATE_LIGHTING 2
#define GAME_STATE_RENDER 3

//#define DECODE

//extern ConsoleObj Console;

class ServerObj {


private:

	void Logon();

	// ***************************************************
	//
	//  Server Timeout routine. Uses Console instead of printf
	//
	// ***************************************************

	static void ServerTimeoutHandler(void) {

//		Console.DisplayString("Receive timed out!!!!\n");
		printf("Receive timed out!!!!\n");

	}

public:

	PacketObj ServerPacket;
	PlayerObj **Player;
	EntityObj *BaselineEntity[MAX_BASELINE_ENTITIES];
	EntityObj *StaticEntity[MAX_STATIC_ENTITIES];

	// Server Parameters
	char *ServerName; // Name of server
	char *IPString;
	char *MapName;		// Current Map Name
	int NumberOfPlayers, MaxPlayers, MaxClients, Multi, BotID;
	char *BotName;
	long ServerVersion;
	float ServerTimeStamp, ClientTimeStamp;
	char Initialized;
	char *PrecacheModel[255], *PrecacheSound[255];
	int NumModels, NumSounds;
	int StaticEntityCount;
	int GameMode;
	ServerObj(char *, int);
	time_t ClientStartTime;
	int sv_gravity, sv_friction, sv_maxspeed, noexit;
	int teamplay, fraglimit, timelimit;

	float DefaultOrigin[3], DefaultAngle[3];
	int DefaultModelIndex, DefaultFrame, DefaultColorMap, DefaultSkin, DefaultAttackState;
	int EntityIndex;

	// Member Functions
	void DecodePacket();
	void SendGoodbye();
	int QueryServer();
	int GetRules();
	void SendRuntimePacket(PlayerObj *);
	void SendBroadcastMessage(char *);
	void SendCommand(char *);
	int ConnectServer();
	int GameInit();
	void Respawn();
	int WhatIsAt(float, float, float);
	void SendClientParms(), SendBegin(), SendNoOp();
	void SendPrespawn();
	void BombOut(char *);
	int FindMe();
	void FreeEntities(), FreePlayers(), FreePrecache(), FreeMisc();
	int NearestPlayerByVector();
	int NearestEntityByVector(float, float, float);
	GameCoord *NextEntity(GameCoord *);

	~ServerObj() {
		FreePlayers();
		FreeEntities();
		FreePrecache();
		SendGoodbye();
	}

};


#endif