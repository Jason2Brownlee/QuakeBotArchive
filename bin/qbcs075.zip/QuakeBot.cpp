//*************************************************************************
//
//			QuakeBot C/S (c)
//
//			by: Jim Rorie, John Simmerman
//			Email: jfrorie@uncc.edu
//
//			You may modify or distribute this code under
//			the following conditions.
//
//			1) This comment text must be included and may not be modified
//
//			2) All derivative works must display the following
//			in their initialization screen:
//
//			"Based on QuakeBot C/S Function Core"
//			or an appropriate variation thereof
//
//			Other than that, Have a ball!!!!!
//
//*************************************************************************


//*************************************************************************
//
//  Unix mods graciously supplied by Joel Jacobson
//
//*************************************************************************

#include <stdio.h>
#include <math.h>

#ifndef __unix__
 #include <conio.h>
 #include <process.h>
#endif


#include <ctype.h>

#include "QuakeBot.h"
#include "ServerObj.h"
#include "ConsoleObj.h"

ConsoleObj Console; 

extern void RuntimeThread(void *);

//#define DEBUG 1
//#define DECODE 1

//#define VERBOSE

// ***********************************************
//
//			arg1 = IP Address of server
//			[arg2] = Bot Name,  Defaults to "QuakeBot"
//
// ***********************************************

int main(int argc, char **argv) {

	char ConsoleBuffer[0xFF]; 
	unsigned long AIThreadID;

	LPDWORD ExitCode;
	
	if(argc < 2) {
		printf("\nusage: Quakebot <IPADDRESS> [<Bot Name>]\n");
		printf("\nIPADDRESS: Address of Quake Server\n");
		printf("RuntimePort: Quake Runtime Port\n");
		exit(-1);
	}

	// This will instantiate object and query server.  Necessary for
	// proper init of internal variables.

	ServerObj QuakeServer(argv[1], 26000);

	if(!QuakeServer.Initialized) {
		Console.DisplayString("Cannot Query Server. Exiting\n");
		exit(1);
	}
	
	Console.SetServer(&QuakeServer);
	
	if(argc < 3)
		QuakeServer.BotName = strdup("QuakeBot");
	else
		QuakeServer.BotName = strdup(argv[2]);

	// Connect to Quake Server
	if(QuakeServer.GetRules() == 0){
		Console.DisplayString("Error: Gravity is an ODD value, I will not connect!!!\n");
		exit(1);
	} else
		Console.DisplayString("Rules Received.\n");


	if(QuakeServer.ConnectServer() <= 0) {
		Console.DisplayString("Connection Rejected.\n");
		exit(2);
	} else
		Console.DisplayString("Connection Accepted.\n");

	// Perform level initialization
	if(!QuakeServer.GameInit()){
		Console.DisplayString("Cannot Initialize Game. Exiting\n");
		exit(3);		
	}

	Console.DisplayString("Handshake Complete. Going Runtime......\n");

//	Begin async portion

//	SyncFlag = CreateMutex(NULL, FALSE, "SyncFlag");
	AIThreadID = _beginthread(RuntimeThread, 0, &QuakeServer);	

	do { 

		Console.GetString(ConsoleBuffer);

	} while(Console.ParseString(ConsoleBuffer) != -1);

	QuakeServer.GameMode = 5;  // This terminates the thread
	
	Sleep(1000L);
	QuakeServer.SendBroadcastMessage("Terminating");
	QuakeServer.SendGoodbye();

	return 0;
}

