#include "ConsoleObj.h"

// *********************************************
// *
// *  Routine to print on console.  
// *
// *********************************************
void ConsoleObj::DisplayString(char *Data, ...) {

	va_list Marker;

	va_start(Marker, Data);

#ifndef __unix__
	SMALL_RECT Source;
	COORD Dest;
	CHAR_INFO Fill;
	LPDWORD Written;

	Fill.Char.AsciiChar = ' ';
	Fill.Attributes = FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED;

	// get current prompt coords
	GetConsoleScreenBufferInfo(ConsoleHandle, &Csbi);
	PromptPosition.X = Csbi.dwCursorPosition.X;
	PromptPosition.Y = Csbi.dwCursorPosition.Y;

	// Set cursor for output
	SetConsoleCursorPosition( ConsoleHandle, CursorPosition);

	// Display output
	vprintf(Data, Marker);
	
	// get new coords
	GetConsoleScreenBufferInfo(ConsoleHandle, &Csbi);

	// Same em for next time
	CursorPosition.X = Csbi.dwCursorPosition.X;
	CursorPosition.Y = Csbi.dwCursorPosition.Y;

	// if too far, scroll up.
	if(CursorPosition.Y > 23) {

		Source.Left = 0;
		Source.Right = 79;
		Source.Top = 1;
		Source.Bottom = 23;

		Dest.X = 0;
		Dest.Y = 0;

		ScrollConsoleScreenBuffer(ConsoleHandle, &Source, NULL , Dest, &Fill);  

		// Save new coords
		CursorPosition.X = 0;
		CursorPosition.Y = 23;
	}

	//  Establish old coords

	SetConsoleCursorPosition( ConsoleHandle, PromptPosition);
	
#else
	vprintf(Data, Marker);
#endif
}

// *********************************************
// *
// *  Routine to get a line of input from the console.  
// *
// *********************************************

void ConsoleObj::GetString(char *InputBuffer) {
	PromptPosition.X = 0;
	PromptPosition.Y = 24;

	//  Establish old coords

	SetConsoleCursorPosition( ConsoleHandle, PromptPosition);

	printf("->");
	PromptPosition.X = 2;  // Account for shift 

	gets(InputBuffer);
	DisplayString("\n");
}

// *********************************************
// *
// *  Set the CurrentServerObj.  
// *
// *********************************************
void ConsoleObj::SetServer(ServerObj *Server) {
	QuakeServer = Server;
}

// *********************************************
// *
// *  Grabs a string token
// *
// *********************************************

char *ConsoleObj::StringToken() {
	return strtok(NULL, " ");
}

// *********************************************
// *
// *  Grabs rest of line
// *
// *********************************************

char *ConsoleObj::LineToken() {
	return strtok(NULL, "\n\"");
}


// *********************************************
// *
// *  Grabs a int token.  
// *
// *********************************************
int ConsoleObj::IntToken() {
	char *Argument;

	Argument = strtok(NULL, " ");
	if(Argument == NULL)
		return 0;
	else
		return atoi(Argument);
}


//*******************************************
//
//  Displays Game Output to a console window
//
//*******************************************

void ConsoleObj::GameStatus() {

	int i;

	DisplayString("Game Status\n");
	DisplayString("Server : %s, Map: %s\n", QuakeServer->ServerName, QuakeServer->MapName);
	
	DisplayString("Server Time: %f, Client Time: %f\n", QuakeServer->ServerTimeStamp, QuakeServer->ClientTimeStamp);
	DisplayString("\n");
	DisplayString("Name\t\tFrags\tPosition\t\tDormant\tFrame\n");
	for(i=0; i<QuakeServer->MaxPlayers; i++) {
		DisplayString("%10s\t%d\t(%5.0f, %5.0f, %5.0f)\t%d\t%d\n", QuakeServer->Player[i]->Name,
		QuakeServer->Player[i]->Frags, (*QuakeServer->Player[i]->PlayerEntity)->Location[0],
		(*QuakeServer->Player[i]->PlayerEntity)->Location[1],
		(*QuakeServer->Player[i]->PlayerEntity)->Location[2],
		QuakeServer->Player[i]->Dormant, (*QuakeServer->Player[i]->PlayerEntity)->Frame);
	}

}


//*******************************************
//
//  Displays Network Statisitcs to a console window
//
//*******************************************
void ConsoleObj::NetworkStatus() {

	DisplayString("Network Status - %s\n", QuakeServer->IPString);
	DisplayString("Incoming - Reliable: %d, Update: %d, ", 
		QuakeServer->ServerPacket.IncomingPacketSequence[SEQUENCE_FINAL], 
		QuakeServer->ServerPacket.IncomingPacketSequence[SEQUENCE_UPDATE]);

	DisplayString("Acknowledgments: %d, ", QuakeServer->ServerPacket.IncomingPacketSequence[SEQUENCE_ACK]);
	DisplayString("Rejected Packets: %d\n", QuakeServer->ServerPacket.IncomingRejected);
	DisplayString("Outgoing - Reliable: %d, Update: %d, ", 
		QuakeServer->ServerPacket.OutgoingPacketSequence[SEQUENCE_FINAL], 
		QuakeServer->ServerPacket.OutgoingPacketSequence[SEQUENCE_UPDATE]);

	DisplayString("Acknowledgments: %d\n", QuakeServer->ServerPacket.OutgoingPacketSequence[SEQUENCE_ACK]);

}

//*******************************************
//
//  Displays Entity Defaults
//
//*******************************************
void ConsoleObj::DisplayDefinedEntities() {

	int i, Hits;
	DisplayString("Static Entities\n");
	for(Hits = 0, i = 0; i < MAX_STATIC_ENTITIES; i++){
		if(QuakeServer->StaticEntity[i] != NULL) {
			DisplayString("#%3d=%20s ", i, 
			QuakeServer->PrecacheModel[QuakeServer->StaticEntity[i]->ModelIndex]);
			Hits++;
			if((Hits % 3) == 0)
				DisplayString("\n");
		}
	}

	DisplayString("\n");

	DisplayString("Baseline Entities\n");
	for(Hits = 0, i = 0; i < MAX_BASELINE_ENTITIES; i++){
		if(QuakeServer->BaselineEntity[i] != NULL) {
			DisplayString("#%3d=%20s ", i, 
			QuakeServer->PrecacheModel[QuakeServer->BaselineEntity[i]->ModelIndex]);
			Hits++;
			if((Hits % 3) == 0)
				DisplayString("\n");
		}

	}
	DisplayString("\n");
}

//*******************************************
//
//  Displays Entity information for arg
//
//*******************************************
void ConsoleObj::EntityInformation(EntityObj *Entity) {

	if(Entity == NULL) {
		DisplayString("Entity is not currently defined!!!!\n");
		return;
	}
	DisplayString("\nEntity Information\n");
	DisplayString("ModelIndex: %d, Frame: %d, ColorMap: %d, Skin: %d, Attack State: %d\n", 
		Entity->ModelIndex, Entity->Frame, Entity->ColorMap, Entity->Skin, Entity->AttackState);
	
	DisplayString("Location: (%5.0f, %5.0f, %5.0f)\n", Entity->Location[0], Entity->Location[1], Entity->Location[2]);
	DisplayString("Orientation: (%5.0f, %5.0f, %5.0f)\n", Entity->Angle[0], Entity->Angle[1], Entity->Angle[2]);
	DisplayString("Model Name: %s\n", QuakeServer->PrecacheModel[Entity->ModelIndex]);
}

//*******************************************
//
//  Displays Player Information
//
//*******************************************
void ConsoleObj::PlayerStatus(PlayerObj *Player) {

	DisplayString("\n");
	DisplayString("Player Information\n");

	DisplayPlayerStatus(Player);
	DisplayString("Weapon: ");
	DisplayWeapon(Player);
	DisplayString("Items: ");
	DisplayItems(Player);

	EntityInformation(*Player->PlayerEntity);

}

void ConsoleObj::InsertAlias(char *Variable, char *Value) {

	DisplayString("Inserting alias\n");
	DisplayString("Variable: %s, Value: %s\n", Variable, Value);
	Alias.Insert(Variable, Value);

}

// *********************************************
// *
// *  Grizzly.  Expect changes
// *
// *********************************************
int ConsoleObj::ParseString(char *InputBuffer){

	int Index;
	char *Command, *Arg1, *Arg2, *Value, *RecurseValue;

	Command = strtok(InputBuffer, " ");
	if(Command == NULL)
		return 0;

	if(stricmp(Command, "quit") == 0)
		return -1;
	
	else if(stricmp(Command, "say") == 0) {
		Arg1 = strtok(NULL, "\n");
		sprintf(OutputBuffer, "(Console) %s", Arg1);
		QuakeServer->SendBroadcastMessage(OutputBuffer);
	
	} else if(stricmp(Command, "player") == 0){
		Index = IntToken();
		if(Index < 1 || Index > QuakeServer->MaxPlayers)
			PlayerStatus(QuakeServer->Player[QuakeServer->BotID]);
		else
			PlayerStatus(QuakeServer->Player[Index -1]);		
		
	} else if(stricmp(Command, "game") == 0)
		GameStatus();		

	else if(stricmp(Command, "net") == 0) 
		NetworkStatus();		
		
	else if(stricmp(Command, "model") == 0) {
	
		Index = IntToken();
		if(Index < 1 || Index > QuakeServer->NumModels)
			Index = QuakeServer->BotID;
		DisplayString("Model Name: %s\n", QuakeServer->PrecacheModel[Index]);		

	} else if(stricmp(Command, "dynamic") == 0) {
		Index = IntToken();
		if(Index < 1 || Index > MAX_BASELINE_ENTITIES)
			Index = QuakeServer->BotID;
		printf("index = %d\n", Index);

		EntityInformation(QuakeServer->BaselineEntity[Index]);		
	
	} else if(stricmp(Command, "alias") == 0) {
		Arg1 = StringToken();
		if(Arg1 != NULL) {
			Arg2 = LineToken();
			if(Arg2 != NULL)
				InsertAlias(Arg1, Arg2);		
		} else
			DisplayAliases();
	} else if(stricmp(Command, "static") == 0) {
		Index = IntToken();
		if(Index < 1 || Index > MAX_STATIC_ENTITIES)
			Index = 1;
		printf("index = %d\n", Index);

		EntityInformation(QuakeServer->StaticEntity[Index]);		
	
	} else if(stricmp(Command, "impulse") == 0)
		QuakeServer->Player[QuakeServer->BotID]->CommandImpulse = IntToken();
	else if(stricmp(Command, "defined") == 0) 
		DisplayDefinedEntities();		
	
	else if(stricmp(Command, "bf") == 0) 
		DisplayString("\a BEEP! :)\n");
	
	else if(stricmp(Command, "nuke") == 0) 
		QuakeServer->SendCommand("quit");
	
	else {
		Value = Alias.Find(Command);  // See if an alias exists
		if(Value == NULL) { // Nope
			sprintf(OutputBuffer, "%s %s", Command, LineToken());
			QuakeServer->SendCommand(OutputBuffer);
		} else { // Call ParseString recursively with the new input
			RecurseValue = strdup(Value);
			ParseString(RecurseValue);  
			free(RecurseValue);
		}
	}

	return 0;
}

// *********************************************
// *
// *  Displays all aliases in alias object
// *
// *********************************************
void ConsoleObj::DisplayAliases() {

	RuleObj *CurrentRule;

	CurrentRule = Alias.GetFirstRule();

	if(CurrentRule == NULL) {
		DisplayString("No Aliases currently Defined\n");
		return;
	}

	while(CurrentRule != NULL) {
		DisplayString("%s = %s\n", CurrentRule->Variable, CurrentRule->Value);
		CurrentRule = CurrentRule->GetNextRule();
	}
}


void ConsoleObj::DisplayWeapon(PlayerObj *Player) {

		switch (Player->Weapon) {
		case 0:
			DisplayString("Axe\n");
			break;
		case 1:
			DisplayString("ShotGun\n");
			break;
		case 2:
			DisplayString("Super Shotgun\n");
			break;
		case 3:
			DisplayString("Nailgun\n");
			break;
		case 4:
			DisplayString("Super Nailgun\n");
			break;
		case 5:
			DisplayString("Grenade Launcher\n");
			break;
		case 6:
			DisplayString("Rocket Launcher\n");
			break;
		case 7:
			DisplayString("Lightning Gun\n");
			break;
		}
}

void ConsoleObj::DisplayItems(PlayerObj *Player) {


	if(Player->Items & IT_EXTRA_WEAPON)
		DisplayString("Extra Weapon - ");
	if(Player->Items & IT_SHELLS)
		DisplayString("Shells - ");
	if(Player->Items & IT_NAILS)
		DisplayString("Nails - ");
	if(Player->Items & IT_ROCKETS)
		DisplayString("Rockets - ");
	if(Player->Items & IT_CELLS)
		DisplayString("Cells - ");
	if(Player->Items & IT_ARMOR1)
		DisplayString("Armor #1 - ");
	if(Player->Items & IT_ARMOR2)
		DisplayString("Armor #2 - ");
	if(Player->Items & IT_ARMOR3)
		DisplayString("Armor #3 - ");
	if(Player->Items & IT_SUPERHEALTH)
		DisplayString("Super Health - ");
	if(Player->Items & IT_KEY1)
		DisplayString("Key #1 - ");
	if(Player->Items & IT_KEY2)
		DisplayString("Key #2 - ");
	if(Player->Items & IT_INVISIBILITY)
		DisplayString("Invisibility - ");
	if(Player->Items & IT_INVULNERABILITY)
		DisplayString("Invunerability - ");
	if(Player->Items & IT_SUIT)
		DisplayString("Suit - ");
	if(Player->Items & IT_QUAD)
		DisplayString("Quad Damage - ");
	if(Player->Items & IT_LIGHTNING) // Got lightning gun and cells
		DisplayString("Lightning Gun - ");
	if(Player->Items & IT_ROCKET_LAUNCHER)  // Got Rocket and Rockets
		DisplayString("Rocket Launcher - ");
	if(Player->Items & IT_GRENADE_LAUNCHER)  // Got Grenade and Rockets
		DisplayString("Grenade Launcher - ");
	if(Player->Items & IT_SUPER_NAILGUN)  // Got super nailgun and nails
		DisplayString("Super NailGun - ");
	if(Player->Items & IT_NAILGUN)  // Got nailgun and nails
		DisplayString("NailGun - ");
	if(Player->Items & IT_SUPER_SHOTGUN)  // Got super shotgun and shells
		DisplayString("Super Shotgun - ");
	if(Player->Items & IT_SHOTGUN)  // Got shotgun and shells
		DisplayString("Shotgun - ");
	if(Player->Items & IT_AXE) // Use da' AXE
		DisplayString("Axe");
	DisplayString("\n");
}

void ConsoleObj::DisplayPlayerStatus(PlayerObj *Player) {
	DisplayString("Name: %s\n", Player->Name); 
	DisplayString("Frags: %d, Health %d, Armor %d\n", 
		Player->Frags, Player->Health, Player->ArmorValue); 

	DisplayString("Shells: %d, Nails: %d, Rockets: %d, Cells: %d\n", 
		Player->AmmoShells, Player->AmmoNails, Player->AmmoRockets,
		Player->AmmoCells); 

	DisplayString("Shirt: ");
	DecodeColors(Player->ShirtColor);
	DisplayString(" Pant: ");
	DecodeColors(Player->PantColor);
	DisplayString("\n");
}


void ConsoleObj::DecodeColors(int Color) {

	switch(Color) {

	case 0:
		DisplayString("White");
		break;
	case 1:
		DisplayString("Brown");
		break;
	case 2:
		DisplayString("Lt. Blue");
		break;
	case 3:
		DisplayString("Green");
		break;
	case 4:
		DisplayString("Red");
		break;
	case 5:
		DisplayString("Dark Yellow");
		break;
	case 6:
		DisplayString("Pink");
		break;
	case 7:
		DisplayString("Lt. Brown");
		break;
	case 8:
		DisplayString("Lt. Purple");
		break;
	case 9:
		DisplayString("Purple");
		break;
	case 10:
		DisplayString("Grey");
		break;
	case 11:
		DisplayString("Aqua");
		break;
	case 12:
		DisplayString("Yellow");
		break;
	case 13:
		DisplayString("Blue");
		break;
	}
}

