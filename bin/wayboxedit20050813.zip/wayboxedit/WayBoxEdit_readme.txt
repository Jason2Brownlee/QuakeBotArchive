Title		: WayBoxEdit
Filename	: ...
Version		: 0.5
Date		: 20050813
Author		: Marko "Urre" Permanto
Email		: imunreal A to the T gmail D to the O to the T com
Website		: http://urre.quakedev.com/
Credits		: LordHavoc for teaching me a lot about QuakeC
		  Ender for scratch tutorials
		  id Software for various good things

Type of Mod
-----------
Quake C		: aye!
Sound		: no
MDL		: no
Level		: no
Gfx		: no
Wayboxes	: yes (one (1))

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no
context diff  : no
.qc files     : yes
progs.dat     : yes

Description of the Modification
-------------------------------
This mod is used to create wayboxes, used by the UrreBot for navigation.

As of writing, only DarkPlaces runs this mod properly.

I am too tired and bored to write the very elaborate description required
to explain the use of this mod. The source is also not documented, and messy.
I will release a new version with proper tutorials for waybox-creation, and
with cleaned up source in the future. For now, you'll have to check client.qc
for impulses and parseclientcommand stuff if you want to figure out how it
works. I've included the waybox-file for dm6 that I made, which you can load
for your viewing (or editing) pleasure. Enjoy!

Known Bugs
----------
None

Legal
-----
Authors MAY use this Quake modification as a basis for other publicly
available work, as long as I am credited. Please send me any modifications
you make.

You may distribute this Quake modification in any electronic format as long
as this description file remains intact and unmodified and is retained along
with all of the files in the archive.

You are not allowed to sell this Quake modification for money without my
permission.

Quake is copyrighted and trademarked, owned by id Software.