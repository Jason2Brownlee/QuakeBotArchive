Please read the file ctfbot14.txt for complete documentation.
Do NOT email me for help unless you have read ctfbot14.txt.
