Paroxysm v1.01b

This patch addresses issues that arose after the release v1.0 - Most of the changes are fixes for more stable LAN play, however, a few general gameplay improvements have been made.

Installation:
Find your 'pox' folder and replace the old 'pak0.pak' with the new one supplied in this archive.

What's new in v1.01b:

- Fixed the oversized packet crashes caused by the ShrapnelBomb, Reduced the amount and type of shrapnel released by the ShrapnelBomb

- Fixed floating, null, player model when a player disconnects (players now gib on suicide/disconnect)

- Fixed scoreboard and fClientNo not realizing a bot disconnected (Bots disconnect when their spawnmaster leaves a game)

- Fixed ShrapnelBomb detonating at owner's death (now detonates two minutes after launch, world gets the kill if owner died before detonating the bomb)

- Fixed wrong version number being displayed at worldspawn, added version display at client_connect

- Fixed LMS timeout (instant observer bug). Entering an LMS game late (after 1 minute) puts that client into observer mode.

- Bots that are members of a real client's team now use the base skin. (This is mainly for better sighting in a single player team game, especially in GLQuake)

- r_wateralpha and r_mirroralpha are no longer set automatically in GLQuake (testing prefs were accidentally left active in v1.0)

- Armour charge-up speed doubled

- Armour now rots (decreases 1 point per second) at values above 150

- Increased the Annihilator's firing rate slightly

A few bugs are still being addressed:

- a client's teambots always display the server's colours (but play properly)

- playing multiplayer on a LAN with bots can lead to packet errors and dropped clients (less likely when the server spawns all bots)

Check the Paroxysm website <http://www.planetquake.com/paroxysm/> for further updates. Send any questions, suggestions, or bug reports to <pox@planetquake.com>