#include <conio.h>
#include <stdio.h>
#include <math.h>
#include <process.h>
#include <ctype.h>

#include "PlayerObj.h"
#include "ServerObj.h"
#include "NavObj.h"

char VERSION[] = "V.90";

const unsigned char AI_MODE_IDLE = 0;
const unsigned char AI_MODE_TARGET = 1;
const unsigned char AI_MODE_ATTACK = 2;
const unsigned char AI_MODE_MAP = 3;
const unsigned char AI_MODE_RETRACE = 4;
const unsigned char AI_MODE_DEAD = 5;
const unsigned char AI_MODE_EVADE = 6;


int AttackPlayer(ServerObj *QuakeServer, int TargetPlayer) {
	float Distance;

	Distance = QuakeServer->Player[QuakeServer->BotID]->Aim(QuakeServer->Player[TargetPlayer]);

	if(Distance <= (float)100.0)
		QuakeServer->Player[QuakeServer->BotID]->CommandInlineSpeed = 0;
	else 
		QuakeServer->Player[QuakeServer->BotID]->CommandInlineSpeed = 0x1FF;

	if(Distance <= (float)300.0 && Distance > (float) 10.0){
		QuakeServer->Player[QuakeServer->BotID]->SelectSafeWeapon(); 
		QuakeServer->Player[QuakeServer->BotID]->CommandActions |= KEY_ACTION_FIRE;
		return 1;
	} else if (Distance <= (float)10.0) {
		QuakeServer->Player[QuakeServer->BotID]->CommandWeapon = SELECT_WEAPON_AXE;
		QuakeServer->Player[QuakeServer->BotID]->CommandActions |= KEY_ACTION_FIRE;
		return 1;
	}
	return 0;


}


void Chatter(ServerObj *QuakeServer, int Count) {

	char Buffer[50];
	if(Count == 50) {
		sprintf(Buffer, "QuakeBot C/S(c) %s", VERSION);
		QuakeServer->SendBroadcastMessage(Buffer);
	}

	if(Count == 100)
		QuakeServer->SendBroadcastMessage("jfrorie@uncc.edu");

	if(Count % 3000 == 300) 
		QuakeServer->SendBroadcastMessage("say 'No bots' to get rid of me");

}

void DisplayMode(ServerObj *QuakeServer, int Mode) {

	switch(Mode) {
	case AI_MODE_IDLE:
		QuakeServer->Console->DisplayString("Bot is IDLE\n");
		break;
	case AI_MODE_ATTACK:
		QuakeServer->Console->DisplayString("Bot is ATTACKING\n");
		break;
	case AI_MODE_TARGET:
		QuakeServer->Console->DisplayString("Bot is TARGETING\n");
		break;
	case AI_MODE_EVADE:
		QuakeServer->Console->DisplayString("Bot is EVADING\n");
		break;
	case AI_MODE_MAP:
		QuakeServer->Console->DisplayString("Bot is MAPPING\n");
		break;
	case AI_MODE_RETRACE:
		QuakeServer->Console->DisplayString("Bot is RETRACING\n");
		break;
	case AI_MODE_DEAD:
		QuakeServer->Console->DisplayString("Bot is DEAD\n");
		break;
	default:
		QuakeServer->Console->DisplayString("Bot is SCREWED UP!!!\n");
	}
}

//*********************************
//
// For right now, this is where the AI goes
//
//*********************************

void RuntimeThread(void *Dummy) {

	int i, Dead = 0, PacketLength, TargetPlayer, MinDistance;
	int OldFrame = 0, Health, OldWeaponCount=0, RespawnMode = 0, OldHealth = 0;
	int AIMode, OldAIMode, Count, StrafeLeft = 0;

	NavObj Navigate;

	ServerObj *QuakeServer;

	QuakeServer = (ServerObj *)Dummy;

	Navigate.SetServer(QuakeServer);

	timeval ShortTime;

	ShortTime.tv_sec = 0;
	ShortTime.tv_usec = 1000;

	AIMode = AI_MODE_IDLE;
	OldAIMode = -1;
	Count = 0;
	while(QuakeServer->GameMode != 5) {
		
		// Reset Everything
		MinDistance = INT_MAX;
		QuakeServer->Player[QuakeServer->BotID]->CommandActions = KEY_ACTION_NONE;
		QuakeServer->Player[QuakeServer->BotID]->CommandLateralSpeed = 0x0;
		Count++;
		Health = QuakeServer->Player[QuakeServer->BotID]->Health;
		for(i = 0; i < QuakeServer->MaxPlayers; i++)	// Mark them all out of view before
			QuakeServer->Player[i]->Dormant = 1;		// decode
 		
		// Get some data
		if((PacketLength = QuakeServer->ServerPacket.GetMessage()) > 0 )
			QuakeServer->DecodePacket();

		// Maybe send a message or two......
		Chatter(QuakeServer, Count);



		// Find nearest Player
		TargetPlayer = QuakeServer->NearestPlayerByVector();
		
		if(QuakeServer->Player[QuakeServer->BotID]->Health <= 0){  // I am dead, deal with it	
			AIMode = AI_MODE_DEAD;
			QuakeServer->Respawn();
		} else if(OldHealth > Health) { // I took a hit
			if(StrafeLeft) {
				StrafeLeft = 0;
				QuakeServer->Player[QuakeServer->BotID]->CommandLateralSpeed = 0x1ff;
			} else {
				StrafeLeft = 1;
				QuakeServer->Player[QuakeServer->BotID]->CommandLateralSpeed = -0x1ff;
			}
			AIMode = AI_MODE_EVADE;
		} else if(TargetPlayer != -1) {
			AIMode = AI_MODE_TARGET;
			if(!QuakeServer->Player[TargetPlayer]->Dead()){
				if(AttackPlayer(QuakeServer, TargetPlayer))
					AIMode = AI_MODE_ATTACK;
			}
		} else if(Navigate.VacantConnection() != -1) { // I can map to somewhere
			AIMode = AI_MODE_MAP;
			Navigate.WayPointSync(QuakeServer->Player[QuakeServer->BotID]);
			Navigate.Map();
		} else {
			AIMode = AI_MODE_RETRACE;
			Navigate.RandomMove();
		}

//#ifdef DEBUG
		// If health has changed.
		if(OldHealth != Health) {
			
			OldHealth = Health;
			QuakeServer->Console->DisplayString("Health : %d\n", QuakeServer->Player[QuakeServer->BotID]->Health);
		
		}
		if(OldAIMode != AIMode) {
			DisplayMode(QuakeServer, AIMode);
			OldAIMode = AIMode;
		}

//#endif

		// Check for extra data
		if(QuakeServer->ServerPacket.Socket.IsData(ShortTime)) {  // Quick check for more data
			QuakeServer->ServerPacket.GetMessage();
			QuakeServer->DecodePacket();
		}

		//  Send some Data		
		QuakeServer->SendRuntimePacket(QuakeServer->Player[QuakeServer->BotID]);

	}


}