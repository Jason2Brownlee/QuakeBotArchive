#ifndef ENTITYOBJ_H
#define ENTITYOBJ_H

#include <float.h>
#include <math.h>
#include <stdio.h>

//#include "PlayerObj.h"

class EntityObj {

public:

	float Angle[3], Location[3], Velocity[3];
	char *Name;

	int Attacker;
	short Entity;

	unsigned char Dormant; 

	unsigned char ModelIndex;
	unsigned char Frame;
	unsigned char ColorMap;
	unsigned char Skin;
	unsigned char AttackState;
	
	unsigned char Visible;

	float Distance(EntityObj *);
	void DisplayAll();
	void Reset();

	EntityObj() {

		int i;

		for(i=0; i<3; i++) {
			Location[i] = (float)0.0;
			Angle[i] = (float)0.0;
			Velocity[i] = (float)0.0;
		}
		Name = NULL;

		ModelIndex = 0;
		Frame = 0;
		AttackState = 0;
		Dormant = 1;
	}


};




#endif
