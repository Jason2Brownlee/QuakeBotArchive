#ifndef NAVOBJ_H
#define NAVOBJ_H

#include "WayPointObj.h"

class NavObj {

private:
	WayPointObj *CurrentWayPoint, *GraphEntry;
	ServerObj *QuakeServer;

public:
	
	NavObj() {

		printf("Instantiating Graph\n");
		GraphEntry = new WayPointObj;
		CurrentWayPoint = GraphEntry;
	}

	//*********************************
	//*
	//* This locates the player's current
	//* Location in the NavObject
	//*
	//*********************************

	void SetServer(ServerObj *Server){

		QuakeServer = Server;
	}

	void Map() {
	}

	void RandomMove() {
	}

	int WayPointSync(PlayerObj *Player){
		int i;
		float Distance;
//		printf("Syncing Waypoint....\n");

		for(i = 0; i <= MAX_STATIC_ENTITIES; i++) {
			Distance = (*Player->PlayerEntity)->Distance(QuakeServer->StaticEntity[i]);
			if(Distance <= 30){
				printf("Found: Entity %d, Distance is %f\n", i, Distance);
				return 1;
			}
		}
		return 0;
	}
		
	int VacantConnection() {
		int i;

		for(i = 0; i < MAX_CONNECTIONS; i++) {
			if(CurrentWayPoint->Connection[i] == NULL)
				return i;

		}

		return -1;
	}

	void AttachWayPoint(){
		printf("Attaching WayPoint\n");
	}


};

#endif

