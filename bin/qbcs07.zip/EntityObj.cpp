#include "EntityObj.h"

float EntityObj::Distance(EntityObj *Target) {

	float XOffset, YOffset, ZOffset;

	if(Target == NULL)
		return FLT_MAX;
	
	XOffset = Target->Location[0] - Location[0];
	YOffset = Target->Location[1] - Location[1];
	ZOffset = Target->Location[2] - Location[2];

	return (float) sqrt(pow(ZOffset, (float)2.0) + pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));

}



