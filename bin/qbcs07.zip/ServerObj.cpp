#include "ServerObj.h"
// ***********************************
//
// Establishes a connection to server.
//
// ***********************************

int ServerObj::ConnectServer() {


	int NewPort, DataLen = 12;

	unsigned char Response;
	// Build the packet.
	ServerPacket.Reset();

	ServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ServerPacket.SaveChar(COMMAND_CONNECT);
	ServerPacket.SaveString("QUAKE");
	ServerPacket.SaveChar((char) 0x03);
	ServerPacket.SendMessage();
	
	Console->DisplayString("Connecting\n");
	do {

		DataLen = ServerPacket.GetMessage();
		Response = ServerPacket.ReadChar();

	} while(Response != CCREP_ACCEPT && Response != CCREP_REJECT);

	//struct ServerConnect Response {
    //    struct Header;                        // { 0x80, 0x00, 0x00, 0x09 }
    //    char OP_Code;							// 0x81 This is CCREP_ACCEPT 
    //    int Port								// This is your port assigned
    //											// by the server
    //    char Unknown[ 2] = {0x00, 0x00 };		// The packet header shows these two byte
                                                // to be valid data, I dunno what, tho.
	//};

	// if connection is successfull, server will return a new port for
	// init and runtime.  This takes care of that.

	if(Response == CCREP_ACCEPT){ //  Accepts!!!!
		time(&ClientStartTime); // Record start of game
		NewPort = ServerPacket.ReadShort();
		ServerPacket.Socket.RemotePort = NewPort;
		return NewPort;

	} else {

		Console->DisplayString("Connection Rejected: %s\n", ServerPacket.ReadString());
		return -1;

	}

}

//
// This function queries the server for its name IP, etc.
//

int ServerObj::QueryServer() {

	int DataLen, Pass;

	ServerPacket.Reset();

	ServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ServerPacket.SaveChar(COMMAND_QUERY);
	ServerPacket.SaveString("QUAKE");
	ServerPacket.SaveChar((char) 0x03);
	
	unsigned char Temp;

	do {
	
		ServerPacket.SendMessage();
		Pass = 0;
		do {
			DataLen = ServerPacket.GetMessage();
			Pass++;
			if(Pass >= 5) 
				return 0;

		} while(DataLen <= 0);

		Temp = ServerPacket.ReadChar();

	} while(Temp != (unsigned char) 0x83);

	// printf out various specs

	IPString = strdup(ServerPacket.ReadString());

	ServerName = strdup(ServerPacket.ReadString());
	
	MapName = strdup(ServerPacket.ReadString());

	NumberOfPlayers = ServerPacket.ReadChar();
	MaxPlayers = ServerPacket.ReadChar(); 

	Console->DisplayString("Address: %s, Name: %s, Map: %s\n", IPString, ServerName, MapName);
	Console->DisplayString("Players: %u, Max: %u\n", NumberOfPlayers, MaxPlayers);

	return 1;

}


//
// Logs off from Quake server
//

void ServerObj::SendBroadcastMessage(char *Message) {
	
	char Buffer[0x7F];
	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ServerPacket.SaveChar(0x04); 

	sprintf(Buffer, "say \"%s\"", Message);
	ServerPacket.SaveString(Buffer); 

	ServerPacket.SendMessage();

	#ifdef DEBUG	
		Console->DisplayString("Message Sent\n");
	#endif

}

void ServerObj::SendCommand(char *Message) {
	
	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ServerPacket.SaveChar(0x04); 
	ServerPacket.SaveString(Message); 
	ServerPacket.SendMessage();

	#ifdef DEBUG	
		Console->DisplayString("Message Sent\n");
	#endif

}

//
// Logs off from Quake server
//

void ServerObj::SendGoodbye() {
	
	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_UPDATE);

	ServerPacket.SaveChar(0x02); 

	ServerPacket.SendMessage();

	#ifdef DEBUG	
		Console->DisplayString("Logoff completed\n");
	#endif

}


//***************************
//
//  Sends the name, color etc....
//
//***************************


void ServerObj::SendClientParms() {

//	struct ClientPlayerData {
//        struct Header; // { 0x00, 0x09, 0x00, 0x31}
//        struct Sequence; { 0x00, 0x00, 0x00, 0x02 }
//        char Data = 0x04;      // Could this be something to do with the rule stuff?
//        const char tag1[5] = "name ";
//        char Name[] // ASCII name
//        const char tail1[3] = { 0x0a, 0x00, 0x04};
//        const char tag2[6] = "color ";
//        char fgcolor[] = // ASCII color number
//        const char tag3 = " ";
//        char bgcolor[] = // ASCII color number
//        char tail3[] = {0x0a, 0x00, 0x04, "spawn ", 0x00};
//	};

	
	// For some reason, the strings have 0x0A append in them (linefeed).
	// Mistake?

	char Buffer[0x7f];

	ServerPacket.Reset();
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ServerPacket.SaveChar(0x04);
	sprintf(Buffer, "name %s\x0a", BotName);
	ServerPacket.SaveString(Buffer);
	
	ServerPacket.SaveChar(0x04); 
	ServerPacket.SaveString("color 3 3\x0a");
	
	ServerPacket.SaveChar(0x04); 
	ServerPacket.SaveString("spawn ");
	
	ServerPacket.SendMessage();

}

//*************************
//
//  Sends the begin command
//
//*************************

void ServerObj::SendBegin() {

	// struct ClientBegin {
    //    struct Header; // { 0x00, 0x09, 0x00, 0x0f }
    //    struct Sequence; // {0x00, 0x00, 0x00, 0x03 };
    //    char Data[7] = { 0x04, "begin", 0x00 };
	// };

	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ServerPacket.SaveChar(0x04); 
	ServerPacket.SaveString("begin");

	ServerPacket.SendMessage();

//	ServerPacket.HexDump(HEXDUMP_OUTPUT_BUFFER);
}

//*************************
//
//  Send a NOOP ?
//
//*************************
void ServerObj::SendNoOp() {

	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);
	ServerPacket.SaveChar(0x01);
	ServerPacket.SendMessage();

//	ServerPacket.HexDump(HEXDUMP_OUTPUT_BUFFER);
}

//*************************
//
//  Tell sever that prespawn has finished (psyche!)
//
//*************************
void ServerObj::SendPrespawn() {

	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);
	ServerPacket.SaveChar(0x04);
	ServerPacket.SaveString("prespawn");
	ServerPacket.SendMessage();

}


//*****************************
//
//  This routine finds the player entity
//  that is a the closest match for the location
//
//*****************************

int ServerObj::WhatIsAt(float X, float Y, float Z) {

	float XOffset, YOffset, ZOffset;
	float Result, Distance;
	int Entity = -1;
	int i;

	Result = FLT_MAX;
	for(i=0; i < NumberOfPlayers; i++) {

		XOffset = (*Player[i]->PlayerEntity)->Location[0] - X;
		YOffset = (*Player[i]->PlayerEntity)->Location[1] - Y;
		ZOffset = (*Player[i]->PlayerEntity)->Location[2] - Z;
		Distance = (float) sqrt(pow(ZOffset, (float)2.0) + pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));
		if(Result > Distance) {
			Result = Distance;
			Entity = i;
		}
	}
	
	return Entity;

}


//*****************************
//
//  This routine performs the handshake for the server
//  Not fully tested on every server type, so could be buggy
//
//*****************************

int ServerObj::GameInit() {
	


	//  ASCII Game Parameters
	Console->DisplayString("Receiving ASCII Game Parameters\n");
	do {
		if(ServerPacket.GetMessage() >= 0)
			DecodePacket();
		else
			continue;
	} while(GameMode != GAME_STATE_PRESPAWN);

//	} while(ServerPacket.GetHeader() != MESSAGE_TYPE_FINAL);
	
	// Prespawn Packet #1
	Console->DisplayString("Sending NoOp\n");
	SendNoOp();
	while(ServerPacket.GetMessage() <= 0);
	DecodePacket();

	// Prespawn Packet #2
	Console->DisplayString("Sending Prespawn\n");
	SendPrespawn();
	while(ServerPacket.GetMessage() <= 0);
	DecodePacket();
	
	Console->DisplayString("Receiving Binary Game Parameters\n");
	Console->DisplayString("Game State is %d\n", GameMode);

	do {
		if(ServerPacket.GetMessage() >= 0)
			DecodePacket();
		else
			continue;		
	} while(GameMode != GAME_STATE_LIGHTING);
	Console->DisplayString("Game State is %d\n", GameMode);

//	} while(ServerPacket.GetHeader() != MESSAGE_TYPE_FINAL);

	Console->DisplayString("Client Parameter Transfer\n");
	SendClientParms();
	while(ServerPacket.GetMessage() <= 0);
	DecodePacket();
	Console->DisplayString("Game State is %d\n", GameMode);

	Console->DisplayString("Begin Game Packet\n");
	SendBegin();
	while(ServerPacket.GetMessage() <= 0); // This should get the ack
	DecodePacket();
	Console->DisplayString("Game State is %d\n", GameMode);

	return 1;
}


//**************************************
//
//  This routine is #$*#^&$#& UGLY. It parses the DEM messages.
//
//**************************************

void ServerObj::DecodePacket() {

	short TempShort;
	int i, TempInt, Misses, EndOfString, PlayerNumber, Color;
	int PacketType = ServerPacket.GetHeader();
	char *ConsoleString;
	int ConsoleStringLength;
	float TempFloatX, TempFloatY, TempFloatZ;
	long BitMask;


	switch(PacketType) {
	case MESSAGE_TYPE_CONTROL:
//		Console->DisplayString("Not Decoded: Control Received\n");
		return;
		break;
	case MESSAGE_TYPE_ACK:
//		Console->DisplayString("Not Decoded: Ack Received\n");
		return;
		break;
	default:
		break;
	}

	Misses = 0;
	while(!ServerPacket.End()){

		unsigned char IDByte = ServerPacket.ReadChar();

		switch(IDByte) {
		case 0x00:
			BombOut("Something Died in Here. Bad Data. Go Away.");
			break;
		case 0x01:
#ifdef DECODE
			Console->DisplayString("Command: NOOP\n");

#endif
			break;
		case 0x02:
#ifdef DECODE
			Console->DisplayString("Command: Disconnect\n");
#endif
			BombOut("Server Shut Down");
			break;
		case 0x03:
#ifdef DECODE
			Console->DisplayString("Command: Update Stat\n");
#endif
			TempInt = ServerPacket.ReadByte();
			if (TempInt > 0x1f) {
				BombOut("svc_updatestat: Invalid Index");
			}
			Player[BotID]->PlayerState[TempInt] = ServerPacket.ReadLong();

#ifdef DECODE
			Console->DisplayString("PlayerState[%ld] = %ld\n", Index, PlayerState[Index]);
#endif
			break;
		case 0x04:
#ifdef DECODE
			Console->DisplayString("Command: Version\n");
#endif
			ServerPacket.ReadLong();
			break;
		case 0x05:
			BotID = ServerPacket.ReadShort() - 1;
#ifdef DECODE
			Console->DisplayString("Command: Setview to %d\n", BotID);
#endif
			break;
		case 0x06:
#ifdef DECODE
			Console->DisplayString("Command: sound\n");
#endif
			{
				float Origin[3];
				long EntityChannel;
				int Entity;
				int BitMask = ServerPacket.ReadByte();
				float Volume = BitMask & 0x01 ? (float) ServerPacket.ReadByte()/ (float)255.0 : (float)1.0;
				float Attenuation = BitMask & 0x02 ? (float) ServerPacket.ReadByte()/ (float)64.0 : (float)1.0;
				EntityChannel = ServerPacket.ReadShort();
				int Channel = EntityChannel & 0x07;
				Entity = (EntityChannel >> 3) & 0x1fff;
				int SoundNumber = ServerPacket.ReadByte();
				for(int i =0; i<3;i++)
					Origin[i] = ServerPacket.ReadCoord();
			}

			break;
		case 0x07:
#ifdef DECODE
			Console->DisplayString("Command: Time\n");
#endif
			ServerTimeStamp = ServerPacket.ReadFloat();

			break;
		case 0x08:
#ifdef DECODE
			Console->DisplayString("Command: print\n");
#endif
			ConsoleString = ServerPacket.ReadString();
			ConsoleStringLength = strlen(ConsoleString);
			EndOfString = 0;

			for(i=0; i < ConsoleStringLength; i++) {
				if((ConsoleString[i] == 0x0a))
					EndOfString = 1;

				if(iscntrl(ConsoleString[i]))
					ConsoleString[i] = ' ';
			}

			Console->DisplayString("%s", ConsoleString);

			if(EndOfString)
				Console->DisplayString("\n");

			TempInt = strlen(ConsoleString);
			TempShort = strlen(QUITSTRING);
			for(i = 0; i < TempInt; i++) {
				if(strnicmp(&ConsoleString[i], QUITSTRING, TempShort) == 0)
					BombOut("WAH!! Someone doesn't love me!!!");
			}
			break;
		case 0x09:

			ConsoleString = ServerPacket.ReadString();
//#ifdef DECODE
			Console->DisplayString("StuffText: %s\n", ConsoleString);
//#endif

			
			if(strncmp(ConsoleString, "reconnect", 9) == 0){
				GameInit(); // Get new parameters
				Console->DisplayString("Reinit Completed\n");
				return;
			}

			break;

		case 0x0A:

			(*Player[BotID]->PlayerEntity)->Angle[0] = ServerPacket.ReadAngle();
			(*Player[BotID]->PlayerEntity)->Angle[1] = ServerPacket.ReadAngle();
			(*Player[BotID]->PlayerEntity)->Angle[2] = ServerPacket.ReadAngle();
#ifdef DECODE
			Console->DisplayString("Command: Set Angle\n");
			Console->DisplayString("New angle is (%f, %f, %f)\n", (*Player[BotID]->PlayerEntity)->Angle[0],
			(*Player[BotID]->PlayerEntity)->Angle[1], (*Player[BotID]->PlayerEntity)->Angle[2]);
#endif
			break;

		case 0x0B: // Server Info - Converted
#ifdef DECODE
			Console->DisplayString("Server Info\n");
#endif
			ServerVersion = ServerPacket.ReadLong();
			if(ServerVersion != 0x0F)
				Console->DisplayString("Bad Server Version, V%x\n", ServerVersion);

			MaxClients = ServerPacket.ReadByte();
			Multi = ServerPacket.ReadByte();

			if(MapName != NULL)
				free(MapName);
	
			MapName = strdup(ServerPacket.ReadString());

			FreePrecache(); // Clear up previous precache entries
			FreeEntities(); // New map, so new entities
			StaticEntityCount = 0;
			NumModels = 0;
			do {
					if (++NumModels > MAX_MODELS){
						BombOut("Server sent too much model precache");
					}

					PrecacheModel[NumModels] = strdup(ServerPacket.ReadString());
			} while (*PrecacheModel[NumModels]);

			NumSounds = 0;
			do {
					if (++NumSounds > MAX_SOUNDS){
						BombOut("Server sent too much model precache");
						}
					PrecacheSound[NumSounds] = strdup(ServerPacket.ReadString());
			} while (*PrecacheSound[NumSounds]);

			break;

		case 0x0C:
#ifdef DECODE
			Console->DisplayString("Command: Light Style\n");
#endif
			ServerPacket.ReadByte();
			ServerPacket.ReadString();
			break;

		case 0x0D:
#ifdef DECODE
			Console->DisplayString("Command: Update Name\n");
#endif
			{
				int PlayerNumber = ServerPacket.ReadByte();

				if(Player[PlayerNumber]->Name != NULL) // If allocated
					free(Player[PlayerNumber]->Name);
				Player[PlayerNumber]->Name = strdup(ServerPacket.ReadString());
			}
			break;

		case 0x0E:
#ifdef DECODE
			Console->DisplayString("Command: Update Frags\n");
#endif
			Player[ServerPacket.ReadByte()]->Frags = ServerPacket.ReadShort();
			break;

		case 0x0F:
			{
			
#ifdef DECODE
				Console->DisplayString("Command: Update Client Data\n");
#endif
				long BitMask = ServerPacket.ReadShort();
				float ViewOfsZ = BitMask & 0x0001 ? (float) ServerPacket.ReadChar() : (float)22.0;
				float AngOfs1 = BitMask & 0x0002 ? (float) ServerPacket.ReadChar() : (float)0.0;
				(*Player[BotID]->PlayerEntity)->Angle[0] = BitMask & 0x0004 ? (float) ServerPacket.ReadChar() : (float)22.0;
				Player[BotID]->Velocity[0] = BitMask & 0x0020 ? (float) ServerPacket.ReadChar() : (float)22.0;
				(*Player[BotID]->PlayerEntity)->Angle[1] = BitMask & 0x0008 ? (float) ServerPacket.ReadChar() : (float)22.0;
				Player[BotID]->Velocity[1] = BitMask & 0x0040 ? (float) ServerPacket.ReadChar() : (float)22.0;
				(*Player[BotID]->PlayerEntity)->Angle[2] = BitMask & 0x0010 ? (float) ServerPacket.ReadChar() : (float)22.0;
				Player[BotID]->Velocity[2] = BitMask & 0x0080 ? (float) ServerPacket.ReadChar() : (float)22.0;
				Player[BotID]->Items = BitMask & 0x0200 ? ServerPacket.ReadLong() : 0x1001;
				Player[BotID]->WeaponFrame = BitMask & 0x1000 ? ServerPacket.ReadChar() : Player[BotID]->WeaponFrame;
				Player[BotID]->ArmorValue = BitMask & 0x2000 ? ServerPacket.ReadChar() : Player[BotID]->ArmorValue;
				Player[BotID]->WeaponModel = BitMask & 0x4000 ? ServerPacket.ReadChar() : Player[BotID]->WeaponModel;
				Player[BotID]->Health = ServerPacket.ReadShort();
				Player[BotID]->CurrentAmmo = ServerPacket.ReadChar();
				Player[BotID]->AmmoShells = ServerPacket.ReadChar();
				Player[BotID]->AmmoNails = ServerPacket.ReadChar();
				Player[BotID]->AmmoRockets = ServerPacket.ReadChar();
				Player[BotID]->AmmoCells = ServerPacket.ReadChar();
				Player[BotID]->Weapon = ServerPacket.ReadChar();
#ifdef DECODE
				Console->DisplayString("Health: %d, Ammo: %d, Armour: %d, Weapon: %d\n", Health, CurrentAmmo, ArmorValue, Weapon);
				Console->DisplayString("Shells: %d, Nails: %d, Rockets: %d, Cells: %d\n", AmmoShells, AmmoNails, AmmoRockets, AmmoCells); 
				Console->DisplayString("Location: (%f,%f,%f) Orientation: (%f,%f,%f)\n", Velocity[0], Velocity[1], Velocity[2], Angles[0], Angles[1], Angles[2]);
#endif
			}
			break;

		case 0x10:
#ifdef DECODE
			Console->DisplayString("Command: Stop Sound\n");
#endif
			ServerPacket.ReadShort();
			break;

		case 0x11:
#ifdef DECODE
			Console->DisplayString("Command: Update Colors\n");
#endif
			PlayerNumber = ServerPacket.ReadByte();
			Color = ServerPacket.ReadByte();
			Player[PlayerNumber]->ShirtColor = (Color >> 4) & 0x0f;
			Player[PlayerNumber]->PantColor = Color & 0x0f;

			break;
	
		case 0x12:
#ifdef DECODE
			Console->DisplayString("Command: Particle\n");
#endif
			{
				float Origin[3], Velocity[3];
				int i;
				for(i=0; i<3; i++)
					Origin[i] = ServerPacket.ReadCoord();
				for(i=0; i<3; i++)
					Velocity[i] = (float) ServerPacket.ReadChar() * (float)0.0625;
			
				int Color = ServerPacket.ReadByte();
				int Count = ServerPacket.ReadByte();
			}
			break;
		
		case 0x13:
			Player[BotID]->ArmorValue -= ServerPacket.ReadChar();
			Player[BotID]->Health -= ServerPacket.ReadChar();
			TempFloatX = ServerPacket.ReadCoord();
			TempFloatY = ServerPacket.ReadCoord();
			TempFloatZ = ServerPacket.ReadCoord();

			Player[BotID]->Attacker = WhatIsAt(TempFloatX, TempFloatY, TempFloatZ);
#ifdef DECODE
			Console->DisplayString("Damage Origin: (%f,%f,%f)\n", TempFloatX, TempFloatY, TempFloatZ);
			Console->DisplayString("%s attacked me\n", Player[Player[BotID]->Attacker]->Name);
#endif
			break;

		case 0x14:

			if(StaticEntityCount >= MAX_STATIC_ENTITIES) {
				BombOut("Too many static entries");
			}
			StaticEntityCount++;
			EntityIndex = StaticEntityCount - 1;
			StaticEntity[EntityIndex] = new EntityObj;
			StaticEntity[EntityIndex]->ModelIndex = ServerPacket.ReadByte();
			StaticEntity[EntityIndex]->Frame = ServerPacket.ReadByte();
			StaticEntity[EntityIndex]->ColorMap = ServerPacket.ReadByte();
			StaticEntity[EntityIndex]->Skin = ServerPacket.ReadByte();
			for(i=0; i < 3; i++) {
				StaticEntity[EntityIndex]->Location[i] = ServerPacket.ReadCoord();
				StaticEntity[EntityIndex]->Angle[i] = ServerPacket.ReadAngle();
			}

#ifdef DECODE
			Console->DisplayString("New Static Entity #%d\n", EntityIndex);
#endif

			break;

		case 0x15:
#ifdef DECODE
			Console->DisplayString("Command: Spawnbinary\n");
#endif
			BombOut("Bad Mojo Command: SpawnBinary");
			break;

		case 0x16:

			EntityIndex = ServerPacket.ReadShort();
			BaselineEntity[EntityIndex] = new EntityObj;
			if(EntityIndex >= MAX_BASELINE_ENTITIES)
				BombOut("CL_EntityNum: Invalid Number");
			BaselineEntity[EntityIndex]->ModelIndex = ServerPacket.ReadByte();
			BaselineEntity[EntityIndex]->Frame = ServerPacket.ReadByte();
			BaselineEntity[EntityIndex]->ColorMap = ServerPacket.ReadByte();
			BaselineEntity[EntityIndex]->Skin = ServerPacket.ReadByte();
			for(i = 0; i<3; i++){
					BaselineEntity[EntityIndex]->Location[i] = ServerPacket.ReadShort();
					BaselineEntity[EntityIndex]->Angle[i] = ServerPacket.ReadChar();
			}

#ifdef DECODE
			Console->DisplayString("Spawned Baseline Entity #%d\n", EntityIndex);
#endif
			break;

		case 0x17:
#ifdef DECODE
			Console->DisplayString("Command: Temp Entity\n");
#endif
			{
				float Origin[3], TraceEndPos[3];
				int i, Entity;
				int EntityType = ServerPacket.ReadByte();
				if(EntityType > 11) {
					BombOut("CL_ParserTEnt: bad type");
				}
				switch(EntityType) {
				case 0:
				case 1:
				case 2:
				case 3:
				case 4:
				case 7:
				case 8:
				case 10:
				case 11:

					for(i=0; i<3;i++)
						Origin[i] = ServerPacket.ReadCoord();
					break;
				case 5:
				case 6:
				case 9:
					Entity = ServerPacket.ReadShort();
					for(i=0; i<3;i++)
						Origin[i] = ServerPacket.ReadCoord();
					for(i=0; i<3;i++)
						TraceEndPos[i] = ServerPacket.ReadCoord();

					break;
				}
			}
			break;

		case 0x18:
#ifdef DECODE
			Console->DisplayString("Command: setpause\n");
#endif
			{
				int PauseState = ServerPacket.ReadByte();
				if(PauseState)
					Console->DisplayString("Pause is on\n");
				else
					Console->DisplayString("Pause is off\n");
			}
			break;
		case 0x19:

			GameMode = ServerPacket.ReadByte();
#ifdef DECODE
			Console->DisplayString("Game Mode: %d\n", Action);
#endif
			break;

		case 0x1A:
#ifdef DECODE
			Console->DisplayString("Command: Centerprint\n");
#endif
			Console->DisplayString("String = %s\n", ServerPacket.ReadString());
			break;

		case 0x1B:
#ifdef DECODE
			Console->DisplayString("Command: Death of Monster\n");
#endif
			break;

		case 0x1C:
#ifdef DECODE
			Console->DisplayString("Command: Found Secret\n");
#endif
			break;

		case 0x1D:
#ifdef DECODE
			Console->DisplayString("Command: Spawn Static Sound\n");
#endif
			{
				float Origin[3];

				for(i = 0; i<3; i++)
					Origin[i] = ServerPacket.ReadCoord();
				int SoundNum = ServerPacket.ReadByte();
				float Volume = (float)ServerPacket.ReadByte() / (float)255.0;
				float Attenuation = (float)ServerPacket.ReadByte() / (float)64.0;
			}
			break;

		case 0x1E:
//#ifdef DECODE
			Console->DisplayString("Command: Intermission\n");
//#endif
			Respawn(); // unpause
			break;

		case 0x1F:
//#ifdef DECODE
			Console->DisplayString("Command: Final\n");
//#endif
			ConsoleString = ServerPacket.ReadString();
			
			break;

		case 0x20:
			int Start, End;
			Start = ServerPacket.ReadByte();
			End = ServerPacket.ReadByte();

#ifdef DECODE
			Console->DisplayString("Command: CD Track\n");
			Console->DisplayString("Range %d - %d\n", Start, End);
#endif
			break;

		case 0x21:
#ifdef DECODE
			Console->DisplayString("Command: Sell Screen\n");
#endif
			break;

		default:
			if(IDByte<0x80){
				Console->DisplayString("ERROR!!!!!  Invalid ID Byte 0x%x\n", IDByte);
				ServerPacket.HexDump(HEXDUMP_INPUT_BUFFER, ServerPacket.InputOffset);
				BombOut("Bad Command");
			} else {

#ifdef DECODE
				Console->DisplayString("Command: Update Entity (%x)\n", IDByte);
#endif

				BitMask = IDByte & 0x07F;

				if (BitMask & 0x0001) 
					BitMask |= ServerPacket.ReadByte() << 8;
				EntityIndex = BitMask & 0x4000 ?  ServerPacket.ReadShort() : (short) ServerPacket.ReadByte();
				if(BaselineEntity[EntityIndex] == NULL) {
					// Console->DisplayString("Attempted to update NULL Entity!!!! Inserting Entry...\n");
					BaselineEntity[EntityIndex] = new EntityObj;
					
				}
				BaselineEntity[EntityIndex]->ModelIndex = BitMask & 0x0400 ? ServerPacket.ReadByte() : BaselineEntity[EntityIndex]->ModelIndex;
				BaselineEntity[EntityIndex]->Frame = BitMask & 0x0040 ? ServerPacket.ReadByte() : BaselineEntity[EntityIndex]->Frame;
				BaselineEntity[EntityIndex]->ColorMap = BitMask & 0x0800 ? ServerPacket.ReadByte() : BaselineEntity[EntityIndex]->ColorMap;
				BaselineEntity[EntityIndex]->Skin = BitMask & 0x1000 ? ServerPacket.ReadByte() : BaselineEntity[EntityIndex]->Skin;
				BaselineEntity[EntityIndex]->AttackState = BitMask & 0x2000 ? ServerPacket.ReadByte() : BaselineEntity[EntityIndex]->AttackState;
				
				BaselineEntity[EntityIndex]->Location[0] = BitMask & 0x0002 ? ServerPacket.ReadCoord() : 0;
				BaselineEntity[EntityIndex]->Angle[0] = BitMask & 0x0100 ? ServerPacket.ReadAngle() : 0;
				BaselineEntity[EntityIndex]->Location[1] = BitMask & 0x0004 ? ServerPacket.ReadCoord() : 0;
				BaselineEntity[EntityIndex]->Angle[1] = BitMask & 0x0010 ? ServerPacket.ReadAngle() : 0;
				BaselineEntity[EntityIndex]->Location[2] = BitMask & 0x0008 ? ServerPacket.ReadCoord() : 0;
				BaselineEntity[EntityIndex]->Angle[2] = BitMask & 0x0200 ? ServerPacket.ReadAngle() : 0;

				if(BitMask & 0x0020)
					Console->DisplayString("Really new stuff received for Entity[%d]\n", EntityIndex); 

				
#ifdef DECODE
				Console->DisplayString("Entity %d, Origin: (%.3f,%.3f,%.3f) ", Entity, Origin[0], Origin[1], Origin[2]);
				Console->DisplayString("Orientation(%.3f,%.3f,%.3f)\n Attackstate: %d, ",Angle[0], Angle[1], Angle[2], AttackState);
				Console->DisplayString("ModelIndex %d, Frame %d, ColorMap %d, Skin %d\n", ModelIndex, Frame, ColorMap, Skin);

#endif
			}	
			break;
		}
#ifdef DEBUG
		Console->DisplayString("New offset: %lx\n", ServerPacket.Offset);
#endif
	}
}

//*************************
//
//  Debug Exit Routine.
//
//*************************


void ServerObj::BombOut(char *String){
	Console->DisplayString("BOOM!: %s\n", String);
	SendGoodbye();
	exit(2);	
}

// *****************************
//
// Routine to send the client runtime parameters.
//
// *****************************


void ServerObj::SendRuntimePacket(PlayerObj *Player) {

	time_t TimeStamp;

	time(&TimeStamp);

	ServerPacket.Reset();

	ServerPacket.SetHeader(MESSAGE_TYPE_UPDATE);

	ServerPacket.SaveByte(0x03);  // Movement Command

	ClientTimeStamp = (float)(TimeStamp - ClientStartTime); // elapsed time

	ServerPacket.SaveFloat(ClientTimeStamp);
	ServerPacket.SaveAngle(Player->CommandViewAngle);
	ServerPacket.SaveAngle(Player->CommandRotation);
	ServerPacket.SaveAngle(Player->CommandRollAngle);	// Rollangle???
	ServerPacket.SaveShort(Player->CommandInlineSpeed);
	ServerPacket.SaveShort(Player->CommandLateralSpeed);
	ServerPacket.SaveShort(Player->CommandVerticalSpeed);
	ServerPacket.SaveByte(Player->CommandActions);	
	ServerPacket.SaveByte(Player->CommandWeapon);	// Weapon Change?????
	
	ServerPacket.SendMessage();

}



//*********************
//
//  Find who you are by parsing player names
//	Currently obsolete, The set camera command tells me who I am.
//	might might be of use later
//
//	This routine is confused by duplicate names.
//
//*********************


int ServerObj::FindMe() {
	int i;
	if(BotID == 0) {
		for(i=0; i< MaxPlayers; i++){
			if(Player[i]->Name != NULL){
				if(strcmp(Player[i]->Name, BotName) == 0) {
					BotID = i;
					return TRUE;
				}
			}
		}
		Console->DisplayString("Can't Find me...\n");

		BotID = 0;
		return FALSE;

	}
	return TRUE;
}

//***************************************************************
//
//  Respawn the player.  This routine is needed because it appears
//	That the server is slow to pick up on space bar presses.
//  So I press the space for several cycle and let go.
//
//***************************************************************

void ServerObj::Respawn() {

	int PacketLength, Count = 5;

	Player[BotID]->CommandActions = KEY_ACTION_JUMP;
	while(Count-- > 0) {
		if((PacketLength = ServerPacket.GetMessage()) > 0 )
			DecodePacket();
			
		SendRuntimePacket(Player[BotID]);
	}

	Player[BotID]->CommandActions = KEY_ACTION_NONE;

	if((PacketLength = ServerPacket.GetMessage()) > 0 )
		DecodePacket();
		
	SendRuntimePacket(Player[BotID]);
}

//***************************************************************
//
//  Frees up allocated players and their names.
//
//***************************************************************

void ServerObj::FreePlayers() {

	int i;

	for(i = 0; i < NumberOfPlayers; i++) {
		if(Player[i]->Name != NULL)
			free(Player[i]->Name);
		free(Player[i]);
	}
}

//***************************************************************
//
//  Frees up allocated entities.
//
//***************************************************************

void ServerObj::FreeEntities() {

	int i;

	for(i = 0; i < MAX_BASELINE_ENTITIES; i++) {
		if(BaselineEntity[i] != NULL) {
			free(BaselineEntity[i]);
			BaselineEntity[i] = NULL;
		}
	}

	for(i = 0; i < MAX_STATIC_ENTITIES; i++) {
		if(StaticEntity[i] != NULL) {
			free(StaticEntity[i]);
			StaticEntity[i] = NULL;
		}
	}
}

//***************************************************************
//
//  Frees up allocated model and sound strings
//
//***************************************************************

void ServerObj::FreePrecache() {

	int i;

	for(i = 0; i < NumModels; i++) {
		if(PrecacheModel[i] != NULL)
			free(PrecacheModel[i]);
	}

	for(i = 0; i < NumSounds; i++) {
		if(PrecacheSound[i] != NULL)
			free(PrecacheSound[i]);

	}
}

//***************************************************************
//
//  Frees up other BS
//
//***************************************************************

void ServerObj::FreeMisc() {

	free(IPString);
	free(ServerName);
	free(MapName);
}

//***************************************************************
//
//  Find nearest player as the crow flies. -1 if none
//	Will return dead players, SO CHECK!!!!
//
//***************************************************************
int ServerObj::NearestPlayerByVector() {

	int i, TargetPlayer, MinDistance, PlayerDistance;		

	//  Find closest player
	MinDistance = INT_MAX;
	TargetPlayer = -1;
	for(i=0;i < MaxPlayers;i++) {
		if(i != BotID ) {		// Can't be me, dip!
			PlayerDistance = (int) Player[BotID]->Distance(Player[i]);
			if(PlayerDistance < MinDistance) {
				MinDistance = PlayerDistance;
				TargetPlayer = i;
			}

		}
	}
	return TargetPlayer;

}

void ServerObj::Logon() {

	Console->DisplayString("Connecting to Server\n");
	if((ServerPacket.Socket.RemotePort = ConnectServer()) == -1) {
		Console->DisplayString("Server Connect Failed\n");
		exit(-1);
	}

	GameInit();
}

ServerObj::ServerObj(char *IPString, int InitPort, ConsoleObj *UserConsole){		

	int i;
	ClientTimeStamp = (float)0.0;
	
	strcpy(ServerPacket.Socket.RemoteIP, IPString);

	ServerPacket.Socket.RemotePort = InitPort;

	Console = UserConsole;

	Console->DisplayString("Performing Query on %s:%d\n", IPString, InitPort);

	if(QueryServer()) {

		Player = (PlayerObj **) calloc(MaxPlayers, sizeof(PlayerObj *)); // An array of pointer to Player objects

		for(i = 0; i < MAX_STATIC_ENTITIES; i++ )  // init baseline array
			StaticEntity[i] = NULL; 

		for(i = 0; i < MAX_BASELINE_ENTITIES; i++ )  // init baseline array
			BaselineEntity[i] = NULL; 

		for(i = 0; i < MaxPlayers; i++ ) {
			Player[i] = new PlayerObj;
			Player[i]->PlayerID = i;  // Let him know who he is.
			Player[i]->PlayerEntity = &BaselineEntity[i+1]; // Assocated entity
															// Anyone know why + 1?
		}
		GameMode = 0;

		Initialized = 1;
	
	} else {
		Console->DisplayString("Server Query FAILED!!!!\n");
		Initialized = 0;
	}
	
	ClientTimeStamp = (float)0.0;

	// Init Precache Areas
	for(i = 0; i <= MAX_MODELS; i++)
		PrecacheModel[i] = NULL;

	for(i = 0; i <= MAX_SOUNDS; i++)
		PrecacheSound[i] = NULL;

	NumModels = 0;
	NumSounds = 0;

}