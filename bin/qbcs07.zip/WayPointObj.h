#ifndef WAYPOINTOBJ_H
#define WAYPOINTOBJ_H

#define MAX_CONNECTIONS 4  // Number of different paths from Waypoint

class WayPointObj {

private:
	int Weight, Visited;

public:


	WayPointObj *Connection[MAX_CONNECTIONS];

	WayPointObj() {
		int i;

		printf("Instantiating WayPoint\n");
		for(i = 0; i < MAX_CONNECTIONS; i++)//  Ground Connections
			Connection[i] = NULL;
		Visited = FALSE;

	}

	void Attach(WayPointObj *NewWayPoint){
		int Index;

		printf("Attaching WayPoint\n");
		Index = FindFreeConnection();
		Connection[Index] = NewWayPoint;
	}

	WayPointObj *Insert() {
		WayPointObj *NewWayPoint;

		printf("Inserting WayPoint\n");
		NewWayPoint = new WayPointObj;
		Attach(NewWayPoint);
		return NewWayPoint;
	}

	int FindFreeConnection() {
		int i;

		for(i = 0; i < MAX_CONNECTIONS; i++) {
			if(Connection[i] == NULL)
				return i;
		}

		printf("Connections are all Full!!!\n");
		exit(2);
		return 0;

	}

};

#endif

