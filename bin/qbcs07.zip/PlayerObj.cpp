#include "PlayerObj.h"

//************************************
//
// Check to see if player is dead by looking at model frames
//
//************************************

unsigned char PlayerObj::Dead() {

	if(NullEntity())
		return 1;

	if(((*PlayerEntity)->Frame < 48 || (*PlayerEntity)->Frame >= 103) && (*PlayerEntity)->Frame != 0)
		return 0; 
	else
		return 1;
}


//************************************
//
// Sets up command structure for &this player to aim at Target
//
//************************************

float PlayerObj::Aim(PlayerObj *Target) {

	float XOffset, YOffset, ZOffset, XYHyp, XYZHyp, RotationRadian;
	float RotationAngle, InclinationRadian, InclinationAngle;

	if(NullEntity())
		return FLT_MAX;

	XOffset = (*Target->PlayerEntity)->Location[0] - (*PlayerEntity)->Location[0];
	YOffset = (*Target->PlayerEntity)->Location[1] - (*PlayerEntity)->Location[1];
	ZOffset = (*Target->PlayerEntity)->Location[2] - (*PlayerEntity)->Location[2];


	XYHyp = (float) sqrt(pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));

	XYZHyp = (float) sqrt(pow(ZOffset, (float)2.0) + pow(YOffset, (float)2.0) + pow(XOffset, (float)2.0));

	RotationRadian = (float) asin(YOffset/XYHyp);

	RotationAngle = (float) (RotationRadian / (3.14/2.0)) * 90;

	InclinationRadian = (float) -asin(ZOffset/XYZHyp);

	InclinationAngle = (float) (InclinationRadian / (3.14/2.0)) * 90;

	if(XOffset < 0)
		RotationAngle = 180 - RotationAngle;

	if(RotationAngle < 0)
		RotationAngle += 360;

	CommandRotation = RotationAngle;
	CommandViewAngle = InclinationAngle;
	return XYZHyp;

}


float PlayerObj::Distance(PlayerObj *Target) {

	if(NullEntity())
		return FLT_MAX;
	return (*PlayerEntity)->Distance((*Target->PlayerEntity));

}

void PlayerObj::SelectBestWeapon(){  // Select Best Weapon

	if((Items & IT_LIGHTNING) && (AmmoCells > 0)) // Got lightning gun and cells
		CommandWeapon = SELECT_WEAPON_LIGHTNING;
	else if((Items & IT_ROCKET_LAUNCHER) && (AmmoRockets > 0))  // Got Rocket and Rockets
		CommandWeapon = SELECT_WEAPON_ROCKET;
	else if((Items & IT_GRENADE_LAUNCHER) && (AmmoRockets > 0))  // Got Grenade and Rockets
		CommandWeapon = SELECT_WEAPON_GRENADE;
	else if((Items & IT_SUPER_NAILGUN) && (AmmoNails > 0))  // Got super nailgun and nails
		CommandWeapon = SELECT_WEAPON_SUPER_NAILGUN;
	else if((Items & IT_NAILGUN) && (AmmoNails > 0))  // Got nailgun and nails
		CommandWeapon = SELECT_WEAPON_NAILGUN;
	else if((Items & IT_SUPER_SHOTGUN) && (AmmoShells > 0))  // Got super shotgun and shells
		CommandWeapon = SELECT_WEAPON_SUPER_SHOTGUN;
	else if((Items & IT_SHOTGUN) && (AmmoShells > 0))  // Got shotgun and shells
		CommandWeapon = SELECT_WEAPON_SHOTGUN;
	else if(Items & IT_AXE) // Use da' AXE
		CommandWeapon = SELECT_WEAPON_AXE;
	else
		CommandWeapon = SELECT_WEAPON_NONE;

}
//*****************************************
//
//	Pick a weapon that wont kill you!!!
//	This is subjective since I can select the thunderbolt also.
//
//*****************************************
void PlayerObj::SelectSafeWeapon(){ 


	if((Items & IT_LIGHTNING) && (AmmoCells > 0))  // Got lightning gun and cells
		CommandWeapon = SELECT_WEAPON_LIGHTNING;
	else if((Items & IT_SUPER_NAILGUN) && (AmmoNails > 0))  // Got super nailgun and nails
		CommandWeapon = SELECT_WEAPON_SUPER_NAILGUN;
	else if((Items & IT_NAILGUN) && (AmmoNails > 0))  // Got nailgun and nails
		CommandWeapon = SELECT_WEAPON_NAILGUN;
	else if((Items & IT_SUPER_SHOTGUN) && (AmmoShells > 0))  // Got super shotgun and shells
		CommandWeapon = SELECT_WEAPON_SUPER_SHOTGUN;
	else if((Items & IT_SHOTGUN) && (AmmoShells > 0))  // Got shotgun and shells
		CommandWeapon = SELECT_WEAPON_SHOTGUN;
	else if(Items & IT_AXE) // Use da' AXE
		CommandWeapon = SELECT_WEAPON_AXE;
	else
		CommandWeapon = SELECT_WEAPON_NONE;  // This actually does occur
											// For servers with observers
}

//************************************
//
// Sets up command structure for &this player to aim at Target
//
//************************************

void PlayerObj::Reset() {

		AmmoShells = 0;
		AmmoNails = 0;
		AmmoRockets = 0;
		AmmoCells = 0;

		ArmorValue = 0;
		Health = 0;

		Items = 0x0000;

		Dormant = 1;

}

int PlayerObj::NullEntity() {
	
	if((*PlayerEntity) == NULL) {
		printf("Attempted to access a non-existant entity\n!!!");
		return 1;
	} else
		return 0;
}

	