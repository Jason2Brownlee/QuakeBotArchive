#ifndef CONSOLEOBJ_H
#define CONSOLEOBJ_H

#include "ServerObj.h"

#ifndef __unix__
 #include <conio.h>
 #include <stdarg.h>
#else
 #include <varargs.h>
#endif

class ServerObj;

class ConsoleObj {

private:

	char InputBuffer[0xFF], OutputBuffer[0xFF];
	ServerObj *QuakeServer;

#ifndef __unix__
	HANDLE ConsoleHandle;
	CONSOLE_SCREEN_BUFFER_INFO Csbi;
	COORD CursorPosition, PromptPosition;
#endif
	
	void PlayerStatus(PlayerObj *);
	char *StringToken();
	int IntToken();
	void GameStatus();
	void NetworkStatus();
	void EntityInformation(EntityObj *);
	void DisplayDefinedEntities();
	void DisplayWeapon(PlayerObj *);
	void DisplayItems(PlayerObj *);
	void DisplayPlayerStatus(PlayerObj *);
	void DecodeColors(int);

public:

	int ParseString();
	void DisplayString(char *, ...);             
	void SetServer(ServerObj *);
	void GetString();

	ConsoleObj() {

#ifndef __unix__
		ConsoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
//		hinst = GetModuleHandle (NULL);
//		hwnd = GetFocus();
		SetConsoleTitle("QuakeBot C/S");
#endif
		ClearScreen();
	}
	
	void ClearScreen() {
#ifndef __unix__
		DWORD ConsoleSize, Written;

		CursorPosition.X = 0;
		CursorPosition.Y = 0;
		GetConsoleScreenBufferInfo(ConsoleHandle, &Csbi);
		ConsoleSize = Csbi.dwSize.X * Csbi.dwSize.Y;
 
		/* fill the entire screen with blanks */
 
		FillConsoleOutputCharacter( ConsoleHandle, (TCHAR) ' ', 
			ConsoleSize, CursorPosition, &Written );
#endif

	}
};


#endif

