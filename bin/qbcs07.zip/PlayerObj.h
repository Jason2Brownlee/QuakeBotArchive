#ifndef PLAYEROBJ_H
#define PLAYEROBJ_H

#include "PacketObj.h"
#include "EntityObj.h"
#include <limits.h>
#include <float.h>

#define KEY_ACTION_NONE 0x00
#define KEY_ACTION_FIRE 0x01
#define KEY_ACTION_JUMP 0x02

#define IT_SHOTGUN			0x01
#define IT_SUPER_SHOTGUN	0x02
#define IT_NAILGUN			0x04
#define IT_SUPER_NAILGUN	0x08
#define IT_GRENADE_LAUNCHER	0x10
#define IT_ROCKET_LAUNCHER	0x20
#define IT_LIGHTNING		0x40
#define IT_EXTRA_WEAPON		0x80
#define IT_SHELLS			0x100
#define IT_NAILS			0x200
#define IT_ROCKETS			0x400
#define IT_CELLS			0x800
#define IT_AXE				0x1000
#define	IT_ARMOR1			0x2000
#define IT_ARMOR2			0x4000
#define IT_ARMOR3			0x8000
#define IT_SUPERHEALTH		0x10000
#define IT_KEY1				0x20000
#define IT_KEY2				0x40000
#define IT_INVISIBILITY		0x80000
#define IT_INVULNERABILITY	0x100000
#define IT_SUIT				0x200000
#define	IT_QUAD				0x400000

#define SELECT_WEAPON_NONE			0x00
#define SELECT_WEAPON_AXE			0x01
#define SELECT_WEAPON_SHOTGUN		0x02
#define SELECT_WEAPON_SUPER_SHOTGUN 0x03
#define SELECT_WEAPON_NAILGUN		0x04
#define SELECT_WEAPON_SUPER_NAILGUN 0x05
#define SELECT_WEAPON_GRENADE		0x06
#define SELECT_WEAPON_ROCKET		0x07
#define SELECT_WEAPON_LIGHTNING		0x08


class PlayerObj {

public:

	float Velocity[3];
	char *Name;

	int PlayerID; // My index into player array, for entity references.

	EntityObj **PlayerEntity; // Pointer to location wher my associated 
							 // entity is stored

	int Attacker;

	short Entity;
	short Frags;				// duh
	short Health;

	void DisplayWeapon();
	void DisplayStatus();

	unsigned char Dormant; 

	unsigned char ArmorValue;
	unsigned char WeaponModel;
	unsigned char WeaponFrame;
	unsigned char CurrentAmmo;
	unsigned char AmmoShells;
	unsigned char AmmoNails;
	unsigned char AmmoRockets;
	unsigned char AmmoCells;
	unsigned char Weapon;
	unsigned char ShirtColor;
	unsigned char PantColor;
	unsigned char Visible;


	long PlayerState[0x1f];		// Player State
	long Items;					// Inventory

	// Client Command structure
	float CommandTimeStamp; // Some type of time stamp
    float CommandRollAngle; //
	float CommandViewAngle; // 00: Horizontal, Positive down, negative up
    float CommandRotation; // Absolute Rotation
    short CommandInlineSpeed; // Speed in forward/reverse
    short CommandLateralSpeed; // Speed, side to side
    short CommandVerticalSpeed; // Speed, side to side
    char  CommandActions; // 01=Fire, 02 Jump
    char  CommandWeapon; 

	float Aim(PlayerObj *);
	float Distance(PlayerObj *);
	void SelectBestWeapon();
	void SelectSafeWeapon();
	void Reset();
	void DisplayItems();
	void DisplayColors();
	void DecodeColors(int);
	unsigned char Dead();
	int NullEntity();


	PlayerObj() {

		int i;

		for(i=0; i<3; i++) {
			Velocity[i] = (float)0.0;
		}
		Name = NULL;


		CommandInlineSpeed = 0x00;
		CommandLateralSpeed = 0;
		CommandVerticalSpeed = 0x00;
		CommandRollAngle = (float) 0x00;
		CommandViewAngle = (float) 0x0;
		CommandRotation = (float) 0.0;
		CommandActions = 0;	
		CommandWeapon = 0;


		Reset();
	}


};



#endif
