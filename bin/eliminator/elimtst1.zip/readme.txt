Eliminator Bot for id Software's Quake
       -- Construction Set --
--------------------------------------

Archive Version 1.1  (Public Release)
CBOT-Engine Version 1.1

Copyright 1996, Cameron B. Newham.


0) What this is About
1) Unpacking the Archive
2) Installing
3) Using
4) Legal
5) Credits



0. What this is About
---------------------
This is the Construction Set for the Eliminator Bot Patch.

Included is a copy of the CBot engine, switched to Level
Debugging Mode.

Information on waypoints can be found in the Eliminator Waypoint Guide

DO NOT use this version as a multi-player server. It is meant
for waypoint design and level debugging ONLY.

For updates, see the CBOT homepage:

http://www.iinet.com.au/~cam/quakec.html


1. Unpacking the Archive
------------------------

This archive should include the following files:

README.TXT        - This file
ELIMTST1.TXT      - The FTP Description file
PROGS.DAT         - The compiled Quake C code
EXAMP.MAP         - The entities for the start level example
ELIMWPT.TXT       - The Eliminator Waypoint Guide document

Create a directory (eg: "ELIM") in your Quake directory. Also create
a MAPS directory under this.  Unzip the archive in ELIM. Move the
.MAP files to the MAPS directory.



2. Installing
-------------

You'll need a number things to install this patch:

  * An "unpacker" to extract the levels from the Quake PAK file
    I suggest something like "winpack".  Check out a Quake FTP
    site (eg: ftp.cdrom.com) for one.

  * QBSP or a derivative (eg: Power QBSP).  Check out a Quake
    FTP site for a version for your system.  There are also
    entity replacers available - you can also use these.

Unpack the levels from the PAK0.PAK file (in QUAKE\ID1). You only
need to extract START.BSP.  Place this file
in the your ELIM\MAPS directory.

Rename START.BSP to EXAMP.BSP.

Now, replace the entities (using QBSP or another entity replacement
program) with the ones defined in this archives MAP file.  For
example, using QBSP and in the ELIM\MAPS directory, you'd type:

  qbsp -onlyents examp.map

Make sure you *type -onlyents*. This will replace *only* the entities
and won't attempt to compile the BSP from the MAP file. If you forget,
you'll probably get an error - the MAP files only contain the entity
information and not the brush details.  If this has gone over your head,
don't worry - just follow the above instructions!

Also note that you don't have to use VIS or LIGHT on the files.

The MAP changes will now have been applied to the BSP files.  All you
have to do now is...

Run Quake.  Use the following command line to run it:

  quake -listen -game elim

This places Quake in Listen mode (Deathmatch) and tells Quake to
use the new PROGS.DAT and the new maps in your ELIM directory tree.

To actually see the example, change to the new map by bringing down
the console and typing:

map examp


3. Using
--------

On the level you can create a cbot by typing

  impulse 166

at the Quake Console.  I suggest you bind this to a key. From the Quake
Console, type:

  bind b "impulse 166"

and then every time you hit the "b" key you'll get a cbot.

The following commands are available:

  impulse 166   - create a cbot (up to a maximum of 10).
  impulse 170   - view the gib scores for the cbots.
  impulse 180   - go to observer mode
  impulse 202   - print your current position and facing angle

Impulse 166 creates a cbot just ahead of you.

Observer Mode - when you enter this mode you won't be able to exit
it unless you change levels or specifically kill yourself using
the "kill" command at the console.

In Observer Mode you can move around the map without affecting
it or other players.  Make sure you remain *inside* rooms to
be able to view other players.


4. Legal
--------

Quake is a Tradmark of id Software.

All parts of this software not coded by myself are Copyright
id Software.

The CBOT Engine and associated MAP file components are Copyright 1996,
Cameron Newham.

This software is provided "as is".  There is no warrenty either
expressed or implied.  USE AT YOUR OWN RISK.  The author cannot be
held responsible for any loss or damages incurred from use of
this software.

You are permitted to copy and redistribute this archive AS LONG
AS THIS TEXT FILE and the other files in the archive REMAIN INTACT 
AND UN-ALTERED.

You are permitted to use the CBOT Engine with other MAP file
information that you create or on any public or private Quake
server.



5. Credits
----------

Thanks to id Software for such an excellent game.

The following people kindly helped me Beta Test the patch:

Roger Bolton
Rowan Crawford ("Sumaleth" on IRC)
Ben Schaffer

Thanks also to

Thane Sherrington - idea of auto-generation of cbots on startup

Thanks to everyone for helpful comments and suggestions!


I hope that you enjoy this patch!

cameron newham (cam@iinet.com.au)

