OrionBots Fourth Release - Rocket Arena

==============
QC files: yes
Models: no
Sounds: no
==============


Features:

*Improved bot finding and following target;
*The bots now follow their enemies through teleporters;
*Improved roaming;
*Rocket arena support;
*Some changes when picking up weapons/ammo (see tweaks);
*Improved swimming AI;
*Client physics emulation (yes, i did it! =D);
*KasCam (impulse 14 to activate it).


Tweaks:

*Super Shotgun now gives you 20 shells instead of only 5 (dropped: 10);
*Nailgun, Super Nailgun: 50 nails;
*Grenade Launcher, Rocket Launcher: 10 rockets;
*Lightning Gun: 25 cells (dropped: 30).
*Small cells box: 15;
*Large cells box: 25;
*The bots and players will drop their current weapon instead of a backpack.


How to install:

To install you must have the orionbots_v2.zip installed, you can get it here: 
http://shub-hub.quaddicted.com/files/mods_multiplayer/orionbots_v2.zip

Once you have installed orionbots_v2, extract all stuff to quake/orionbots directory.

Now with a pak editor, open pak0.pak, and remove the old progs.dat from it and you're ready! =)


To play rocket arena:

Type "deathmatch 5" without quotes at the console, if you're running a server, restart it, run any rocket arena map if 
you have, when the map is running, type "impulse 100" without quotes at the console to add a bot 
(can do it repeatedly and in normal deathmatch).
Add one or more bots then type "impulse 150" without quotes at the console, then 2 players or bots will teleport to the arena,
and you don't need to type impulse 150 every time, when someone dies, will wait a while, reset the winner's health and ammo,
then teleport another contestant.

Have fun!