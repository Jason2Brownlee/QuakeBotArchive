Title    : Xreaper
Filename : xreaper130.zip
Version  : Beta 1.30
Date     : 23/12/01
Author   : Ruud 'Mephisto' Heemskerk
Email    : mephisto@planetquake.com
Homepage : http://www.planetquake.com/botarea51
Credits  : Id for quake, all quakeC authors, quakeC tool authors,
           Cyber (aka 'dranko') & Drake (aka 'draakje') for testing and all fun LAN hours,
           all users for reporting bugs and posting their suggestions,
           and Randar (http://www.users.qwest.net/~mimpchnk/)
	   

Type of Mod
-----------
Quake C  : yes
Sound    : yes
MDL      : yes
Level    : no


Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no
context diff  : no
.qc files     : no 
progs.dat     : yes


Description of the Modification
-------------------------------
This mod is really a modification of the reformed reaperbot,
one of the best bots around. The bot can be found on the internet.
The Xreaper quakeC project is something like a hobby,
I've been coding in quakeC a long time ago making small weapon patches, and
when I recently saw this project again I was thinking why shouldn't I finish
it to a mod and make it pulic available for the 'veterans' who still play quake?
That's what I did and I would be very pleased if you would send me some feedback and
tell me what you think of it!

The bot has been improved and several bugs are fixed.
There are some great gameplay improvements for some serious deathmatch action:

- reformed reaper bots : Intelligent emulated opponents.
- multimapcycle : You can create multiple mapcycles,
  and in-game specify the one you want to use.
- deathmatch 3 : Deathmatch 3 rules; weapons stay, respawn items.
- deathmatch 4 : [Unofficial] Deathmatch 4 rules; weapons stay, 1/2 respawn time.
- multiple skins : Multiple skin support, you can choose 1 out of 20 skins,
  including gibbed head skins.
- ycam chasecam (by Harvey Lee) : Chasecam for in deathmatch.
- hook : Grapple hook, implemented as a new weapon (The Cool TeamFortress Model).
- intermission music : Intermission music, when the game is over you hear some music.
- damage depend on hit : The damage inflicted by the shotuns, nailguns and axe are now
  now depends on where the enemy is hit. A shot in the head does almost twice the damage
  as a shot in the chest. And a shot in the legs is does half the damage as a shot in
  the chest. So next time you shoot an enemy, try to aim at the right places, the head or
  chest that is.


How to Install the Modification
-------------------------------
- Unzip this file into your quake directory, using "use folder names".
  There will be a new directory in your quake dir called \xreaper.
- If you are new to setting up a botgame or a server, simply go
  to the \xreaper\batch directory, here are two batfiles, one for a
  listen and one for a dedicated server.
  Edit these files to your needs, like if you use an executable
  other then the normal quake.exe, or if you use more or less winmem,
  and stuff.
  Winmem is currently set to 16mb which should be good for most computers.
- Be sure to read docs\variables.txt for more game variables to configure the game.
- Check the cfg\binds.cfg for new key bindings and adjust them to your needs.
- Run the batch\sv_listen.bat file to start a game and use the 'b' key to add a bot.


Impulses
--------
See docs\impulse.txt for the impulses.
See cfg\binds.cfg for the current bindings.


Variables
---------
See docs\variables.txt for detailed variables.


Technical Details
-----------------
- The source parsed with preqcc 1.04.
- Progs.dat was compiled with frikqcc 2.2 by Ryan Smith.


Bugs
----
- The bots won't reenter the game when you use "changelevel" from the console. They will
  reenter the next level after timelimit or the fraglimit is hit.
- Sometimes the bots get stuck.
- Connected player gets skin from last one who is connected.


Revision History
----------------
Beta 1.30 [19-12-2001] :
	- Rewritten botspawn code.
	- Rewritten temp1 var use.
	- Bot chat fixed.
	- Various bugfixes.
	- Default mapcycle enhanced.
	- Removed admin, was not very useful and safe.
	- Removed skin at spawn.	

Beta 1.23 [18/09/2001] :
	- New damage handling for shotguns, nailguns and axe, the amount now depends
          on where the target is hit.
	- New message at start.
	- Fixed teamplay mode bug.
	- Fixed YCam drawviewmodel bug.
	- Bottargeting adjustment.
	- Skin mode toggle.

Beta 1.22 [20/12/2000] :
	- Server-side skinshow variable (scratch3).
	- Implemented centerprint leader messages in admin.
	- Implemented centerprint skin at respawn message in admin.
	- Fixed bot "stuck-at-spawn" bug.
	- Fixed admin serverinfo mapcycle variable bug.
Beta 1.21 [14/12/2000] :
	- Created player head skins.
	- Fixed bot disconnect bug.
	- Fixed skinbug, it changed sometimes when respawning.
	  - Revealed a new one; a connected client starts with server skin.
	- Fixed double connect message bug.
Beta 1.20 [23/11/2000] :
	- Removed kascam support, gave major errors.
	- Entities freeze at intermission, cool effect.
	- Fixed intermission bugs.
	- Fixed hook-intermission bug, hook would stay in an intermission.
Beta 1.10 [12/11/2000] :
	- Admin server info impulse added.
	- Multiple mapcycle usage implemented.
	- Revised mapcycles
	- Revised all cfg files.
	- Mapcycle added to admin.
	- Samelevel extended at admin.
	- Fixed bug that sometimes a level was skipped when pushing multiple times
	  in the intermission.
Beta 1.00 [08/11/2000] :
	- First version.


Copyright and Distribution Permissions
--------------------------------------
You are allowed to use and distribute this mod as long as the archive and this
text file remains intact and the mod is provided free of charge.
You *are* allowed to modify and incorporate this mod into your own mods,
as long as adequate credit is given and the end result of your modifications
is also provided free of charge.
For questions or comments regarding the please write me at rs_heemskerk@hotmail.com.


Availability
------------
This modification is available from the following places:
http://www.planetquake.com/botarea51

