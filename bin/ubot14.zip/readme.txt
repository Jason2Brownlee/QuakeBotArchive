=========================================================================
 The UnknownBot!                                v1.4
 by Brian L. (aka UnknownBot)
.........................................................................

=========================================================================
Title                   : UnknownBot
Author                  : Brian L (aka UnknownBot)
Homepage                : http://members.xoom.com/unknownbot
Email Address           : unknownbot@hotmail.com

Description             : Human-like AI for Simulated Quake
                           Deathmatch play

Additional Credits to   : id Software for being id Software,
                          and Coffee's great tutorials 

Build Time              : ~1500 or more coding, lots of hours testing
=========================================================================

DESCRIPTION

  There's nothing new just that they avoid the slime and lava better.  
  I'm still new to QuakeC so bare with me! hehe  Just help a little.
  I'm a newbie. :=)  

RUNNING THE GAME

  cd\quake
  quake.exe -listen 16 -game ubot

IMPULSES

  Impulse 100 - Binded as 'b';


Contact me at:

  unknownbot@hotmail.com