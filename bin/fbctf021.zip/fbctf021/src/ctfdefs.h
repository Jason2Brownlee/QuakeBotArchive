/****************************************************************************
 * ThreeWave Capture The Flag
 ****************************************************************************
 * Based on John Spikles Complete Enhanced Teamplay
 ****************************************************************************
 * Version 4.0 rewrite Mar 21, 1997
 ****************************************************************************/

void(entity e) remove_apply = #15;

// motd
.float writer_seconds;
string string_one;
.entity writer;
void() WriterStep;

.string stringname;
.float creepflags;

float yellowdot   = 143;
float exclamation = 33;
float apostrophe  = 39;

//float redteam     = 68;
//float blueteam    = 221;

.float laststattime;		// time of last status update
.float statstate;			// is the status bar on?
float teamscr1;			    // team 1's teamscr score
float teamscr2;			    // team 2's teamscr score
float lastteamscrtime;		// last time we calculated it
float TEAMSCRTIME = 1;

// detailed scores
.float		num_kills;			// CTFBOT EXTRAS number of kills
.float		num_deaths;			// CTFBOT EXTRAS number of deaths
.float		num_suicides;		// CTFBOT EXTRAS number of suicides
.float		num_captures;		// CTFBOT EXTRAS number of personal flag captures 
.float 		num_pickups;		// CTFBOT EXTRAS number of personal enemy flag pickups
.float 		num_recovery;		// CTFBOT EXTRAS number of flag recoveries
.float 		num_assists;		// CTFBOT EXTRAS number of assists
.float 		num_bonus;			// CTFBOT EXTRAS number of general bonuses

.float escort_time;
.float help_teammate_time;
.entity escort_entity;
.float workaround; // flag floating bug

void() ForceGib;
void() goal_cells;
void() goal_rockets;
void() goal_spikes;
void() goal_health_backpack;

void(vector org, entity death_owner) spawn_tdeath;

void(entity who, string s) TeamPlayerUpdate;
void(float to, entity client) SetColorName;
void() ChangeTeam;
float (float myTeam) IsHumanOnTeam;
float (float myTeam) NumPlayersOnMyTeam;
void(vector org, entity e) spawn_tfog;
void() UpdateGoalEntity;
entity(vector org) LocateMarker;
void() DetailedScoresBroadcast;
void() TeamCaptureFlagThink;
void(entity e) UpdateFrags;
void() TeamCaptureRegenFlags;
float teamScorePrintTime;
void() TeamCaptureResetUpdate;
void() goal_flag_team1;
void() goal_flag_team2;
void() goal_base_1;
void() goal_base_2;
void(entity e) InitTouchMarker;
void(entity e) Flag_InitGoalBase;

float TEAM_PRINT_DELAY =	45;	
float BOT_ATTACK = 1;
float BOT_DEFEND = 2;
float BOT_ROAM   = 3;
float BOT_ESCORT = 4;
float ESCORT_TIME = 120;

float BASE_WEIGHT = 1000;
float FLAG_WEIGHT = 1000; 
  
float red_base_count = 0;
float blue_base_count = 0;

.float      motd;
.float		killed;			// have we been killed yet
.float      escort_time;
.entity     escort_entity;
.float      bot_plan;
.float      update_plan_time;

entity lastspawn;

void() goal_supershotgun1;
void() goal_nailgun1;
void() goal_supernailgun1;
void() goal_grenadelauncher1;
void() goal_rocketlauncher1;
void() goal_lightning1;
void() bf;
void() bound_ammo;
void() W_SetCurrentAmmo;
void(float new) Deathmatch_Weapon;
void() ResquestEscort;
void() SetBotPlan;
void() not_supported;

entity redflag, blueflag;
float item_flag1, item_flag2;

.string oldmodel;
.string stringname;
.float last_returned_flag;
.float last_fragged_carrier;
.float last_hurt_carrier;
.float flag_check_invisible_finished;
.float ident_stat;

// *XXX* EXPERT CTF
.float flag_since;

// high chars

float __A = 193;
float __B = 194;
float __C = 195;
float __D = 196;
float __E = 197;
float __F = 198;
float __G = 199;
float __H = 200;
float __I = 201;
float __J = 202;
float __K = 203;
float __L = 204;
float __M = 205;
float __N = 206;
float __O = 207;
float __P = 208;
float __Q = 209;
float __R = 210;
float __S = 211;
float __T = 212;
float __U = 213;
float __V = 214;
float __W = 215;
float __X = 216;
float __Y = 217;
float __Z = 218;
float __exclamation = 161;
