Nirvana Final: Awakening of the Artificial
A SP and COOP compilation modification for Quake
by Arwing
C. A. Dozier

//////////////////
Features:
//////////////////

-FrikBot n6 (with multimodel support) (3 skill levels)
-Automatic Lasersight
-Advanced Enemy AI

(For Deathmatch modes 3 and 5, you MUST be using the command line parameter "-listen 16")

-Deathmatch modes
	1 - normal
	2 - weapons stay
	3 - STROGGS vs. HUMANS
        5 - WAR ZONE mode(stroggs and humans free for all)
-Coop modes (type coop # at the console)
	1 - regular
	2 - extreme (regenerating monsters)
//Ycam

-Chasecam (impulse 15 - Classic Quake only)

//Bots

impulse 101 (frikbot or enemy bot in teamplay)
impulse 100 (frikbot or friendly bot in teamplay)
impulse 21 (Nirvana Bot: works only in deathmatch 1 and 2)

//Multimodel

-Multimodel Q2 Female (impulse 16)
-Multimodel Q2 Male (impulse 17)
-Multimodel Q2 Monstrous (impulse 18)
-Multimodel Quake Guy (impulse 20)

/////////////////
Description:
/////////////////

Nirvana Final: Awakening of the Artificial is a mod for both single player and deathmatch
that holds one purpose: to train the player in the arts of virtual self defense. In
single player, you will find the enemies very agressive and active. They know every level
by heart, every combat trick in the book, and hold underneath their make-believe skins
everything needed to torment the player, all under the same rules and constraints the player uses. The AI is cognition-based, using dozens of variables to make every action possible.

In deathmatch the AI, is both fierce and cunning, more so than in SP. In teamplay, the monsters are their own team, whole and unified. Be warned.