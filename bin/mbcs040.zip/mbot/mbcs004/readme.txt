+--------------------------------------------------------+
|    mikeBot Client-Server Bot Base Code version 0.40    |
|    released June.28.1998                               |
+--------------------------------------------------------+
|                                                        |
|   copyright (c) 1997 Mike Warren. All rights reserved  |
|                                                        |
|   Web  ::   http://www.planetquake.com/mikebot         |
|             http://www.ucalgary.ca/~mbwarren           |
| email  ::   mbwarren@acs.ucalgary.ca                   |
|             mike@botauthors.org                        |
|                                                        |
+--------------------------------------------------------+

1.0  Copyright

	This code and the accompaning documentation is copyright
1997 Mike Warren. You may not distribute it, sell it or in any 
way make money off it without the written consent of the author.
You must also include this copyright, and a link to The mikeBot
Project <www.planetquake.com/mikebot> in anything you do eventually
distribute (i.e. a binary).

2.0  Introduction

	This code will allow you to easily create a client-side 
autonomous quake-bot. I do not support the creation of cyborg bots
such as Stooge Bot and Loef Bot (however, Stooge Bot is very well done
and has many safeties to make it "nice". LoefBot is not as well 
behaved).

	The "skeleton" AI which comes with the code (MBFIRE and MBNAV
classes) currently don't do too much, but that's the point; they are
all ready for you to add your own AI routines. The bot currently shoots
at the closest visible player and runs after anything that firecontrol
is targeting, or the nearest health or ammo if firecontrol doesn't have
a target.

	See the files mbnav.cpp and mbfire.cpp for some comments and
suggestions for improvement of the fire and navigation routines.


3.0  Compatability

	I have compiled version 0.31 successfully on Windows 95 with 
Microsoft Visual C++ 4.0, SunOS with g++ and CC and AIX 4.1.4 with
xlC. I presume it will compile with Linux since g++ (GNU C++) compiles
it. Since I didn't have a lot of time around the release of 0.40, I
can only verify that it compiles under Windows 95 using MSVC++ 4.0.

	If anyone has problems compiling on these systems, or has success
compiling it on the same or different systems with different compilers, 
*please* mail me about it.


4.0  Installation

	Unzip the "code.zip" file into a fresh directory. Unzip the
"documentation.zip" file into its own directory. Using your favorite
web browser (I recomment Internet Explorer) open the "csbase.html"
file in the documentation directory and click on the "setup" heading
in the left-most frame. This will explain how to compile with
Unix and Microsoft Visual C++ 4.0. (NB: If you don't have a frames-compliant
web browser, open the file "setup.html")

	IMPORTANT: You must add the "wsock.lib" libruary to the link
line if you are compiling on a Windows system; the documentation explains
how to do this for MSVC++.

	MORE IMPORTANT: Look in the "defines.h" file for information on
which #define settings you need for your system.


5.0  Documentation

	If you have any questions about or problems with the documentation, 
*please* tell me. There is no point in having documentation if it is unclear 
or doesn't answer your questions. Be sure to check the web page also (under "C++ Source Code"
and "Source Feedback") for more information. Don't be afraid to email me, though.


6.0  Author/Support

	Please email me any questions or comments you have about the
code (good or bad). There is a source code feedback/question and answer
page on my web page (http://www.planetquake.com/mikebot), so look there
for an answer first. However, don't be afraid to email me; I don't bite :)

	
	
	