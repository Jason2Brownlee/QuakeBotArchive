/*====================================*\
|| KNBOT - Header File                ||
|| by: Ken Madlener                   ||
|| mail: kenzer@D219-2.ibk.fnt.hvu.nl ||
\*====================================*/

// Global Constants

float   BOT_CREATE                              = 100;          // impulse constant
float   BOT_CREATE4                             = 101;          // spawn 4 bots
float   BOT_VERBOSE                             = 102;          // verbose bots
float   BOT_COMMENT                             = 103;          // bots comment
float   BOT_SCORES                              = 104;          // score printing

// Bot Prototypes - called by player

void ()                 Bot_Precache;           // Precache information for the bot
void (string name)      BotCreate;              // Creating Bots


float   BOT_LEAD_TIME = 10;
float   BOT_LEAD_DIST = 65;
float   ROAM_DEVEL = 0;

// Prototypes

float   ()                                              bot_bestweapon;
void    ()                                              bot_SetCurrentAmmo;
float   ()                                              bot_CheckNoAmmo;
void    ()                                              bot_attack;
void    ()                                              botrespawn;
void    ()                                              bot_counter_use;
void    ()                                              bot_trigger_onlyregistered_touch;
float   ()                                              BotFindTarget;
float   ()                                              BotFindStuff;
void    ()                                              bot_ai_stand;
void    (entity attacker, float damage)                 bot_pain;
void    ()                                              bot_die;
void    ()                                              BotFoundTarget;
void    ()                                              BotHuntTarget;
void    ()                                              BotFoundStuff;
void    ()                                              BotHuntStuff;
void    (float dist)                                    bot_ai_walk;
void    (float dist)                                    bot_ai_run;
void    (float dist)                                    bot_ai_stuff;
void    (void () thinkst)                               BotCheckRefire;
void    ()                                              BotSelfDeActivate;
void    ()                                              bot_FireNail;
void    ()                                              bot_FireSuperNail;
void    (vector org, vector dir)                        launch_spike;
void    ()                                              spike_touch; 
void    ()                                              bot_ai_run_slide;
void    (float dist)                                    bot_ai_follow;
void    ()                                              bot_ai_face;
void    ()                                              update_enemydist;
