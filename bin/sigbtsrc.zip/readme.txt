Sigmund Bot Source Code Agreement (read before doing anything else)

If the contents of this archive are used in any way, full credit must be given to the
author for whatever they're used for. If the contents of this archive are in any way
used in a commercial product, the author must be notified and his blessing (after
coming to a financial agreement) must be given before the product can be distributed.

Failure to obey these conditions can and will result in legal action.
