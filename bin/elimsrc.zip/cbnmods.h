float IT_NONE = 8388608;  // no weapon for cbot

float SEARCH    = 2;  // cbot modes
float CAMPER    = 4;
float WITHDRAW  = 8;
float OTFATTACK = 16;
float ATTACK    = 32;
float JUMP      = 64;

//taken from client.qc
float   modelindex_eyes, modelindex_player;

float cbotnum;  // what number we are up to.

.float goal_status; // the bots goal status:
                    // 0 = seeking off-route
                    // 1 = seeking on-route
                    // 2 = sub-goal off-route
                    // 3 = sub-goal on-route
                    // 4 = sub-goal backtracking
                    // 10 = attacking
                    // 20 = retreating
                    // 30 = idle

.float  botmode;
.entity origin_save;     // origin position save for sub-routes
.string oldgoalname;     // the goal we had before a sub-goal
.vector old_posn;        // watchdog saved position
.float  watchdog_time;   // time to call watchdog
.float  prioritise_time; // when to think about reorganising our priority list
.float  other_item_time; // time to look for other items (health etc)
.float  camp_time;       // time we sit around a fire for
.float  blasttime;       // how long to turn nail/lightning guns on for
.float  sighted_time;    // how long we wait for an enemy to show in attack
.float ideal_pitch;


//Priority list  (should really be a bit field)
.float pi1;
.float pi2;
.float pi3;
.float pi4;
.float pi5;
.float pi6;
.float pi7;
.float pi8;
.float pi9;

/* prototypes */
void (entity me) CBot_Create;

void () Precache_Cbot_Models;
