#define MAP_dm3
#define MAP_dm4
#define MAP_dm6
#define MAP_ztndm3
