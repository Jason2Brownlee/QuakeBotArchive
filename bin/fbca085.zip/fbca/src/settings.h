// Public
//#define QUAKE
//#define MANUAL
#define CREEPCAM
#define KASCAM
#define MAZE
#define CONSOLE
#define LETTERCODES
#define TALK
#define ARCADE
#define ARENA // Asdf

// Private
#ifndef QUAKE
	#undef CREEPCAM
	#undef KASCAM
	#undef MAZE
	#undef CONSOLE
	#undef ARCADE
#endif
