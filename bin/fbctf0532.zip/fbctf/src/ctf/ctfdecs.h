////////////////////////////////////////////////////
// Frogbot Capture The Flag
// Based on Zoid's Threewave Capture The Flag
// By Gerard Ryan
//
// This code falls under the GNU public license, and cannot be 
// redistributed without the original readme.txt file.


void() WriterStep;
void() UpdatePlan;
void() CheckCombatJump;
void() goal_cells;
void() goal_rockets;
void() goal_spikes;
void() goal_health_backpack;
void() goal_supershotgun1;
void() goal_nailgun1;
void() goal_supernailgun1;
void() goal_grenadelauncher1;
void() goal_rocketlauncher1;
void() goal_lightning1;
void() backpack_touch;

void() adjust_view_ofs_z;
void() marker_touch;
void() bf;
void() bound_ammo;
void() not_supported;
float() pickup_true;
float() W_BestWeapon;
void() AddToQue;
void() SaveFrogbot;
void() AssignVirtualGoal;
void() DropItem;
void() check_marker;
void() ForceGib;
void() ChangeTeam;
void() UpdateGoalEntity;
void() W_SetCurrentAmmo;


void(vector org, entity e) spawn_tfog;
void(float new) Deathmatch_Weapon;
void(vector org, entity death_owner) spawn_tdeath;
void(float to, entity client) SetColorName;
entity(vector org) LocateMarker;
void(entity e) UpdateFrags;
void(entity marker) BecomeMarker;


void(entity e) remove_apply = #15;