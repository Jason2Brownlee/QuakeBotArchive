////////////////////////////////////////////////////
// Frogbot Capture The Flag
// Based on Zoid's Threewave Capture The Flag
// By Gerard Ryan
//
// This code falls under the GNU public license, and cannot be 
// redistributed without the original readme.txt file.


float TEAM_COLOR1       =       5;
float TEAM_COLOR2       =       14;

float team1shirt;
float team2shirt;

entity lastvotespawn;

// Globals

entity search_entity;
entity team1_lastspawn;
entity team2_lastspawn;
float	nextteamupdtime;	// time until next team update
float last_flag_capture;	// time of last capture
float last_capture_team;	// last team that captured

// misc fields
.float  observer;
.float last_check_team;
.float lastteamset;
.float ctf_item;
#ifndef QUAKE
.float ctfskinno;
.string ctfskin;
#endif
// Teamplay bitfield entries

//float TEAM_TOTAL_HEALTH_PROTECT =	1;      // No health damage from friendly fire (including self)
//float TEAM_FRAG_PENALTY =		2;      // One frag penalty for killing teammate
//float TEAM_HEALTH_PROTECT =		3;      // No health damage from friendly fire (excluding self)
//float TEAM_HEALTH_MASK = 		3;
//float TEAM_ARMOR_PROTECT =		4;      // No armor or health damage from friendly fire
float TEAM_DEFAULT_PENALTY =    1;
//float TEAM_DEATH_PENALTY =      5;
//float TEAM_CAPTURE_CAPTURE_BONUS = 15; // what you get for capture
//float TEAM_CAPTURE_TEAM_BONUS = 10; // what your team gets for capture
//float TEAM_CAPTURE_RECOVERY_BONUS = 1; // what you get for recovery
//float TEAM_CAPTURE_FRAG_CARRIER_BONUS = 2; // what you get for fragging
	//enemy flag carrier
//float TEAM_CAPTURE_FLAG_RETURN_TIME = 40; // seconds until auto return

// XXX EXPERT CTF Additional scoring system

// bonuses

//float TEAM_CAPTURE_CARRIER_DANGER_PROTECT_BONUS = 2; // bonus for fraggin someone
// who has recently hurt your flag carrier
//float TEAM_CAPTURE_CARRIER_PROTECT_BONUS = 1; // bonus for fraggin someone while
// either you or your target are near your flag carrier
//float TEAM_CAPTURE_FLAG_DEFENSE_BONUS = 1; // bonus for fraggin someone while
// either you or your target are near your flag
//float TEAM_CAPTURE_RETURN_FLAG_ASSIST_BONUS = 1; // awarded for returning a flag that causes a
// capture to happen almost immediately
//float TEAM_CAPTURE_FRAG_CARRIER_ASSIST_BONUS = 2; // award for fragging a flag carrier if a
// capture happens almost immediately

// radii

//float TEAM_CAPTURE_TARGET_PROTECT_RADIUS = 550; // the radius around an object being
// defended where a target will be worth extra frags
//float TEAM_CAPTURE_ATTACKER_PROTECT_RADIUS = 550; // the radius around an object being
// defended where an attacker will get extra frags when making kills

// timeouts

//float TEAM_CAPTURE_CARRIER_DANGER_PROTECT_TIMEOUT = 4;
//float TEAM_CAPTURE_CARRIER_FLAG_SINCE_TIMEOUT = 2;
//float TEAM_CAPTURE_FRAG_CARRIER_ASSIST_TIMEOUT = 6;
//float TEAM_CAPTURE_RETURN_FLAG_ASSIST_TIMEOUT = 4;

//float TEAM_CAPTURE_UPDATE_TIME = 120;

// END EXPERT CTF

// flag status used in aflag field of flag
float FLAG_AT_BASE = 0;
float FLAG_CARRIED = 1;
float FLAG_DROPPED = 2;

#ifndef QUAKE
float PLAYERSTATTIME = 1.25;
#else
float PLAYERSTATTIME = 1.75;
#endif


// motd
.string string_one, string_two, string_three;
.float writer_seconds;
.entity writer;

.string stringname;
.float creepflags;
.float base;

float yellowdot   = 143;
float exclamation = 33;
float apostrophe  = 39;

//float redteam     = 68;
//float blueteam    = 221;

.float laststattime;		// time of last status update
.float statstate;			// is the status bar on?
float teamscr1;			    // team 1's teamscr score
float teamscr2;			    // team 2's teamscr score
float lastteamscrtime;		// last time we calculated it
float teamScorePrintTime;
float TEAMSCRTIME = 1;

// detailed scores
.float		num_kills;			// CTFBOT EXTRAS number of kills
.float		num_deaths;			// CTFBOT EXTRAS number of deaths
.float		num_suicides;		// CTFBOT EXTRAS number of suicides
.float		num_captures;		// CTFBOT EXTRAS number of personal flag captures 
.float 		num_pickups;		// CTFBOT EXTRAS number of personal enemy flag pickups
.float 		num_recovery;		// CTFBOT EXTRAS number of flag recoveries
.float 		num_assists;		// CTFBOT EXTRAS number of assists
.float 		num_bonus;			// CTFBOT EXTRAS number of general bonuses

.float escort_time;
.float help_teammate_time;
.entity escort_entity;
.float bot_plan;

float TEAM_PRINT_DELAY =	45;	

float BOT_ATTACK 	= 1;
float BOT_DEFEND 	= 2;
float BOT_ROAM   	= 4;
float BOT_ESCORT 	= 8;
float BOT_GATHER_ITEMS	= 16;
float BOT_PREVIOUS_PLAN	= 31;

float ESCORT_TIME = 120;

float BASE_WEIGHT = 275;
float FLAG_WEIGHT = 250; 

float LOAD_DELAY_TIME;

.float 		motd;
.float 		killed;			// have we been killed yet

entity lastspawn;

float item_flag1;
float item_flag2;
float save_blu_team_starts;
float save_red_team_starts;

entity redflag, bluflag;

.float base_count;
.vector t_origin;
.vector redorigin, bluorigin;
.vector red1, red2, red3, red4;
.float redang1, redang2, redang3, redang4;
.vector blu1, blu2, blu3, blu4;
.float bluang1, bluang2, bluang3, bluang4;
.string stringname;

.float last_returned_flag;
.float last_fragged_carrier;
.float last_hurt_carrier;
.float ident_stat;

// *XXX* EXPERT CTF
.float flag_since;

// high chars

float __A = 193;
float __B = 194;
float __C = 195;
float __D = 196;
float __E = 197;
float __F = 198;
float __G = 199;
float __H = 200;
float __I = 201;
float __J = 202;
float __K = 203;
float __L = 204;
float __M = 205;
float __N = 206;
float __O = 207;
float __P = 208;
float __Q = 209;
float __R = 210;
float __S = 211;
float __T = 212;
float __U = 213;
float __V = 214;
float __W = 215;
float __X = 216;
float __Y = 217;
float __Z = 218;
float __exclamation = 161;
