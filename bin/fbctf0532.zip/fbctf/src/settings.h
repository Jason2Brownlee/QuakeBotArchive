// Public
#define QUAKE
#define CREEPCAM
#define KASCAM
#define TALK
#define CTF
//#define RUNAWAY_
//#define HEIGHT
//#define DEBUG
//#define MANUAL
//#define MAZE
//#define CONSOLE
//#define LETTERCODES
//#define ARCADE

// Private
#ifndef QUAKE
	#undef CREEPCAM
	#undef KASCAM
	#undef MAZE
	#undef CONSOLE
	#undef ARCADE
// ctf is broken in QW
	#undef CTF 
//	#define SKILL
#endif

#ifdef DEBUG
	#undef TALK
#endif
#ifdef MANUAL
	#undef CREEPCAM
	#undef KASCAM
	#undef TALK
#endif