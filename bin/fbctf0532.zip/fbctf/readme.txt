Title    : Frogbot Capture the Flag
Filename : fbctf053.zip
Version  : Beta 0.53 - see changes.txt
Date     : 5-08-01
Authors  : Credits below
Email    : ranchhand@eudoramail.com
WWW      : http://www.botepidemic.com/fmods


OVERVIEW:
---------

This modification of the Frogbot is unsupported by the Frogbot author, Robert 
Field. Please direct your suggestions, complaints, and praises to the above 
address. Frogbot CTF is a simple hack to the Frogbot which makes use of Robert 
Field's excellent goal evaluation code. The bot will assess the flags as goals 
based on various criteria: whether the flag is dropped, carried, or at base, what 
team the bot is on and what its current "plan" is: i.e., defend, roam, escort, 
or attack. The bots are autonomous, however you can request an escort if a bot 
is nearby by typing "escort." The bot responding to your request will escort
for 2 minutes. 

   Although the mod has full Threewave support, the Threewave maps can be 
problematic due to their size. Gameplay is very fast if you enable "simple" 
planning, playing with two or three man teams, on a medium sized map. Try ztndm3 
with one flag in the corner stairs near the yellow armor, and the other 
flag placed in the small L-shaped hallway, near the quad.

 
  Frogbot v0.13 bug fixes:
  
  - NaN velocity fix
  - Goal fix
  - Pitch angle fix
  - Improved platform support
  - Improved water support
  - Secret door fix
  - Reduced crashes
  - Improved "oldsolid" hack


INSTRUCTIONS:
-------------

Quickstart:

Create a batch file in the fbctf directory with the following text:

cd..
<yourquake.exe> -listen 16 -zone 4096 -game fbctf +maxplayers 8 +map <supportedmap>

Save the file as type "All Files" and name it "fbctf.bat", with 
<yourquake.exe> being the name of your quake executable (example: winquake.exe),
and <supportedmap> being one of the maps supported (and compiled) in this release.
 
Now invoke this new batch file from your fbctf directory, launching the game.

* See autoexec.cfg for the full list of options, and the default CTF settings.


FLAGS: 
------

There are three choices for flag placement on non-custom ctf maps: 

1. Manual placement

   Enable manual flag placement mode from the console by typing 'setflag'. Then 
   walk to the spot you want to place the flag, and type the team name ('red' or 
   'blue'). 

   - Type "red" to spawn a red flag
   - Type "blue" to spawn a blue flag

   * You may only spawn a flag of the team you are currently on
   * Only Admins can spawn flags and change teams

   Once you fire off the impulse, step back, because the flag will spawn exactly 
   where you are standing. After you've set the flag for one team, switch colors, 
   set the second flag, and play! Be sure to place the flags at adequate distances 
   apart, to ensure challenging gameplay. Also, be careful not to place them too 
   deeply into corners because the bots will have difficulty getting to them. 
   
   NOTE: Manually placed flag positions will persist over level 
         changes if the same map is loaded again.

2. Code based spawning

   Same as above, except begin the game in -condebug mode. To choose team spots, 
   walk to the spot you would like to become a team start and type 'spot' at the 
   console-- or bind a key to the spot command. Once you've spawned both flags, 
   and the team start positions (they're optional; you don't need them to play)
   type 'write' at the console. This will dump the start data to a file named 
   'qconsole.log' (providing you began with "-condebug" in the command line), 
   which will be written in your fbctf directory. Quit the game, open the 
   Qconsole.log file, and look for the formatted code at the bottom. This code 
   should be copied and pasted into the 'mapsnew.qc' module, in the function 
   'CustomSpawn.' Modify CustomSpawn with the new blocks of code like so:

        // add flags and/or teamstarts here
        ...
        else if (mapname == "e1m2") 
    	{
	        SpawnFlag('-533 -495 480', TEAM_COLOR1); 
	        SpawnFlag('1497 1672 288', TEAM_COLOR2);  
        }
        ...

   Now recompile and enjoy customized ctf maps! The advantages of customizing 
   the maps through the code is that the flags will spawn by themselves after a 
   level change, and you don't have to do any bsp editing.


3. See the Threewave document 'capture.txt' by Zoid (included in this archive)
   for modifying bsp files.
   
NOTE: Custom maps have flag positions hard-coded into them, and the maps which 
      have markers in this version of the mod, are already "soft-coded" in the
      mapsnew.qc
      

MAPS:
-----
      
Markers for Escher's Debello and Ultra Violence need to be recompiled into the 
mod. To accomplish this, (or add markers for any map) you need a text editor and 
a copy of Mr. Elusive's Meqcc. The code is already written to support several maps, 
however, you need to uncomment a few lines to use these maps:
   
       maps.h  
       
       Open maps.h and comment out (two forward slashes)
       the first two maps. This is necessary because of the 
       size limitations when compiling quake c. Next, uncomment 
       the #defines (remove the two forward slashes) for MAP_debello 
       and MAP_ultrav. Save and close the file.
       

       Now execute Meqcc from the command line, running it from within the src 
       directory of the fbctf directory. This will generate a file named 
       progs.dat in your fbctf directory.
       

THREEWAVE CUSTOM CTF:
---------------------

It's possible to make use of the Threewave pak0 and pak1 pak files by 
placing them into the fbctf folder and invoking the "custom" command at 
the console. 

      When using the multiwep and custom modes, the additional pak files must 
      be installed!! you can get the Threewave CTF pak0 and pak1 files here:
           
      ftp://ftp.cdrom.com/pub/quake/planetquake/threewave/ctf/client/3wctfc.zip
           
      You can get the pak2 file for Threewave CTF multiwep here:
      
      ftp://numb.macquakeinfinity.com/numb/ctf/pak2pak.zip
      
      
QUAKEWORLD:
-----------

The QuakeWorld version of Frogbot CTF, similar to the normal Quake version, is
a work in progress. There are several features which either haven't been
implemented yet, or need refinement. 

Bots have ping time and packetloss. You can change their ping/pl by addding 
the line:

localinfo botping modem

to your server.cfg (if you're running a qw server), or, you can change bot ping
remotely, by using rcon. There's three possible values for ping/pl: LAN, modem, 
or digital. Digital is the default. These values are purely cosmetic, however, 
I've added some code which supports skill and response time values. This code 
will approximate "ping" and "packetloss" conditions. To enable it in QuakeWorld,
uncomment the "#define SKILL" line in settings.h and recompile the source.


TODO:
-----

1.) Bot Grappling
2.) Better lift and water support
3.) More map support


IMPULSES:
---------------

Game options        - impulse 47 (or type 'options' at the console)
CTF                 - impulse 67 (or type 'ctf' at the console)
Team-Score          - impulse 77 (or type 'score' at the console)
Spawn red flag      - impulse 78 (or type 'red' at the console)
Spawn blue flag     - impulse 79 (or type 'blue' at the console)
Order Escort        - impulse 80 (or type 'escort' at the console)
Identify Player     - impulse 81 (or type 'identify' at the console)
Simple planning     - impulse 82 (or type 'simple' at the console)
Write Positions     - impulse 83 (or type 'write' at the console)
Save Positions      - impulse 84 (or type 'spot' at the console)
RemoveFlags         - impulse 84 (or type 'remove' at the console)
Detailed scores     - impulse 85 (or type 'myscore' at the console)
Status bar          - impulse 86 ('sbar' to toggle, impulses 87 - 96 to set resolution)
Multiwep            - impulse 97 (or type 'multiwep' at the console)
Drop Ring           - impulse 98 (or type 'dropring' at the console)
Drop Quad           - impulse 99 (or type 'dropquad' at the console)
Toss Weapon         - impulse 100 
Toss Backpack       - impulse 101 
NOCLIP & Z movement - impulse 102 in MANUAL mode (or type 'noclipz' at the console)
SetFlags            - impulse 103 (or type 'setflags' at the console)
PrintLocation       - impulse 104 (or type 'loc' at the console)


CREDITS:
--------

Frogbot CTF was developed by Gerard "numb" Ryan

Robert "Frog" Field wrote the awesome Frogbot
This mod uses version 0.13 test
Website: http://www.telefragged.com/metro/

Dave "Zoid" Kirsch for Threewave CTF
Website: http://www.captured.com/threewave/

Dan "Methabol" Zetterstrom for the Pure CTF stuff
Email: metabol@bt.nu
Website: http://purectf.solgames.com/

Matt "asdf" McChesney for help with 0.13 test 'hacks'
Email: Mtm07@hotmail.com

Hylke "gibbie" Beck for the additional waypoints and beta-testing
Email: hylke_b@hotmail.com

The bot planning code is based on Anthony (*this) Distler's Ctfbot+,
(adistler@ace.cs.ohiou.edu) which is based on Drew "BZ" Davidson's 
Ctfbot 1.4. 
Website: http://www.captured.com/ctfbot/
 

COPYRIGHTS & DISTRIBUTION:
--------------------------

The modifications included in this archive are Copyright 1998, Robert
Field, and Copyright 1999, Gerard Ryan. The original QuakeC source is 
Copyright 1996, id software.

You may distribute this Quake modification in any electronic format as
long as:

A.) all the files in this archive are distributed together, and remain 
    intact and unmodified 
    
B.) there are no fees or charges of any kind.


DISCLAIMER:
----------

Software under this agreement is under no kind of warranty. Software
under this agreement is provided as is, and isn't guaranteed in any
way by the mod author. Use this software at your own risk.

