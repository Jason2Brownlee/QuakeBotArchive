#define MAP_dm4
#define MAP_dm6
#define MAP_ztndm3
#define MAP_holy1
#define MAP_holy2
#define MAP_holy3