Battle Mech
by Wazat

To run Battle Mech, type:

quake -game bmech -listen 8 +map test1

(assuming you installed the files into quake/bmech/).

If you use DarkPlaces (or any other engine that slows the turn speed of your mech to unbearable levels) will want to include a command to keep the turn rate up.  You can't fix it completely (will still be way slower than regular quake turning), but it's better than nothing.  For Darkplaces, just add this to anywhere in your commandline:
+sys_ticrate 0.01

For example:
quake -game bmech -listen 8 +map test1 +sys_ticrate 0.01

Really, the best engine to use by far is... regular quake, or winquake.  Neither of those will mess with angle speeds.


How to Play:

In Battle Mech you need only run around, picking up weapons and destroying enemies.  If you wish to get rid of the weapon you are currently carrying, press the weapon drop button; this will allow you to pick up a different weapon (as you can only carry one at a time).


Controls:

Do not delete the autoexec.cfg, it binds your keys for you.

Up, down, left and right keys will move your mech accordingly (you can also go diagonally).

Left mouse button: Fire weapon (can also use CTRL)

Right mouse button: Jump (can also use SHIFT)

Middle mouse button: Drop current weapon (can also use ENTER)


Frikbots:

Frikbots are computer opponents you can fight.  To bring some into the game, use the impulse below.  You must use the -listen parameter in your command line to spawn bots, just like you do to let other people join your server (for example, -listen 8 will allow yourself and 7 other bots or people, for a total of eight players).

100	Add a bot
102	Remove a bot



Changes
=======

v0.4
----



v0.3
----
Fixed camera problems

Added weapon models for all the new weapons

Fixed some aim problems

Increased autoaim fov - it will now aim further to the side with most weapons

v0.2
----

Added new weapons: Flame Thrower, Laser Mine, Rifle, Homing Missile, Navis, and Penetrator.

Added this readme.

Decreased a few problems with turning in some engines

Fixed a few problems
