#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

#include "socket.h"


int sock_client( char *hostname, int port )
{
    int sock;
    
    if( (sock = socket( AF_INET, SOCK_DGRAM, 0 )) == -1 ) 
    {
	perror( "connect: socket" );
	return -1;
    }

    sock = sock_connect( sock, hostname, port );
    return sock;
}

int sock_stream_client( char *hostname, int port )
{
    int sock;
    
    if( (sock = socket( AF_INET, SOCK_STREAM, 0 )) == -1 ) 
    {
	perror( "connect: socket stream" );
	return -1;
    }

    sock = sock_connect( sock, hostname, port );
    return sock;
}



int sock_connect( int sock, char *host, int port )
{
    struct sockaddr_in serv_addr;
    struct hostent *he;

    memset( (char *) &serv_addr, 0, sizeof( serv_addr ) );
    if( (he = gethostbyname( host )) == 0 )
      {
	perror("sock_connect: gethostbyname failed");
	return -1;
      }
    
    serv_addr.sin_addr = *((struct in_addr *)he->h_addr);
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons( port );

    if( connect( sock,
		 (struct sockaddr *) &serv_addr,
		 sizeof( serv_addr ) ) == -1)
      {
	perror("sock_connect: connect failed");
	return -1;
      }

    return sock;
}


int send_packet( int s, unsigned char *buf, int length, int mode )
{
    int count, w;

    count = 0;
    
    do
    {
	if( (w = write( s, &(buf[count]), length - count )) < 0 )
	{
	    perror( "send_packet: write" );
	    return -1;
	}
	count += w;
    } while( count < length && w > 0 );

    if( mode == S_NOISY )
    {
	printf( "Sent:\n" );
	dump_packet( buf, count );
    }

    return( count );
}


int receive_packet( int s, unsigned char *buf, int mode )
{
    short length;
    int r, count;

    count = 0;

    if( (r = read( s, buf, /*5*/ BUFSIZE)) < 0 )
    {
	perror( "receive_packet: read header" );
	return -1;
    }

    count += r;
    length = ((((int) buf[2] << 8)) & 0xFF00) |
	  ((int) buf[3] & 0x00FF);


    while( count < BUFSIZE &&
	   count < length && r > 0 )
    {
	if( (r = read( s, &buf[count], length - count )) < 0 )
	{
	    perror("receive_packet: read");
	    return -1;
	}
	count += r;
    }

    if( mode == S_NOISY )
    {
	printf( "Received:\n" );
	dump_packet( buf, count );
    }
    return count;
}


void dump_packet( unsigned char *pack, int count )
{
    int i;
    unsigned char foo;
    
#ifndef QUIET
    for( i = 0; i < count; i++ )
    {
	foo = pack[i];
	printf( "%d:%02x", i, foo );
	if( foo >= 32 )

	  printf( "'%1c' ", foo );
	else
	  printf( "    " );
    }
    
    printf( "\nPacket size %d bytes\n", count );		
#else
    extern FILE *dumpfp;

    if ( !dumpfp )
      return;
    for( i = 0; i < count; i++ )
    {
	foo = pack[i];
	fprintf( dumpfp, "%02x", foo );
	if( foo > 32 )
	    fprintf( dumpfp, "'%1c' ", foo );
	else
	    fprintf( dumpfp, "    " );
    }
    
    fprintf( dumpfp, "\nPacket size %d bytes\n", count );		
#endif
}


void dump_packet_tight( unsigned char *pack, int count )
{
    int i;
    unsigned char foo;
    
#ifndef QUIET
    for( i = 0; i < count; i++ )
    {
	foo = pack[i];
	printf( "%02x:", foo );
    }
    
    printf( "\n" );		

#else
    extern FILE *dumpfp;

    if ( !dumpfp )
      return;
    for( i = 0; i < count; i++ )
    {
	foo = pack[i];
	fprintf( dumpfp, "%02x:", foo );
    }
    
    fprintf( dumpfp, "\n" );		
#endif

}
