#ifndef __qproto_h_
#define __qproto_h_

#define QPACK_INIT1	"INIT1"
#define QPACK_INIT2	"INIT2"
#define QPACK_PING0	"PING0"
#define QPACK_PING1	"PING1"
#define QPACK_PING2	"PING2"
#define QPACK_PING3	"PING3"
#define QPACK_PING4	"PING4"
#define QPACK_MYNAME	"MYNAME"
#define QPACK_BEGIN	"BEGIN"
#define QPACK_SAY	"SAY"
#define QPACK_QUIT	"QUIT"
#define QPACK_HARAKIRI  "HARAKIRI"
#define QPACK_MOVEMENT  "MOVEMENT"

#define P_PARSED	0
#define P_NPARSED	1
#define P_RECONNECT	2


struct qpacket_str 
{
    char *identifier;
    char *packet;
    int length;
};


void init_packnum();
void increase_packnum( int p );
void insert_packnum( unsigned char *pack, int p );
void set_packnum( int p, unsigned long num );
unsigned long get_packnum( int p );
unsigned char *get_qpack( char *identifier );
unsigned char *copy_qpack( char *identifier );
int get_qpack_length( char *identifier );
int get_new_port( unsigned char *pack );
int get_packet_number( unsigned char *pack );
unsigned int get_packet_header( unsigned char *buf );
void print_level_info( unsigned char *buf, int length );
void get_player_info( unsigned char *buf, int length, int maxp );
int parse_packet( int sock, unsigned char *buf, int length );
int check_send( int socket, unsigned char *buf, int length, int mode );
void ack_packet( int sock, unsigned char *buf );
void packet_say( int socket, char *message );
int parse_message( int socket, unsigned char *buf, int length );
void send_quit( int socket );
void send_harakiri( int socket );
void send_movement( int sock );
void parse_scene( unsigned char *pack, int length );
int parse_sound( unsigned char *pack );
void tell_sound( const char *msg );

#endif !__qproto_h_
