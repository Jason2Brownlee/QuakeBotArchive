#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "qplayer.h"

#define TRUE 1
#define FALSE 0

struct player_str **Players;
static int maxp;


void init_players( int num )
{
    int i;
    Players = (struct player_str **)
	      calloc( num, sizeof( struct player_str *) );
    maxp = num;
    for( i = 0; i < num; i++ )
	Players[i] = (struct player_str *) calloc( 1, sizeof( struct player_str ) );
}


void insert_player( int id, char *name, int frags, int c1, int c2 )
{
    Players[id]->active = TRUE;
    sprintf( Players[id]->name, "%s", name );
    Players[id]->frags = frags;
    Players[id]->color1 = c1;
    Players[id]->color2 = c2;    
}


void change_colors( int id, int c1, int c2 )
{
    Players[id]->color1 = c1;
    Players[id]->color2 = c2;
}


void rename_player( int id, char *name )
{
    sprintf( Players[id]->name, "%s", name );
    if( Players[id]->active == FALSE )
	Players[id]->active = TRUE;

    if( name[0] == 0 )
	Players[id]->active = FALSE;
}


void set_fragcount( int id, int frags )
{
    Players[id]->frags = frags;
}


void delete_players()
{
    int i;

    for( i = 0; i < maxp; i++ )
	delete_player( i );
}


void delete_player( int id )
{
    Players[id]->active = FALSE;
}


void print_players()
{
    int i;

    for( i = 0; i < maxp; i++ )
	print_player( i );
}


void print_player( int id )
{
    if( Players[id]->active == TRUE )
	printf( "id:%d\t%-20s\tfrags:%d\tcolor:%d/%d\n", id,
		Players[id]->name, Players[id]->frags, Players[id]->color1,
		Players[id]->color2 );
}


int get_maxp()
{
    return maxp;
}
