#ifndef __main_h_
#define __main_h_

void print_usage( char *progname );
void handler( int sig );
void reconnect( int maxp );
const char *getmapname( const char *buf, int count );

#endif !__main_h_
