#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "qproto.h"
#include "socket.h"
#include "qbot.h"
#include "qplayer.h"
#include "qcdefs.h"
#include "rproto.h"


#define FALSE 0
#define TRUE 1

static unsigned long proto_num1, proto_num2;
int hits = 0, misses = 0;


char INIT1[] = {
  0x80, 0x00, 0x00, 0x0C,
  0x02, 0x51, 0x55, 0x41,
  0x4B, 0x45, 0x00, 0x03,
};

char INIT2[] = {
  0x80, 0x00, 0x00, 0x0C,
  0x01, 0x51, 0x55, 0x41,
  0x4B, 0x45, 0x00, 0x03,
};

/* do-it-yourself packets */
char PING0[] = {
  0x00, 0x02, 0x00, 0x08,
  0x00, 0x00, 0x00, 0x00,
};
char PING1[] = {
  0x00, 0x02, 0x00, 0x08,
  0x00, 0x00, 0x00, 0x00,
};
char PING2[] = {
  0x00, 0x09, 0x00, 0x09,
  0x00, 0x00, 0x00, 0x00,
  0x01,
};
char PING3[] = {
  0x00, 0x09, 0x00, 0x12,
  0x00, 0x00, 0x00, 0x01,
  0x04, 0x70, 0x72, 0x65,
  0x73, 0x70, 0x61, 0x77,
  0x6e, 0x00,
};
char PING4[] = {
  0x00, 0x04, 0x00, 0x08,
  0x00, 0x00, 0x00, 0x00,
};

char MYNAME[] = 
{
  0x00, 0x09, 0x00, 48, 0x00, 0x00, 0x00, 0x02,
  0x04,  'n',  'a',  'm',  'e',  ' ',  'A',  'E', '_', 'P',  'l',
  'a',  'y',  'm',  'a',  't',  'e', 0x0a, 0x00, 0x04,  'c',  'o',
  'l',  'o',  'r',  ' ',  '1',  '2',  ' ',  '4',
  0x0a, 0x00, 0x04,  's',  'p',  'a',  'w',  'n',
  ' ', 0x00,
};

char BEGIN[] =
{
  0x00, 0x09, 0x00, 0x0f, 0x00, 0x00, 0x00, 0x03,
  0x04, 0x62, 0x65, 0x67, 0x69, 0x6e, 0x00,
};


char SAY[] =
{
  0x00, 0x09, 0x00, 0x16, 0x00, 0x00, 0x00, 0x04,
  0x04,  's',  'a',  'y',  ' ',  '"',  'f',  'o',
  'o',  'b',  'a',  'r',  '"', 0x00,
};


char QUIT[] =
{
  0x00, 0x10, 0x00, 0x09, 0x00, 0x00, 0x00, 0x00,
  0x02,
};

char HARAKIRI[] =
{
  0x00, 0x09, 0x00, 0x0e, 0x00, 0x00, 0x00, 0x00,
  0x04,  'k',  'i',  'l',  'l', 0x00,
};

char MOVEMENT[] =
{
  0x00, 0x10, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00,
  0x03, 0xd0, 0x3c, 0xc2, 0x44, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};



struct qpacket_str quake_packets[] = 
{
  { QPACK_INIT1, INIT1, sizeof( INIT1 ) },
  { QPACK_INIT2, INIT2, sizeof( INIT2 ) },
  { QPACK_PING0, PING0, sizeof( PING0 ) },
  { QPACK_PING1, PING1, sizeof( PING1 ) },
  { QPACK_PING2, PING2, sizeof( PING2 ) },
  { QPACK_PING3, PING3, sizeof( PING3 ) },        
  { QPACK_PING4, PING4, sizeof( PING4 ) },
  { QPACK_MYNAME, MYNAME, sizeof( MYNAME ) },            
  { QPACK_BEGIN, BEGIN, sizeof( BEGIN ) },
  { QPACK_SAY, SAY, sizeof( SAY ) },
  { QPACK_QUIT, QUIT, sizeof( QUIT ) },
  { QPACK_HARAKIRI, HARAKIRI, sizeof( HARAKIRI ) },
  { QPACK_MOVEMENT, MOVEMENT, sizeof( MOVEMENT ) },    
  { NULL, NULL, 0 }
};


void init_packnum()
{
  proto_num1 = 0;
  proto_num2 = 0;
}


void increase_packnum( int p )
{
  switch( p )
    {
    case 0:
      proto_num1++;
      break;
    case 1:
      proto_num2++;
      break;
    }
}


void insert_packnum( unsigned char *pack, int p )
{
  unsigned long mynum;

  switch( p )
    {
    case 0:
      mynum = proto_num1;
      break;
    case 1:
      mynum = proto_num2;
      break;	
    }

  pack[4] = (mynum >> 24) & 0xff;
  pack[5] = (mynum >> 16) & 0xff;
  pack[6] = (mynum >> 8) & 0xff;
  pack[7] = mynum & 0xff;
}


void set_packnum( int p, unsigned long num )
{
  switch( p )
    {
    case 0:
      proto_num1 = num;
      break;
    case 1:
      proto_num2 = num;
      break;	
    }
}


unsigned long get_packnum( int p )
{
  unsigned long mynum;
    
  switch( p )
    {
    case 0:
      mynum = proto_num1;
      break;
    case 1:
      mynum = proto_num2;
      break;
    }

  return mynum;
}


unsigned char *get_qpack( char *identifier )
{
  int i;
    
  for( i = 0; quake_packets[i].identifier != NULL; i++ )
    if( strcmp( quake_packets[i].identifier, identifier ) == 0 )
      return quake_packets[i].packet;

  return NULL;
}


unsigned char *copy_qpack( char *identifier )
{
  int i, j;
  unsigned char *ret;
    
  for( i = 0; quake_packets[i].identifier != NULL; i++ )
    if( strcmp( quake_packets[i].identifier, identifier ) == 0 )
      {
	ret = (unsigned char *) malloc( sizeof( unsigned char ) * quake_packets[i].length );
	for( j = 0; j < quake_packets[i].length; j++ )
	  ret[j] = quake_packets[i].packet[j];
	return ret;
      }

  return NULL;
}


int get_qpack_length( char *identifier )
{
  int i;
    
  for( i = 0; quake_packets[i].identifier != NULL; i++ )
    if( strcmp( quake_packets[i].identifier, identifier ) == 0 )
      return quake_packets[i].length;

  return 0;
}


int get_new_port( unsigned char *pack )
{
  return ((unsigned char)pack[6])*256 + (unsigned char)pack[5];
}


int get_packet_number( unsigned char *pack )
{
  return pack[4];
}


unsigned int get_packet_header( unsigned char *buf )
{
  return ((unsigned char)buf[1])*256 + (unsigned char)buf[0];
}


int update_arsenal( long arsenal, unsigned char *buf )
{
  int health, curr_weapon_ammo, shells, nails, rockets, cells;
  long curr_weapon, mask;
  int ammo_index;

  health = buf[1] * 256 + buf[0];
  curr_weapon_ammo = buf[2];
  shells = buf[3];
  nails = buf[4];
  rockets = buf[5];
  cells = buf[6];
  curr_weapon = buf[7];

  /* Check that we have only one weapon in use and that we */
  /* really have the weapon we are using.                  */ 
  /* The weapons we have are in the lowest byte of arsenal */

  if ( curr_weapon == 0 ) /* The axe is 4096 */
    curr_weapon = 4096;

  mask = 0x80;
  while( mask )
    {
      if ( ( curr_weapon & mask ) && curr_weapon != mask )
	return 1;
      mask = mask >> 1;
    }
  
  if ( ( curr_weapon & arsenal ) == 0 )
    {
      extern FILE *dumpfp;
      if ( dumpfp )
	fprintf( dumpfp, "currweapon: %lx, arsenal %lx ", curr_weapon, arsenal );
      return 2;
    }

  /* Check that we use only one type of ammo at a time.   */
  /* Check that the amount of current ammo is the same as */
  /* the amount of ammo of the type we are using.         */

  mask = 0x0100;
  ammo_index = 3;
  while ( mask & 0x0f00 )
    {
      if ( arsenal & mask )
	{
	  if ( ( arsenal & 0xf00 ) != mask )
	    return 3;
	  if ( curr_weapon_ammo != buf[ammo_index] )
	    return 4;
	  break;
	}
      mask = mask << 1;
      ammo_index++;
    }
  /* Check that we have only one armor. Support for armor strength will be	*/
  /* included soon.								*/

  mask = 0x8000;
  while( mask & 0xfe )
    {
      if ( mask != ( arsenal & 0xfe ) )
	return 5;
      mask = mask >> 1;
    }

  /* Everything seems OK. Lets fill the struct. */

#if 0
  if ( botweapons.arsenal == arsenal &&
       botweapons.health == health &&
       botweapons.curr_weapon_ammo == curr_weapon_ammo &&
       botweapons.shells == shells &&
       botweapons.nails == nails &&
       botweapons.rockets == rockets &&
       botweapons.cells == cells && 
       botweapons.curr_weapon == curr_weapon )

    return 0;

  if ( botweapons.shells > shells )
    update_goodies( gk_shells, botweapons.shells - shells );
  if ( botweapons.nails > nails )
    update_goodies( gk_nails, botweapons.nails - nails );
  if ( botweapons.rockets > rockets )
    update_goodies( gk_rockets, botweapons.rockets - rockets );
  if ( botweapons.cells > cells )
    update_goodies( gk_cells, botweapons.cells - cells );

  if ( (botweapons.arsenal&IT_SUPER_SHOTGUN) > (arsenal&IT_SUPER_SHOTGUN) )
    update_goodies( gk_supershotgun, 1 );
  if ( (botweapons.arsenal&IT_NAILGUN) > (arsenal&IT_NAILGUN) )
    update_goodies( gk_nailgun, 1 );
  if ( (botweapons.arsenal&IT_SUPER_NAILGUN) > (arsenal&IT_SUPER_NAILGUN) )
    update_goodies( gk_supernailgun, 1 );
  if ( (botweapons.arsenal&IT_GRENADE_LAUNCHER) > (arsenal&IT_GRENADE_LAUNCHER) )
    update_goodies( gk_grenadelauncher, 1 );
  if ( (botweapons.arsenal&IT_ROCKET_LAUNCHER) > (arsenal&IT_ROCKET_LAUNCHER) )
    update_goodies( gk_nailgun, 1 );
  if ( (botweapons.arsenal&IT_LIGHTNING) > (arsenal&IT_LIGHTNING) )
    update_goodies( gk_nailgun, 1 );

#endif

  botweapons.arsenal = arsenal;
  botweapons.health = health;
  botweapons.curr_weapon_ammo = curr_weapon_ammo;
  botweapons.shells = shells;
  botweapons.nails = nails;
  botweapons.rockets = rockets;
  botweapons.cells = cells;
  botweapons.curr_weapon = curr_weapon;
  return 0;
}


void print_level_info( unsigned char *buf, int length )
{
  int pos;
  int packnum;
  unsigned char next;
    
  packnum = buf[7];

  if( packnum == 0 )
    pos = 15;
  else
    pos = 8;
    
  while( pos < length ) 
    {
      next = buf[pos++];
#ifndef QUIET       
      if( next == 0 )
	{
	  printf( "\n" );
	}
      else if( next >= 32 )
	{
	  printf( "%c", next );
	}
#endif
    }
}


void get_player_info( unsigned char *buf, int length, int maxp )
{
  unsigned char *s;
  int count, len, c1, c2;
    
  s = buf+15;
  count = 0;
  do {
    count++;
    len = strlen(s);
    c1 = (s[len+7] >> 4) & 0x0f;
    c2 = (s[len+7] & 0x0f);
    if( strlen( s ) > 0 )
      {
	if( strcmp( get_bot_name(), s ) == 0 )
	  set_my_id( s[-1] );
	    
	insert_player( s[-1], s, s[len+3], c1, c2 );
      }
	
    s += strlen(s) +2 +8;
  } while (count<maxp);
}



int parse_packet( int sock, unsigned char *buf, int length )
{
  int head, ack;
  unsigned int resolved;

  ack = FALSE;
  resolved = P_NPARSED;
  head = get_packet_header( buf );

  switch( head )
    {
      /* some kind of general information */	
    case 0x0100:
      if( length > 9 )
	{
	  printf( "Levelinfo: " );
	  print_level_info( buf, length );
	}
      ack = TRUE;
      resolved = P_PARSED;
      break;

      /* Message packet, or last packet of general information */
    case 0x0900:
      resolved = parse_message( sock, buf, length );
      ack = TRUE;
      break;
	
      /* Acknowledgement packet */	
    case 0x0200:
      ack = FALSE;
      resolved = P_PARSED;	
      break;
	
      /* Scene data */
    case 0x1000:
      parse_scene( buf, length );
      ack = FALSE;
      resolved = P_PARSED;
      break;
    }
    
  if( ack == TRUE )
    ack_packet( sock, buf );
  return( resolved );
}


int check_send( int socket, unsigned char *buf, int length, int mode )
{
  unsigned char num[4];
  unsigned char mybuf[2048];
  int i, len, end, ret;
  long al;
    
  for( i = 4; i < 8; i++ )
    num[i-4] = buf[i];

  end = FALSE;

  do 
    {
      ret = send_packet( socket, buf, length, mode );

      len = -1;
      alarm( 4 );
      len = receive_packet( socket, mybuf, S_SILENT );
      al = alarm( 0 );
	
      if( al != 0 &&
	  num[0] == mybuf[4] &&
	  num[1] == mybuf[5] &&
	  num[2] == mybuf[6] &&
	  num[3] == mybuf[7] )
	end = TRUE;
	
    } while( end != TRUE );

  return ret;
}


void ack_packet( int sock, unsigned char *buf )
{
  unsigned char *mypack;

  mypack = get_qpack( QPACK_PING1 );
  mypack[4] = buf[4];
  mypack[5] = buf[5];
  mypack[6] = buf[6];
  mypack[7] = buf[7];
    
  send_packet( sock, mypack,
	       get_qpack_length( QPACK_PING1 ),
	       S_SILENT ) ;   
}


void packet_say( int socket, char *message )
{
  unsigned char *pack;
  int leng, i;

  leng = strlen( message ) + 16;
  pack = (unsigned char *) malloc( leng * sizeof(unsigned char *) );
  pack[0] = 0x00;
  pack[1] = 0x09;
  pack[2] = 0x00;
  pack[3] = leng;
  pack[8] = 0x04;
  pack[9] = 's';
  pack[10] = 'a';
  pack[11] = 'y';    
  pack[12] = ' ';
  pack[13] = '"';
  for( i = 0; message[i] != 0; i++ )
    pack[14+i] = message[i];
  pack[14+i++] = '"';
  pack[14+i++] = 0;    

  insert_packnum( pack, 0 );
  increase_packnum( 0 );
    
  send_packet( socket, pack, 14+i, S_SILENT );
}


int parse_message( int socket, unsigned char *buf, int length )
{
  int offset;
  int ret;
  int c1, c2;
  extern int route_socket;

  ret = P_PARSED;
  offset = 8;
  /*
    dump_packet( buf, length );
    */    
  while( offset < length )
    {
      switch( buf[offset] )
	{
	case 0x0a:
	  /* Unknown packet */
#ifndef QUIET
	  printf( "Unknown packet: %d '%s'\n", buf[offset], buf+offset+1 );
#endif
	  offset += strlen( buf+offset+1 ) + 2;
	  break;

	case 0x09:
	  /* Unknown packet */
	  if( strncmp( "reconnect", buf+offset+1, 9 ) == 0 ) 
	    {
	      set_state( BS_STOPPING );
	      ret = P_RECONNECT;
	    }
	  else
#ifndef QUIET
	    if( strncmp( "bf", buf+offset+1, 2 ) == 0 )
	      printf( "%s", buf+offset+1 );
	    else 
	      {
		printf( "Unknown packet: %d '%s'\n", buf[offset], buf+offset+1 );
		/*
		  dump_packet( buf, length );
		  */
	      }
#endif
	  offset += strlen( buf+offset+1 ) + 2;
	  break;
	    
	case 0x08:
	  /* General text, OR speach */
	  if( buf[offset+1] >= 32 )
	    {
	      static int prevlen = 0;
	      char *ch;

	      ch = buf+offset+1;
	      /* text */
	      printf( "%s", ch );
	      offset += strlen( ch ) + 2;
	      prevlen += strlen( ch ) + 1;
	    }
	  else
	    {
	      if( buf[offset+1] == 1 )
		{
		  /* speech */
		  printf( "%s", buf+offset+2 );
		  offset += strlen( buf+offset+2 ) + 3;
		}
	      else
		if( buf[offset+1] == 0x0a )
		  {
		    /* odd extra enter */
		    printf( "%s", buf+offset+2 );
		    offset += strlen( buf+offset+1 ) + 2;
		  }
		else
		  {
		    if( buf[offset+1] == 0 )
		      offset += 2;
		    else
		      {
			printf( "ALERT! Unknown text sub-type %d\n", buf[offset+1] );
			dump_packet( buf, length );
			/* Ugly exit */
			exit( 1 );
		      }
		  }
	    }
	  break;
	  
	case 0x0c:
	  /* Ligthstyle ?? */
	  offset += strlen( buf+offset+1 ) + 2;
	  break;

	case 0x0d:
	  /* New name for a player */
	  /*
	    printf( "Player %d is now known as %s\n", buf[offset+1],
	    buf+offset+2 );
	    */		    
	  rename_player( buf[offset+1], buf+offset+2 );
	  /*
	    print_player( buf[offset+1] );
	    */	    
	  offset += strlen( buf+offset+2 ) + 3;		     
	  break;

	case 0x0e:
	  /* new fragcount for player */
	  /*
	    printf( "player %d now has %d frags\n", (int) buf[offset+1],
	    buf[offset+2] );
	    */		    
	  set_fragcount( (int) buf[offset+1], buf[offset+2] );
	  /*
	    print_player( buf[offset+1] );
	    */	    
	  offset += 4;
	  break;

	case 0x11:
	  /* New player color*/
	  c1 = (buf[offset+2] >> 4) & 0x0f;
	  c2 = buf[offset+2] & 0x0f;
	  /*
	    printf( "Player %d changed his colors to %d %d \n",
	    buf[offset+1], c1, c2 );
	    */
	  change_colors( buf[offset+1], c1, c2 );
	  /*
	    print_player( buf[offset+1] );
	    */	    
	  offset += 3;
	  break;
	    
	case 0x1a:
	  printf( "        ----   Centerprint   ----\n" );
	  printf( "%s", buf+offset+1 );
	  printf( "        -------------------------\n" );
	  offset += strlen( buf+offset ) + 1;
	  break;

	case 0x20:
	  /* Player exited the level */
#if 0
	  if ( route_socket >= 0 )
	    {
	      char *msg = "exitlevel\n";
	      send_packet( route_socket, msg, strlen( msg ), S_SILENT );
	    }
#else
	  send_update( EXITLEVEL );
	  begin_update();
#endif
#ifndef QUIET
	  printf( "Someone left the level, data %d %d %d\n",
		  buf[offset+1], buf[offset+2], buf[offset+3] );
	  print_players();
#endif
	  offset += 4;
	  break;
		       

	default:
	  /* Unknow packet */
#ifndef QUIET
	  printf( "ALERT! Unknown packet %d at %d\n", buf[offset], offset );
#endif
	  if( buf[offset] >= 32 )
	    {
	      printf( "%s\n", buf+offset );
	      offset += strlen( buf+offset ) + 1;
	    }
	  else
	    {

	      dump_packet( buf, length );
	      offset = length;
	    }
	  break;
	}
    }

  return ret;
}


void send_quit( int socket )
{
  unsigned char *mypack;
    
  mypack = get_qpack( QPACK_QUIT );
  insert_packnum( mypack, 0 );
  increase_packnum( 0 );
  send_packet( socket, mypack, get_qpack_length( QPACK_QUIT ),
	       S_SILENT );
  exit( 0 );
}


void send_harakiri( int socket )
{
  unsigned char *mypack;
    
  mypack = get_qpack( QPACK_HARAKIRI );
  insert_packnum( mypack, 0 );
  increase_packnum( 0 );    
  send_packet( socket, mypack, get_qpack_length( QPACK_HARAKIRI ),
	       S_SILENT );
}


void send_movement( int sock )
{
  unsigned char *mypack;
  int myid;
  static int jcount = 5;
  static int rnd = 0;
    
  if( get_state() == BS_STOPPED )
    return;
    
  myid = get_my_id();
    
  mypack = copy_qpack( QPACK_MOVEMENT );
  insert_packnum( mypack, 1 );
  increase_packnum( 1 );

  mypack[18] = botmove.strafe & 0xff;
  mypack[19] = (botmove.strafe >> 8) & 0xff;

    
  mypack[14] = botmove.angle1;
  mypack[13] = botmove.angle2;    

  if( botmove.forward == 1 )
    {
      if ( get_state() == BS_MOVING && get_movingmode() == mm_stop_at )
	{
	  mypack[16] = 0xb0;
	  mypack[17] = 0x04;
	}
      else
	{
	  mypack[16] = 0xb0;
	  mypack[17] = 0x04;
	}
    }

  if( botmove.fire == 1 )
    {
      mypack[22] |= 1;
    }

  if( botmove.jump == 1 )
    {
      mypack[22] |= 2;
    }

  mypack[23] = botmove.weapon;
  if ( (rnd++)%1023 == 200 )
    mypack[23] = 240;

  send_packet( sock, mypack, get_qpack_length( QPACK_MOVEMENT ),
	       S_SILENT );
  free( mypack );
}


void parse_scene( unsigned char *pack, int length )
{
  int offset, skip, packid;
  int dump, already_dumped = FALSE;
  int i, x, y, z, myid;
  int shiftplayer, shiftx, shifty, shiftz, shiftimage, tail;
  int shift_weapons = 0, shift_health = 0;
  int mask = 0x80;
  long *arsenalp;
  int ret;

  hits = 0, misses = 0;
  delete_visible();

  if( pack[13] != 0x0f )
    return;

  while( mask )
    {
      if ( pack[14] & mask )
	shift_weapons++;
      if ( pack[15] & ( mask & 0x30 ) )
	shift_health++;
      mask = mask >> 1;
    }
  botweapons.byte2 = pack[14];
  botweapons.byte3 = pack[15];

  arsenalp = (long*) (pack + 16 + shift_weapons);

  offset = 16 + shift_weapons + 4 + shift_health + 1;
  ret = update_arsenal( *arsenalp, pack + offset );

  if ( ret != 0 )
    {
      extern FILE *dumpfp;
      if ( dumpfp )
	{
	  fprintf( dumpfp, "parse of arsenal failed: retvalue %d offset %d w_shift %d, h_shift %d\n", ret, offset, shift_weapons, shift_health );
	  dump_packet_tight( pack+13, 32 );	    
	}

      for( i = 16 + shift_weapons + shift_health + 12; i < length; i++ )
	{
	  if( pack[i] == 0x8f )
	    break;
	  if( pack[i] == 0x9f ) /* ring of shadows */
	    break;		
	  if( pack[i] == 0xce )
	    break;
	  if( pack[i] == 0xcf )
	    break;	
	  if( pack[i] == 0xde )
	    break;
	  if( pack[i] == 0xdf )
	    break;
	}

      if( i == length )
	return;
      offset = i;
    }
  else
    offset += 8;
    
  myid = get_my_id();

  while( offset+4 <= length )
    {
      int sub_pack_dumped = 0;
      dump = TRUE;
      skip = FALSE;
      shiftplayer = 0;
      shiftimage = 1;
      shiftx = shifty = shiftz = tail = 0;
      
      packid = pack[offset];
	
      if( pack[offset] == 0xdf && pack[offset+1] == 0x0c )
	{
	  /* ett lik... eller �r det n�got annat som alltid kommer
	     efter den sista spelaren som botten ser ??? */
	  skip = TRUE;
	  dump = FALSE;
#if 0
	  if ( sub_pack_dumped == 0 )
	    {
	      extern FILE *dumpfp;
	      dump_packet_tight( pack + offset, 13 );
	      if ( dumpfp )
		fflush( dumpfp );
	      sub_pack_dumped = 1;
	    }
#endif
	}
	
      /* K�nda paket ( som skall parsas ) */

      if( pack[offset] != 0x8f &&
	  pack[offset] != 0x9f &&
	  pack[offset] != 0xce &&
	  pack[offset] != 0xcf &&
	  pack[offset] != 0xde &&
	  pack[offset] != 0xdf )
	{
	  skip = TRUE;
	  dump = FALSE;
	}

      if ( packid == 0x9f ) /* Granat ? */
	{
	  dump = FALSE;
	  /*	  dump_packet_tight( pack+offset, 20 ); */
	  shiftimage--;
	  if ( pack[offset+1] & 0x02 )
	    shiftz++;
	  if ( pack[offset+1] & 0x01 )
	    shifty++;
	  if ( pack[offset+1] & 0x04 )
	    shiftx++;
	  if ( pack[offset+1] & 0x20 )
	    shiftx++;
	}

      if ( packid == 0xce )
	{
	  dump = FALSE;
	  /* nyf�dd spelare */
	}   
	
      if ( packid == 0xcf )
	{
	  dump = FALSE;
	  if ( pack[offset+1] & 0x01 )
	    shifty++;
	  if ( pack[offset+1] & 0x20 )
	    shiftx++;
	}
	
      if ( packid == 0xde )
	{
	  dump = FALSE;
	  /* Spelare som stannat efter att ha r�rt sig??? */
	  shiftz++; /* Alltid shiftz */
	}

      if ( packid == 0xdf  )
	{
	  dump = FALSE;
	  shiftz++; /* Alltid shiftz */
	  if ( pack[offset+1] & 0x01 )
	    shifty++;
	  if ( pack[offset+1] & 0x20 )
	    shiftx++;
	  if ( pack[offset+1] & 0x10 )
	    shiftx++;
	  if ( pack[offset+1] & 0x02 )
	    tail++;
	}

      if ( (packid & 0x0f) == 0x0f )
	{
	  shiftplayer++;
	  if ( packid != 0xdf )
	    tail++; /* trailing byte */
	}

      /* Dessa �r images f�r lik & diverse kroppsdelar */
      if ( (packid == 0xce || packid == 0xde) &&
	   (pack[offset+shiftplayer+2] == 0x3c ||
	    pack[offset+shiftplayer+2] == 0x54 ||
	    pack[offset+shiftplayer+2] == 0x45 ||
	    pack[offset+shiftplayer+2] == 0x5d ||
	    pack[offset+shiftplayer+2] == 0x31 ||
	    pack[offset+shiftplayer+2] == 0x66) )
	{
#if 0
	  int len;
	  len = 8 + shiftplayer + shiftimage + shiftx + shifty + shiftz + tail;
	  if ( sub_pack_dumped == 0 )
	    {
	      extern FILE *dumpfp;
	      dump_packet_tight( pack+offset, len );
	      if ( dumpfp )
		fflush( dumpfp );
	      sub_pack_dumped = 1;
	    }
#endif
	  skip = TRUE;
	  dump = FALSE;
	}

      if ( pack[offset+shiftplayer+1] <= get_maxp() &&
	   pack[offset+shiftplayer+1] != 0 && skip == FALSE )
	{
	  unsigned char player_id;
	  player_id = pack[offset+shiftplayer+1];
	  if( Players[player_id-1]->active == TRUE )
	    {
	      x = get_packet_header( pack + offset + shiftplayer +
				     shiftimage + 2 + shiftx );
	      y = get_packet_header( pack + offset + shiftplayer +
				     shiftimage + 4 + shiftx + shifty );
	      z = get_packet_header( pack + offset + shiftplayer + 
				     shiftimage + 6 + 
				     shiftx + shifty + shiftz );
		
	      if( x > 32768 )
		x -= 65535;
		
	      if( y > 32768 )
		y -= 65535;
		
	      if( z > 32768 )
		z -= 65535;
		
	      Players[player_id-1]->x = x;
	      Players[player_id-1]->y = y;
	      Players[player_id-1]->z = z;	

	      if ( shifty )
		{
		  Players[player_id-1]->angle2 = pack[offset + shiftplayer +
						   shiftimage + 2 + shiftx + 2];
		}
	      else
		Players[player_id-1]->angle2 = 0;

	      if ( shiftz )
		{
		Players[player_id-1]->angle1 = pack[offset + shiftplayer +
						 shiftimage + 2 + shiftx +
						 2 + shifty + 2];
		}
	      else
		Players[player_id-1]->angle1 = 0;
    
		
	      if( pack[offset+shiftplayer+1] != myid + 1 )
		add_visible( pack[offset+shiftplayer+1] - 1 );

#if 0
	      /*	      if ( sub_pack_dumped == 0 ) */
		{
		  extern FILE *dumpfp;
		  dump_packet_tight( pack+offset, 8 + shiftplayer + 
				     shiftimage + shiftx + shifty + shiftz +
				     tail );
		  if ( dumpfp )
		    fflush( dumpfp );
		  sub_pack_dumped = 1;
		}
#endif
		
	    }
	    
	}


      if ( packid == 0x06 ) /* Ljud, h�ndelse ?? */
	{
#if 0
	  if ( sub_pack_dumped == 0 )
	    {
	      extern FILE *dumpfp;
	      dump_packet_tight( pack+offset, 11 );
	      if ( dumpfp )
		fflush( dumpfp );
	      sub_pack_dumped = 1;
	    }
#endif
	  offset += parse_sound( pack+offset );
	  continue;
	}

      if ( packid == 0x12 ) /* tr�ff (hagel/spik) */
	{
#if 0
	  if ( sub_pack_dumped == 0 )
	    {
	      extern FILE *dumpfp;
	      dump_packet_tight( pack+offset, 12 );
	      if ( dumpfp )
		fflush( dumpfp );
	      sub_pack_dumped = 1;
	    }
#endif
	  hits++;
	  offset += 12;
	  continue;
	}

      if ( packid == 0x17 ) /* Hagel, troligen hutiskott ?? */
	{
#if 0
	  if ( sub_pack_dumped == 0 )
	    {
	      extern FILE *dumpfp;
	      dump_packet_tight( pack+offset, 8 );
	      if ( dumpfp )
		fflush( dumpfp );
	      sub_pack_dumped = 1;
	    }
#endif
	  misses++;
	  offset += 8;
	  continue;
	}

      if ( packid == 0x80 ) /* ?? */
	{
	  offset += 2;
	  continue;
	}

      if ( packid == 0x81 ) /* ?? */
	{
	  offset += 4;
	  continue;
	}

      if ( packid == 0x88 ) /* Sak inom synh�ll */
	{
#if 0
	  static char items_i_see[256];
	  static int i_index = 0;
	  static int first_item = 0;

	  if ( sub_pack_dumped == 0 )
	    {
	      extern FILE *dumpfp;
	      dump_packet_tight( pack+offset, 4 );
	      if ( dumpfp )
		fflush( dumpfp );
	      sub_pack_dumped = 1;
	    }
	  if ( pack[offset+1] < i_index )
	    {
	      i_index = first_item;
	      first_item = pack[offset+1];
	    }
	  while( i_index < pack[offset+1] )
	    {
	      if ( items_i_see[i_index] == 1 )
		printf( "Lost sight of item number 0x%x\n", i_index );
	      items_i_see[i_index] = 0;
	      i_index++;
	    }
	  if ( items_i_see[i_index] == 0 )
	    {
	      printf( "Got sight of item number 0x%x\n", i_index );
	    }
	  items_i_see[i_index] = 1;

#endif
	  offset += 4;
	  continue;
	}

      if ( packid == 0x89 ) /* ?? */
	{
	  offset += 6;
	  continue;
	}

      if ( packid == 0xc4 ) /* ?? */
	{
#if 0
	  if ( sub_pack_dumped == 0 )
	    {
	      extern FILE *dumpfp;
	      dump_packet_tight( pack+offset, 5 );
	      if ( dumpfp )
		fflush( dumpfp );
	      sub_pack_dumped = 1;
	    }
#endif
	  offset += 5;
	  continue;
	}

      if ( !already_dumped )
	{
	  extern FILE *dumpfp;
#if 0
	  if ( sub_pack_dumped == 0 )
	    {
	      if ( length - offset > 0 )
		dump_packet_tight( pack /*+ offset*/, length /*- offset*/ );
	      if ( dumpfp )
		fflush( dumpfp );
	      sub_pack_dumped = 1;
	    }
#endif
	  already_dumped = TRUE;
	}
      offset += 8 + shiftplayer + shiftimage + shiftx + shifty + shiftz + tail;

    }
}

void tell_sound( const char *msg )
{
#if 1
  printf( "%s", msg );
#endif
  return;
}

int handle_weapon_sound( unsigned char kind )
{
  switch( kind )
    {
    case 0x02: /* Nailgun */
      tell_sound( "nailgun" );
      break;
    case 0x03: /* Rocket */
      tell_sound( "rocket launched, duck!" );
      break;
    case 0x04: /* Shotgun */
      tell_sound( "shotgun" );
      break;
    case 0x08: /* Supernailgun */
      tell_sound( "supernailgun" );
      break;
    case 0x0a: /* Grenade */
      tell_sound( "GRENADE!" );
      break;
    case 0x0c: /* Supershotgun */
      tell_sound( "supershotgun" );
      break;
    case 0x22: /* Shaft */
      tell_sound( "shaft" );
      break;
    case 0x34: /* Axe miss */
      tell_sound( "swinging the axe" );
      break;
    case 0x36: /* Axe miss, wall */
      tell_sound( "hitting the wall" );
      break;
    default:
      {
	char msg[64];
	sprintf( msg, "Unknown weapon sound 0x%x", kind );
	tell_sound( msg );
	return 0;
      }
    }
  return 1;
}

int handle_pickup_sound( unsigned char kind )
{
  char msg[64];

  switch( kind )
    {
    case 0x20: /* Weapon */
      tell_sound( "weapon pickup" );
      break;
    case 0x1f: /* Ammo */
      tell_sound( "picked ammo/rucksack " );
      break;
    case 0x21: /* armor */
      tell_sound( "got armor" );
      break;
    case 0x40: /* Health */
      tell_sound( "picked up health I" );
      break;
    case 0x43: /* Health */
      tell_sound( "picked up health II" );
    case 0x4f: /* Superhealth */
      tell_sound( "got superhealth" );
      break;
    default:
      sprintf( msg, "picked up unknown item: 0x%x", kind );
      tell_sound( msg );
      return 0;
    }
  return 1;
}

int handle_end_sound( unsigned char kind )
{
  char msg[64];
  switch( kind )
    {
    case 0x23: /* Shaft */
      tell_sound( "player 1 shaftburst ended" );
      break;
    case 0x4e:
      tell_sound( "Quattro end" );
      break;
    default:
      sprintf( msg, "Unknown end sound 0x%x\n", (int) kind );
      tell_sound( msg );
      return 0;
    }
  return 1;
}

int handle_jump_sound( unsigned char kind )
{
  char msg[64];
  switch( kind )
    {
    default:
      sprintf( msg, "Unknown jump sound 0x%x\n", (int) kind );
      tell_sound( msg );
      return 0;
    }
  return 1;
}

int handle_hurt_sound( unsigned char kind )
{
  char msg[64];
  switch( kind )
    {
    case 0x11: /* Drop ( person falling? ) */
      tell_sound( "Drop ( person falling? )" );
      break;
    case 0x12:
      tell_sound( "Bonecrusher" );
    case 0x13:
    case 0x14:
      tell_sound( "Gurgel" );
      break;
    case 0x15: /* Gasp */
      tell_sound( "Gasp 0x15" );
      break;
    case 0x18: /* Tzing ? */
      tell_sound( "hurt 0x18" );
      break;
    case 0x1a: /* Teleport hurt sounds ?? */
    case 0x1b:
    case 0x1c:
    case 0x1d:
    case 0x1e:
      sprintf( msg, "Teleport hurt 0x%x ", (int) kind );
      tell_sound( msg );
      break;

    case 0x2a: /* ouch */
    case 0x2b: /* ouch */
    case 0x2c: /* ouch */
    case 0x2d: /* ouch */
      sprintf( msg, "saying ouch #0x%x", kind );
      tell_sound( msg );
      break;

    case 0x3c: /* Lava ouch */
      tell_sound( "'s lava ouch" );
      break;
    case 0x3d: /* Lava plask */
      tell_sound( "'s lava plask" );
      break;
    case 0x41: /* Biosuit ? */
      tell_sound( " took a Biosuit?" );
      break;
    case 0x43: /* Quattro ? */
      tell_sound( " took a quattro?" );
      break;
    case 0x45: /* Pentagram */
      tell_sound( " took pentagram" );
      break;
    case 0x48: /* Ring of Shadows */
      tell_sound( " got Ring of Shadows" );
      break;
    case 0x4a: /* Quattro m�lli */
    case 0x4d:
      tell_sound( "'s quattro" );
      break;
    default:
      sprintf( msg, "Unknown hurt sound 0x%x\n", (int) kind );
      tell_sound( msg );
      return 0;
    }
  return 1;
}

int handle_death_sound( unsigned char kind )
{
  char msg[64];
  switch( kind )
    {
    default:
      sprintf( msg, "Unknown death sound 0x%x", (int) kind );
      tell_sound( msg );
      return 0;
    }
  return 1;
}

int parse_sound( unsigned char *pack )
{
  unsigned char type, extra1, extra2, objnum, type_of_sound;
  short sx, sy;
  char msg[64];
  int ret = 11;
  if ( *pack != 0x06 )
    {
      printf( "parse_sound(): %x is NOT 0x06\n", *pack );
      return 1;
    }

  extra1 = pack[1];
  if ( extra1 & 0x01 )
    ret++;
  if ( extra1 & 0x02 )
    ret++;
  sx = 0x100*pack[ret-5] + pack[ret-6];
  sy = 0x100*pack[ret-3] + pack[ret-4];
  type = pack[2];
  objnum = pack[2];
  type_of_sound = pack[4];

#if 1
  return ret;
#endif


  if ( type_of_sound == 0x0f ) /* respawn */
    {
      sprintf( msg, "Respawn 0x%x\n", (int) objnum );
      tell_sound( msg );
      dump_packet_tight( pack, ret );
      return ret;
    }

  sprintf( msg, "Player %d ", objnum/0x08 );
  switch ( objnum )
    {
    case 0x00: /* SCHPlu��th */
      handle_death_sound( pack[4] );
      break;

    case 0x08: /* Player action end */
    case 0x10:
    case 0x18:
    case 0x20:
    case 0x28:
    case 0x30:
    case 0x38:
    case 0x40:
    case 0x48:
    case 0x50:
    case 0x58:
    case 0x60:
    case 0x68:
      tell_sound( msg );
      if ( handle_end_sound( type_of_sound ) == 0 )
	dump_packet_tight( pack, ret );
      break;
      
    case 0x09: /* Player weapon (start) */
    case 0x11: case 0x19: case 0x21: case 0x29:
    case 0x31: case 0x39: case 0x41: case 0x49:
    case 0x51: case 0x59: case 0x61: case 0x69:
      tell_sound( msg );
      if ( handle_weapon_sound( pack[4] ) == 0 )
	dump_packet_tight( pack, ret );
      break;

    case 0x0a: /* Player sound */
    case 0x12: case 0x1a: case 0x22: case 0x2a:
    case 0x32: case 0x3a: case 0x42: case 0x4a:
    case 0x52: case 0x5a: case 0x62: case 0x6a:
      tell_sound( msg );
      if ( handle_hurt_sound( pack[4] ) == 0 )
	dump_packet_tight( pack, ret );
      else if ( objnum/0x8 == get_my_id() + 1 &&
		(pack[4] == 0x3c || pack[4] == 0x3d) ) /* lava */
	update_deadly_damage( dk_lava );
      break;

    case 0x0b: /* 's pickup */
    case 0x13: case 0x1b: case 0x23: case 0x2b:
    case 0x33: case 0x3b: case 0x43: case 0x4b:
    case 0x53: case 0x5b: case 0x63: case 0x6b:
      tell_sound( msg );
      if ( handle_pickup_sound( pack[4] ) == 0 )
	dump_packet_tight( pack, ret );
      break;

    case 0x0c: /* Jump ( 's ) */
    case 0x14: case 0x1c: case 0x24: case 0x2c:
    case 0x34: case 0x3c: case 0x44: case 0x4c:
    case 0x54: case 0x5c: case 0x64: case 0x6c:
      if ( handle_jump_sound( pack[4] ) == 0 )
	dump_packet_tight( pack, ret );
      tell_sound( msg );
      break;
     
    case 0x7f:
      dump_packet_tight( pack, ret );
      tell_sound( "Invisibility whispering" );
      break;

    case 0xe1:
      dump_packet_tight( pack, ret );
      tell_sound( "Lava skvalp 0xe1" );
      break;
    case 0xe4:
      dump_packet_tight( pack, ret );
      tell_sound( "Lava skvalp 0xe4" );
      break;


    case 0xba:
    case 0xf2:
      dump_packet_tight( pack, ret );
      tell_sound( "Teleportation " );
      break;

    case 0xb8:
    case 0xb9:
      dump_packet_tight( pack, ret );
      tell_sound( "Grenade bounce " );
      break;

      /* sounds we have heard, but don't know the meaning of */

    case 0x80:
    case 0x88:
    case 0xac:
    case 0xda:
    case 0xe2:


      dump_packet_tight( pack, ret );
      sprintf( msg, "Got this 0x%x sound again", type );
      tell_sound( msg );
      break;
    default:
      dump_packet_tight( pack, ret );
      sprintf( msg, "Unknown sound-source 0x%x", objnum );
      tell_sound( msg );
    }

  if ( type != 0x14 )
    {
      sprintf( msg, " at %hx %hx\n", sx, sy );
      tell_sound( msg );
    }
  return ret;
}
