/*
  Playmate v0.2
  Quake-bot
  Author: nicke, Klonk
  Date: 07.08.96 - 18.12.96
  */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

#include "main.h"
#include "socket.h"
#include "qproto.h"
#include "qbot.h"
#include "qplayer.h"
#include "rproto.h"

#define FALSE 0
#define TRUE 1

#define DEBUG 		TRUE

#define MYNAME		"AE_Playmate"

static int socket;
extern int route_socket;

FILE *dumpfp = NULL;
unsigned char buf[BUFSIZE];
char *teamprefix = NULL;

int main( int argc, char *argv[] )
{
    int port, length, newport, stat, curr_arg;
    unsigned char *s;
    char *server;

    signal( SIGHUP, handler );
    signal( SIGTERM, handler );
    signal( SIGINT, handler );
    signal( SIGPIPE, handler );
        
    port = 26000;

    srand( 4242 );

    if( argc < 2 ) 
    {
	print_usage( argv[0] );
	exit( 1 );
    }

    curr_arg = 1;
    server = argv[curr_arg];
   
    while ( ++curr_arg < argc )
      {
	if ( strcmp( argv[curr_arg], "-port" ) == 0 )
	  {
	    if ( ++curr_arg < argc )
	      port = atoi( argv[curr_arg] );
	    continue;
	  }
	if ( strcmp( argv[curr_arg], "-teamplay" ) == 0 )
	  {
	    if ( ++curr_arg < argc )
	      teamprefix = argv[curr_arg];
	    else
	      teamprefix = "";
	    continue;
	  }
	if ( strcmp( argv[curr_arg], "-dumpfile" ) == 0 )
	  {
	    if ( ++curr_arg < argc )
	      dumpfp = fopen( argv[curr_arg], "a" );
	    continue;
	  }
      }

    if ( connect_to_router() == -1 )
      {
	printf( "Guess I have to manage without routing then...\n" );
      }

    socket = sock_client( server, port );
    if( socket == -1 )
    {
	fprintf( stderr, "Error: Can't connect to host '%s' on port %d\n",
		 server, port );
	exit( 1 );
    }

    length = send_packet( socket,
			  get_qpack( QPACK_INIT1 ),
			  get_qpack_length( QPACK_INIT1 ),
			  S_SILENT );
    length = receive_packet( socket, buf, S_SILENT );
    s = buf + 5;
    printf("hostname: %s\n", s+=strlen(s)+1); /* hostname */
    printf("mapname: %s\n", s+=strlen(s)+1); /* map */
    strncpy( s-5, "maps/", 5 );
    update_mapname( s-5 );
    send_update( ENTERLEVEL );
    s += strlen(s)+1;
    printf("players/maxplayers: %d/%d\n", s[0], s[1]);  /* players/maxplayers */

    init_players( s[1] );
    set_bot_name( MYNAME );
    
    length = send_packet( socket,
			  get_qpack( QPACK_INIT2 ),
			  get_qpack_length( QPACK_INIT2 ),
			  S_SILENT );
    length = receive_packet( socket, buf, S_SILENT );    

    if( get_packet_number( buf ) != 0x81 )
    {
	printf( "Server is full\n" );
	exit( 1 );
    }
    
    newport = get_new_port( buf );
    socket = sock_connect( socket, argv[1], newport );
    if( socket == -1 )
    {
	fprintf( stderr, "Error: Can't connect to host '%s' on port %d\n",
		 argv[1], newport );
	exit( 1 );
    }

    init_packnum();
    reconnect( get_maxp() );
    set_packnum( 1, get_packnum( 0 ) );
    
    do 
    {
	length = receive_packet( socket, buf, S_SILENT );
	begin_update();
	stat = parse_packet( socket, buf, length );
	switch ( stat )
	{
	  case P_NPARSED:
	    printf( "Received:\n" );
	    dump_packet( buf, length );
	    break;

	  case P_RECONNECT:
	    printf( "\n\nRECONNECTING\n" );
	    reconnect( get_maxp() );
	    printf( "Reconnected\n" );	
	    send_update( ENTERLEVEL );
	    break;

	  default:
	    poll_commands();
	    run_qbot();
	    update_qbot( socket );
	    send_update( PLAYMATE_UPDATE );
	}
    } while( 1 != 2 );
    
    close( socket );
    return 0;
}


void print_usage( char *progname )
{
    fprintf( stderr, "Usage: %s server [-port portnumber] [-teamplay teamprefix]\n", progname );
}


void handler( int sig )
{
    printf( "\nCaught signal %d - %s\n", sig, strsignal( sig ) );
    send_quit( socket );
    if ( sig != 13 )
      send_update( ENTERLEVEL );
}


void reconnect( int maxp )
{
    int length, lastpack;
    unsigned char buf[BUFSIZE];
    unsigned char *mypack;
    extern FILE *dumpfp;
    int check = 0;
    int extracted_players = FALSE;

    delete_players();

    mypack = get_qpack( QPACK_PING0 );
    lastpack = -1;
    do
    {
	length = receive_packet( socket, buf, S_SILENT );
	if ( !check )
	  {
	    getmapname( buf, length );
	    check = 1;
	  }
	ack_packet( socket, buf );
    } while( get_packet_header( buf ) != 0x0900 );

    mypack = get_qpack( QPACK_PING2 );
    insert_packnum( mypack, 0 );
    increase_packnum( 0 );
    length = check_send( socket, mypack,
			  get_qpack_length( QPACK_PING2 ),
			  S_SILENT );

    mypack = get_qpack( QPACK_PING3 );
    insert_packnum( mypack, 0 );
    increase_packnum( 0 );
    length = check_send( socket, mypack,
			  get_qpack_length( QPACK_PING3 ),
			  S_SILENT );
  
    mypack = get_qpack( QPACK_PING0 );
    lastpack = -1;
    do
    {      
	length = receive_packet( socket, buf, S_SILENT );
	ack_packet( socket, buf );
    } while( get_packet_header( buf ) != 0x0900 );
    
    
    mypack = get_qpack( QPACK_MYNAME );
    insert_packnum( mypack, 0 );
    increase_packnum( 0 );
    length = check_send( socket, mypack,
			  get_qpack_length( QPACK_MYNAME ),
			  S_SILENT );

    mypack = get_qpack( QPACK_PING0 );
    lastpack = -1;
    do
    {
	length = receive_packet( socket, buf, S_SILENT );
	if( buf[7] != lastpack && extracted_players == FALSE )
	  {
	    get_player_info( buf, length, maxp );
	    /* dirty hack: qcmods generate too much data -> split up */
	    extracted_players = TRUE;
	  }
	ack_packet( socket, buf );
    } while( get_packet_header( buf ) != 0x0900 );    

    mypack = get_qpack( QPACK_BEGIN );
    insert_packnum( mypack, 0 );
    increase_packnum( 0 );
    length = check_send( socket, mypack,
			  get_qpack_length( QPACK_BEGIN ),
			  S_SILENT );

    print_players();
    init_bot();
    if ( dumpfp )
      fflush( dumpfp );
}

const char *getmapname( const char *buf, int count )
{
  const char *s;

  if ( count < 51 )
    return NULL;

  s = buf + 50;
  if ( *s < 32 )
    return NULL;

  printf( "Entering %s\n", s );
  s += strlen( s ) + 1;

  if ( count < ( s - buf + strlen( s ) ) )
       return NULL;

  printf( "New mapname is: %s\n", s );
  update_mapname( s );
  return s;
}
