#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

#include "qbot.h"
#include "qproto.h"
#include "socket.h"
#include "qplayer.h"
#include "qcdefs.h"
#include "rproto.h"

static int state;
static int myid;
static unsigned char *myname;
static int visible[16];
static int vcount;
static int targetid;

struct move_str botmove;
struct weapons_str botweapons;

extern FILE *poslogfp;


#define FALSE 0
#define TRUE 1

void set_my_id( int id )
{
    myid = id;
}

int get_my_id()
{
    return myid;
}


void set_bot_name( char *n )
{
    myname = strdup( n );
}

char *get_bot_name()
{
    return myname;
}


void delete_visible()
{
    vcount = 0;
}

void add_visible( int id )
{
    visible[vcount++] = id;
}


void init_bot()
{
    set_state( BS_MOVING );
    targetid = -1;
    botmove.forward = 0;
    botmove.backward = 0;
    botmove.strafe = 0;    
    botmove.angle1 = 0;
    botmove.fire = 0;    
    botmove.jump = 0;    
}


int set_state( int newstate )
{
/*
  printf( "%s entered state %d\n", myname, newstate );
  */  
    state = newstate;
    return state;
}

int get_state()
{
    return state;
}


int update_qbot( int socket )
{
    if( state == BS_STOPPED )
    {
	return state;
    }
    send_movement( socket );
    return state;
}


int get_angle( int id, int mode )
{
    int lx, ly, lz, kat1;
    double dest;
    double angle, ra;
    int tmpangle;
    int myid;

    myid = get_my_id();

    lx = Players[myid]->x - Players[id]->x;
    ly = Players[myid]->y - Players[id]->y;
    lz = Players[myid]->z - Players[id]->z;    

    dest = sqrt( pow( ((double)lx), 2 ) + pow( ((double)ly), 2 ) );
    if( dest <= 0 )
	return 0;

    if( mode == 1 )
    {
	kat1 = dest;
	dest = sqrt( pow( kat1, 2 ) + pow( ((double)lz), 2 ) );	

	ra = (double) kat1 / dest;
	angle = acos( ra ) * ( lz < 0 ? -1 : 1 );
	tmpangle = (int) (angle * 256 / (2*PI));

    }
    else
    {
	ra = (double) lx / dest;
	angle = acos( ra );
	
	if( lx < 0 && ly > 0 )
	    angle = PI - angle;
	
	if( lx < 0 && ly < 0 )
	    angle = PI + angle;
	
	if( lx > 0 && ly < 0 )
	    angle = 2 * PI - angle;
	
	angle += PI;
	
	if( lx < 0 )
	    angle = PI - angle;
	tmpangle = (int) (angle * 256 / (2*PI));
	tmpangle = tmpangle % 256;
    }
    
    return tmpangle;
}


int is_visible( int id )
{
    int i;

    for( i = 0; i < vcount; i++ )
	if( visible[i] == id )
	    return TRUE;

    return FALSE;
}


void run_qbot()
{
    int i;
    double prev_dist;
    static int strafedist = 1;
    static int distance = 0;
    static int lastid = -1;
    static int stopcount = 2;
    int friendly = TRUE;
    extern char *teamprefix;

    
#if 0
    if( get_state() == BS_STOPPED )
	return;
#endif
#ifndef QUIET    
    fflush( stdout );
#endif
      if ( (botweapons.byte2 & 0x01) == 0 ) /* I'm not dead */
	{
#if 1
	  if( vcount == 0 )
	    {
	      targetid = -1;
	      set_state( BS_MOVING );
	    }
	  else
	    set_state( BS_ATTACK );
#else
	  /* for development of the routing */
	  set_state( BS_MOVING );
#endif
	}


      {
	int myid;
	extern FILE *dumpfp;
	extern int route_socket;
	static int oldhealth = 100;
	static int oldarmor = 0;
	static int oldbit = 0;
	char rbuf[256];

	myid = get_my_id();

	if ( (botweapons.byte2 & 0x01) != oldbit )
	  {
	    if ( !oldbit )
	      {
		set_state( BS_STOPPING );
	      }
	    printf( "deathbit is %u\n", botweapons.byte2 & 0x01 );
	    oldbit = botweapons.byte2 & 0x01;
	  }
	if ( !oldbit )
	  update_position( Players[myid]->x, Players[myid]->y, Players[myid]->z );
	if ( botweapons.health > oldhealth )
	  {
	    int increase;
	    increase = botweapons.health - oldhealth;
	    if ( increase <= 100 ) /* be sane */
	      update_goodies( gk_health, increase );
	  }
	
	if ( botweapons.armor > oldarmor )
	  {
	    int increase;
	    increase = botweapons.armor - oldarmor;
	    if ( increase <= 200 ) /* be sane */
	      update_goodies( gk_armor, increase );
	  }

	oldhealth = botweapons.health;
	oldarmor = botweapons.armor;
      }

      update_state( (char) state );
      switch( state )
    {
      case BS_ATTACK:
	stopcount = 2;
	targetid = visible[0];
	prev_dist = 999999;
	/*	    printf( "self at x:%hx, y:%hx, z:%hx\n",
		    Players[myid]->x, Players[myid]->y, Players[myid]->z );
		    */
	for( i = 0; i < vcount; i++ )
	{
	  int this_one_friendly = FALSE;
	  if ( teamprefix )
	    this_one_friendly = ( strstr( Players[visible[i]]->name, teamprefix ) != NULL );

	  Players[visible[i]]->dist = get_distance( get_my_id(), visible[i] );
	  if ( friendly == TRUE && this_one_friendly == FALSE )
	    {
	      prev_dist = Players[visible[i]]->dist;
	      targetid = visible[i];
	      friendly = FALSE;
	    }

	  /*	    printf( "%d at distance %lf x:%hx, y:%hx, z:%hx\n", visible[i], Players[visible[i]]->dist,
		    Players[visible[i]]->x, Players[visible[i]]->y, Players[visible[i]]->z );
		    */

	    if( Players[visible[i]]->dist < prev_dist )
	      {
		if ( friendly == TRUE || this_one_friendly == FALSE )
		  {
		    prev_dist = Players[visible[i]]->dist;
		    targetid = visible[i];
		  }
	      }
	    
	}

	if( lastid != -1 )
	{
	    if( targetid != lastid )
		lastid = targetid;
	}

	botmove.angle1 = get_angle( targetid, 0 );
	botmove.angle2 = get_angle( targetid, 1 );
#if 0
	if( botmove.angle2 > 0x0f )
	    botmove.angle2 = 0x0f;
#endif
    
/*
	printf( "Attacking at dist:%lf a1:%d a2:%d\n",
		prev_dist, botmove.angle1, botmove.angle2 );
		*/
	select_weapon( prev_dist );
	botmove.fire = ( friendly ? 0 : 1 );
	if( (rand()&31) == 2 && friendly == FALSE )
	  {
	    botmove.jump = 1;
	  }
	else
	  botmove.jump = 0;

	if ( friendly && prev_dist < 1000 )
	  botmove.forward = 0;
	else
	  botmove.forward = 1;
	if ( botmove.weapon == 6 /* grenade launcher */ ||
	     botmove.weapon == 7 /* rocket launcher */ )
	  botmove.forward = 0;

#if 0
	if( (rand()&3) == 1 )
	  strafedist *= -1;
	botmove.strafe = 1 * strafedist;
#else
	{
	  int d_angle;
	  d_angle = (Players[targetid]->angle1 + 256 - botmove.angle1) % 256;
	  if ( d_angle < 128 )
	    botmove.strafe = 0x7ff;
	  else
	    botmove.strafe = -0x800;
	  if( (rand()%5) == 1 )
	    botmove.strafe *= -1;
	  if ( d_angle < 128 - ( prev_dist < 300 ? 42 : 24 ) || d_angle > 128 + ( prev_dist < 300 ? 42 : 24 ) )
	    botmove.strafe = 0;
	}
#endif
	break;
	
      case BS_MOVING:
	stopcount = 2;
	lastid = -1;
#if 1
	/* random direction - pretty good */
	if( distance <= 0 )
	{
	    distance = rand() & 31;
	    botmove.angle1 = rand() & 255;
	    botmove.angle2 = rand() & 255;
	}
	botmove.forward = 1;
#else
	/* routing development */
	{
	  int moving_mode;
	  int myid;
	  int at_destination;
	  short tx, ty, tz;

	  myid = get_my_id();
	  moving_mode = get_movingmode();
	  get_destination( &tx, &ty, &tz );
	  update_destination( tx, ty, tz );
	  at_destination = ( (abs(tx-Players[myid]->x)&~0x1f) == 0 && 
			     (abs(ty-Players[myid]->y)&~0x1f) == 0 &&
			     (abs(tz-Players[myid]->z)&~0x1f) == 0 );
	  if ( at_destination && moving_mode != mm_spin_on )
	    {
	      switch( moving_mode )
		{
		case mm_walk_on:
		  if ( botmove.forward == 1 )
		    printf( "Reached destination, moving on\n" );
		  botmove.forward = 1;
		  break;
		case mm_stop_at:
		  if ( botmove.forward == 1 )
		    printf( "Reached destination, stopping\n" );
		  botmove.forward = 0;
		  break;
		default:
		  printf( "Unknown movingmode %d\n", moving_mode );
		}
	    }
	  else
	    {
	      botmove.forward = 1;
	      Players[0]->x = tx;
	      Players[0]->y = ty;
	      Players[0]->z = tz;
	      botmove.angle1 = get_angle( 0, 0 );
	      botmove.angle2 = get_angle( 0, 1 );
	      if( botmove.angle2 > 0x0f )
		botmove.angle2 = 0x0f;
	    }
	}
#endif	
	if( (rand() & 16) == 2 )
	    botmove.jump = 1;
	else
	    botmove.jump = 0;

	botmove.fire = 0;
	botmove.strafe = 0;
	distance--;
	break;

      case BS_STOPPING:
	printf( "Stopping...\n" );
	stopcount--;
	if( stopcount <= 0 )
	    set_state( BS_STOPPED );
	botmove.forward = 0;
	botmove.angle1 = 0;
	botmove.angle2 = 0;
	botmove.fire = 0;
	botmove.jump = 0;
	botmove.strafe = 0;
	break;
    case BS_STOPPED:
      printf( "Stopped - starting to respawn\n" );
      set_state( BS_RESPAWNING );
      break;
    case BS_RESPAWNING:
      stopcount--;
      fflush( stdout );
      botmove.fire = 0;
      botmove.jump = (stopcount & 0x08) >> 3;
      putc( 48+botmove.jump, stdout );
      botmove.forward = 0;
      botmove.strafe = 0;
      break;
    }
}


double get_distance( int id1, int id2 )
{
    int x1, x2, y1, y2, z1, z2, dx, dy, dz;

    x1 = Players[id1]->x;
    y1 = Players[id1]->y;
    z1 = Players[id1]->z;

    x2 = Players[id2]->x;
    y2 = Players[id2]->y;
    z2 = Players[id2]->z;

    dx = x1 - x2;
    dy = y1 - y2;
    dz = z1 - z2;
/*
    printf( "x1:%d y1:%d z1:%d x2:%d y2:%d z2:%d dx:%d dy:%d dz:%d \n", x1, y1, z1,
	    x2, y2, z2, dx, dy, dz );
	    */  
    return( sqrt( pow( ((double)dx), 2 ) +
		  pow( ((double)dy), 2 ) +
		  pow( ((double)dz), 2 ) ) );
}

void select_weapon( int distance )
{

  /* select a weapon, start with the axe and */
  /* see if we have anything better */
  /* a players height is 70 (pixels) */

  extern int hits, misses;
  botmove.weapon = 0;
  if ( distance < 200 )
    botmove.weapon = 1; /* IT_AXE, we always have it and the shotgun */
  if ( botweapons.shells > 0 )
    {
      if ( distance < 1500 && (botweapons.arsenal & IT_SUPER_SHOTGUN) )
	botmove.weapon = 3;
      else if ( distance > 100 )
	botmove.weapon = 2;
    }
  
  if ( botweapons.nails > 0 )
    {
      if (botweapons.arsenal & IT_SUPER_NAILGUN )
	botmove.weapon = 5;
      else if ( (botweapons.arsenal & IT_NAILGUN) &&
		botmove.weapon != 3 )
	botmove.weapon = 4;
    }
  
  /* Here ought to be a check for armor, but we dont know that yet */
  if ( hits > 2 && botweapons.rockets > 0 && distance > 2000 && botmove.angle2 < 0x0f )
    {
      if ( distance < 2500 && botweapons.arsenal & IT_GRENADE_LAUNCHER )
	botmove.weapon = 6;
      if ( distance < 4000 && botweapons.arsenal & IT_ROCKET_LAUNCHER )
	botmove.weapon = 7;
    }
  
  if ( distance < 6000 && botweapons.cells > 0 && (botweapons.arsenal & IT_LIGHTNING) )
    botmove.weapon = 8;

  /* OK, if we already are using the selected weapon, we don't need to */
  /* change to it */
  if ( ( botweapons.curr_weapon == IT_AXE && botmove.weapon == 1 ) ||
       ( botweapons.curr_weapon == ( 0x01 << (botmove.weapon-2) ) ) )
    botmove.weapon = 0;
#ifndef QUIET
  if ( botmove.weapon )
    printf( "Weaponchange: impulse %d\n", botmove.weapon );
#endif
}


