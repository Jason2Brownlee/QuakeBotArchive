#ifndef __qplayer_h_
#define __qplayer_h_

struct player_str 
{
    char name[64];
    int active;
    int color1, color2;
    int frags;
    
    int x, y, z;
    int angle1;
    int angle2;
    double dist;
};

extern struct player_str **Players;

void init_players( int num );
void insert_player( int id, char *name, int frags, int c1, int c2 );
void rename_player( int id, char *name );
void change_colors( int id, int c1, int c2 );
void set_fragcount( int id, int frags );
void delete_players();
void delete_player( int id );
void print_players();
void print_player( int id );
int get_maxp();


#endif !__qplayer_h_
