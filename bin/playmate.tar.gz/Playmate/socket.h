#ifndef __socket_h_
#define __socket_h_

#define	BUFSIZE		8192

#define S_SILENT	0
#define S_NOISY		1

int sock_client( char *hostname, int port );
int sock_stream_client( char *hostname, int port );
int sock_connect( int sock, char *host, int port );
int send_packet( int s, unsigned char *buf, int length, int mode );
int receive_packet( int s, unsigned char *buf, int mode );
void dump_packet( unsigned char *pack, int count );
void dump_packet_tight( unsigned char *pack, int count );

#endif !__socket_h_
