#ifndef __rproto_h
#define __rproto_h

/*
   Protocol for the playmate-qroute connection
   alonn@odin.tf.hut.fi 1996 
*/

#include "../qroute/pproto.h"
#include "qbot.h"

#define PLAYMATE_UPDATE 0x42666
#define EXITLEVEL 0x42111
#define ENTERLEVEL 0x11142

typedef enum { gk_health, gk_armor, gk_shells, gk_nails, gk_rockets, gk_cells,
	       gk_supershotgun, gk_nailgun, gk_supernailgun,
	       gk_grenadelauncher, gk_rocketlauncher, gk_thunderbolt,
	       gk_quaddamage, gk_pentagram, gk_biosuit,
	       gk_ringofshadows, gk_unknown } goodieskind;

typedef enum { dk_telefrag, dk_slime, dk_lava, dk_squish, dk_drown,
	       dk_spike, dk_unknown } damagekind;

struct update_str
{
  int start_check;
  char state;
  struct q_point pos;
  struct q_point dest;
  struct weapons_str weapons;
  goodieskind goodie;
  short amount;
  damagekind damage;
};

int connect_to_router();

int send_update( int type );

void update_mapname( const char *s );
void update_position( short x, short y, short z );
void update_destination( short x, short y, short z );
void update_goodies( goodieskind type, short amount );
void update_deadly_damage( damagekind type );
void update_state( char state );

int poll_commands();
int get_playrect( short *xl, short *xh, short *yl, short *yh );
int get_destination( short *x, short *y, short *z ); 
m_mode get_movingmode();

#endif /* __rproto_h */
