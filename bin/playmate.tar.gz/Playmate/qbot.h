#ifndef __qbot_h_
#define __qbot_h_

struct move_str 
{
    int forward;
    int backward;
    int strafe;
    int angle1;
    int angle2;
    int fire;
    int jump;
    int weapon;
};

extern struct move_str botmove;


struct weapons_str
{
  unsigned char byte2; /* second byte in packet */
  unsigned char byte3; /* third byte in packet */

  long arsenal; /* bits telling what we have */

  short health;
  short armor;
  unsigned char curr_weapon_ammo;
  unsigned char shells;
  unsigned char nails;
  unsigned char rockets;
  unsigned char cells;
  unsigned char curr_weapon;
};

extern struct weapons_str botweapons;

#define MS_ROMP		0
#define MS_FOLLOW	1

#define BS_IDLE		0
#define BS_STOPPING	1
#define BS_STOPPED	2
#define BS_MOVING	3
#define BS_ATTACK	4
#define BS_RESPAWNING   5


void set_my_id( int id );
int get_my_id();
void set_bot_name( char *n );
char *get_bot_name();
void delete_visible();
void add_visible( int id );
void init_bot();
int set_state( int newstate );
int get_state();
int update_qbot( int socket );
int get_angle( int id, int mode );
int is_visible( int id );
void run_qbot();
double get_distance( int id1, int id2 );
void select_weapon( int distance );

#endif !__qbot_h_
