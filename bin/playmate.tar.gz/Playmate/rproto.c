#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include "glob.h"
#include "rproto.h"
#include "socket.h"
#include "../qroute/pproto.h"

#define ROUTE_HOST "odin.tf.hut.fi"
#define ROUTE_PORT 25999

static char rbuf[256]; /* no need to run up and down the stack all the time */
int route_socket = -1;
static struct r_packet route_command;
static struct update_str route_update;
static char map_name[64];

int connect_to_router()
{
    route_socket = sock_stream_client( ROUTE_HOST, ROUTE_PORT );
    
    if( route_socket == -1 )
    {
	fprintf( stderr, "Error: Can't connect to router host '%s' on port %d\n", ROUTE_HOST, ROUTE_PORT );
    }
    return route_socket;
}

void update_mapname( const char *s )
{
#if 0
  if ( route_socket >= 0 && strlen( s ) < 255 )
    {
      sprintf( rbuf, "enterlevel: %s\n", s );
      send_packet( route_socket, rbuf, strlen( rbuf ), S_SILENT );
    }
#else
  strncpy( map_name, s, sizeof( map_name ) );
#endif
}

void update_position( short x, short y, short z )
{
#if 0
  static short prevx = 0, prevy = 0, prevz = 0;
  if ( route_socket >= 0 )
    {
      sprintf( rbuf, "moved to: %hd %hd %hd from %hd %hd %hd\n",
	       x, y, z, prevx, prevy, prevz );
      send_packet( route_socket, rbuf, strlen( rbuf ), S_SILENT );
    }
  prevx = x;
  prevy = y;
  prevz = z;
#else
  route_update.pos.x = x;
  route_update.pos.y = y;
  route_update.pos.z = z;
#endif
}

void begin_update()
{
  memset( &route_update, 0, sizeof( route_update ) );
}

void update_destination( short x, short y, short z )
{
#if 0
  static short px, py, pz;
  if ( x == px && y == py && pz == z && (rand()&32) > 2 )
    return;
  px = x;
  py = y;
  pz = z;
  if ( route_socket >= 0 )
    {
      sprintf( rbuf, "moving towards: %hd %hd %hd\n", x, y, z );
      send_packet( route_socket, rbuf, strlen( rbuf ), S_SILENT );
    }
#else
  route_update.dest.x = x;
  route_update.dest.y = y;
  route_update.dest.z = z;
#endif
}

void update_state( char state )
{
  route_update.state = state;
}

void update_goodies( goodieskind type, short amount )
{
#if 0
  if ( route_socket >= 0 )
    {
      printf( "goodie\n" );
      sprintf( rbuf, "goodie: 0 %d %d\n", type, amount );
      send_packet( route_socket, rbuf, strlen( rbuf ), S_SILENT );
    }
#else
  route_update.goodie = type;
  route_update.amount = amount;
#endif
}

void update_deadly_damage( damagekind type )
{
#if 0
  if ( route_socket >= 0 )
    {
      printf( "deadly damage\n" );
      sprintf( rbuf, "deadly damage: %d\n", type );
      send_packet( route_socket, rbuf, strlen( rbuf ), S_SILENT );
    }
#else
  route_update.damage = type;
#endif
}

int send_update( int type )
{
  int ret;
  char *ch;
  int offset = 0;
  int filedes;

  filedes = route_socket;
  if ( filedes == -1 )
    {
      static int donethis = 0;
      if ( !donethis )
	{
	  fprintf( stderr, "send_update() : file descriptor is not valid\n" );
	  donethis = 1;
	}
      return 0;
    }

  switch( type )
    {
    case EXITLEVEL:
      route_update.start_check = type;
      break;
    case ENTERLEVEL:
      route_update.start_check = type;
      strncpy( ( (char*) &route_update ) + sizeof( int ), map_name,
	       sizeof( route_update ) - sizeof( int ) );
      break;
    case PLAYMATE_UPDATE:
      route_update.start_check = type;
      break;
    default:
      printf( "send_update(): Unknown type %d\n", type );
      return 0;
    }
  ret = write( filedes, (char *) &route_update, sizeof( route_update ) );
  return ret;
}


int poll_commands()
{
  fd_set rdset;
  struct timeval tout = { 0, 0 };

  if ( route_socket == -1 )
    return -1;
  FD_ZERO( &rdset );
  FD_SET( route_socket, &rdset );
  
  select( 32, &rdset, NULL, NULL, &tout );

  if ( FD_ISSET( route_socket, &rdset ) )
    {
      int count = 0;
      int max_reads = 100;
      while( count < sizeof( struct r_packet ) && max_reads > 0 )
	{
	  count += read( route_socket, rbuf + count, sizeof( struct r_packet ) - count );
	}

      if ( *rbuf == pp_area && count == sizeof( struct r_packet ) )
	{
	  memcpy( &route_command, rbuf, sizeof( struct r_packet ) );
	  return count;
	}
      printf( "Synchronizing" );
      while( read( route_socket, rbuf, sizeof( rbuf ) ) > 0 )
	putc( '.', stdout );
      putc( '\n', stdout );
    }

  return 0;
}

m_mode get_movingmode()
{
  return route_command.mmode;
}

int get_playrect( short *xl, short *xh, short *yl, short *yh )
{
  if ( xl )
    *xl = route_command.rect.lx;
  if ( xh )
    *xh = route_command.rect.hx;
  if ( yl )
    *yl = route_command.rect.ly;
  if ( yh )
    *yh = route_command.rect.hy;

  return 0;
}

int get_destination( short *x, short *y, short *z )
{
  if ( x )
    *x = route_command.dest.x;
  if ( y )
    *y = route_command.dest.y;
  if ( z )
    *z = route_command.dest.z;
  return 0;
} 

