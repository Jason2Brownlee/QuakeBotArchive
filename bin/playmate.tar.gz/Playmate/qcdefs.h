
/*
==============================================================================

			SOURCE FOR ENTVARS_T C STRUCTURE

==============================================================================
*/

/*
//
// system fields (*** = do not set in prog code, maintained by C code)
//
.float		modelindex;		// *** model index in the precached list
.vector		absmin, absmax;	// *** origin + mins / maxs

.float		ltime;			// local time for entity
.float		movetype;
.float		solid;

.vector		origin;			// ***
.vector		oldorigin;		// ***
.vector		velocity;
.vector		angles;
.vector		avelocity;

.vector		punchangle;		// temp angle adjust from damage or recoil

.string		classname;		// spawn function
.string		model;
.float		frame;
.float		skin;
.float		effects;

.vector		mins, maxs;		// bounding box extents reletive to origin
.vector		size;			// maxs - mins

.void()		touch;
.void()		use;
.void()		think;
.void()		blocked;		// for doors or plats, called when can't push other

.float		nextthink;
.entity		groundentity;

// stats
.float		health;
.float		frags;
.float		weapon;			// one of the IT_SHOTGUN, etc flags
.string		weaponmodel;
.float		weaponframe;
.float		currentammo;
.float		ammo_shells, ammo_nails, ammo_rockets, ammo_cells;

.float		items;			// bit flags

.float		takedamage;
.entity		chain;
.float		deadflag;

.vector		view_ofs;			// add to origin to get eye point


.float		button0;		// fire
.float		button1;		// use
.float		button2;		// jump

.float		impulse;		// weapon changes

.float		fixangle;
.vector		v_angle;		// view / targeting angle for players
.float		idealpitch;		// calculated pitch angle for lookup up slopes


.string		netname;

.entity 	enemy;

.float		flags;

.float		colormap;
.float		team;

.float		max_health;		// players maximum health is stored here

.float		teleport_time;	// don't back up

.float		armortype;		// save this fraction of incoming damage
.float		armorvalue;

.float		waterlevel;		// 0 = not in, 1 = feet, 2 = wast, 3 = eyes
.float		watertype;		// a contents value

.float		ideal_yaw;
.float		yaw_speed;

.entity		aiment;

.entity 	goalentity;		// a movetarget or an enemy

.float		spawnflags;

.string		target;
.string		targetname;

// damage is accumulated through a frame. and sent as one single
// message, so the super shotgun doesn't generate huge messages
.float		dmg_take;
.float		dmg_save;
.entity		dmg_inflictor;

.entity		owner;		// who launched a missile
.vector		movedir;	// mostly for doors, but also used for waterjump

.string		message;		// trigger messages

.float		sounds;		// either a cd track number or sound number

.string		noise, noise1, noise2, noise3;	// contains names of wavs to play

//================================================
void		end_sys_fields;			// flag for structure dumping
//================================================

*/
/*
==============================================================================

				VARS NOT REFERENCED BY C CODE

==============================================================================
*/



#define	FL_FLY			1
#define	FL_SWIM			2
#define	FL_CLIENT		8
	/* set for all client edicts */
#define	FL_INWATER		16
	/* for enter / leave water splash */
#define	FL_MONSTER		32
#define	FL_GODMODE		64
	/* player cheat */
#define	FL_NOTARGET		128
	/* player cheat */
#define	FL_ITEM			256
	/* extra wide size for bonus items */
#define	FL_ONGROUND		512
	/* standing on something */
#define	FL_PARTIALGROUND	1024
	/* not all corners are valid */
#define	FL_WATERJUMP		2048
	/* player jumping out of water */
#define	FL_JUMPRELEASED		4096
	/* for jump debouncing */

/* edict.movetype values */
#define	MOVETYPE_NONE			0
	/* never moves */
/*#define	MOVETYPE_ANGLENOCLIP	1 */
/*#define	MOVETYPE_ANGLECLIP	2 */
#define	MOVETYPE_WALK			3
	/* players only */
#define	MOVETYPE_STEP			4
	/* discrete, not real time unless fall */
#define	MOVETYPE_FLY			5
#define	MOVETYPE_TOSS			6
	/* gravity */
#define	MOVETYPE_PUSH			7
	/* no clip to world, push and crush */
#define	MOVETYPE_NOCLIP			8
#define	MOVETYPE_FLYMISSILE		9
	/* fly with extra size against monsters */
#define	MOVETYPE_BOUNCE			10
#define	MOVETYPE_BOUNCEMISSILE		11
	/* bounce with extra size */

/* edict.solid values */
#define	SOLID_NOT			0
	/* no interaction with other objects */
#define	SOLID_TRIGGER			1
	/* touch on edge, but not blocking */
#define	SOLID_BBOX			2
	/* touch on edge, block */
#define	SOLID_SLIDEBOX			3
	/* touch on edge, but not an onground */
#define	SOLID_BSP			4
	/* bsp clip, touch on edge, block */

/* range values */
#define	RANGE_MELEE			0
#define	RANGE_NEAR			1
#define	RANGE_MID			2
#define	RANGE_FAR			3

/* deadflag values */

#define	DEAD_NO				0
#define	DEAD_DYING			1
#define	DEAD_DEAD			2
#define	DEAD_RESPAWNABLE		3

/* takedamage values */

#define	DAMAGE_NO			0
#define	DAMAGE_YES			1
#define	DAMAGE_AIM			2

/* items */
#define	IT_AXE				4096
#define	IT_SHOTGUN			1
#define	IT_SUPER_SHOTGUN		2
#define	IT_NAILGUN			4
#define	IT_SUPER_NAILGUN		8
#define	IT_GRENADE_LAUNCHER		16
#define	IT_ROCKET_LAUNCHER		32
#define	IT_LIGHTNING			64
#define	IT_EXTRA_WEAPON			128

#define	IT_SHELLS			256
#define	IT_NAILS			512
#define	IT_ROCKETS			1024
#define	IT_CELLS			2048

#define	IT_ARMOR1			8192
#define	IT_ARMOR2			16384
#define	IT_ARMOR3			32768
#define	IT_SUPERHEALTH			65536

#define	IT_KEY1				131072
#define	IT_KEY2				262144

#define	IT_INVISIBILITY			524288
#define	IT_INVULNERABILITY		1048576
#define	IT_SUIT				2097152
#define	IT_QUAD				4194304

/* point content values */

#define	CONTENT_EMPTY			-1
#define	CONTENT_SOLID			-2
#define	CONTENT_WATER			-3
#define	CONTENT_SLIME			-4
#define	CONTENT_LAVA			-5
#define	CONTENT_SKY				-6

#define	STATE_TOP			0
#define	STATE_BOTTOM			1
#define	STATE_UP			2
#define	STATE_DOWN			3


/* protocol bytes */
#define	SVC_TEMPENTITY			23
#define	SVC_KILLEDMONSTER		27
#define	SVC_FOUNDSECRET			28
#define	SVC_INTERMISSION		30
#define	SVC_FINALE			31
#define	SVC_CDTRACK			32
#define	SVC_SELLSCREEN			33


#define	TE_SPIKE		0
#define	TE_SUPERSPIKE		1
#define	TE_GUNSHOT		2
#define	TE_EXPLOSION		3
#define	TE_TAREXPLOSION		4
#define	TE_LIGHTNING1		5
#define	TE_LIGHTNING2		6
#define	TE_WIZSPIKE		7
#define	TE_KNIGHTSPIKE		8
#define	TE_LIGHTNING3		9
#define	TE_LAVASPLASH		10
#define	TE_TELEPORT		11

/* sound channels */
/* channel 0 never willingly overrides */
/* other channels (1-7) allways override a playing sound on that channel */
#define	CHAN_AUTO		0
#define	CHAN_WEAPON		1
#define	CHAN_VOICE		2
#define	CHAN_ITEM		3
#define	CHAN_BODY		4

#define	ATTN_NONE		0
#define	ATTN_NORM		1
#define	ATTN_IDLE		2
#define	ATTN_STATIC		3

/* update types */

#define	UPDATE_GENERAL		0
#define	UPDATE_STATIC		1
#define	UPDATE_BINARY		2
#define	UPDATE_TEMP		3

/* entity effects */

#define	EF_BRIGHTFIELD		1
#define	EF_MUZZLEFLASH 		2
#define	EF_BRIGHTLIGHT 		4
#define	EF_DIMLIGHT 		8


/* messages */
#define	MSG_BROADCAST		0
		/* unreliable to all */
#define	MSG_ONE			1
		/* reliable to one (msg_entity) */
#define	MSG_ALL			2
		/* reliable to all */
#define	MSG_INIT		3
		/* write to the init string */

