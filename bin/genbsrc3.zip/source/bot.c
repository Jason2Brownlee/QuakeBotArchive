#include "qwsvdef.h"
//#include "world.h"

extern float bots;
extern	cvar_t	sv_gravity;
int msecnum;
float msecdel;
float msecval;

int wp_edit_mode;

int wp_total;

int wp_loaded;

waypoint_t	WPArray[4096]; //I am being very lazy here. Fix it if you want.
char		wpdatastring[524288]; //This is awful also, feel free to fix it.
//This stuff is basically carried over from old bad Jumbot code.

float vlen2(vec3_t v)
{
	return sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
	/*vec3_t value1;
	float new;

	value1[0] = v[0];
	value1[1] = v[1];
	value1[2] = v[2];

	new = value1[0] * value1[0] + value1[1] * value1[1] + value1[2]*value1[2];
	new = sqrt(new);*/
}

int BotUtil_Visible(vec3_t v1, vec3_t v2, edict_t *ent) {
	float wplen;
	trace_t trCheck;
	vec3_t v_mins, v_maxs;
	vec3_t product;

	//trCheck = BotUtil_TraceLine(v1, v2, 0, ent);
	trCheck = SV_Move (v1, vec3_origin, vec3_origin, v2, 0, ent);//ent);

	if (trCheck.fraction == 1) {
		/*product[0] = 0;
		product[1] = 0;
		product[2] = 0;

		VectorSubtract(v1, v2, product);

		wplen = vlen2(product);

		Con_Printf("Visible! %f\n", wplen);*/
		return 1;
	}
	else
		return 0;
	
	return 0;
}

char	*vtos (vec3_t v)
{
	static	int		index;
	static	char	str[8][32];
	char	*s;
	
	s = str[index];
	index = (index + 1)&7;
	
	sprintf (s, "(%i %i %i)", (int)v[0], (int)v[1], (int)v[2]);
	
	return s;
}

trace_t BotUtil_TraceLine(vec3_t v1, vec3_t v2, int nomons, edict_t *ent) {
	trace_t trace;
	vec3_t v_mins, v_maxs;

	//trace = SV_Move (v1, mins, maxs, v2, nomons, ent);
	trace = SV_Move (v1, v_mins, v_maxs, v2, nomons, ent);

	return trace;
}

void vectoanglesbot(vec3_t vec, vec3_t ang)
{
	float	forward;
	float	yaw, pitch;
	
	if (vec[1] == 0 && vec[0] == 0)
	{
		yaw = 0;
		if (vec[2] > 0)
			pitch = 90;
		else
			pitch = 270;
	}
	else
	{
		yaw = (int) (atan2(vec[1], vec[0]) * 180 / M_PI);
		if (yaw < 0)
			yaw += 360;
		
		forward = sqrt (vec[0]*vec[0] + vec[1]*vec[1]);
		pitch = (int) (atan2(vec[2], forward) * 180 / M_PI);
		if (pitch < 0)
			pitch += 360;
	}
	
	ang[0] = pitch;
	ang[1] = yaw;
	ang[2] = 0;
}

float UTIL_VecToYaw(vec3_t value1) {
	//float	*value1;
	float	yaw;
	
	//value1 = G_VECTOR(OFS_PARM0);

	if (value1[1] == 0 && value1[0] == 0)
		yaw = 0;
	else
	{
		yaw = (int) (atan2(value1[1], value1[0]) * 180 / M_PI);
		if (yaw < 0)
			yaw += 360;
	}

	//G_FLOAT(OFS_RETURN) = yaw;
	return yaw;
}

void RemoveBot(client_t *thisclient) {
	SV_DropClient(thisclient);
	thisclient->state = cs_zombie;
	thisclient->isabot = 0;
	thisclient->enemy = NULL;
	thisclient->afteritem = NULL;
	
	ED_ClearEdict(thisclient->edict);
	bots--;
}

int dontadd;

void RemoveBotL(client_t *thisclient) {
	dontadd = 1;
	SV_DropClient(thisclient);
	thisclient->state = cs_zombie;
	thisclient->isabot = 0;
	thisclient->enemy = NULL;
	thisclient->afteritem = NULL;
	
	ED_ClearEdict(thisclient->edict);
}

void Bot_WP_Create(client_t *player, int type) {
	if (!wp_edit_mode) {
		SV_ClientPrintf(host_client, PRINT_HIGH, "Waypoint edit mode is off on the server.\n");
		return;
	}

	if (wp_total >= 4095) {
		SV_ClientPrintf(host_client, PRINT_HIGH, "Waypoint limit hit.\n");
		return;
	}

	WPArray[wp_total].wpnum = wp_total + 1;
	WPArray[wp_total].wptype = type;
	WPArray[wp_total].origin[0] = player->edict->v.origin[0];
	WPArray[wp_total].origin[1] = player->edict->v.origin[1];
	WPArray[wp_total].origin[2] = player->edict->v.origin[2];
	wp_total++;
}

void Bot_WP_Remove(client_t *player) {
	if (!wp_edit_mode) {
		SV_ClientPrintf(host_client, PRINT_HIGH, "Waypoint edit mode is off on the server.\n");
		return;
	}

	if (wp_total < 1) {
		SV_ClientPrintf(host_client, PRINT_HIGH, "No waypoint to remove.\n");
		return;
	}

	WPArray[wp_total].wpnum = 0;
	WPArray[wp_total].wptype = 0;
	WPArray[wp_total].origin[0] = 0;
	WPArray[wp_total].origin[1] = 0;
	WPArray[wp_total].origin[2] = 0;
	wp_total--;
}

sizebuf_t *WriteDest (void);
int cheaphack;
int wpset;

void WP_Send_Visible (void) {
	/*WriteByte (MSG_MULTICAST, SVC_TEMPENTITY);
	WriteByte (MSG_MULTICAST, TE_GUNSHOT);
	WriteByte (MSG_MULTICAST, 3);
	WriteCoord (MSG_MULTICAST, org_x);
	WriteCoord (MSG_MULTICAST, org_y);
	WriteCoord (MSG_MULTICAST, org_z);
	multicast (org, MULTICAST_PVS);*/
	int i = 0;

	if (!wp_edit_mode)
		return;

	while (i < 10) {
		if (WPArray[wpset].origin[0] ||
			WPArray[wpset].origin[1] ||
			WPArray[wpset].origin[2]) {
			cheaphack = 1;
			MSG_WriteByte (WriteDest(), 23); //23
			cheaphack = 1;
			MSG_WriteByte (WriteDest(), 12); //2
			cheaphack = 1;
			MSG_WriteByte (WriteDest(), 3);
			cheaphack = 1;
			MSG_WriteCoord (WriteDest(), WPArray[wpset].origin[0]);
			cheaphack = 1;
			MSG_WriteCoord (WriteDest(), WPArray[wpset].origin[1]);
			cheaphack = 1;
			MSG_WriteCoord (WriteDest(), WPArray[wpset].origin[2]);
		}
		wpset++;
		if (wpset > wp_total)
			wpset = 0;
		i++;
	}
}

void WP_Edit_Mode (void) {
	if (wp_edit_mode) {
		wp_edit_mode = 0;
		Con_Printf("Client waypoint edit mode off.\n");
	}
	else {
		wp_edit_mode = 1;
		Con_Printf("Client waypoint edit mode on.\n");
	}
}

void MakeWP_Manual (vec3_t org, int num, int type) {
	WPArray[wp_total].wptype = type;
	WPArray[wp_total].wpnum = num;
	WPArray[wp_total].origin[0] = org[0];
	WPArray[wp_total].origin[1] = org[1];
	WPArray[wp_total].origin[2] = org[2];
	WPArray[wp_total].WeightValue = 0;
	//Con_Printf("WP: %i, %s\n", WPArray[wp_total].wpnum, vtos(WPArray[wp_total].origin));
	wp_total++;
}

void MakeWPFromData (char wpdata[256]) {
	int wpnum_n;
	float wpx_n;
	float wpy_n;
	float wpz_n;
	int wptype_n;
	vec3_t remadeorigin;
	char *readdat = Hunk_Alloc(256);//new char[256];
	int charnum = 0;
	int dat_charnum = 0;

	while (wpdata[charnum] != ' ') {
		readdat[dat_charnum] = wpdata[charnum];
		dat_charnum++;
		charnum++;
	}
	readdat[dat_charnum] = '\0';

	wpnum_n = (int)strtod(readdat, NULL);
	
	dat_charnum = 0;

	charnum++;

	while (wpdata[charnum] != ' ') {
		readdat[dat_charnum] = wpdata[charnum];
		dat_charnum++;
		charnum++;
	}
	readdat[dat_charnum] = '\0';

	wptype_n = (int)strtod(readdat, NULL);

	dat_charnum = 0;

	charnum++;
	charnum++;

	while (wpdata[charnum] != ' ') {
		readdat[dat_charnum] = wpdata[charnum];
		dat_charnum++;
		charnum++;
	}
	readdat[dat_charnum] = '\0';

	wpx_n = (float)strtod(readdat, NULL);

	dat_charnum = 0;

	charnum++;

	while (wpdata[charnum] != ' ') {
		readdat[dat_charnum] = wpdata[charnum];
		dat_charnum++;
		charnum++;
	}
	readdat[dat_charnum] = '\0';

	dat_charnum = 0;

	wpy_n = (float)strtod(readdat, NULL);

	charnum++;

	while (wpdata[charnum] != ')') {
		readdat[dat_charnum] = wpdata[charnum];
		dat_charnum++;
		charnum++;
	}
	readdat[dat_charnum] = '\0';

	dat_charnum = 0;

	wpz_n = (float)strtod(readdat, NULL);

	charnum++;

	remadeorigin[0] = wpx_n;
	remadeorigin[1] = wpy_n;
	remadeorigin[2] = wpz_n;

	MakeWP_Manual (remadeorigin, wpnum_n, wptype_n);
}

void MakeWPsFromFile(FILE *f) {
	char readin[256];
	char buffer = 0;
	int charnum;
	
	wp_loaded = 1;
	
	charnum = 0;
	
	while (!feof(f) && buffer != '$') //$=EOF, automatically placed in WP write file func
	{
		buffer = fgetc(f);
		if (buffer != '$')
		{
			while (buffer != '\n' && buffer != '$')
			{
				readin[charnum] = buffer;
				charnum++;
				buffer = fgetc(f);
			}
			readin[charnum] = '\0';
			charnum = 0;
			MakeWPFromData (readin);
		}
	}
}

void LoadWPData() {
	char filename[256];
	FILE *f;
	char *gamedir;

	gamedir = Info_ValueForKey (svs.info, "*gamedir");

	if (!gamedir || strcmp(gamedir, "") == 0)
		gamedir = "id1";

	sprintf(filename, "%s\\Genebot Waypoint Data\\%s.gwd", gamedir, sv.name);

	f = fopen(filename, "r");
	if (!f) {
		Con_Printf("-------------------------------------------\nNote: This level has no waypoint data file.\n-------------------------------------------\n");
		return;
	}
	
	MakeWPsFromFile(f);
	fclose(f);

	Con_Printf("---------------------------------------------\nWaypoint data for this level has been loaded.\n---------------------------------------------\n");
}

void CompileArrayData() {
	int i = 0;

	while (i < wp_total) {
		sprintf(wpdatastring, "%s%d %d %s\n\0", wpdatastring, i, WPArray[i].wptype, vtos(WPArray[i].origin));
		i++;
	}

	sprintf(wpdatastring, "%s$\0", wpdatastring);
}

void WP_Write_Data (void) {
	char *gamedir;
	char *dstring = Hunk_Alloc(256);//(char *)malloc(512);
	int strsize = 0;
	FILE *f;

	if (!wp_edit_mode) {
		Con_Printf("Waypoint edit mode is off.\n");
		return;
	}

	if (wp_total < 1) {
		Con_Printf("There is no waypoint data to save.\n");
		return;
	}
	
	gamedir = Info_ValueForKey (svs.info, "*gamedir");

	if (!gamedir || strcmp(gamedir, "") == 0)
		gamedir = "id1";

	sprintf(dstring, "%s\\Genebot Waypoint Data", gamedir);
	//sprintf(dstring, "d:\\quake\\Arena");

	if (_chdir(dstring)) {
		Con_Printf("There is no Genebot path data for this mod.\nThe data will be placed in:\n%s\n", dstring);

		if (_mkdir(dstring)) {
			Con_Printf("There was an error creating %s, waypoint data will not be saved.\n", dstring);
			return;
		}
	}
	else {
		_chdir("..");
		_chdir("..");
	}
	
	sprintf(dstring, "%s\\Genebot Waypoint Data\\%s.gwd", gamedir, sv.name);

	f = fopen(dstring, "w+");
	
	if (!f) {
		Con_Printf("Could not create %s, waypoint data will not be saved.\n", dstring);
		return;
	}

	CompileArrayData();
	
	while (wpdatastring[strsize] && wpdatastring[strsize] != '\0')
		strsize++;
	
	fwrite( wpdatastring, strsize, 1, f );
	fclose(f);

	Con_Printf("Waypoint data file has been written to\n%s\n", dstring);
	WP_Edit_Mode();
	wp_loaded = 1;
}

void Cmd_RemoveBot (void) {
	client_t *cl;
	int i;
	
	for (i=0,cl=svs.clients ; i<MAX_CLIENTS ; i++,cl++)
	{
		if (cl->state != cs_free && cl->isabot == 1)
			break;
	}
	if (cl && cl->isabot == 1)
		RemoveBot(cl);
}

extern float gbllocaltime;

void ChangeYaw (client_t *cl, float speed)
{
	edict_t		*ent;
	float		ideal, current, move;
	
	ent = cl->edict;
	current = anglemod( ent->v.v_angle[1] );
	ideal = ent->v.ideal_yaw;
	
	if (current == ideal)
		return;
	move = ideal - current;
	if (ideal > current)
	{
		if (move >= 180)
			move = move - 360;
	}
	else
	{
		if (move <= -180)
			move = move + 360;
	}
	if (move > 0)
	{
		if (move > speed)
			move = speed;
	}
	else
	{
		if (move < -speed)
			move = -speed;
	}
	
	ent->v.v_angle[1] = anglemod (current + move);
}

float byaw = 10;

void Nav_Fallback(client_t *thisclient) {
	trace_t	trace, traceoldpos, tracevis, tracefw;
	vec3_t fororg, forward, right, up, yawangle;
	int anglenum = 0;
	int bestway = 0;
	int found = 0;
	int idist = 0;
	float bestdist = 0;
	vec3_t v_mins, v_maxs;
	vec3_t product, start, end;

	thisclient->s_move = 0;
				
	//ucmd->forwardmove = sv_maxspeed.value;
	thisclient->f_move = sv_maxspeed.value;
				
	thisclient->edict->v.v_angle[PITCH] = 0;
	yawangle[YAW] = anglenum;
				
	end[0] = thisclient->edict->v.origin[0];
	end[1] = thisclient->edict->v.origin[1];
	//end[2] = thisclient->edict->v.origin[2];
	end[2] = thisclient->gohere[2];
	
	//if (!thisclient->gohere[0] && !thisclient->gohere[1] && !thisclient->gohere[2]) {
	//	thisclient->gohere[0] = thisclient->edict->v.origin[0];
	//	thisclient->gohere[1] = thisclient->edict->v.origin[1];
	//	thisclient->gohere[2] = thisclient->edict->v.origin[2];
	//}
	
	AngleVectors(thisclient->edict->v.v_angle, forward, right, up);
	
	fororg[0] = thisclient->edict->v.origin[0] + forward[0]*30;
	fororg[1] = thisclient->edict->v.origin[1] + forward[1]*30;
	fororg[2] = thisclient->edict->v.origin[2] + forward[2]*30;
				
	tracevis = SV_Move (thisclient->edict->v.origin, v_mins, v_maxs, thisclient->gohere, 0, thisclient->edict);
	tracefw = SV_Move (thisclient->edict->v.origin, v_mins, v_maxs, fororg, 0, thisclient->edict);
	
	if (tracevis.fraction != 1.0 || SV_PointContents(fororg) == CONTENTS_SOLID || tracefw.fraction != 1.0) {
		thisclient->gohere[0] = thisclient->gohere[1] = thisclient->gohere[2] = thisclient->washere[0] = thisclient->washere[1] = thisclient->washere[2] = 0;
		thisclient->roamtime = sv.time + 5;
	}
	
	VectorSubtract(thisclient->gohere, end, product);
	
	if (vlen2(product) < 30 || (!thisclient->gohere[0] && !thisclient->gohere[1] && !thisclient->gohere[2])) { //Find next target place
		while (anglenum < 361) {
			yawangle[YAW] = anglenum;
			
			AngleVectors(yawangle, forward, right, up);
			
			fororg[0] = thisclient->edict->v.origin[0] + forward[0]*5000;
			fororg[1] = thisclient->edict->v.origin[1] + forward[1]*5000;
			fororg[2] = thisclient->edict->v.origin[2] + forward[2]*5000;
			
			trace = SV_Move (thisclient->edict->v.origin, v_mins, v_maxs, fororg, 0, thisclient->edict);
			traceoldpos = SV_Move (thisclient->washere, v_mins, v_maxs, trace.endpos, 0, thisclient->edict);
			
			VectorSubtract(thisclient->edict->v.origin, trace.endpos, product);
			
			if (vlen2(product) > bestdist && trace.fraction == 1.0 && (traceoldpos.fraction != 1.0 || (!thisclient->washere[0] && !thisclient->washere[1] && !thisclient->washere[2])) ) {
				//idist = vlen2(product);
				//SV_BroadcastPrintf (2, "Best dist: %i\n", idist);
				found = 1;
				bestdist = vlen2(product);
				bestway = yawangle[YAW];
				thisclient->gohere[0] = trace.endpos[0];
				thisclient->gohere[1] = trace.endpos[1];
				thisclient->gohere[2] = trace.endpos[2];
			}
			anglenum += 20; //5?
		}
		if (found == 0) {
			thisclient->washere[0] = 0;
			thisclient->washere[1] = 0;
			thisclient->washere[2] = 0;
			//thisclient->gohere[0] = 0;
			//thisclient->gohere[1] = 0;
			//thisclient->gohere[2] = 0;
		}
		else {
			thisclient->washere[0] = thisclient->edict->v.origin[0];
			thisclient->washere[1] = thisclient->edict->v.origin[1];
			thisclient->washere[2] = thisclient->edict->v.origin[2];
		}
	}
	VectorSubtract(thisclient->gohere, thisclient->edict->v.origin, product);
	
	vectoanglesbot(product, product);
	
	if (thisclient->roamtime < sv.time) {
		thisclient->edict->v.v_angle[YAW] = product[YAW];
	}
	else {
		if (thisclient->turntime < sv.time) {
			thisclient->roamyaw = rand()%360;
			thisclient->turntime = sv.time + 5 + rand()%25;
		}
		else {
			trace_t	trace;
			
			thisclient->edict->v.v_angle[PITCH] = 0;
			yawangle[YAW] = thisclient->edict->v.v_angle[YAW];
			
			AngleVectors(yawangle, forward, right, up);
			
			fororg[0] = thisclient->edict->v.origin[0] + forward[0]*100;
			fororg[1] = thisclient->edict->v.origin[1] + forward[1]*100;
			fororg[2] = thisclient->edict->v.origin[2] + forward[2]*100;
					
			trace = SV_Move (thisclient->edict->v.origin, thisclient->edict->v.mins, thisclient->edict->v.maxs, fororg, 0, thisclient->edict);
			
			if (trace.fraction != 1.0) {
				thisclient->roamyaw = rand()%360;
				thisclient->edict->v.v_angle[YAW] = thisclient->roamyaw;
			}
		}
	}
				
	if (thisclient->edict->v.v_angle[YAW] < 0)
		thisclient->edict->v.v_angle[YAW] = 0;
	if (thisclient->edict->v.v_angle[YAW] > 360)
		thisclient->edict->v.v_angle[YAW] = 360;
				
	thisclient->edict->v.angles[0] = thisclient->edict->v.v_angle[0];
	thisclient->edict->v.angles[1] = thisclient->edict->v.v_angle[1];
	thisclient->edict->v.angles[2] = thisclient->edict->v.v_angle[2];
}

void GetNextWP(client_t *thisclient) {
	int i = 0;

	//wp_order:
	//1 = backward (down)
	//0 = forward (up)

	if (!thisclient->wp_dest)
		return;

	while (i <= wp_total) {
		if (thisclient->wp_order) {
			if (WPArray[i].wpnum == (thisclient->wp_dest->wpnum - 1)) {
				thisclient->wp_dest = &WPArray[i];
				thisclient->wp_timeout = sv.time + 10;
				return;
			}
		}
		else {
			if (WPArray[i].wpnum == (thisclient->wp_dest->wpnum + 1)) {
				thisclient->wp_dest = &WPArray[i];
				thisclient->wp_timeout = sv.time + 10;
				return;
			}
		}
		i++;
	}

//	Con_Printf("Reverse order\n");
	
	if (thisclient->wp_order)
		thisclient->wp_order = 0;
	else
		thisclient->wp_order = 1;
}

int CheckForward(edict_t *thisclient, vec3_t pos, int fovval) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t forward, right, up;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int cvarval;
	vec3_t product;
	int fovaddangle;
	int fovsubangle;
	int gothroughrange;
	vec3_t novang;

	VectorSubtract(pos, thisclient->v.origin, product);

	enemy_yaw = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	
	//UTIL_MakeVectors(bot->pev->v_angle);
	
	AngleVectors(thisclient->v.v_angle, forward, right, up);
	
	fororg[0] = thisclient->v.origin[0] + forward[0]*(5);
	fororg[1] = thisclient->v.origin[1] + forward[1]*(5);
	fororg[2] = thisclient->v.origin[2];
	
	VectorSubtract(fororg, thisclient->v.origin, product);

	current_yaw = UTIL_VecToYaw (product);

	botfovval = fovval;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw)
			return 1;

		gothroughrange++;
	}

	return 0;
}

int CheckBack(edict_t *thisclient, vec3_t pos, int fovval) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t forward, right, up;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int cvarval;
	vec3_t product;
	int fovaddangle;
	int fovsubangle;
	int gothroughrange;

	VectorSubtract(thisclient->v.origin, pos, product);

	enemy_yaw = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	
	//UTIL_MakeVectors(bot->pev->v_angle);
	AngleVectors(thisclient->v.v_angle, forward, right, up);
	
	fororg[0] = thisclient->v.origin[0] + forward[0]*(5);
	fororg[1] = thisclient->v.origin[1] + forward[1]*(5);
	fororg[2] = thisclient->v.origin[2];
	
	VectorSubtract(fororg, thisclient->v.origin, product);

	current_yaw = UTIL_VecToYaw (product);

	botfovval = fovval;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw)
			return 1;

		gothroughrange++;
	}

	return 0;
}

int CheckRight(edict_t *thisclient, vec3_t pos, int fovval) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t forward, right, up;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int cvarval;
	vec3_t product;
	int fovaddangle;
	int fovsubangle;
	int gothroughrange;
	vec3_t novang;

	VectorSubtract(pos, thisclient->v.origin, product);

	enemy_yaw = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	
	//UTIL_MakeVectors(bot->pev->v_angle);
	novang[YAW] = thisclient->v.v_angle[YAW];
	AngleVectors(novang, forward, right, up);
	//AngleVectors(thisclient->v.v_angle, forward, right, up);
	
	fororg[0] = thisclient->v.origin[0] + right[0]*(5);
	fororg[1] = thisclient->v.origin[1] + right[1]*(5);
	fororg[2] = thisclient->v.origin[2];
	
	VectorSubtract(fororg, thisclient->v.origin, product);

	current_yaw = UTIL_VecToYaw (product);

	botfovval = fovval;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw)
			return 1;

		gothroughrange++;
	}

	return 0;
}

int CheckLeft(edict_t *thisclient, vec3_t pos, int fovval) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t forward, right, up;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int cvarval;
	vec3_t product;
	int fovaddangle;
	int fovsubangle;
	int gothroughrange;
	vec3_t novang;

	VectorSubtract(thisclient->v.origin, pos, product);

	enemy_yaw = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	
	//UTIL_MakeVectors(bot->pev->v_angle);
	novang[YAW] = thisclient->v.v_angle[YAW];
	AngleVectors(novang, forward, right, up);
	//AngleVectors(thisclient->v.v_angle, forward, right, up);
	
	fororg[0] = thisclient->v.origin[0] + right[0]*(5);
	fororg[1] = thisclient->v.origin[1] + right[1]*(5);
	fororg[2] = thisclient->v.origin[2];
	
	VectorSubtract(fororg, thisclient->v.origin, product);

	current_yaw = UTIL_VecToYaw (product);

	botfovval = fovval;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw)
			return 1;

		gothroughrange++;
	}

	return 0;
}

void MoveToVector(client_t *bot, vec3_t v) { //another carried from Jumbot
	float botspeed;
	float botspeed2 = sv_maxspeed.value;
	
	botspeed = botspeed2;
	
	if (CheckForward(bot->edict, v, 90) == 1)
		bot->f_move = botspeed;
	else if (CheckBack(bot->edict, v, 90) == 1)
		bot->f_move = -botspeed;
	else
		bot->f_move = 0;
	
	if (CheckRight(bot->edict, v, 90) == 1)
		bot->s_move = botspeed;
	else if (CheckLeft(bot->edict, v, 90) == 1)
		bot->s_move = -botspeed;
	else
		bot->f_move = 0;
}

void MoveToVector_StdNav(client_t *bot, vec3_t v) { //another carried from Jumbot
	float botspeed;
	float botspeed2 = sv_maxspeed.value;
	
	botspeed = botspeed2;
	
	if (CheckForward(bot->edict, v, 90) == 1)
		bot->f_move = botspeed;
	else if (CheckBack(bot->edict, v, 90) == 1)
		bot->f_move = -botspeed;
	else
		bot->f_move = 0;
	
	if (CheckRight(bot->edict, v, 45) == 1)
		bot->s_move = botspeed;
	else if (CheckLeft(bot->edict, v, 45) == 1)
		bot->s_move = -botspeed;
	else
		bot->s_move = 0;
}

void StrafeTroubleshoot(client_t *thisclient) {
	float wplen;
	trace_t trCheck_Right, trCheck_Left;
	vec3_t v_mins, v_maxs, v1, v2;
	vec3_t product;
	vec3_t forward, right, up;

	vec3_t novang;

	/*v_mins[0] = -10;
	v_mins[1] = -10;
	v_mins[2] = -10;

	v_maxs[0] = 10;
	v_maxs[1] = 10;
	v_maxs[2] = 10;*/

	novang[YAW] = thisclient->edict->v.v_angle[YAW];

	AngleVectors(novang, forward, right, up);

	v1[0] = thisclient->edict->v.origin[0] + right[0]*15;
	v1[1] = thisclient->edict->v.origin[1] + right[1]*15;
	v1[2] = thisclient->edict->v.origin[2] + right[2]*15;

	v2[0] = v1[0] + forward[0]*15;
	v2[1] = v1[1] + forward[1]*15;
	v2[2] = v1[2] + forward[2]*15;

	trCheck_Right = SV_Move (v1, v_mins, v_maxs, v2, 0, thisclient->edict);

	if (trCheck_Right.fraction != 1) { //something blocking right, move left
		thisclient->s_move = -sv_maxspeed.value;
		return;
	}

	v1[0] = thisclient->edict->v.origin[0] - right[0]*15;
	v1[1] = thisclient->edict->v.origin[1] - right[1]*15;
	v1[2] = thisclient->edict->v.origin[2] - right[2]*15;

	v2[0] = v1[0] + forward[0]*15;
	v2[1] = v1[1] + forward[1]*15;
	v2[2] = v1[2] + forward[2]*15;

	trCheck_Right = SV_Move (v1, v_mins, v_maxs, v2, 0, thisclient->edict);

	if (trCheck_Right.fraction != 1) { //something blocking left, move right
		thisclient->s_move = sv_maxspeed.value;
		return;
	}
}

int NoEntUnderOrg(vec3_t vecspot, edict_t *ent) {
	vec3_t vecspot2;
	trace_t tr;

	vecspot2[0] = vecspot[0];
	vecspot2[1] = vecspot[1];
	vecspot2[2] = vecspot[2] - 60;

	tr = SV_Move(vecspot, vec3_origin, vec3_origin, vecspot2, 0, ent);
	if (tr.fraction == 1)
		return 1;

	if (!tr.ent)
		return 1;

	return 0;
}

void Nav_Primary(client_t *thisclient) {
	vec3_t start, end, product;
	float wplen;

	end[0] = thisclient->edict->v.origin[0];
	end[1] = thisclient->edict->v.origin[1];
	end[2] = thisclient->edict->v.origin[2];
				
	start[0] = thisclient->wp_dest->origin[0];
	start[1] = thisclient->wp_dest->origin[1];
	start[2] = thisclient->wp_dest->origin[2];

	product[0] = 0;
	product[1] = 0;
	product[2] = 0;

	VectorSubtract(start, end, product);

	wplen = vlen2(product);

	//Con_Printf("WaypointL: %f\n", wplen);

	//START DEBUG DRAW
/*	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 23); //23
	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 12); //2
	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 3);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), thisclient->wp_dest->origin[0]);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), thisclient->wp_dest->origin[1]);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), thisclient->wp_dest->origin[2]);*/
	//END DEBUG DRAW

	if (wplen < 40)
		GetNextWP(thisclient);

	product[0] = 0;
	product[1] = 0;
	product[2] = 0;

	if (thisclient->enemy) {
		start[0] = thisclient->enemy->v.origin[0];
		start[1] = thisclient->enemy->v.origin[1];
		start[2] = thisclient->enemy->v.origin[2];
	}
				
	VectorSubtract(start, end, product);
				
	vectoanglesbot(product, product);
				
	thisclient->edict->v.ideal_yaw = product[YAW];
	//thisclient->edict->v.v_angle[PITCH] = 0;
	
	if (start[2] < end[2]) {
		VectorSubtract (end, start, product);
		vectoanglesbot(product, product);
	}
	else
		product[PITCH] = -product[PITCH];
	if (product[PITCH] > 80)
		product[PITCH] = 80;
	if (product[PITCH] < -70)
		product[PITCH] = -70;

	thisclient->edict->v.v_angle[PITCH] = product[PITCH];
	
	//thisclient->edict->v.v_angle[YAW] = product[YAW];

	thisclient->edict->v.angles[0] = thisclient->edict->v.v_angle[0];
	thisclient->edict->v.angles[1] = thisclient->edict->v.v_angle[1];
	thisclient->edict->v.angles[2] = thisclient->edict->v.v_angle[2];
	
	ChangeYaw(thisclient, byaw);
	
	//Con_Printf("Primary nav\n");
	
	//ucmd->forwardmove = sv_maxspeed.value;
	//thisclient->f_move = sv_maxspeed.value;
	
	//thisclient->f_move = 0;
	thisclient->s_move = 0;

	if (thisclient->wp_dest->wptype == 1 && NoEntUnderOrg(thisclient->wp_dest->origin, thisclient->edict)) {
		thisclient->f_move = 0;
		thisclient->s_move = 0;
	}
	else if (thisclient->enemy)
		MoveToVector(thisclient, thisclient->wp_dest->origin);
	else
		MoveToVector_StdNav(thisclient, start);
	//MoveToVector(thisclient, start);

	/*if (CheckForward(thisclient->edict, start, 90) == 1)
		thisclient->f_move = sv_maxspeed.value;
	else if (CheckBack(thisclient->edict, start, 90) == 1)
		thisclient->f_move = -sv_maxspeed.value;
	else
		thisclient->f_move = 0;
	
	if (CheckRight(thisclient->edict, start, 90) == 1)
		thisclient->s_move = sv_maxspeed.value;
	else if (CheckLeft(thisclient->edict, start, 90) == 1)
		thisclient->s_move = -sv_maxspeed.value;
	else
		thisclient->f_move = 0;*/


	StrafeTroubleshoot(thisclient);

//	if (thisclient->enemy) {
//		Con_Printf("Enemy while running\n");
//	}
}

void FindNearWP(client_t *thisclient) {
	int i = 0;
	float closest = 256;
	int bestindex = 0;
	int foundgood = 0;
	vec3_t start, end, product;
	trace_t trCheck;

	while (i < wp_total) {
		end[0] = thisclient->edict->v.origin[0];
		end[1] = thisclient->edict->v.origin[1];
		end[2] = thisclient->edict->v.origin[2];
				
		start[0] = WPArray[i].origin[0];
		start[1] = WPArray[i].origin[1];
		start[2] = WPArray[i].origin[2];

		product[0] = 0;
		product[1] = 0;
		product[2] = 0;

		VectorSubtract(start, end, product);
				
		if (vlen2(product) < closest && BotUtil_Visible(thisclient->edict->v.origin, start, thisclient->edict)) {
			bestindex = i;
			foundgood = 1;
			closest = vlen2(product);
		}

		i++;
	}
	
	if (foundgood == 1) {
		thisclient->wp_dest = &WPArray[bestindex];
		thisclient->wp_timeout = sv.time + 10;
	}
}

int NearEnt(client_t *thisclient) {
	vec3_t forward, right, up, fororg, mins, maxs, novang, product;
	trace_t trace;

/*	if (thisclient->wp_dest) {
		VectorSubtract(thisclient->wp_dest->origin, thisclient->edict->v.origin, product);

		novang[YAW] = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	}
	else*/
//		novang[YAW] = thisclient->edict->v.v_angle[YAW];

//	AngleVectors(novang, forward, right, up);

	AngleVectors(thisclient->edict->v.v_angle, forward, right, up);

	fororg[0] = thisclient->edict->v.origin[0] + forward[0]*200;
	fororg[1] = thisclient->edict->v.origin[1] + forward[1]*200;
	fororg[2] = thisclient->edict->v.origin[2] + forward[2]*200;

	trace = SV_Move (thisclient->edict->v.origin, mins, maxs, fororg, 0, thisclient->edict);

	if (trace.ent && (strstr(PR_GetString(trace.ent->v.classname), "func"))) {
		return 1;
	}

	return 0;
}

void DoNavigation(client_t *thisclient) {
	if (!wp_loaded) {
		Nav_Fallback(thisclient);
		return;
	}

	if (thisclient->wp_dest && !BotUtil_Visible(thisclient->edict->v.origin, thisclient->wp_dest->origin, thisclient->edict) && !NearEnt(thisclient)) {
		thisclient->wp_dest = NULL;
		thisclient->wp_nofollow = sv.time + 8;
	}

	if (!thisclient->wp_dest && thisclient->wp_nofollow < sv.time)
		FindNearWP(thisclient);

	if (thisclient->wp_dest)
		Nav_Primary(thisclient);
	else
		Nav_Fallback(thisclient);
}

int CanHear(client_t *bot, client_t *enemy) {
	vec3_t product;

	VectorSubtract(bot->edict->v.origin, enemy->edict->v.origin, product);
	
	if (enemy->edict->madenoise < sv.time)
		return 0;

	if (vlen2(product) < enemy->edict->noiserad)
		return 1;

	return 0;
}

int VertFOV(edict_t *thisclient, edict_t *enemy) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t forward, right, up;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int cvarval;
	vec3_t product;
	int fovaddangle;
	int fovsubangle;
	int gothroughrange;

	if (!enemy || !thisclient)
		return 0;

	VectorSubtract(enemy->v.origin, thisclient->v.origin, product);

	vectoanglesbot(product, product);

	enemy_yaw = product[ROLL];//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	
	//UTIL_MakeVectors(bot->pev->v_angle);
	AngleVectors(thisclient->v.v_angle, forward, right, up);
	
	fororg[0] = thisclient->v.origin[0] + forward[0]*(5);
	fororg[1] = thisclient->v.origin[1] + forward[1]*(5);
	fororg[2] = thisclient->v.origin[2];
	
	VectorSubtract(fororg, thisclient->v.origin, product);

	vectoanglesbot(product, product);

	current_yaw = product[ROLL];//UTIL_VecToYaw (product);

	botfovval = 90;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw)
			return 1;

		gothroughrange++;
	}

	return 0;
}

int InFov(edict_t *thisclient, edict_t *enemy) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t forward, right, up;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int cvarval;
	vec3_t product;
	int fovaddangle;
	int fovsubangle;
	int gothroughrange;

	if (!enemy || !thisclient)
		return 0;

	VectorSubtract(enemy->v.origin, thisclient->v.origin, product);

	enemy_yaw = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	
	//UTIL_MakeVectors(bot->pev->v_angle);
	AngleVectors(thisclient->v.v_angle, forward, right, up);
	
	fororg[0] = thisclient->v.origin[0] + forward[0]*(5);
	fororg[1] = thisclient->v.origin[1] + forward[1]*(5);
	fororg[2] = thisclient->v.origin[2];
	
	VectorSubtract(fororg, thisclient->v.origin, product);

	current_yaw = UTIL_VecToYaw (product);

	botfovval = 90;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw && VertFOV(thisclient, enemy))
			return 1;

		gothroughrange++;
	}

	return 0;
}

int InFireFov(client_t *thisclient) {
	float enemy_yaw;
	float current_yaw;
	vec3_t fororg;
	vec3_t forward, right, up;
	int ienemy_yaw, icurrent_yaw, botfovval;
	int cvarval;
	vec3_t product;
	int fovaddangle;
	int fovsubangle;
	int gothroughrange;

	if (!thisclient->enemy)
		return 0;

	VectorSubtract(thisclient->enemy->v.origin, thisclient->edict->v.origin, product);

	enemy_yaw = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	
	//UTIL_MakeVectors(bot->pev->v_angle);
	AngleVectors(thisclient->edict->v.v_angle, forward, right, up);
	
	fororg[0] = thisclient->edict->v.origin[0] + forward[0]*(5);
	fororg[1] = thisclient->edict->v.origin[1] + forward[1]*(5);
	fororg[2] = thisclient->edict->v.origin[2];
	
	VectorSubtract(fororg, thisclient->edict->v.origin, product);

	current_yaw = UTIL_VecToYaw (product);

	cvarval = 30;

	botfovval = cvarval + 10;
	
	ienemy_yaw = enemy_yaw;
	icurrent_yaw = current_yaw;
	
	fovaddangle = icurrent_yaw + botfovval*1;
	fovsubangle = icurrent_yaw - botfovval*1;

	if (fovaddangle > 360)
		fovaddangle -= 360;

	if (fovsubangle < 0)
		fovsubangle += 360;
		
	gothroughrange = fovsubangle;

	while (gothroughrange != (fovaddangle + 1)) {
		if (gothroughrange == 361)
			gothroughrange = 0;

		if (gothroughrange == ienemy_yaw)
			return 1;

		gothroughrange++;
	}

	return 0;
}

int FeetBlocked(client_t *thisclient) {
	float wplen;
	trace_t trCheck, trCheck_Up;
	vec3_t v_mins, v_maxs, v1, v2;
	vec3_t product;
	vec3_t forward, right, up;

	vec3_t novang;

	v_mins[0] = -10;
	v_mins[1] = -10;
	v_mins[2] = -10;

	v_maxs[0] = 10;
	v_maxs[1] = 10;
	v_maxs[2] = 10;

	if (thisclient->wp_dest) {
		VectorSubtract(thisclient->wp_dest->origin, thisclient->edict->v.origin, product);

		novang[YAW] = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	}
	else
		novang[YAW] = thisclient->edict->v.v_angle[YAW];

	AngleVectors(novang, forward, right, up);

	v1[0] = thisclient->edict->v.origin[0];
	v1[1] = thisclient->edict->v.origin[1];
	v1[2] = thisclient->edict->v.origin[2];

	v1[2] -= 15;

	v2[0] = v1[0] + forward[0]*15;
	v2[1] = v1[1] + forward[1]*15;
	v2[2] = v1[2] + forward[2]*15;

/*	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 23); //23
	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 12); //2
	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 3);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), v2[0]);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), v2[1]);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), v2[2]);*/

	trCheck = SV_Move (v1, v_mins, v_maxs, v2, 0, thisclient->edict);

	v1[0] = thisclient->edict->v.origin[0];
	v1[1] = thisclient->edict->v.origin[1];
	v1[2] = thisclient->edict->v.origin[2];

	v1[2] += 15;

	v2[0] = v1[0] + forward[0]*15;
	v2[1] = v1[1] + forward[1]*15;
	v2[2] = v1[2] + forward[2]*15;

/*	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 23); //23
	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 12); //2
	cheaphack = 1;
	MSG_WriteByte (WriteDest(), 3);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), v2[0]);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), v2[1]);
	cheaphack = 1;
	MSG_WriteCoord (WriteDest(), v2[2]);*/

	trCheck_Up = SV_Move (v1, v_mins, v_maxs, v2, 0, thisclient->edict);

	if (trCheck.fraction == 1) { //nothing by feet
		return 0;
	}
	else if (trCheck_Up.fraction == 1) { //something by feet, nothing by self
		//Con_Printf("Feet blocked\n");
		return 1;
	}
	
	return 0;
}

int EnemyOutWeighWeapon(client_t *thisclient, edict_t *enemy) {
	int botw = 0;
	int enew = 0;

	if (thisclient->edict->v.weapon == IT_SHOTGUN)
		botw = 1;
	else if (thisclient->edict->v.weapon == IT_SUPER_SHOTGUN)
		botw = 2;
	else if (thisclient->edict->v.weapon == IT_NAILGUN)
		botw = 3;
	else if (thisclient->edict->v.weapon == IT_SUPER_NAILGUN)
		botw = 4;
	else if (thisclient->edict->v.weapon == IT_GRENADE_LAUNCHER)
		botw = 5;
	else if (thisclient->edict->v.weapon == IT_ROCKET_LAUNCHER)
		botw = 6;
	else if (thisclient->edict->v.weapon == IT_LIGHTNING)
		botw = 6;
	else
		botw = 7;

	if (enemy->v.weapon == IT_SHOTGUN)
		enew = 1;
	else if (enemy->v.weapon == IT_SUPER_SHOTGUN)
		enew = 2;
	else if (enemy->v.weapon == IT_NAILGUN)
		enew = 3;
	else if (enemy->v.weapon == IT_SUPER_NAILGUN)
		enew = 4;
	else if (enemy->v.weapon == IT_GRENADE_LAUNCHER)
		enew = 5;
	else if (enemy->v.weapon == IT_ROCKET_LAUNCHER)
		enew = 6;
	else if (enemy->v.weapon == IT_LIGHTNING)
		enew = 6;
	else
		enew = 7;

	if ((botw + 2) < enew)
		return 1;

	return 0;
}

int PassRunChecks(client_t *bot, edict_t *enemy) {
	/*
	#define	IT_SHOTGUN				1
	#define	IT_SUPER_SHOTGUN		2
	#define	IT_NAILGUN				4
	#define	IT_SUPER_NAILGUN		8

	#define	IT_GRENADE_LAUNCHER		16
	#define	IT_ROCKET_LAUNCHER		32
	#define	IT_LIGHTNING			64
	#define	IT_SUPER_LIGHTNING		128*/

	if (bot->edict->v.health < 40 && bot->edict->v.health < enemy->v.health)
		return 0;

	if (bot->edict->v.weapon < 2 || EnemyOutWeighWeapon(bot, enemy))
		return 0;

	return 1;
}

int LedgeHere(client_t *thisclient) {
	float wplen;
	trace_t trCheck, trCheck_Up;
	vec3_t v_mins, v_maxs, v1, v2;
	vec3_t product;
	vec3_t forward, right, up;

	vec3_t novang;

	v_mins[0] = thisclient->edict->v.mins[0];
	v_mins[1] = thisclient->edict->v.mins[1];
	v_mins[2] = thisclient->edict->v.mins[2];

	v_maxs[0] = thisclient->edict->v.maxs[0];
	v_maxs[1] = thisclient->edict->v.maxs[1];
	v_maxs[2] = thisclient->edict->v.maxs[2];

	if (thisclient->wp_dest) {
		VectorSubtract(thisclient->wp_dest->origin, thisclient->edict->v.origin, product);

		novang[YAW] = UTIL_VecToYaw(product);//UTIL_VecToYaw( enemy->pev->origin - bot->pev->origin );
	}
	else
		novang[YAW] = thisclient->edict->v.v_angle[YAW];

	AngleVectors(novang, forward, right, up);

	v1[0] = thisclient->edict->v.origin[0] + forward[0]*60;
	v1[1] = thisclient->edict->v.origin[1] + forward[1]*60;
	v1[2] = thisclient->edict->v.origin[2] + forward[2]*60;

	v2[0] = v1[0];
	v2[1] = v1[1];
	v2[2] = v1[2] - 65;

	trCheck = SV_Move (thisclient->edict->v.origin, v_mins, v_maxs, v1, 0, thisclient->edict);

	if (trCheck.fraction != 1) { //Wall in front of
		return 0;
	}

	trCheck = SV_Move (v1, v_mins, v_maxs, v2, 0, thisclient->edict);

	if (trCheck.fraction == 1) { //ledge
		return 1;
	}
	else { //no ledge
		return 0;
	}
	
	return 0;
}

void DoBotThink(float f_time) {
	int i = 0;
	int found = 0;
	int targetdis = 0;
	int worstdis = 0;
	vec3_t product, start, end;

	if (msecdel <= sv.time) {
		msecdel = sv.time + 1;
		if (msecnum > 0)
			msecval = 800/msecnum;
		msecnum = 0;
	}
	else
		msecnum++;

	if (msecval < 5)
		msecval = 5;

	if (msecval > 100)
		msecval = 100;

	for (i=0 ; i<MAX_CLIENTS ; i++) {
		if ( svs.clients[i].isabot == 1 ) {
			usercmd_t ucmd;
			client_t *thisclient;
			int stopthistime = 0;
			int charnum = 0;
			int rfact = 0;


			thisclient = &svs.clients[i];
			if (!thisclient)
				continue;
			if (thisclient->num_backbuf > 0)
				thisclient->num_backbuf = 0;
			if (thisclient->backbuf.cursize > 0)
				thisclient->backbuf.cursize = 0;
			found++;

			if (thisclient->state != cs_spawned)
				thisclient->state = cs_spawned;
			
			thisclient->entgravity = sv_gravity.value/1000;
			thisclient->maxspeed = sv_maxspeed.value;

			SV_WriteEntitiesToBot (thisclient, NULL);

			if (thisclient->enemy) {
				trace_t	trace;
				vec3_t trmin, trmax;

				trmax[0] = 0;
				trmax[1] = 0;
				trmax[2] = 0;

				trmin[0] = 0;
				trmin[1] = 0;
				trmin[2] = 0;

				trace = SV_Move (thisclient->edict->v.origin, trmin, trmax, thisclient->enemy->v.origin, 0, thisclient->edict);

				if (trace.fraction != 1.0 && (!(trace.ent) || trace.ent != thisclient->enemy) ) {
					thisclient->enemy = NULL;
				}

				if (thisclient->enemy && thisclient->enemy->v.health < 1)
					thisclient->enemy = NULL;

				if (thisclient->enemy && thisclient->enemy->v.takedamage == DAMAGE_NO)
					thisclient->enemy = NULL;
			}

			if (thisclient->teammate) {
				trace_t	trace;
				vec3_t trmin, trmax;

				trmax[0] = 0;
				trmax[1] = 0;
				trmax[2] = 0;

				trmin[0] = 0;
				trmin[1] = 0;
				trmin[2] = 0;

				trace = SV_Move (thisclient->edict->v.origin, trmin, trmax, thisclient->teammate->v.origin, 0, thisclient->edict);

				if (trace.fraction != 1.0 && (!(trace.ent) || trace.ent != thisclient->teammate) ) {
					thisclient->teammate = NULL;
				}

				if (thisclient->teammate && thisclient->teammate->v.health < 1)
					thisclient->teammate = NULL;

				//if (thisclient->teammate && thisclient->teammate->v.takedamage == DAMAGE_NO)
				//	thisclient->teammate = NULL;
			}

			if (thisclient->afteritem) {
				//if (thisclient->item_to < sv.time) {
					thisclient->afteritem = NULL;
				//	thisclient->item_noget = sv.time + 5 + rand()%5;
				//}
				//ITEM CODE DISABLED
			}

			if (thisclient->afteritem) {
				trace_t	trace;
				vec3_t trmin, trmax;

				trmax[0] = 0;
				trmax[1] = 0;
				trmax[2] = 0;

				trmin[0] = 0;
				trmin[1] = 0;
				trmin[2] = 0;

				trace = SV_Move (thisclient->edict->v.origin, trmin, trmax, thisclient->afteritem->v.origin, 0, thisclient->edict);

				if (trace.fraction != 1.0 && (!(trace.ent) || trace.ent != thisclient->afteritem) ) {
					thisclient->afteritem = NULL;
				}

				if (thisclient->afteritem && strcmp(PR_GetString(thisclient->afteritem->v.model), "") == 0)
					thisclient->afteritem = NULL;

				//ADD "DO I NEED THIS?" CHECKS HERE
			}

			if (thisclient->teammate && !thisclient->afteritem && !thisclient->enemy) {
				end[0] = thisclient->edict->v.origin[0];
				end[1] = thisclient->edict->v.origin[1];
				end[2] = thisclient->edict->v.origin[2];

				start[0] = thisclient->teammate->v.origin[0];
				start[1] = thisclient->teammate->v.origin[1];
				start[2] = thisclient->teammate->v.origin[2];

				VectorSubtract(start, end, product);

				vectoanglesbot(product, product);

				thisclient->edict->v.v_angle[YAW] = product[YAW];
				thisclient->edict->v.v_angle[PITCH] = 0;

				ucmd.angles[0] = thisclient->edict->v.v_angle[0];
				ucmd.angles[1] = thisclient->edict->v.v_angle[1];
				ucmd.angles[2] = thisclient->edict->v.v_angle[2];
				thisclient->edict->v.angles[0] = thisclient->edict->v.v_angle[0];
				thisclient->edict->v.angles[1] = thisclient->edict->v.v_angle[1];
				thisclient->edict->v.angles[2] = thisclient->edict->v.v_angle[2];

				VectorSubtract(start, end, product);

				if (vlen2(product) < 60)
					ucmd.forwardmove = -sv_maxspeed.value;
				else if (vlen2(product) > 90)
					ucmd.forwardmove = sv_maxspeed.value;
				else
					ucmd.forwardmove = 0;

				ucmd.sidemove = 0;

				thisclient->s_move = 0;
			}

			if (thisclient->afteritem && !thisclient->enemy) {
				end[0] = thisclient->edict->v.origin[0];
				end[1] = thisclient->edict->v.origin[1];
				end[2] = thisclient->edict->v.origin[2];

				start[0] = thisclient->afteritem->v.origin[0];
				start[1] = thisclient->afteritem->v.origin[1];
				start[2] = thisclient->afteritem->v.origin[2];

				VectorSubtract(start, end, product);

				vectoanglesbot(product, product);

				thisclient->edict->v.v_angle[YAW] = product[YAW];
				thisclient->edict->v.v_angle[PITCH] = 0;

				ucmd.angles[0] = thisclient->edict->v.v_angle[0];
				ucmd.angles[1] = thisclient->edict->v.v_angle[1];
				ucmd.angles[2] = thisclient->edict->v.v_angle[2];
				thisclient->edict->v.angles[0] = thisclient->edict->v.v_angle[0];
				thisclient->edict->v.angles[1] = thisclient->edict->v.v_angle[1];
				thisclient->edict->v.angles[2] = thisclient->edict->v.v_angle[2];
			}

			if (thisclient->enemy && PassRunChecks(thisclient, thisclient->enemy)) {
				end[0] = thisclient->edict->v.origin[0];
				end[1] = thisclient->edict->v.origin[1];
				end[2] = thisclient->edict->v.origin[2];

				start[0] = thisclient->enemy->v.origin[0];
				start[1] = thisclient->enemy->v.origin[1];
				start[2] = thisclient->enemy->v.origin[2];

				VectorSubtract(start, end, product);

				if (vlen2(product) < 220 && ( (((int)thisclient->edict->v.items & IT_LIGHTNING && (int)thisclient->edict->v.ammo_cells > 0) || ((int)thisclient->edict->v.items & IT_SUPER_NAILGUN && (int)thisclient->edict->v.ammo_nails > 1) || ((int)thisclient->edict->v.items & IT_SUPER_SHOTGUN && (int)thisclient->edict->v.ammo_shells > 1) ) && (thisclient->edict->v.weapon == IT_ROCKET_LAUNCHER || thisclient->edict->v.weapon == IT_GRENADE_LAUNCHER) )) {
					if ((int)thisclient->edict->v.items & IT_LIGHTNING && thisclient->edict->v.ammo_cells > 0)
						thisclient->edict->v.weapon = IT_LIGHTNING;
					else if ((int)thisclient->edict->v.items & IT_SUPER_NAILGUN && thisclient->edict->v.ammo_nails > 1)
						thisclient->edict->v.weapon = IT_SUPER_NAILGUN;
					else if ((int)thisclient->edict->v.items & IT_SUPER_SHOTGUN && thisclient->edict->v.ammo_shells > 1)
						thisclient->edict->v.weapon = IT_SUPER_SHOTGUN;
				}
				if (vlen2(product) > 260 && thisclient->enemy->v.origin[2] <= thisclient->edict->v.origin[2] && ((int)thisclient->edict->v.items & IT_ROCKET_LAUNCHER && thisclient->edict->v.ammo_rockets > 0 && thisclient->edict->v.weapon != IT_ROCKET_LAUNCHER)) {
					stopthistime = 1;
					thisclient->edict->v.weapon = IT_ROCKET_LAUNCHER;
				}

				if (vlen2(product) < 900 && thisclient->enemy->v.origin[2] > thisclient->edict->v.origin[2] + 100 && ((int)thisclient->edict->v.items & IT_LIGHTNING && thisclient->edict->v.ammo_cells > 0)) {
					thisclient->edict->v.weapon = IT_LIGHTNING;
				}

				if (thisclient->edict->v.weapon == IT_ROCKET_LAUNCHER || thisclient->edict->v.weapon == IT_GRENADE_LAUNCHER || (thisclient->edict->v.weapon != IT_ROCKET_LAUNCHER && (int)thisclient->edict->v.items & IT_ROCKET_LAUNCHER && thisclient->edict->v.ammo_rockets > 0)) {
					targetdis = 450;
					worstdis = 400;
				}
				else if (thisclient->edict->v.weapon == IT_AXE)
				{
					targetdis = 10;
					worstdis = 25;
				}
				else {
					targetdis = 125;
					worstdis = 75;
				}

				if (vlen2(product) < worstdis)
					ucmd.forwardmove = -sv_maxspeed.value;
				else if (vlen2(product) > targetdis)
					ucmd.forwardmove = sv_maxspeed.value;
				else
					ucmd.forwardmove = 0;

				if (thisclient->edict->v.weapon == IT_ROCKET_LAUNCHER) {
					start[2] -= 40;
					VectorSubtract(start, end, product);
				}

				vectoanglesbot(product, product);

				/*if (rand()%10 < 5)
					thisclient->edict->v.ideal_yaw = product[YAW] + rand()%25;
					//thisclient->edict->v.v_angle[YAW] = product[YAW] + rand()%25;
				else
					thisclient->edict->v.ideal_yaw = product[YAW] - rand()%25;
					//thisclient->edict->v.v_angle[YAW] = product[YAW] - rand()%25;
				*/

				if (thisclient->aimoffset_time < sv.time) {
					thisclient->aimoffset_time = sv.time + 1;
					
					if (rand()%10 < 5)
						thisclient->aimoffset = rand()%25;
					else
						thisclient->aimoffset = -rand()%25;
				}
				
				thisclient->edict->v.ideal_yaw = product[YAW] + thisclient->aimoffset;

				ChangeYaw(thisclient, 10);

				if (start[2] < end[2]) {
					VectorSubtract (end, start, product);
					vectoanglesbot(product, product);
				}
				else
					product[PITCH] = -product[PITCH];
				if (product[PITCH] > 80)
					product[PITCH] = 80;
				if (product[PITCH] < -70)
					product[PITCH] = -70;
				thisclient->edict->v.v_angle[PITCH] = product[PITCH];
				ucmd.angles[0] = thisclient->edict->v.v_angle[0];
				ucmd.angles[1] = thisclient->edict->v.v_angle[1];
				ucmd.angles[2] = thisclient->edict->v.v_angle[2];
				thisclient->edict->v.angles[0] = thisclient->edict->v.v_angle[0];
				thisclient->edict->v.angles[1] = thisclient->edict->v.v_angle[1];
				thisclient->edict->v.angles[2] = thisclient->edict->v.v_angle[2];
			}
			else if (thisclient->teammate && !thisclient->enemy && !thisclient->afteritem) {
				end[0] = thisclient->edict->v.origin[0];
				end[1] = thisclient->edict->v.origin[1];
				end[2] = thisclient->edict->v.origin[2];

				start[0] = thisclient->teammate->v.origin[0];
				start[1] = thisclient->teammate->v.origin[1];
				start[2] = thisclient->teammate->v.origin[2];

				VectorSubtract(start, end, product);

				if (vlen2(product) < 60)
					ucmd.forwardmove = -sv_maxspeed.value;
				else if (vlen2(product) > 90)
					ucmd.forwardmove = sv_maxspeed.value;
				else
					ucmd.forwardmove = 0;

				thisclient->s_move = 0;
			}
			else if (!thisclient->teammate && (!thisclient->enemy || !PassRunChecks(thisclient, thisclient->enemy)) && !thisclient->afteritem) {
				/*trace_t	trace, traceoldpos, tracevis, tracefw;
				vec3_t fororg, forward, right, up, yawangle;
				int anglenum = 0;
				int bestway = 0;
				int found = 0;
				int idist = 0;
				float bestdist = 0;
				vec3_t v_mins, v_maxs;

				ucmd.forwardmove = sv_maxspeed.value;

				thisclient->edict->v.v_angle[PITCH] = 0;
				yawangle[YAW] = anglenum;

				end[0] = thisclient->edict->v.origin[0];
				end[1] = thisclient->edict->v.origin[1];
				end[2] = thisclient->gohere[2];

				AngleVectors(thisclient->edict->v.v_angle, forward, right, up);

				fororg[0] = thisclient->edict->v.origin[0] + forward[0]*30;
				fororg[1] = thisclient->edict->v.origin[1] + forward[1]*30;
				fororg[2] = thisclient->edict->v.origin[2] + forward[2]*30;

				tracevis = SV_Move (thisclient->edict->v.origin, v_mins, v_maxs, thisclient->gohere, 0, thisclient->edict);
				tracefw = SV_Move (thisclient->edict->v.origin, v_mins, v_maxs, fororg, 0, thisclient->edict);

				if (tracevis.fraction != 1.0 || SV_PointContents(fororg) == CONTENTS_SOLID || tracefw.fraction != 1.0) {
					thisclient->gohere[0] = thisclient->gohere[1] = thisclient->gohere[2] = thisclient->washere[0] = thisclient->washere[1] = thisclient->washere[2] = 0;
					thisclient->roamtime = sv.time + 5;
				}

				VectorSubtract(thisclient->gohere, end, product);

				if (vlen2(product) < 30 || (!thisclient->gohere[0] && !thisclient->gohere[1] && !thisclient->gohere[2])) { //Find next target place
					while (anglenum < 361) {
						yawangle[YAW] = anglenum;

						AngleVectors(yawangle, forward, right, up);

						fororg[0] = thisclient->edict->v.origin[0] + forward[0]*5000;
						fororg[1] = thisclient->edict->v.origin[1] + forward[1]*5000;
						fororg[2] = thisclient->edict->v.origin[2] + forward[2]*5000;

						trace = SV_Move (thisclient->edict->v.origin, v_mins, v_maxs, fororg, 0, thisclient->edict);
						traceoldpos = SV_Move (thisclient->washere, v_mins, v_maxs, trace.endpos, 0, thisclient->edict);

						VectorSubtract(thisclient->edict->v.origin, trace.endpos, product);

						if (vlen2(product) > bestdist && trace.fraction == 1.0 && (traceoldpos.fraction != 1.0 || (!thisclient->washere[0] && !thisclient->washere[1] && !thisclient->washere[2])) ) {
							//idist = vlen2(product);
							//SV_BroadcastPrintf (2, "Best dist: %i\n", idist);
							found = 1;
							bestdist = vlen2(product);
							bestway = yawangle[YAW];
							thisclient->gohere[0] = trace.endpos[0];
							thisclient->gohere[1] = trace.endpos[1];
							thisclient->gohere[2] = trace.endpos[2];
						}
						anglenum += 20; //5?
					}
					if (found == 0) {
						thisclient->washere[0] = 0;
						thisclient->washere[1] = 0;
						thisclient->washere[2] = 0;
						//thisclient->gohere[0] = 0;
						//thisclient->gohere[1] = 0;
						//thisclient->gohere[2] = 0;
					}
					else {
						thisclient->washere[0] = thisclient->edict->v.origin[0];
						thisclient->washere[1] = thisclient->edict->v.origin[1];
						thisclient->washere[2] = thisclient->edict->v.origin[2];
					}
				}
				VectorSubtract(thisclient->gohere, thisclient->edict->v.origin, product);

				vectoanglesbot(product, product);

				if (thisclient->roamtime < sv.time) {
					thisclient->edict->v.v_angle[YAW] = product[YAW];
				}
				else {
					if (thisclient->turntime < sv.time) {
						thisclient->roamyaw = rand()%360;
						thisclient->turntime = sv.time + 5 + rand()%25;
					}
					else {
						trace_t	trace;

						thisclient->edict->v.v_angle[PITCH] = 0;
						yawangle[YAW] = thisclient->edict->v.v_angle[YAW];

						AngleVectors(yawangle, forward, right, up);

						fororg[0] = thisclient->edict->v.origin[0] + forward[0]*100;
						fororg[1] = thisclient->edict->v.origin[1] + forward[1]*100;
						fororg[2] = thisclient->edict->v.origin[2] + forward[2]*100;

						trace = SV_Move (thisclient->edict->v.origin, thisclient->edict->v.mins, thisclient->edict->v.maxs, fororg, 0, thisclient->edict);

						if (trace.fraction != 1.0) {
							thisclient->roamyaw = rand()%360;
							thisclient->edict->v.v_angle[YAW] = thisclient->roamyaw;
						}
					}
				}

				if (thisclient->edict->v.v_angle[YAW] < 0)
					thisclient->edict->v.v_angle[YAW] = 0;
				if (thisclient->edict->v.v_angle[YAW] > 360)
					thisclient->edict->v.v_angle[YAW] = 360;

				*/

				DoNavigation(thisclient);

				ucmd.forwardmove = thisclient->f_move;
				ucmd.sidemove = thisclient->s_move;

				ucmd.angles[0] = thisclient->edict->v.v_angle[0];
				ucmd.angles[1] = thisclient->edict->v.v_angle[1];
				ucmd.angles[2] = thisclient->edict->v.v_angle[2];
				thisclient->edict->v.angles[0] = thisclient->edict->v.v_angle[0];
				thisclient->edict->v.angles[1] = thisclient->edict->v.v_angle[1];
				thisclient->edict->v.angles[2] = thisclient->edict->v.v_angle[2];
			}
			else {
				ucmd.forwardmove = sv_maxspeed.value;
			}
			ucmd.upmove = 0;

			if (thisclient->enemy && PassRunChecks(thisclient, thisclient->enemy) && thisclient->edict->v.weapon != IT_AXE) {
				if (thisclient->strafedir == 1)
					ucmd.sidemove = sv_maxspeed.value;
				else
					ucmd.sidemove = -sv_maxspeed.value;

				if (thisclient->strafetime < sv.time) {
					if (thisclient->strafedir == 1)
						thisclient->strafedir = 0;
					else
						thisclient->strafedir = 1;
					thisclient->strafetime = sv.time + 0.5 + rand()%2;
				}
			}
			//else
			//	ucmd.sidemove = 0;

			if (thisclient->enemy && InFireFov(thisclient))
				ucmd.buttons = 1;
			else
				ucmd.buttons = 0;

			if (thisclient->edict->v.health < 1) {
				if (thisclient->wp_dest)
					thisclient->wp_dest = NULL;

				if (rand()%10 < 2)
					ucmd.buttons = 1;
				else
					ucmd.buttons = 0;
			}

			if (stopthistime == 1)
				ucmd.buttons = 0;

			//ucmd.msec = 10;
			ucmd.msec = f_time;
			//ucmd.msec = ucmd.msec*0.001;

			thisclient->delta_sequence = -1;
			thisclient->chokecount = 0;

			if (thisclient->edict->v.weapon == IT_AXE)
				rfact = 18;
			else
				rfact = 10;

			if (thisclient->tjumptime < sv.time && thisclient->wp_timeout < sv.time + 9 && FeetBlocked(thisclient)) {
				ucmd.buttons += 2;
				thisclient->tjumptime = sv.time + 0.2;
			}
			else if (thisclient->tjumptime < sv.time && LedgeHere(thisclient)) {
				ucmd.buttons += 2;
				thisclient->tjumptime = sv.time + 0.2;
			}
			else if (rand()%rfact < 3 && (int)thisclient->edict->v.flags & FL_ONGROUND && thisclient->jumptime < sv.time && thisclient->enemy && PassRunChecks(thisclient, thisclient->enemy)) {
				ucmd.buttons += 2;
				thisclient->jumptime = sv.time + rand()%5;
			}
			else if (ucmd.buttons & 2)
				ucmd.buttons -= 2;

			if (!(ucmd.buttons & 2) && thisclient->edict->v.waterlevel > 1 && thisclient->edict->v.health > 0 && !thisclient->wp_dest)
				ucmd.buttons += 2;

			sv_player = thisclient->edict;
			host_client = thisclient;

			SV_PreRunCmd();
			SV_RunCmd(&ucmd);
			SV_PostRunCmd(); //h4h4h4h4h4h
		}
	}
	//SV_BroadcastPrintf (2, "Bots found: %i\n", found);
}
