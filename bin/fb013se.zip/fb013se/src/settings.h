// Public
//#define QUAKE
#define MANUAL
//#define LETTERCODES

// Private
#ifdef QUAKE
//	#define CREEPCAM
//	#define KASCAM
//	#define CONSOLE
//	#define MAZE
//	#define ARCADE
#endif

#ifndef QUAKE
	#ifdef MANUAL
		#undef MANUAL
	#endif
	#define QUAKEWORLD
#endif