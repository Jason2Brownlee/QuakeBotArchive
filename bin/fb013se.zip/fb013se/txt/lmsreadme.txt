Title    : Last Man Standing (LMS)
Filename : lms0921.zip
Version  : 0.921b
Date     : 1997-08-03

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no

Format of Quake C
-----------------
unified diff  : no
context diff  : no
.qc files     : yes
progs.dat     : yes

Description of the Modification
-------------------------------

	From the homepage:
This is the patch that will show who is the truly best Quake player. There
won't be any problems with getting weapons or ammo. There won't be any
power ups that will make players much better just because they got it first.
The only thing you will have to worry about is killing everything, and
survive. Of course, you won't have unlimited ammo or health. But it won't
be the most important thing to camp the RL anymore.

There will be no new weapons or spells either. It's just you and your
weapons. No team that can help you/drag your score down. Just your pure
skill against the others.

	How it works
The object of the game is to kill everyone in each round, and be the
last survivor, the Last Man Standing. When you are killed, you are put
into observer mode, and you will get to watch the rest of the round.
When there has been a last man standing, everyone is respawned, and after
a 5 second immortality time, you play another round. You only get a frag
for being the Last Man Standing, no frags for killing or suiciding.

When you kill another player, you get refreshed health and new ammo. You
also get 200 points of the next armor in line. This means you won't find
any weapons, armor, or power ups around in the levels. Though you have
everything you need from the beginning.

There is also a status command, which shows current timelimit, time left
until level change, max round time, how much time is left of the current
round, and the number of players still alive. You can access it with
'impulse 23' (you might want to bind it to a key for easy access). This
is the only new impulse in LMS, making it even easier to start playing.


Installation Note
-----------------
Install it just like any other patch, ie. unzip it in a sub directory of
your quake folder.

If the patch is in:
"c:\quake\lms"

the command line to start the server would be something like:
"winquake -dedicated -game lms"

I can't help you more then that, you should know it. A good max number of
players may be around 8. There will be long waiting times in observer mode
with 16 players.


	The config file
I've done some BIG changes here, it should be very much easier now (I hope).
deathmatch, teamplay, timelimit and fraglimit are as default.

Note 1: You might want to put fraglimit lower then normal, you wont get at all as
many frags as normal DM.
Note 2: You have to set deathmatch to something, LMS wont run otherwise.

I've made a few small changes to noexit and samelevel. If you set noexit to
'3', nothing will happen when someone is in the exit area (just like CTF).
samelevel is now also used as a toggle for the custom level order (set in
maps.qc). If you want to toggle it, set samelevel to '-1' (by default,
the custom level order includes a few of my favourite LMS levels).

Then we have the temp1 cvar. It is used to set the max time one round may
be. If there is no Last Man Standing when the time is up, everyone is
respawned. Just set temp1 to the number of minutes you want. If you set
it to '0', no limit will be used.


Author Information
------------------
Knoll is from version 0.9 and on developing the patch. He is the one to
mail about bugs, changes, ideas, etc. Your input is needed!

E-mail Knoll: ehdr@canit.se
LMS homepage: http://www.fragzone.se/lms/


Copyright and Distribution Permissions
--------------------------------------
The source code is avalible to download from the homepage.

You may edit the code as you like, to make it fit your needs. If you
use any of the code in your patches, it would be nice if you gave me
some credit. Thanks.

You may distribute this Quake modification in any electronic format
as long as this description file remains intact and unmodified
and is retained along with all of the files in the archive.

Feel free to include this in any CD-ROM, though please give me a mail
so I'll know what to buy ;)


Credits
-------
Coder and contact person:	Knoll <ehdr@canit.se>
Beta tester and homepage maker:	Tott <m-2487@mailbox.swipnet.se>

Thanks goes to the old LMS team:
Evildead, Hobbex, KrYo, Arnolth, HeCUll


Availability
------------
You can get the latest version and the source code from
the official homepage: http://www.fragzone.se/lms/
