/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

//
//  m_hash
//  mike warren 1997
//
//  Simple hash table. Depends on m_string
//
//


#ifndef _M_HASH_H_
#define _M_HASH_H_

#include <stdio.h>

const int M_HASH_TABLE_SIZE = 1024;
#include "m_string.h"

template< class T > class m_hash
{
private:
	T * m_atTable;
	m_string * m_asKeys;
	int m_dTableSize;
	int m_dNumNew;

protected:
	T m_tDefaultValue;
	m_string m_sTempString;

	int _getHashValue( m_string & );
	void _expand();

public:
	m_hash();
	~m_hash() { delete [] m_atTable; delete [] m_asKeys; }

	T get( class m_string & );
	void set( class m_string &, T );

	T get( const char * s ) { m_sTempString = s; return get( m_sTempString ); }
	void set( const char * s, T d ) { m_sTempString = s; set( m_sTempString, d ); }

	T defaultValue() { return m_tDefaultValue; }
	void defaultValue( T & x ) { m_tDefaultValue = x; }

	friend ostream & operator << <> ( ostream &, m_hash< T > & );
};





#endif

