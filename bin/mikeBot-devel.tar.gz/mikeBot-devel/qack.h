/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  QACK class
**
**  (c) 1997, mike warren
**  mikeBot
**
**  handles resending of reliable client-server packets. Call QACK::resend()
**  every second or so...#defined as QACK_TIMEOUT
**
**
*/

#ifndef _QACK_H_
#define _QACK_H_

#include "qpacket.h"
#include "qsocket.h"

#if !WIN32
#include <sys/time.h>
#endif

class qack
{

  qpacket packets[ QACK_MAX ];
  int packetNumbers[ QACK_MAX ];
  int size;
  int tail;
  int head;

  int MaxTimeout;
  
  int lastSend;
  int current;

  int deletePacket();

public:

  qack();
  ~qack(){}

  int addPacket( qpacket &, qsocket * );
  int gotAck( int, qsocket * );
  int resend( qsocket * );
  void clear() { head=0; tail=0; size=0; }

  void setTimeout( int x ) { MaxTimeout=x; }
  
  int isEmpty() { return (size==0); }
#if DEBUG & DQACK
  void dumpPacketNumbers();
#endif

};


#endif
