/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  m_plane
**  mike warren 1997
**
**  plane class
**
*/


#ifndef _M_PLANE_H_
#define _M_PLANE_H_

#include "vector.h"

class m_plane
{
public:
	enum type_t { unknown, x, y, z };

protected:
	float m_distance;
	vector m_vNormal;

	type_t m_eType;

public:
	m_plane() { m_distance=(float)0.0; m_eType = unknown; }
	~m_plane(){}


				//
				//  some "access" functions
				//

	type_t type() const { return m_eType; }
	void type( type_t t ) { m_eType = t; }

	vector normal() const { return m_vNormal; }
	void normal( vector & n ) { m_vNormal = n; }

	float distance() const { return m_distance; }
	void distance( float x ) { m_distance = x; }

};


#endif