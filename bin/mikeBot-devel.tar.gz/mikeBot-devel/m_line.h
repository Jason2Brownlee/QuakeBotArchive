/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  m_line
**  mike warren 1997
**
**  Simple line class for BSP stuff
**
*/


#ifndef _M_LINE_H_
#define _M_LINE_H_

#include "vector.h"


class m_line
{
private:
	vector * m_first;
	vector * m_second;

public:
	m_line() { m_first = 0; m_second = 0; }
	~m_line(){}

	void first( vector * x ) { m_first = x; }
	void second( vector * x ) { m_second = x; }

	vector first() const { return *m_first; }
	vector second() const { return *m_second; }

	vector * pFirst() { return m_first; }
	vector * pSecond() { return m_second; }

};


#endif