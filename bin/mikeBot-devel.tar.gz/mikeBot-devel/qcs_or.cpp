/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
** "overridable" (i.e. designed to be) functions
**
*/

#include "defines.h"
#include "qcs.h"


/*
** rankings : displays names and rankings
**
**  TODO : sort by frags
*/

void qcs::rankings()
{
  for( int i=0; i < info.maxPlayers; i++ )
    if( players[ i ].name && *players[ i ].name )
      {
	printf("%-20s    %2d [ ", players[ i ].name, players[ i ].frags);
	printf("%02d | %02d ]\n", players[ i ].shirt, players[i].pants);
      }

	    
}
    
	
