/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**
**  MBFIRE class 
**
**  (c) 1997, mike warren
**  mikeBot
**
**
**  handles firecontrol : has 100% control of facing info and ``fire'' flag,
**  as well as impulses ( weapon switching )
**
*/

#ifndef _MBFIRE_H_
#define _MBFIRE_H_

#include "mbotbase.h"
#include "mbtalk.h"

class mbfire : public mbtalk
{
protected:

  int mbf_oldTarget;

  vector mbf_predictedPosition;	// where i think the target will be

  int mbf_shoot;		// 2 if inactive, 1 or 0 if active
  int mbf_impulse;		// for weapon changes, etc. 0 is nothing

  vector mbf_facing;		// where firing system wants to aim

  int mbf_idealrange;		// used by nav system

  int aimAt( int );		// adjusts facing to aim at the specified ent.

  void fire() { if( mbf_shoot == 2 ) mbf_shoot = 1; }

  void predictPosition( int );
  void selectWeapon();
  void setIdealRange();

public:
  
  mbfire();
  ~mbfire(){}

  void botShoot() { mbf_shoot=1; }
  void update();

  void forceShoot() { fire(); }

  void mbf_printTarget() { if( mbf_target != -1 ) printf("`%s'", players[mbf_target-1].name); else printf("`none'"); }
  void sendImpulse( int x ) { mbf_impulse=x; }

  int cmd( char *	);

};



#endif
