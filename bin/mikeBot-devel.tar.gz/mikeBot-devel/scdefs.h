/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**
**  server - client message types
**  mike warren 1997
**  mikeBot
**
**  many thanks to the very helpful Unofficial DEM Formal Description by
**  Uwe Girlich, available at 
**
** 		http://www.physik.uni-leipzig.de/~girlich/games/
**
*/



#ifndef _SC_DEFS_H_
#define _SC_DEFS_H_


#define SC_BAD  (unsigned char)0x00
#define SC_NOP  (unsigned char)0x01
#define SC_NOOP SC_NOP				// kept making typos ;)
#define SC_DISCONNECT  (unsigned char)0x02
#define SC_UPDATESTAT  (unsigned char)0x03
#define SC_VERSION  (unsigned char)0x04
#define SC_SETVIEW  (unsigned char)0x05
#define SC_SOUND  (unsigned char)0x06
#define SC_TIME  (unsigned char)0x07
#define SC_PRINT  (unsigned char)0x08
#define SC_STUFFTEXT  (unsigned char)0x09
#define SC_SETANGLE  (unsigned char)0x0A
#define SC_SERVERINFO  (unsigned char)0x0B
#define SC_LIGHTSTYLE  (unsigned char)0x0C
#define SC_UPDATENAME  (unsigned char)0x0D
#define SC_UPDATEFRAGS  (unsigned char)0x0E
#define SC_CLIENTDATA  (unsigned char)0x0F
#define SC_STOPSOUND  (unsigned char)0x10
#define SC_UPDATECOLORS  (unsigned char)0x11
#define SC_PARTICLE  (unsigned char)0x12
#define SC_DAMAGE  (unsigned char)0x13
#define SC_SPAWNSTATIC  (unsigned char)0x14
#define SC_SPAWNBINARY  (unsigned char)0x15
#define SC_SPAWNBASELINE  (unsigned char)0x16
#define SC_TEMPENTITY  (unsigned char)0x17
#define SC_SETPAUSE  (unsigned char)0x18
#define SC_SIGNON  (unsigned char)0x19
#define SC_CENTERPRINT  (unsigned char)0x1A
#define SC_KILLEDMONSTER  (unsigned char)0x1B
#define SC_FOUNDSECRET  (unsigned char)0x1C
#define SC_SPAWNSTATICSOUND  (unsigned char)0x1D
#define SC_INTERMISSION  (unsigned char)0x1E
#define SC_FINALE  (unsigned char)0x1F
#define SC_CDTRACK  (unsigned char)0x20
#define SC_SELLSCREEN  (unsigned char)0x21
#define SC_UPDATEENTITY  (unsigned char)0x80


#define CCREP_ACCEPT			(unsigned char)0x81
#define CCREP_REJECT			(unsigned char)0x82
#define CCREP_SERVER_INFO		(unsigned char)0x83
#define CCREP_PLAYER_INFO		(unsigned char)0x84
#define CCREP_RULE_INFO			(unsigned char)0x85


#endif
