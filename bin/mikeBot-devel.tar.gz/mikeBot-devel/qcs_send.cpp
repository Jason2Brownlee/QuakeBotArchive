/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**
**  QCS handles client-server communication
**
**  (c) mike warren, 1997
**  mikeBot
**
**  ``send'' functions; sendDisconnect() <--- use qcs::disconnect() instead!!
**  sendMovement(), etc. not for human consumption
**
*/


#include "defines.h"
#include "qcs.h"
#include "vector.h"
#include <stdlib.h>
#include <math.h>


/*
**  send : sends an arbitrary packet; correctly waits for acks on reliable 
**
*/

int qcs::send( qpacket & qp )
{
   if( qp.getType() != qpacket::reliableEnd && 
     qp.getType() != qpacket::reliableFragment )
    {
      return qp.send( sock );
    }
  else
    {
	return ackQueue.addPacket( qp, sock );
    }

}

/*
**  sendKeepalive : sends a no op (unreliable) aka client to server keepalive
**
*/

int qcs::sendKeepalive()
{
#if QCS_SAFESEND
  if( !connected() )
    return 0;
#endif
	
  outPacket.reset();
  outPacket.addBEint( outgoingUnreliable++ );
  outPacket.addByte( CS_KEEPALIVE );
  outPacket.changeType( qpacket::unreliable );
  return send( outPacket );
}

/*
**  sendDisconnect : send a disconnect packet (unreliable)
**
*/

int qcs::sendDisconnect()
{

  if( !connected() )
    return 0;

  outPacket.reset();
  outPacket.addBEint( outgoingUnreliable++ );
  outPacket.addByte( CS_DISCONNECT );
  outPacket.changeType( qpacket::unreliable );
	
  return send ( outPacket );
}

/*
**  sendMovement : sends the current movement values 
**  ---> IN mbot
*/

int qcs::sendMovement()
{
  if( signonLevel < 3 )		// not connected
    return FALSE;

  printf("ERROR: qcs::sendMovement() not overriden\n");
  return FALSE;

}



/*
**  sendConsole : sends a console command. MAKE SURE THERE IS A NEWLINE AT THE
**  END!! (i think...;) )
**
*/

int qcs::sendConsole( char * st )
{
#if QCS_SAFESEND
  if( !connected() )
    {
      printf("qcs::sendConsole(): not connected\n");
      return 0;
    }
#endif

  outPacket.reset();
  outPacket.addBEint( outgoingReliable++ );
  outPacket.addByte( CS_CONSOLE );
  outPacket.addString( st );
  outPacket.changeType( qpacket::reliableEnd );
	
  return send ( outPacket );
}


