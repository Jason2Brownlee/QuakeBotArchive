/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  m_polygon
**  mike warren 1997
**
**  simple polygon class
**
*/



#ifndef _M_POLYGON_H_
#define _M_POLYGON_H_

#define POLY_MAX_POINTS 16

#include "m_plane.h"
#include "vector.h"

class m_polygon
{
private:
	void expand()
	{
		vector ** n = new vector* [ m_dCapacity + POLY_MAX_POINTS ];
		for( int i=0; i < m_dNumPoints; i++ )
			n[ i ] = m_vPoints[ i ];

		delete [] m_vPoints;
		m_vPoints = n;
	}

protected:
	m_plane * m_pPlane;

	int m_bOnFront;
	int m_dPolygonNumber;

	vector ** m_vPoints;
	int m_dCapacity;
	int m_dNumPoints;

	m_polygon( m_polygon & );


public:
	m_polygon( int n = POLY_MAX_POINTS )
	{
		m_vPoints = new vector* [ n ]; 
		m_dCapacity = n;
		m_dNumPoints = 0;
		m_bOnFront = 0;
		m_dPolygonNumber = 0;
	}
	~m_polygon() { delete [] m_vPoints; }

	void addPoint( vector * p )
	{
		if( m_dNumPoints >= m_dCapacity-1 )
			expand();

		m_vPoints[ m_dNumPoints++ ] = p;
	}

	vector & operator [] ( int index ) const { return *m_vPoints[ index%m_dNumPoints ]; }

	void onFront( int x ) { m_bOnFront = x; }
	int onFront() const { return m_bOnFront; }

	vector normal() const { return m_bOnFront?m_pPlane->normal() : -m_pPlane->normal(); }

	m_plane * pPlane() const { return m_pPlane; }
	m_plane plane() const { return *m_pPlane; }
	void plane( m_plane * p ) { m_pPlane = p; }

	int isFloor();

	int pointInside( vector );	

	int number() const { return m_dPolygonNumber; }
	void number( int x ) { m_dPolygonNumber = x; }

	vector center();

};

#endif

