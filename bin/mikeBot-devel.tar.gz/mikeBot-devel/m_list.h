/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  m_list
**  mike warren 1997
**
*/


#ifndef _M_LIST_H_
#define _M_LIST_H_

template< class T > class m_listNode
{
public:
  T data;
  m_listNode<T> * next;
  m_listNode<T> * prev;

  m_listNode( m_listNode<T> * n=0, m_listNode<T> * p = 0 )
    {
      next = n; prev = p;
    }
  m_listNode( T d, m_listNode<T> * n=0, m_listNode<T> * p = 0 )
    {
      next = n; prev = p; data = d; 
    }
};



template< class T > class m_list
{
protected:
  m_listNode< T > * head;
  m_listNode< T > * tail;
  m_listNode< T > * current;

  void _deleteAllElements();

public:
  m_list() { head = tail = current= (m_listNode<T> *)0; }
  ~m_list() { _deleteAllElements(); }
  
  m_listNode< T > * find( T );
  int findAndDelete( T );

  void empty() { if( !isEmpty() )_deleteAllElements(); }

  void reset() { current = head; }
  int isEmpty() { return head==(m_listNode< T > *)0; }

  int operator ++ () { if( current ) current=current->next; return !(current==(m_listNode<T> *)0); }
  int operator -- () { if( current ) current=current->prev; return !(current==(m_listNode<T> *)0); }
  T operator * () { return current->data; }
  
  int addHead( T );
  int addTail( T );

  int deleteHead();
  int deleteTail();

};


#endif
  
