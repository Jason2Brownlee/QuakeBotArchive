/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**
**  MBNAV class 
**
**  (c) 1997, mike warren
**  mikeBot
**
**  ROAM version
**
**  handles navigation : has complete control over idealSpeeds, which are
**  changed to actual speeds after facing is determined (by mbfire). Also 
**  controls jumping. (unused, basically)
**
** TODO : pretty much everything :)
**
*/

#ifndef _MBNAV_H_
#define _MBNAV_H_

#include "mbfire.h"
#include "stack.h"
#include "m_list.h"

class mbnav : public mbfire
{
public:
	enum navMode { nm_seek, nm_flee, nm_wall_avoid, nm_chase, nm_none, nm_path };

protected:

  vector mbn_facing;		// where nav system wants to go
  double mbn_velocity;		// target speed
  int mbn_jump;				// turned off after send
  vector mbn_turnvector;	// for behaviours
  vector mbn_intersection;	// for projectile avoidance

  
  int chase_targetNumber;	// entity I'm chasing
  double chase_rating;		// rating at time of chase start
  vector chase_target;		// current chase waypoint
  int chase_isChasing;		// should I trash waypoints?
  m_list< vector > chase_queue;	// waypoints for player chasing

  int path_followingPath;	// is a valid path available?
  int path_targetNumber;	// entity the path goes to
  double path_rating;		// rating of path target
  m_stack< vector > path_path;	// actual path [ waypoints ]
  vector path_target;		// next path waypoint
  double path_stoppedTime;	// time i've not moved...


  int mbn_los;				// debug stuff...

  vector seekTarget;		// where to "seek" or "flee"

  navMode mode;				// what am I doing?

  double stoppedTimestamp;	// when movement ceased
  double stoppedTime;		// ...time since then
  

							// qcs::mbn_target
  int mbn_oldTarget;		// previous target

  int aimAt( vector & );
  void updateRatings();
  void aquireTarget();

				//
				//  behaviours : listed in order of precedence
				//

  void b_avoidlava();
  void b_avoidwall();
  void b_seekandflee();
  void b_chaseplayer();
  void b_pathfollow();
  void b_pursueandevade();
  
  void jump() { if( mbn_jump == 10) mbn_jump = 9; }

public:

  mbnav();
  ~mbnav() { }
  
  void forceJump() { jump(); }
  void mbn_printTarget() { if( mbn_target != -1 ) printf("`%s'", modeltable[ entities[mbn_target].index ]); else printf("`none'"); }
  void dumpPath();

  void update();

  int cmd( char * );

};





#endif

