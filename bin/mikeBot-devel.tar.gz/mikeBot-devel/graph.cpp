/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  graph class
**
**  (c) 1997 mike warren
**  mikeBot
**
**
**  builds a directed graph of the current level as the bot moves through
**  the level. as position is updates, this class figures out where the bot
**  is and if that new node has a floor polygon or is lava/slime/water, it
**  is added to the graph.  use the public: interface functions to get info
**  about the level. Provides line of sight, leaf type, etc
**
**  TODO:
**     . lava check when linking polygons
**     . path finding working right?
**
*/



#include "graph.h"
#include <memory.h>
#include <string.h>
#include "mpack.h"
#include "m_stack.h"

extern packList packFileList;

/*
**  newMap 
**
**  Loads new map, if possible, after saving the level graph for the
**  current map. Returns FALSE on failure, TRUE on success.
**
*/

int bspGraph::newMap( char * fname, int )
{
  if( map )
    {
      save();			// save current directed graph
      delete map;		// erase bspFile
    }

  printf("loading BSP from %s...", fname);
  fflush( stdout );

  mFile * mf;

  mf = packFileList.getFile( fname );

  if( !mf )
  {
	  try 
	  {
		  mf = new mFile( fname );
	  }
	  catch( char * err )
	  {
		  printf("bspGraph::newMap(): open error `%s'\n", err );
		  delete map;
		  return FALSE;
	  }
  }
  else
  {
  	  try 
	  {
		  map = new BSPlevel( *mf );
	  }
	  catch( char * err )
	  {
		  fprintf(stderr, "\n%s\nbspGraph::newMap(): level not loaded\n",err);
		  delete map;
      map=0;
      return FALSE;
	  }
  }

  eraseGraph();

				//
				// figure out graph-node file-name
				//

  strcpy( gfname, fname );
  int i=strlen( gfname );
  gfname[i-3]='g';
  gfname[i-2]='n';
  gfname[i-1]=0;

  load();				// loads graph from maps/*.GN file
    
  preprocessGraph();

  return TRUE;

}

/*
**  updatePosition 
**
**  Call this everytime the bot moves...figures out where
**	it is and possibly starts remaking paths
**
*/

void bspGraph::updatePosition( vector newPos )
{
			//
			//  update position and leaf
			//

  oldNode = currentNode;
  currentNode = findLeaf( newPos );

  oldPosition = position;
  position=newPos;

			//
			//  figure out which polygon I'm in
			//

  m_pOldPolygon = m_pPolygon;
  m_pPolygon = currentNode ? currentNode->floorPolygonForPoint( newPos ) : 0;
	
			//
			//  see if a link should be added (TODO check for lava)
			//

  if( m_pOldPolygon && m_pPolygon && (m_pOldPolygon != m_pPolygon) )
  {
	  if( !dead )
	  {
		  addLink( m_pOldPolygon, m_pPolygon, position );
	  }
  }

			//
			//  reset 'dead' flag. This is to prevent graph links
			//  forming when I respawn.
			//

  if( dead )
    dead=0;

}


/*
**  getLeafOrigin
**
**  Return the center of the bbox for the specified leaf
**
**  TODO:
**    is this really needed? if so, implement it.
**
*/

vector bspGraph::getLeafOrigin( int x )
{
  vector r;
  return r;
}
  

/*
**  getCurrentLeafType
**
**  Which type of leaf is the bot in (water, slime, lava, normal)
**
*/

m_BSPnode::type_t bspGraph::getCurrentLeafType()
{
  if( !map || !currentNode )
	  return m_BSPnode::unknown;

	return currentNode->type();
}

/*
**  getLeafType
**
**  Same as above, but uses vector to find leaf first
**
*/

m_BSPnode::type_t bspGraph::getLeafType( vector pos )
{
  if( !map )
	  return m_BSPnode::unknown;

  m_BSPnode * leaf = findLeaf( pos );

  if( !leaf ) 
	  return m_BSPnode::unknown;

  return leaf->type();
}

/*
**  isShotBlocked 
**
**  return TRUE if there's a wall between bot's current position
**  and the one passed in. if *hp is not null, the origin of the
**  intersection is also returned.
**
*/

int bspGraph::isShotBlocked( vector origin, vector * hp )
{
	return isLineBlocked( position, origin, hp );
}


/*
**  findLeaf
**
**  Determines which leaf the vector is in.
**
*/

m_BSPnode * bspGraph::findLeaf( vector origin )
{
	if( !map )
		return (m_BSPnode *)0;

	m_BSPnode * pNode = map->worldspawnRoot();
	double dist;

	if( !pNode ) return (m_BSPnode *)0;

	while( pNode )
	{
		if( !pNode->isLeaf() )
		{
			dist = (origin * pNode->plane().normal()) - pNode->plane().distance();
			pNode = (dist > 0.0) ? pNode->front() : pNode->back();
		}
		else
		{
			return pNode;
		}
	}

	fprintf( debugFile, "bspGraph::findLeaf(): NULL child node\n" );
	fflush( debugFile );
	return (m_BSPnode *)0;

}

/*
**  isLineBlocked
**
**  returns TRUE iff the line segment intersects the BSP (not including
**  water, slime or lava) if hitPoint is not NULL, the origin of the 
**  intersection is returned (used for fireParticle). If plane is not
**  NULL, the plane which the intersection point lies on is returned.
**
*/

#define R_E 0.001		// rounding error

int bspGraph::isLineBlocked( vector sv, vector ev, vector * hitPoint )
{
	if( !map ) return FALSE;

	double e, s;
	vector start, end, tv;
	m_BSPnode * pNode, * pEnd, * pStart;

	static m_stack< vector > vectorStack;
	static m_stack< m_BSPnode * > nodeStack;

	vectorStack.empty();
	nodeStack.empty();

	start = sv;
	end = ev;

	pNode = map->worldspawnRoot();

	if( !pNode ) 
	{
		fprintf( debugFile, "bspGraph::isLineBlocked(): 0th model root is NULL\n" );
	}


	while( pNode )
	{
		if( !pNode->isLeaf() )
		{
			s = (start * pNode->plane().normal()) - pNode->plane().distance();
			e = (end * pNode->plane().normal()) - pNode->plane().distance();

			pEnd = (e > 0.0) ? pNode->front() : pNode->back();
			pStart=(s > 0.0) ? pNode->front() : pNode->back();

			if( ((s < -R_E) && (e > R_E)) || ((s > R_E) && (e < -R_E)) )
			{
				vectorStack.push( end );
				nodeStack.push( pEnd );
			
				tv = start;
				tv *= e;
				end *= s;
				end = end - tv;
				end /= (s-e);
			}

			pNode = pStart;
		}
		else
		{
			if( pNode->type() == m_BSPnode::solid ||
				pNode->type() == m_BSPnode::unknown )
			{
				if( hitPoint ) *hitPoint = start;
				return TRUE;
			}

			start = end;
			if( nodeStack.isEmpty() ) 
			{
				pNode = (m_BSPnode *)0;
			}
			else
			{
				end = vectorStack.pop();
				pNode = nodeStack.pop();
			}
		}
	}


	if( hitPoint ) *hitPoint = start;
	return FALSE;

}



/*
**  isLineBlockedFluid
**
**  Returns TRUE if the line is blocked by lava or slime, or water 
**  if water==1.
**
*/

int bspGraph::isLineBlockedFluid( vector sv, vector ev, vector * hitPoint, int water )
{
	if( !map ) return FALSE;

	double e, s;
	vector start, end, tv;
	m_BSPnode * pNode, * pEnd, * pStart;

	static m_stack< vector > vectorStack;
	static m_stack< m_BSPnode * > nodeStack;

	vectorStack.empty();
	nodeStack.empty();

	start = sv;
	end = ev;

	pNode = map->worldspawnRoot();

	if( !pNode ) 
	{
		fprintf( debugFile, "bspGraph::isLineBlocked(): 0th model root is NULL\n" );
	}


	while( pNode )
	{
		if( !pNode->isLeaf() )
		{
			s = (start * pNode->plane().normal()) - pNode->plane().distance();
			e = (end * pNode->plane().normal()) - pNode->plane().distance();

			pEnd = (e > 0.0) ? pNode->front() : pNode->back();
			pStart=(s > 0.0) ? pNode->front() : pNode->back();

			if( ((s < -R_E) && (e > R_E)) || ((s > R_E) && (e < -R_E)) )
			{
				vectorStack.push( end );
				nodeStack.push( pEnd );
			
				tv = start;
				tv *= e;
				end *= s;
				end = end - tv;
				end /= (s-e);
			}

			pNode = pStart;
		}
		else
		{
			if( pNode->type() == m_BSPnode::water && water ) 
			{
				if( hitPoint ) *hitPoint = start;
				return TRUE;
			}

			if( pNode->type() == m_BSPnode::lava || pNode->type() == m_BSPnode::slime ) 
			{
				if( hitPoint ) *hitPoint = start;
				return TRUE;
			}

			if( pNode->type() == m_BSPnode::solid || pNode->type() == m_BSPnode::unknown )
			{
				if( hitPoint ) *hitPoint = start;
				return FALSE;
			}

			start = end;
			if( nodeStack.isEmpty() ) 
			{
				pNode = (m_BSPnode *)0;
			}
			else
			{
				end = vectorStack.pop();
				pNode = nodeStack.pop();
			}
		}
	}


	if( hitPoint ) *hitPoint = start;
	return FALSE;
}


/*
**  modelBlocksLine 
**
**  Checks if a particular model is blocking the line segment.
**
**  TODO:
**    implement me.
**
*/

int bspGraph::modelBlocksLine( vector end, vector delta, int )
{
  return 0;
}


/*
**  updateTable
**
**  Finds all paths from leaf A using Djserka's algorithm. (NOTE that
**  this is just as fast as finding shortest route to one particular
**  target node)
**
*/

void bspGraph::updateTable( m_polygon * a )
{
  static m_graph_queue q;
  m_polygon * v, * w;
  adjNode * p;

#if DEBUG & MBM
  if( a == 0 )
    printf("bspGraph::updateTable(): start node 0\n");
#endif

  for( int i=0; i < listSize; i++ )
    {
      t[i].p=0;
      t[i].dist=-1;
    }

  t[ a->number() ].dist = 0;		// start node
  q.add( a );

  while( !q.isEmpty() )
    {
      v = q.get();
#if DEBUG & MBM
      if( v==0 )
	printf("bspGraph::updateTable(): WARNING: v==0\n");
#endif
      p = adjList[ v->number() ];
      while( p->next )
	{
	  w = p->next->data;
	  p = p->next;
	  if( t[ w->number() ].dist == -1 )
	    {
	      t[ w->number() ].dist = t[ v->number() ].dist + 1;
	      t[ w->number() ].p = v;
	      q.add( w );
	    }
	}
    }

}

/*
**  pathToPoint
**
**  Finds the polygon which the point lies over and then find a path
**  to that point using bspGraph::findPath() and returns a full stack of
**  waypoints in STACK and returns TRUE if a path found. Returns FALSE and
**  an empty stack otherwise.
**
*/

int bspGraph::pathToPoint( vector point, m_stack< vector > & stack )
{
	m_BSPnode * node = findLeaf( point );

	if( !node )
	{
		stack.empty();
		return FALSE;
	}

	m_polygon * poly = node->floorPolygonForPoint( point );

	if( !poly )
	{
		stack.empty();
		return FALSE;
	}

	return findPath( m_pPolygon, poly, stack );
}


/*
**  findPath 
**
**  Finds a path from node A to B. Updates the table if nessecary. Returns
**  FALSE if there is no path, otherwise the passed stack is now full of
**  suitable vector-waypoints.
**
*/

int bspGraph::findPath( m_polygon * a, m_polygon * b, m_stack< vector > & stack )
{
  if( !map )
    return FALSE;

  if( a==b )
    return FALSE;

  if( !a || !b )
    return FALSE;

  if( t[ a->number() ].dist != 0 )				// find all paths
    updateTable( a );

  if( t[ b->number() ].p == (m_polygon *)0 )	// no path
    return 0;

  if( t[ b->number() ].dist == -1 || t[ b->number() ].dist == 0 )
    return 0;

  stack.empty();						// reset stack

#if DEBUG & MBM
  printf("bspGraph::findPath(): length should be %d\n", t[b].dist );
#endif

  m_polygon * v = b;
  m_polygon * oldv;

  stack.push( v->center() );
  
  int length=0;

  while( v != a )
  {
      if( length++ > listSize || t[ v->number() ].p == (m_polygon *)0 )
	  {
		  fprintf( debugFile, "bspGraph::findPath(): Search cut short\n");
		  return FALSE;	
	  }
      
	  oldv=v;
	  v = t[ v->number() ].p;

//	  stack.push( linkOrigin(oldv, v) );
      stack.push( v->center() );
  }

  return TRUE;

}

/*
**  linkOrigin
**
**  Returns the auxiliary waypoint associated with a link.
**
*/

vector bspGraph::linkOrigin( m_polygon * a, m_polygon * b )
{
	if( a->number() > listSize || b->number() > listSize )
		return FALSE;

	adjNode * p = adjList[ a->number() ];
	
	while( p )
	{
		if( p->data == b )
		{
			return p->origin;
		}
		p = p->next;
	}

	fprintf( debugFile, "bspGraph::linkOrigin(): No such link. THIS SHOULDN'T HAPPEN!!\n" );

	vector r;
	return r;
}

/*
**  removeLink 
**
**  Takes out link from A to B (if it exists...)
**
*/

int bspGraph::removeLink( m_polygon * a, m_polygon * b )
{
	if( a->number() > listSize || b->number() > listSize )
		return FALSE;

 adjNode * p = adjList[ a->number() ];
 adjNode * q;

 while( p->next )
 {
     if( p->next->data == b )
	 {
		 q = p->next->next;
		 delete p->next;
		 p->next = q;
		 return TRUE;
	 }
     p = p->next;
 }

 return FALSE;

}

/*
**  isLink 
**
**  Returns TRUE iff A --> B is a link in the graph. (NOTE that FALSE
**  will be returned even if B --> A is linked...)
**
*/

int bspGraph::isLink( m_polygon *, m_polygon * )
{
	return FALSE;
	/*
  if( a >= listSize || b >= listSize )
    return TRUE;
  if( a < 0 || b < 0 )
    return TRUE;

  adjNode * p = adjList[ a ];

  if( !p )
    {
      fprintf(stderr, "bspGraph::isLink(): problem\n");
      return FALSE;
    }

  while( p->next )
  {
      if( p->next->data == b )
		  return TRUE;
      p = p->next;
  }

  return FALSE;
*/
}

/*
**  addLink
**
**  Links node A to B. (NOTE this is not the same as B --> A)
**
*/

int bspGraph::addLink( m_polygon * a, m_polygon * b, vector origin )
{
	if( a->number() > listSize || b->number() > listSize )
	{
		fprintf( debugFile, "bspGraph::updatePosition(): addLink( %d --> %d ) failed\n", a->number(), b->number() );
		return FALSE;
	}
  
	if( isLink( a, b ) )
		return FALSE;

	adjNode * p = adjList[ a->number() ];

	if( !p )
    {
		fprintf(stderr,"bspGraph::addLink(): problem\n");
		return FALSE;
    }

#if DEBUG & MBM
  int i=0;
#endif

  while( p->next )
  {
      p = p->next;
#if DEBUG & MBM
      i++;
#endif
  }

#if DEBUG & MBM
  printf("%d links from node %d ", i, a );
  origin->print();
  printf("\n");
#endif

  p->next = new adjNode( b, origin );

  totalLinks++;

  return TRUE;

}

/*
**  numLinks
**
**  Returns number of links out of node A
**
*/

int bspGraph::numLinks( int a )
{
	if( a >= listSize )
		return -1;
	if( a < 0 )
		return -1;

	adjNode * p = adjList[ a ];

	if( !p )
    {
		fprintf(stderr, "bspGraph::isLink(): problem\n");
		return -1;
    }

	int i=0;

	while( p->next )
    {
		i++;
		p = p->next;    
	}

	return i;
}


/*
**  eraseGraph 
**
**  Deletes directed-graph stuff if it exists
**
*/

void bspGraph::eraseGraph()
{
  if( listSize <= 0 )
    return;
  
  adjNode *p, *q;
  int i;
  
  delete[] t;
  for( i=0; i < listSize; i++ )
    {
      p = adjList[i];
      while( p->next )
	{
	  q = p;
	  p = p->next;
	  delete q;
	}
      adjList[i]=0;
    }
  
  delete[] adjList;

  adjList=0;
  listSize=0;
  t = 0;
  
}

/*
**  save
**
**  Saves directed graph to a file. Any file by the same name is
**  overwritten. The directoy must already exist.
**
*/

int bspGraph::save()
{
  if( gfname[0]==0 )
    return 0;

  int fd = open( gfname, O_WRONLY|O_CREAT|O_TRUNC, 0600 );
  vector tv;
  float f;

  if( fd < 2 )
    {
      perror( gfname );
      return 0;
    }

  if( write( fd, (char *)&totalLinks, 4 ) < 4 )
    {
      perror(gfname);
      close( fd );
      return 0;
    }

  adjNode * p;

#if DEBUG & MBM
//  int j=0,k=0;
//  printf("%d links to save\n", totalLinks);
#endif

  printf("saving level graph");
  fflush( stdout );

  for( int i=0; i < listSize; i++ )
    {
      if( !(i%100) )
	{
	  printf(".");
	  fflush(stdout);
	}
      p = adjList[i];
#if DEBUG & MBM
//      k=0;
#endif
      while( p->next )
	{
#if DEBUG & MBM
//	  k++;
#endif
	  if( write( fd, (char *)&i, 4 ) < 4 )
	    {
	      perror(gfname);
	      close( fd );
	      return 0;
	    }
	  if( write( fd, (char *)&p->next->data, 4 ) < 4 )
	    {
	      perror(gfname);
	      close( fd );
	      return 0;
	    }

	  f = (float)p->next->origin.getx();
	  if( write( fd, (char *)&f, 4 ) < 4 )
	    {
	      perror(gfname);
	      close( fd );
	      return 0;
	    }

	  f = (float)p->next->origin.gety();
	  if( write( fd, (char *)&f, 4 ) < 4 )
	    {
	      perror(gfname);
	      close( fd );
	      return 0;
	    }

	  f = (float)p->next->origin.getz();
	  if( write( fd, (char *)&f, 4 ) < 4 )
	    {
	      perror(gfname);
	      close( fd );
	      return 0;
	    }

	  p=p->next;
#if DEBUG & MBM
//	  j++;
#endif
	}
#if DEBUG & MBM
//      printf("node %d : %d links saved\n", i,k );
#endif
    }

  printf("saved %d links\n", totalLinks);

  gfname[0]=0;			// so it won't be saved twice

  return totalLinks;
}

/*
**  load
**
**  Allocates space for directed graph and then loads it from the
**  bspGraph::gfname[] file.
**
*/

int bspGraph::load()
{
	static vector foo;

	if( adjList ) 
	{
		delete [] adjList;
		adjList = 0;
	}

	if( t )
	{
		delete [] t;
		t = 0;
	}

	if( !map )
		return FALSE;

			//
			//  allocate space for graph
			//

	listSize = map->numPolygons();

	fprintf( debugFile, "bspGraph::load(): List size is %d\n", listSize );

	adjList = new adjNode * [ listSize ];
	for( int i=0; i < listSize; i++ )
	{
		adjList[ i ] = new adjNode( 0, foo );
	}
	t = new g_table[ listSize ];

	totalLinks = 0;

			//
			//  load graph from file
			//

	
	return FALSE;
}
     

/*
**  preprocessGraph 
**
**  Will make a "first-cut" directed graph of polygons who share
**  a piece of an edge.
**
*/

void bspGraph::preprocessGraph()
{
  int links=0;

  printf("bspGraph::preprocessGraph(): processing...");
  fflush( stdout );

  printf("added %d links\n", links );
}
