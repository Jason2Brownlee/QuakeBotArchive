/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  support class for bspFile
**  (c) 1997 mike warren
**
**  this code is *not* freeware. See the file ``README'' or contact
**  mbwarren@acs.ucalgary.ca
**
**  (excuse the rather long ::read() inlined functions, but i didn't feel like
**   having lotsa .cc files :) )
**
*/



#include "defines.h"
#include "mfile.h"

class bspEntry
{
  int offset;
  int size;

public:
  bspEntry() { offset=0; size=0; }
  bspEntry( mFile & mf ) { read( mf ); }

  void read( mFile & mf ) { offset=mf.readLEint(); size=mf.readLEint(); }
  int getOffset() { return offset; }
  int getSize() { return size; }
};
    

class bspHead
{
  int version;
  bspEntry * entries[ 15 ];

  bspHead() {}			// no NULL ctor

public:
  bspHead( mFile & mf ) { read( mf ); }
  ~bspHead()
  {
	  for( int i=0; i < 15; i++ ) delete entries[i];
  }


  void read( mFile & mf )
  { 
	  version = mf.readLEint(); 
	  for( int i=0; i < 15; i++ ) 
		  entries[i]=new bspEntry( mf );
  }

  bspEntry & getEntry( int index ) const { return *entries[ index ]; }

  int getVersion() const { return version; }

};

  
  
