/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  support class for bspFile
**  (c) 1997 mike warren
**
**  this code is *not* freeware. See the file ``README'' or contact
**  mbwarren@acs.ucalgary.ca
**
**  (excuse the rather long ::read() inlined functions, but i didn't feel like
**   having lotsa .cc files :) )
**
*/



#ifndef _CLIPNODE_H_
#define _CLIPBODE_H_

#include "defines.h"
#include "vector.h"


class bspClipnode
{
  int planeId;
  short front;
  short back;

  bspClipnode(){}

public:

  bspClipnode( mFile & mf ) { read( mf ); }

  void read( mFile & mf ) 
  { 
	  planeId=mf.readLEint(); 
	  front=mf.readLEshort(); 
	  back=mf.readLEshort(); 
  }

  int getPlaneId() { return planeId; }
  int getFront() { return front; }
  int getBack() { return back; }

  void dump() { printf("%d %d %d\n", planeId, front, back); }

};


class bspClipnodes
{
  bspClipnode ** clipnodes;
  int loadedClipnodes;

  bspClipnodes(){}

public:
  
  bspClipnodes( mFile & mf, int n ) 
  {
	  clipnodes=new bspClipnode* [ n ]; 
	  for(int i=0; i < n; i++) 
		  clipnodes[i]=0; 
	  loadedClipnodes=0; 
	  read( mf, n ); 
  }
  ~bspClipnodes()
  { 
	  for( int i=0; i < loadedClipnodes; i++)
		  delete clipnodes[i]; 
	  delete clipnodes;
  }

  void read( mFile & mf, int n ) { for( int i=0; i < n; i++) clipnodes[i] = new bspClipnode( mf ); loadedClipnodes=n; }
  
  bspClipnode * getClipnode( int x ) { return operator[]( x ); }
  bspClipnode * operator[] ( int x )
  { 
	  if ( x >= 0 && x < loadedClipnodes )
		  return clipnodes[x]; 
	  else
		  return 0;
  }
  int getNum() { return loadedClipnodes; }

  void dump() 
  { 
	  for( int i=0; i < loadedClipnodes; i++)
		  clipnodes[i]->dump(); 
  }

};


    
#endif
