/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**
**  STACK
**
**  (c) 1997 mike warren
**  mikeBot
**
**  wheee, its a stack
**
*/


#ifndef _STACK_H_
#define _STACK_H_

#define STACK_SIZE 1024

#include "defines.h"

template< class T >
class stack
{
  int size;
  T * items;
  int maxSize;

  void growStack()
  {
	  T * n = new T[ maxSize+STACK_SIZE ];
	  for( int i=0; i < maxSize; i++ )
		  n[ i ] = items[ i ];
	  delete[] items;
	  items = n;
  }
  
public:

  stack() 
  { 
	  size=STACK_SIZE; 
	  items = new T[ STACK_SIZE ];
	  maxSize=STACK_SIZE; 
  }
  ~stack() { delete[] items; }

  int push( T x ) 
  { 
	  if( size>=maxSize) 
		  growStack();
	  items[size++]=x; 
	  return TRUE; 
  }
  T pop() 
  { 
	  if( !isEmpty() )
		  return items[--size]; 
	  return 0; 
  }
  T peek()
  { 
	  if( !isEmpty() ) 
		  return items[ size-1 ]; 
	  return 0; 
  }

  const int getSize() const { return size; }
  const int isEmpty() const { return (size==0); }
};


#endif
