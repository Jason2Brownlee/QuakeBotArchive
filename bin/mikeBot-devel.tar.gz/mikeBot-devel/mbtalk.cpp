/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**
**  MBTALK
**
**  (c) 1997 mike warren
**  mikeBot
**
**  sends random insults, parses MBL- commands. see 
**
**   http://www.ucalgary.ca/~mbwarren/mikeBot/ 
**
**  for more on the mikeBotLanguage (MBL-)
**
*/



#include "mbtalk.h"

#if UNIX
#include <sys/types.h>
#include <sys/time.h>
#endif

/*
**  initWords : initializes words.
**
**  TODO : load from file
**
*/

void mbtalk::initWords()
{
  
  numGoodVerbs=5;
  numGoodNouns=5;
  numBadNouns=7;
  numBadVerbs=7;
  numCannedHurt=8;

  badVerbs = new char *[ numBadVerbs ];
  goodVerbs = new char *[ numGoodVerbs ];
  goodNouns = new char *[ numGoodNouns ];
  badNouns = new char *[ numBadNouns ];
  cannedHurt = new char *[ numCannedHurt ];

  goodVerbs[0] = "kicks ass like a";
  goodVerbs[1] = "is a";
  goodVerbs[2] = "plays like a";
  goodVerbs[3] = "shoots like a";
  goodVerbs[4] = "moves like a";

  badVerbs[0] = "sucks";
  badVerbs[1] = "licks";
  badVerbs[2] = "is a";
  badVerbs[3] = "smells like a";
  badVerbs[4] = "looks like a";
  badVerbs[5] = "sucks the hiney of a";
  badVerbs[6] = "kisses the butt of a";

  badNouns[0] = "llama";
  badNouns[1] = "spode";
  badNouns[2] = "dumbass";
  badNouns[3] = "pylon";
  badNouns[4] = "LPB";
  badNouns[5] = "hiney";
  badNouns[6] = "moron";
  badNouns[6] = "moron";

  goodNouns[0] = "carmack";
  goodNouns[1] = "quake-god";
  goodNouns[2] = "-=mike=-";
  goodNouns[3] = "stooge-bot";
  goodNouns[4] = "hero";

  cannedHurt[0] = "Is that all you can do,";
  cannedHurt[1] = "Bring it on,";
  cannedHurt[2] = "You call that aiming,";
  cannedHurt[3] = "My grandma shoots better than";
  cannedHurt[4] = "Everyone against";
  cannedHurt[5] = "Gang up on";
  cannedHurt[6] = "You're dead,";
  cannedHurt[7] = "Watch your back,";

  cooperating = -1;
  mbt_wingman = 0;

#if UNIX && !AIX
  srand( (int)time( NULL ) );
#endif

}

/*
**  deleteWords : dealloctes words memory
**
**  TODO : run through arrays, after init() loads from file...
**
*/

void mbtalk::deleteWords()
{

  delete[] badNouns;
  delete[] goodNouns;
  delete[] badVerbs;
  delete[] goodVerbs;

}

/*
**  update : if random numbers dictate time to talk, he does
**
*/

void mbtalk::update()
{
  char temp[80];

  if( lastDamage > -1 )
    {
      talkDamage( lastDamage );
      lastDamage=-1;
    }

  if( cooperating > -1 )
    {
      if( players[ cooperating ].hate >= 0 )
	{
	  sprintf(temp,"say %s: you blew it...no more cooperate\n", players[cooperating].name );
	  sendConsole( temp );
	  pants( opts.get( "default-pants" ) );
	  shirt( opts.get( "default-shirt" ) );
	  players[ cooperating ].hate = 1000;

	  cooperating = -1;
	  mbt_wingman = 0;
	}
    }
  
  if( opts.get( "talk" ) )
    if( (rand()%10000) < opts.get( "talk-prob" ))
      if( info.maxPlayers != 0 )
	{
	  int i = rand()%info.maxPlayers;
	  i++;

#if DEBUG & MBT
//	  printf("%d %d %d %d\n", numGoodNouns, numBadVerbs, numGoodVerbs, numBadNouns );
#endif

	  if( players[i].name && *players[i].name )
	    {
#if DEBUG & MBT
	      printf("talking to %s\n", players[i].name);
#endif

	      if( players[i].hate >= 0 )
		sprintf(mbt_message, "say \""MBT_PREFIX" %s %s %s.\n", players[i].name,
			badVerbs[rand()%numBadVerbs],
			badNouns[rand()%numBadNouns] );
	      else if( players[i].hate < 0 )
		sprintf(mbt_message, "say \""MBT_PREFIX" %s %s %s.\n", players[i].name, 
			goodVerbs[rand()%numGoodVerbs], 
			goodNouns[rand()%numGoodNouns] );

	      sendConsole( mbt_message );
	    }
	}
}


/*
**  parseMessage 
**
**  Looks for mblanguage strings in say messages
**
*/

void mbtalk::parseMessage( char * x )
{
  static char buff[ Q_MAX_STRING ];
  static char buff2[ Q_MAX_STRING ];
  char * name, * message;
  char * command=0;
  int i,k, playerNumber;

  if( x[0] != 1 )		// not a "say" message
    return;

  strcpy( buff, &x[1] );

  name = strtok( buff, ":" );
  message = strtok( NULL, " \t\n\0" );

  i=0;
  while( message && message[i] )
    {
      if( !strncmp( &message[i], "mbl-", 4 ))
	command = strtok( &message[i+4], " \t\n\0" );
      i++;
    }

  parseName( (unsigned char *)name );

  playerNumber=-1;

  for( i=0; i < info.maxPlayers; i++ )
    if( players[i].name && !strcmp( name, players[i].name ) )
      {
	playerNumber=i;
	break;
      }

  if( command )
    {
      if( !opts.get("no-print-mbl") )
		  printf("mbtalk::parseMessage(): from %d:%s `%s'\n", playerNumber, name, command );

      if( playerNumber != (myEntityNumber-1) )
	  {

        if( !strcmp( "author", command ) )
	    {
	      sendConsole( "say \"author: mike warren " );
	      sendConsole( "say \"www.planetquake.com/mikebot");
	      sendConsole( "say \"mbwarren@acs.ucalgary.ca ");
	    }
      else if ( !strcmp( "cooperate", command ) )
	{
	  if( players[ playerNumber ].hate < 900 && (cooperating < 0) )
	    {
	      sprintf( buff2, "say \"%s: mbl-cooperate-yes ", name);
	      sendConsole( buff2 );
	      players[ playerNumber ].hate = -200;
	      pants( players[ playerNumber ].pants );
	      shirt( players[ playerNumber ].shirt );
	      cooperating = playerNumber;
	    }
	  else
	    {
	      sprintf( buff2, "say \"%s: mbl-cooperate-no ", name);
	      sendConsole( buff2 );
	    }
	}
	  else if( !strcmp( "wingman-on", command ) )
	  {
		  printf("mbtalk:parseMessage(): player %d, cooperating with %d\n", playerNumber, cooperating );

		  if( (cooperating > -1) && (playerNumber == cooperating) )
		  {
			  sprintf( buff2, "say \"%s: wingman mode acitvated \n", name );
			  sendConsole( buff2 );
			  mbt_wingman = playerNumber+1;
		  }
		  else
		  {
			  sprintf( buff2, "say \"%s: i'm not cooperating with you\n", name);
			  sendConsole( buff2 );
		  }
			
	  }
	  else if( !strcmp( "wingman-off", command ) )
	  {
		  if( mbt_wingman && ((playerNumber+1) == mbt_wingman) )
		  {
			  sprintf( buff2, "say \"%s: wingman mode off \n", name );
			  sendConsole( buff2 );
			  mbt_wingman = 0;
		  }
		  else
		  {
			  sprintf( buff2, "say \"%s: I'm not your wingman\n", name );
			  sendConsole( buff2 );
		  }

	  }
      else if ( !strcmp( "maximal-hate", command ) )
	{
	  sprintf( buff2, "say \"%s: mbl-maximal-hate-yes ", name );
	  sendConsole( buff2 );
	  players[ playerNumber ].hate = 500;
	}
      else if ( !strcmp( "hate", command ) )
	{
	  k=0;
	  for( i=0; i < info.maxPlayers; i++ )
	    {
	      if( players[i].hate > k )
		k=players[i].hate;
	    }
	  sprintf( buff2, "say \"%s: %8.2f%% (%d of %d) ", name, 100.0*((float)players[playerNumber].hate / (float)k), players[playerNumber].hate, k );
	  sendConsole( buff2 );
	}
      else if ( !strcmp( "bot", command ) )
	{
	  sprintf( buff2, "say \"%s: mbl-bot-mikeBot\n", players[playerNumber].name);
	  sendConsole( buff2 );
	}
      else if ( !strcmp( "socket", command ) )
	{
	  sprintf( buff2, "say \"%s: mbl-socket-no\n",players[playerNumber].name );
	  sendConsole( buff2 );
	}
      else if ( !strcmp( "compliance", command ) )
	{
	  sprintf( buff2, "say \"%s: mbl-compliance-level-2\n", players[playerNumber].name);
	  sendConsole( buff2 );
	}
      else if ( !strcmp( "help", command ) )
	{
	  sendConsole( "say \"mbl-author:contact info");
	  sendConsole( "say \"mbl-cooperate:be on team");
	  sendConsole( "say \"mbl-hate:your hate level");
	  sendConsole( "say \"mbl-maximal-hate:increase hate");
	  sendConsole( "say \"mbl-target:my target");
	  sendConsole( "say \"mbl-observers:connected observers");
	  sendConsole( "say \"connect to my IP to watch...");
	}
      else if ( !strcmp( "target", command ) )
	{
	  sprintf( buff2, "say \"target : %s", mbf_target?players[mbf_target-1].name:"none." );
	  sendConsole( buff2 );
	}
      else if ( !strcmp( "observers", command ) )
	{
#if QPROXY
	  if( proxy )
	    {
	      sprintf( buff2, "say \"observers %d : ", proxy->connected());
	      for( i=0; i < QX_MAX_CLIENTS; i++ )
		{
		  strcat( buff2, proxy->getClientName( i ) );
		  strcat( buff2, ", " );
		}
	      sendConsole( buff2 );
	    }
	  else
	    sendConsole(" say\"observers: none.");
#else
	  sendConsole("say \"observers: none.");
#endif
	}
      else
	{
	  sprintf( buff2, "say \"%s: unknown: %s ", name, command );
	  sendConsole( buff2 );
	}
    }
    }
  message = x;
  i=0;
  while( message[i] != ':' )
    if( ++i >= Q_MAX_STRING ) 
      break;

  if( i < Q_MAX_STRING )
    if( !strncmp( &message[i], ": no bots", 9 ) || 
       !strncmp( &message[i], ": humans only", 13 ) || 
       !strncmp( &message[i], ": bots suck", 11 ) )
      {
	sprintf( buff2, "say \"%s: i am autonomous...\n", players[playerNumber].name );
	sendConsole( buff2 );
      }
}


/*
**  talkDamage : pass playerNumber of suspect and if random numbers say so
**               a random canned taunt will be sent
**
*/

void mbtalk::talkDamage( int pn )
{

  if( opts.get( "talk" ) )
    if( (rand()%500) < opts.get( "damage-talk-prob" ))
	{
	  int i = rand()%numCannedHurt;

	  sprintf(mbt_message, "say \""MBT_PREFIX" %s %s\n", cannedHurt[i],players[pn].name);
	  sendConsole( mbt_message );
	}

	  

}


/*
**  gotSayMessages
**
**  Overrides from QCS
**
*/

void mbtalk::gotSayMessage( char * x )
{ 
	if( opts.get("parse-string") ) 
		parseString(x); 
	
	if( !opts.get("no-print-say") ) 
		printf("%s", x ); 
	
	parseMessage(x); 
}
  
	
    
/*
**  cmd
**
**  see qcs::cmd()
**
*/

int mbtalk::cmd( char * x )
{
	return mbotbase::cmd( x );
}