/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */



#include "defines.h"
#include "cmdflags.h"

#include <string.h>
#include <stdio.h>

/*
**  parseCommandLine : returns a cmdFlags struct filled with tons o' valuable
**			info. (see qpstruct.h)
**
*/

cmdFlags::cmdFlags( int argc, char **argv )
{

  int i, j;

  filename=0;
  port=0;
  address=0;
  pakpath=new char[ Q_MAX_STRING ];
  configfile = new char[ Q_MAX_STRING ];
  
  strcpy( configfile, CONFIG_FNAME );
  strcpy( pakpath, "C:\\quake\\id1\\" );

  for( i=1; i < argc; i++ )
    {
      if( *argv[i] == '-' )
	for( j=1; j < (int)strlen( argv[i] )-1; j++ )
	  switch( argv[i][j] )
	    {
	    case 'r':
	      filename = new char[ Q_MAX_STRING ];
	      strcpy( filename, &argv[i][j+1] );
	      j = 10000;	// strange way to exit switch, but hey :)
	      break;

	    case 'p':
	      port = atoi( &argv[i][j+1] );
	      j = 10000;
	      break;

		case 'c':
			strcpy( configfile, &argv[i][j+1] );
			printf("cmdflags::cmdflags(): using config file `%s'\n",configfile);
			j = 10000;
			break;

		case 'f':
			strcpy( pakpath, &argv[i][j+1] );
			printf("cmdflags::cmdflags(): using PAK path `%s'\n", pakpath);
			j=10000;
			break;
	      
	    default:
	      fprintf(stderr, "parseCommandLine(): unknown flag `%c'\n", argv[i][j]);
	      break;
	    }
      else
	{
	  address = new char[ Q_MAX_STRING ];
	  strcpy( address, argv[i] );
	}
    }

}

