/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  bspNode
**  mike warren 1997
**
**  A node of a BSP tree. 
**
*/


#ifndef _BSPNODE_H_
#define _BSPNODE_H_

#include "vector.h"
#include "nodes.h"
#include "m_list.h"
#include "m_polygon.h"
#include "m_plane.h"


class m_BSPnode
{
public:
	enum type_t { normal, solid, water, slime, lava, sky, unknown };

private:
	int m_isLeaf;
	type_t m_type;

protected:
	vector m_bboxMin;
	vector m_bboxMax;

	m_plane * m_pPlane;

	int m_faceID;
	int m_faceNumber;

	m_BSPnode * m_front;
	m_BSPnode * m_back;

	m_list< m_polygon * > m_polygons;

	m_BSPnode( bspNode & );

public:
	m_BSPnode() { m_front = 0; m_back = 0; m_pPlane=0; }
	~m_BSPnode(){}

	m_BSPnode * front() const { return m_front; }
	m_BSPnode * back() const { return m_back; }
	void front( m_BSPnode * x ) { m_front = x; }
	void back( m_BSPnode * x ) { m_back = x; }

	void addPolygon( m_polygon * x ) { m_polygons.addHead( x ); }

	vector & bboxMin() { return m_bboxMin; }
	vector & bboxMax() { return m_bboxMax; }
	void bboxMin( vector x ) { m_bboxMin = x; }
	void bboxMax( vector x ) { m_bboxMax = x; }

	m_polygon * floorPolygonForPoint( vector & );

	int isLeaf() const { return m_isLeaf; }
	void isLeaf( int x ) { m_isLeaf = x; }
	int isFrontLeaf() const
	{
		if( !m_front )
			return FALSE;
		return m_front->isLeaf();
	}

	int isBackLeaf() const
	{
		if( !m_back )
			return FALSE;
		return m_back->isLeaf();
	}

	m_plane & plane() { return *m_pPlane; }
	void plane( m_plane * x ) { m_pPlane = x; }

	type_t type() const { return m_type; }
	void type( type_t x ) { m_type = x; }
};



#endif