/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**
**  QENTITY class
**
**  (c) 1997, mike warren
**  mikeBot
**
**  keeps track of where, what different entities are.
**
*/

#ifndef _QENTITY_H_
#define _QENTITY_H_

#include "defines.h"
#include "vector.h"

//
//  TODO : convert the index into a type through the modeltable[] entry
//

class qentity
{
public:

  int index;			// into modeltable[]
  int default_index;
  int frame;			// model's frame (usefull for determing
						// weather player is dead)
  int skin;				// good for determining armour type
  
  vector origin;		// center of entity
  vector facing;		// which way is it looking?
  vector velocity;		// how fast, which direction moving?

  int spawned;			// TRUE/FALSE if spawnbaseline recieved for this

  float lastTime;		// last timestamp update received

  float rate;			// for MBNAV and MBFIRE
  float rateMultiplier; // for MBNAV
  int shootable;		// used by MBFIRE


  qentity() { index=-1;frame=0;skin=0;origin.set((float)0,(float)0,(float)0);facing.set((float)0,(float)0,(float)0);lastTime=(float)0.0; rate=(float)0.0; rateMultiplier=(float)0.0; spawned=FALSE; shootable=FALSE; }
	  
  void updateOrigin( vector & v, float t1, float t2 ) { velocity = v - origin; origin = v; velocity /= (t2 - t1); }

};


#endif
