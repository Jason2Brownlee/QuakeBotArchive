/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**
**  MBOT class, derived from MBFIRE and MBNAV and MBTALK and MBEARS
**
**  (c) 1997, mike warren
**  mikeBot
**
*/

#ifndef _MBOT_H_
#define _MBOT_H_

#include "mbnav.h"

class mbot : public mbnav
{
protected:

  int respawn;			// > 0 iff bot is dead. and should fire
  int verticleSpeed;	// these are the massaged speeds 
  int forwardSpeed;		// after accounting for idealSpeeds
  int strafeSpeed;		// from mbnav and facing from mbfire

  int sendMovement();		// overrideds QCS::SENDMOVEMENT()

public:
  
  mbot();
  ~mbot(){  }

  void reinit() { mbotbase::reinit(); }

  void update();		// only function which needs to be called
						// calls qcs::update(), mbfire::update(), etc.
  int setOptsFromFile( char * );// initializes MBOT options from a file
  void changeHate( int i, int x ) { players[i].hate = x; }

  void disconnect() { map.save(); qcs::disconnect(); }

  int cmd( char * );

};





#endif

