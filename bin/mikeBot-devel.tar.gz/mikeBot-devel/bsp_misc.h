/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  BSP support routines and misc. classes
**  mike warren 1997
**
*/


#ifndef _BSP_MISC_H_
#define _BSP_MISC_H_

#include "mfile.h"

class BSPentry
{
private:
	int m_offset;
	int m_size;

public:
	BSPentry() { m_offset=0; m_size=0; }
	BSPentry( mFile & mf ) { m_offset = mf.readLEint(); m_size = mf.readLEint(); }
	~BSPentry(){}

	int size() const { return m_size; }
	int offset() const { return m_offset; }
};

class BSPhead
{
public:
	enum index_t { entities=0, planes, textures, vertices, visilist, nodes, texinfo, faces, lightmaps, clipnodes, leaves, facelist, edges, edgelist, models };

private:
	int m_version;
	BSPentry * entries[ 15 ];

public:
	BSPhead( mFile & mf )
	{
		m_version = mf.readLEint();
		for( int i=0; i < 15; i++ )
			entries[ i ] = new BSPentry( mf );
	}
	~BSPhead() { for( int i=0; i < 15; i++ ) delete entries[ i ]; }

	int version() const { return m_version; }
	BSPentry const & get( index_t i ) const { return *entries[ (int)i ]; }

};


#endif