/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  bspLevel
**  mike warren 1997
**
**  A "nice" BSP-object (i.e. more intuitive than bspFile)
**
*/


#ifndef _BSPLEVEL_H_
#define _BSPLEVEL_H_

#include "m_plane.h"
#include "m_polygon.h"
#include "m_line.h"
#include "bsp.h"
#include "vector.h"
#include <stdio.h>
#include "mfile.h"


class BSPlevel
{
protected:
	m_plane * m_aPlanes;
	m_polygon * m_aPolygons;
	m_line * m_edges;
	vector * m_vertices;

	m_BSPnode * m_pTreeRoot;
	m_BSPnode ** m_apModelRoots;

	m_BSPnode ** m_pBSPnodes;
	int m_dLeafOffset;
	int m_dNumLeaves;
	int numberOfLeavesAndNodes;

	int m_dNumPlanes;
	int m_dNumModels;
	int m_dNumPolygons;

	BSPlevel( BSPlevel & ){}

public:
	BSPlevel( mFile & );
	~BSPlevel();

	m_BSPnode * model( int i ) { if( i < m_dNumModels ) return 0; return m_apModelRoots[ i ]; }
	m_plane * pPlane( int i ) { return &(m_aPlanes[ i%m_dNumPlanes ]); }
	m_plane plane( int i ) { return m_aPlanes[ i%m_dNumPlanes ]; }

	m_polygon & polygon( int i ) { return m_aPolygons[ i%m_dNumPolygons ]; }

	m_BSPnode * worldspawnRoot() { return m_apModelRoots[ 0 ]; }

	int numLeaves() const { return m_dNumLeaves; }
	int numModels() const { return m_dNumModels; }
	int numPolygons() const { return m_dNumPolygons; }

	void printInfo()
	{
		printf("bspLevel: %d polygons, %d planes, %d models\n", m_dNumPolygons, m_dNumPlanes, m_dNumModels );
	}

};

#endif

	
