/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*

**  support class for bspFile

**  (c) 1997 mike warren

**

**  this code is *not* freeware. See the file ``README'' or contact

**  mbwarren@acs.ucalgary.ca

**

**  (excuse the rather long ::read() inlined functions, but i didn't feel like

**   having lotsa .cc files :) )

**

*/





#ifndef _VERTICES_H_

#define _VERTICES_H_



#include "defines.h"

#include "vector.h"

#include "mfile.h"





class bspVertex

{

  vector position;

  

  bspVertex(){}



public:



  bspVertex( mFile & mf ) { read( mf ); }



  void read( mFile & mf ) { position.setx( mf.readLEfloat() ); position.sety( mf.readLEfloat() ); position.setz( mf.readLEfloat() ); }

  vector getVertex() { return position; }



  void dump() { position.print(); putchar('\n'); }

};



class bspVertices

{

  bspVertex ** vertices;

  int loadedVertices;

  

  bspVertices(){}



public:

  

  bspVertices( mFile & mf, int x ) { vertices=new bspVertex*[ x ]; loadedVertices=0; for( int i=0; i < x; i++ ) vertices[i]=0; read( mf, x ); }

  ~bspVertices() { for( int i=0; i < loadedVertices; i++ ) delete vertices[i]; delete[] vertices;}



  void read( mFile & mf, int n ) { for( int i=0; i < n; i++ ) vertices[i]=new bspVertex( mf ); loadedVertices=n; }



  int getNum() { return loadedVertices; }

  bspVertex * getVertex( int x ) {  if (x>=0 && x < loadedVertices ) return vertices[x]; else return 0; }



  void dump() { for( int i=0; i < loadedVertices; i++ ) vertices[i]->dump(); }



};







#endif

