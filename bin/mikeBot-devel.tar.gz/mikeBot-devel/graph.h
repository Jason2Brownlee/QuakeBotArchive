/**
 *
 *  mikeBot -- an autonomous, client-side AI for Quake
 *  Copyright (C) 1997 Mike Warren <mike@mike-warren.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
**  graph class
**
**  (c) 1997 mike warren
**  mikeBot
**
**
**  builds a directed graph of the current level as the bot moves through
**  the level. as position is updates, this class figures out where the bot
**  is and if that new node has a floor polygon or is lava/slime/water, it
**  is added to the graph.  use the public: interface functions to get info
**  about the level. Provides line of sight, leaf type, etc
**
*/


#ifndef _GRAPH_H_
#define _GRAPH_H_

#include "defines.h"
#include "bsplevel.h"
#include "vector.h"
#include "m_stack.h"


//
//  g_table
//
//  Support class for directed-graph shortest-path stuff
//


struct g_table
{
  int dist;
  m_polygon * p;
  g_table() { dist=-1; p = (m_polygon *)0; }
};

//
// m_queue
//
// NOTE NAME CHANGE since version 0.31. 
//

class m_graph_queue
{
  m_polygon ** entries;
  int start;
  int end;
  int num;
  int max;

public:
  m_graph_queue( int size=1024 ) { entries=new m_polygon *[ size ]; start=0; end=0; num=0; max=size; }
  ~m_graph_queue() { delete[] entries; }

  void add( m_polygon * x ) { if( num >= max ) return; entries[start]=x; start = ++start % max; num++; }
  m_polygon * get() { if (num==0) return (m_polygon *)0; end %= max; num--; return entries[ end++ ]; }

  int isEmpty() { return num==0; }

};

//
//  adjNode
//
//  A node for the adjacency list (used to store the graph)
//

struct adjNode
{
  adjNode * next;		// linked-list-like structure
  m_polygon * data;		// polygon number
  vector origin;		// intermediate waypoint between the polys	
  
  adjNode( m_polygon * x, vector & o ) { data=x; origin=o; next=0; }
  adjNode( m_polygon * x, vector & o, adjNode * n ) { data=x; next=n; origin=o; }
};


//
//  bspGraph
//
//  loading and saving of directed graphs. Also BSPlevel interface.
//


class bspGraph
{
private:

  BSPlevel * map;			// the .BSP file

  vector position;			// bot's current position
  vector oldPosition;		// last timestamp's position (i.e. where the
							// bot was 0.1 seconds ago, unless a packet was
							// dropped)

  m_polygon * m_pOldPolygon;// previous floor polygon
  m_polygon * m_pPolygon;	// pointer to current floor polygon

  m_BSPnode * currentNode;	// actually pointer to current leaf
  m_BSPnode * oldNode;		// former leaf
  int dead;					// if 1, the player just died

  char gfname[Q_MAX_STRING];// name of graph-link file

				//
				//  directed graph things
				//

  int listSize;
  adjNode ** adjList;		// vector of pointers to linked lists
  g_table * t;				// for shortest path
  int totalLinks;
  
  void updateTable( m_polygon * );
  void eraseGraph();
  void preprocessGraph();

				//
				//  some additional fun-filled methods
				//
  
  m_BSPnode * findLeaf( vector );

public:
  bspGraph() { currentNode=oldNode=0;map=0;listSize=0; adjList=0; t=0; gfname[0]=0; dead=0; m_pPolygon=m_pOldPolygon=0; }
  ~bspGraph() { save(); delete map; eraseGraph(); }

  int save();
  int load();
  void updatePosition( vector );
  void died() { dead=1; }
	
				//
				//  to do with leaves
				//

  m_BSPnode::type_t getCurrentLeafType();
  m_BSPnode::type_t getLeafType( vector );
  vector getLeafOrigin( int );

				//
				//  some BSP tracing functions
				//
  
  int isShotBlocked( vector, vector * h=0 );
  int isLineBlocked( vector start, vector end, vector * hp=0 );
  int isLineBlockedFluid( vector start, vector end, vector * hp=0, int water=FALSE );
  int modelBlocksLine( vector, vector, int ); 
  
  int isLoaded() { return (map!=0); }

				//
				//  directed graph interface.
				//

  int findPath( m_polygon *, m_polygon *, m_stack< vector > & );
  int addLink( m_polygon *, m_polygon *, vector );
  int removeLink( m_polygon *, m_polygon * );
  int isLink( m_polygon *, m_polygon * );
  vector linkOrigin( m_polygon *, m_polygon * );
  int numLinks( int );

  int pathToPoint( vector, m_stack< vector > & );

				//
				//  misc.
				//

  int newMap( char * fname, int noGraph=0 );

  int validFloorPolygon() { return m_pPolygon != (m_polygon *)0; }
  int floorPolygonNumber() { if ( m_pPolygon ) return m_pPolygon->number(); return -1; }
  vector floorPolygonCenter() { vector x; if( m_pPolygon ) x = m_pPolygon->center(); return x; }
  
};

#endif
  

