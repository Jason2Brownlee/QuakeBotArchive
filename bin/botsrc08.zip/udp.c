/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"
#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "data.h"
#include "udp.h"

#if (SYS_UNIX)&&(SYS_AIX)           /*AIX, a flavor of Unix*/
#include <sys/select.h> /*Select*/
#endif


#if ISWINSOCK           /*WINSOCK*/
#include <winsock.h>
#elif (SYS_UNIX)        /*Unix*/
#include <sys/types.h>
#include <netinet/in.h> /*Internet*/
#include <sys/ioctl.h>  /*set options*/
#include <sys/socket.h> /*Socket*/
#include <sys/time.h>
#include <arpa/inet.h>  /*Internet*/
#include <netdb.h>
#include <sys/wait.h>
#include <unistd.h>
#else /* Not Winsock, not Unix */
#error "No known support for sockets under this system"
#endif


#define DEBUG 0


#define CODEMODULE 'u'

#if ISWINSOCK
#include <conio.h> /* kbhit() */
/*Under winsock, SOCKET,INVALID_SOCKET,SOCKET_ERROR are already defined*/
#else
typedef int SOCKET;
#define INVALID_SOCKET  (SOCKET)(~0)
#define SOCKET_ERROR            (-1)
#endif
/*
** Winsock REQUIRES that we call some init/cleanup functions
** Before begining to work.
*/
#if ISWINSOCK
#define LOWERVERSION  1
#define HIGHERVERSION 1
static WSAwasInitialised = FALSE;
static WSADATA WsaData;
void ClientWSAStartup(void)
{
  Int16 wVersionRequested = (LOWERVERSION<<8)|HIGHERVERSION;
  /* Init only once*/
  if(WSAwasInitialised!=FALSE)
  { return; }

  if(WSAStartup (wVersionRequested, &WsaData)!=0)
  {
    ERRwarn("Init failed for WINSOCK.DLL");
    exit(-1);
  }
  printf("Winsock: %s\n", WsaData.szDescription);
  /* check comaptibility */
  if( (LOBYTE( WsaData.wVersion ) != HIGHERVERSION)
      ||(HIBYTE( WsaData.wVersion ) != LOWERVERSION))
  {
    ERRwarn("Invalid WINSOCK.DLL version: %04x", (Int)WsaData.wVersion);
    WSACleanup( );
    exit(-1);
  }
  if(WsaData.iMaxUdpDg<0x440)
  {
    ERRwarn("UDP packet size: %d (too small)", (Int)WsaData.iMaxUdpDg);
    WSACleanup( );
    exit(-1);
  }
  WSAwasInitialised = TRUE;
  return;
}
void ClientWSACleanup(void)
{
  WSACleanup();
  return;
}
#endif /*ISWINSOCK*/


/*
** SADR encapsulates sockaddr_in
*/
typedef struct sockaddr SADR;
typedef SADR PTR *pSADR;
typedef struct sockaddr_in SADR_IN;
typedef SADR_IN PTR *pSADR_IN;
/*
struct sockaddr_in {
  short   sin_family;
  u_short sin_port;
  struct  in_addr sin_addr;
  char    sin_zero[8];
};
*/

/*
** SadrSetPort(&Sadr, Port)
**  Set Port number in SADR_IN
*/
static void SadrSetPort(pSADR_IN pSadr, Int32 Port)
{
  pSadr->sin_port = htons((u_short)(Port&0xFFFFL));
}
/*
** SadrGetPort(&Sadr)
**  Get Port number in SADR_IN
*/
static Int32 SadrGetPort(pSADR_IN pSadr)
{
  if(pSadr->sin_family != AF_INET) return -1;
  return (htons(pSadr->sin_port)&0xFFFFL);
}
/*
** SadrCmp(&Sadr, &Sadr2)
**  Compare, return TRUE if the two addresses are equal
*/
#if 0 /*CODE DISABLED: SERVER ACCEPTS ANY HOST NOW*/
static Bool SadrAllowed(pSADR_IN pSadr,pSADR_IN pSadr2)
{
  if(pSadr->sin_family != AF_INET)
  { return FALSE; }
  if(pSadr->sin_addr.s_addr!= pSadr2->sin_addr.s_addr)
  { return FALSE; }
#if 0 /*Allow changes in the port number*/
  if(pSadr->sin_port != pSadr2->sin_port)
  { return FALSE; }
#endif
  return TRUE;
}
#endif
/*
** Copy one address into another
*/
static void SadrCpy(pSADR_IN pSadr,pSADR_IN pSadr2)
{
  pSadr->sin_family= AF_INET;
  pSadr->sin_addr.s_addr= pSadr2->sin_addr.s_addr;
  pSadr->sin_port = pSadr2->sin_port;
}
/*
** Parse an address
**   modify pPort if contains a port
**   modify pIp if can translate to IP address
**  return <0 if error, 0 if "NONE", >0 if valid Ip
*/
static Int32 SadrParse(pInt32 pIp, pInt32 pPort, pInt8 Adrs)
{
  static Int8 AdrsIp[64];
  struct hostent *host;
  Int32 len, split;
  Int32 ip, port;
  len = Strlen(Adrs, sizeof(AdrsIp)-1);
  split= Strfind(Adrs,":", len);
  if((split<0)||(split+1>=len))
  { split = len; }
  else /*set port */
  {
    port =  Strval(&Adrs[split+1]);
    if((port!=0)&&(pPort!=NULL)) /*if valid port*/
    { *pPort=port; }
  }
  /* Copy Ip address */
  if(pIp==NULL)
  { return 0; }
  Strncpy(AdrsIp,Adrs,min(split, sizeof(AdrsIp)-1));
#if DEBUG
  printf("Address: %s\n", AdrsIp);
#endif
  switch(AdrsIp[0])
  {
    case 'N': case 'n':
      /*no address*/
      if(Strncmpi(AdrsIp,"NONE",4)>0)
      { *pIp= 0; return 0; } /*None*/
      break;
    case 'A': case 'a':
      /*Any address*/
      if(Strncmpi(AdrsIp,"ANY",3)>0)
      { *pIp = htonl(INADDR_ANY); return 1; }
      break;
    case 'B': case 'b':
      if(Strncmpi(AdrsIp,"BROAD",5)>0) /*Broadcast*/
      { *pIp = htonl(INADDR_BROADCAST); return 1; }
      break;
    case 'L': case 'l':
      if(Strncmpi(AdrsIp,"LOCAL",5)>0)
      { /*let AdrsIp be the name of the local host*/
        gethostname (AdrsIp,sizeof(AdrsIp)-1);
      }
      break;
  }
  ip = inet_addr(AdrsIp);
  if (ip == (~0L)) /*invalid ip address*/
  { /* Try to see if Adrs is not the name of a known machine*/
    host = gethostbyname (AdrsIp);
    if((host == NULL)||(host->h_addrtype!=PF_INET)||(host->h_length!=4))
    {
      ERRwarn("Invalid IP Address %s",AdrsIp);
      return -1;
    }
    Memcpy(&ip, host->h_addr_list[0], sizeof(ip));
  }
  if (ip == (~0L))
  {
    ERRwarn("Invalid IP Address %s",AdrsIp);
    return -1;
  }
  *pIp = ip;
  return 1;
}
/*
** SadrInit(&Sadr, Adrs, Port)
**   Sadr = SADR_IN
**   Adrs = address:port  
**        = "1.2.3.4" or "smurf.land.com"   (no port)
**        = "smurf.land.com:26000"          (port is 26000)
**        = "LOCAL" for local host
**        = "ANY" for any host
**        = "BROAD" for broadcast
**   Port = specific value>0, or 0 for any suitable port.
**          if a port is defined in the address, this parameter is ignored
**  Initialise a SADR_IN.
**  return <0 if error, 0 if No address, >0 if ok
*/
static Int32 SadrInit(pSADR_IN pSadr, pInt8 Adrs, Int32 Port)
{
  Int32 res, ip;   /*ip address, as long*/
  /*Protocol = IP*/
  Memset(pSadr, 0, sizeof (SADR_IN));
  pSadr->sin_family = AF_INET;
  /*parse address*/
  res = SadrParse(&ip, &Port, Adrs);
  if(res<0)
  { return -1; }
  pSadr->sin_addr.s_addr=ip;
  SadrSetPort(pSadr, Port);
  return res;
}

static Int32 SadrSprint(pSADR_IN pSadr, pInt8 String, Int32 StringSz)
{
  Int32 Port;
  pUInt8 b;
  if(StringSz<0x18) return -1;
  Port = (ntohs(pSadr->sin_port)&0xFFFFL);
  /* Note: for portability reason, sun_addr.S_un cannot be used*/
  b = (pUInt8) &(pSadr->sin_addr);
  sprintf(String,"%d.%d.%d.%d:%d", b[0],b[1],b[2],b[3],Port);
  return 1;
}
/*
**
** Hidden client stucture
**
*/
typedef struct
{
  /*
  ** Opaque Data, made available
  */
  SOCKET Sock;	/*file descriptor*/
  SADR_IN Peer;	/*Peer Address*/
  Int32  ServerPort; /*Port of the Peer server*/
} CLI2;
typedef CLI2 PTR *pCLI2;
#if SYS_CPPSIZEOF
#if (sizeof(CLI2)>sizeof(CLIENT))
#error Size of CLIENT is too small. Make it bigger than CLI2.
#endif
#endif
/*
** Client connect
*/
static ClientConnect(pCLI2 pCli2)
{
  /* Connect to peer UDP socket, returns 0 on success */
  return (connect(pCli2->Sock, (pSADR)&(pCli2->Peer), sizeof(pCli2->Peer))==0)? 1:-1;
}
/*
** ClientInit(&Client, Adrs, Port)
**   Client = CLIENT
**   Adrs = Server Address "192.41.10.23" or "ftp.hell.gov" or "local"
**   Port = Server port.
**  Create a client, and connect it to the given address and port
*/
Int32 ClientInit(pCLIENT pClient, pInt8 Adrs, Int32 Port)
{
  pCLI2 pCli2 = (pCLI2)pClient;
#if ISWINSOCK
  /* Check if Winsock was really initialised */
  if(WSAwasInitialised != TRUE)
    return ERRfault(ERR_BUG); /* Please Call ClientWSAinit()*/
#endif
  /* Check if opaque and normal versions of CLIENT really match*/
#if !(SYS_CPPSIZEOF)
  if(sizeof(CLI2)>sizeof(CLIENT))
    return ERRfault(ERR_BUG); /*CLIENT size is too small*/
#endif
  if(pCli2==NULL) return -1;
  /* Create UDP socket, returns -1 if error*/
  pCli2->Sock = socket (AF_INET, SOCK_DGRAM, 0);
  if(pCli2->Sock == INVALID_SOCKET)
  { return ERRfault(ERR_BUG);}
  pCli2->ServerPort = 0; /* no server port */
  return ClientSetPeer((pCLIENT)pCli2, Adrs, Port);
}
/*
** Set client's peer
*/
Int32 ClientSetPeer(pCLIENT pClient, pInt8 Adrs, Int32 Port)
{
  pCLI2 pCli2 = (pCLI2)pClient;
  if(pCli2->Sock== INVALID_SOCKET)
  { return -1;}
  /* Try to build peer address*/
  if(SadrInit(&(pCli2->Peer), Adrs, Port)<0) 
  { return -1; }
  /* Connect to peer UDP socket*/
  if(ClientConnect(pCli2)<0)
  { return ERRfault(ERR_BUG);}
#if DEBUG
  if(SadrSprint(&(pCli2->Peer), Buff, sizeof(Buff))>0)
  { printf("Client connected to %s\n",Buff); }
#endif
  /* preserve the server port */
  pCli2->ServerPort = SadrGetPort(&(pCli2->Peer));
  return 1;
}
/*
** ClientFree(&Client)
**  Close a client
*/
Int32 ClientFree(pCLIENT pClient)
{
  pCLI2 pCli2 = (pCLI2)pClient;
  if(pCli2==NULL) return -1;
#if ISWINSOCK
  /* With winsock, use closesocket(), not close() */
  if(pCli2->Sock!=INVALID_SOCKET) closesocket(pCli2->Sock);
#else
  if(pCli2->Sock!=INVALID_SOCKET) close(pCli2->Sock);
#endif
  /**/
  pCli2->Sock=INVALID_SOCKET;
  return 1;
}
/*
**  Change Peer port
*/
Int32 ClientSetPeerPort(pCLIENT pClient, Int32 Port)
{
  pCLI2 pCli2 = (pCLI2)pClient;
  if((pCli2==NULL)||(pCli2->Sock==INVALID_SOCKET)) return -1;
  /* Change port*/
  SadrSetPort(&(pCli2->Peer), Port);
  /* Reconnect  (allowed, with UDP sockets) */
  return ClientConnect(pCli2);
}
/*
** Restore the original peer port (server port)
*/
Int32 ClientReInit(pCLIENT pClient)
{
  pCLI2 pCli2 = (pCLI2)pClient;
  if((pCli2==NULL)||(pCli2->Sock==INVALID_SOCKET)) return -1;
  /* Check if port is valid */
  if(pCli2->ServerPort==0) return 0;
  /* Change port*/
  SadrSetPort(&(pCli2->Peer), pCli2->ServerPort);
  /* Reconnect  (allowed, with UDP sockets) */
  return ClientConnect(pCli2);
}
/*
** ClientGetPort(pCLIENT pCLient)
**  Get the local port number of a client
**
** BUG: it gives the file descriptor, not the port!
*/
Int32 ClientGetPort(pCLIENT pClient)
{
  pCLI2 pCli2 = (pCLI2)pClient;
  SADR_IN tmp;   /*to store the local socket address*/
  Int32 tmpsz= sizeof(SADR_IN);
  if((pCli2==NULL)||(pCli2->Sock==INVALID_SOCKET)) return -1;
  if(getsockname (pCli2->Sock, (pSADR) &tmp, (pInt)&tmpsz)<0) /*0 on success*/
  { return -1; }
  return SadrGetPort(&tmp); /*Get port of Tmp*/
} 
/*
** ClientSend(&Client, Data);
**  Send Data to the Client's peer
**  Data must be initialised and filled with the message
*/
Int32 ClientSend(pCLIENT pClient, pDTA pDta)
{
  pCLI2 pCli2 = (pCLI2)pClient;
  /* Check that data storage is valid*/
  Int32 sz= DtaSize(pDta);
  if(sz<=0) return -1;
  /* Send data to peer, no special flags needed*/
  DtaRewind(pDta); /*Ensure read pointer is at 0*/
  return (send(pCli2->Sock, DtaData(pDta), sz, 0)<sz)? -1: 1;
}
/*
** ClientRecv(&Client, Data);
**  Receive data from the client
**  Data must be an initialised, but filled with nothing
*/
Int32 ClientRecv(pCLIENT pClient, pDTA pDta)
{
  pCLI2 pCli2 = (pCLI2)pClient;
  Int32 sz= DtaMaxSize(pDta);
  /* Check that data storage is valid*/
  if(sz<0) return -1;
  /* Receive data from peer, no special flags needed*/
  DtaClear(pDta); /*restart from scratch*/
  sz= recv(pCli2->Sock,  DtaData(pDta), sz, 0);
  if(sz<0) return -1;
  /* Set actual size of data storage */
  DtaSetSize(pDta,sz);
#if DEBUG
  printf("Client received: %ld bytes.\n",(long)sz);
#endif
  return 1;
}
/*
** Print Client's Peer address in a string
*/
Int32 ClientPeerAdrsPrint(pCLIENT pClient, pInt8 String, Int32 StringSz)
{
  pCLI2 pCli2 = (pCLI2)pClient;
  return SadrSprint(&(pCli2->Peer), String, StringSz);
}
/****************************************************\
*
*  Udp Server
*
\****************************************************/

/*
**
** Hidden server stucture
**
*/
typedef struct
{
  /*
  ** Opaque Data, made available
  */
  SOCKET  Sock;	/*file descriptor*/
  SADR_IN Local; /*Server local address*/
  SADR_IN Peer;	/*Last Peer Address*/
  Bool    HasPeer; /*Found a peer, and locked on it*/
} SRV2;
typedef SRV2 PTR *pSRV2;

#if SYS_CPPSIZEOF
#if (sizeof(SRV2)>sizeof(SERVER))
#error Size of SERVER is too small. Make it bigger than SRV2.
#endif
#endif
/*
** ServerInit(&Server, Port)
**   Port = Server port.
**  Create a server, on the given port
*/
Int32 ServerInit(pSERVER pServer, Int32 Port)
{
  pSRV2 pSrv2 = (pSRV2)pServer;
#if ISWINSOCK
  /* Check if Winsock was really initialised */
  if(WSAwasInitialised != TRUE)
    return ERRfault(ERR_BUG); /* Please Call ClientWSAinit()*/
#endif
  /* Check if opaque and normal versions of SERVER really match*/
#if !(SYS_CPPSIZEOF)
  if(sizeof(SRV2)>sizeof(SERVER))
    return ERRfault(ERR_BUG); /*SERVER size is too small*/
#endif
  if(pSrv2==NULL) return -1;
  /**/
  pSrv2->HasPeer=FALSE; /*no peer*/
  pSrv2->Sock=INVALID_SOCKET;
  /* Try to build local address*/
  if(SadrInit(&(pSrv2->Local), "LOCAL", Port)<0)
  { return -1;}
  /* Clear the peer address */
  if(SadrInit(&(pSrv2->Peer), "NONE", 0)<0)
  { return -1;}
  /* Create UDP socket, returns -1 if error*/
  pSrv2->Sock = socket (AF_INET, SOCK_DGRAM, 0);
  if(pSrv2->Sock == INVALID_SOCKET)
  { return -1;}
  /* Bind to local UDP socket*/
  if( bind(pSrv2->Sock, (pSADR)(&pSrv2->Local), sizeof(pSrv2->Local)) <0)
  { ServerFree(pServer); return -1;}
#if DEBUG
  printf("Server bound to port %ld\n", (long)Port);
#endif
  return 1;
}
/*
** ServerFree(&Server)
**  Close a server
*/
Int32 ServerFree(pSERVER pServer)
{
  pSRV2 pSrv2 = (pSRV2)pServer;
  if(pSrv2==NULL) return -1;
#if ISWINSOCK
  /* With winsock, use closesocket(), not close() */
  if(pSrv2->Sock!=INVALID_SOCKET) closesocket(pSrv2->Sock);
#else
  if(pSrv2->Sock!=INVALID_SOCKET) close(pSrv2->Sock);
#endif
  /**/
  pSrv2->HasPeer=FALSE;
  pSrv2->Sock=INVALID_SOCKET;
  return 1;
}
/*
** Print Server's Local  address in a string
*/
Int32 ServerAdrsPrint(pSERVER pServer,pInt8 String, Int32 StringSz)
{
  pSRV2 pSrv2 = (pSRV2)pServer;
  return SadrSprint(&(pSrv2->Local), String, StringSz);
}
/*
** ClientCopyPeer(&Server, pSADR_IN pSadr)
**  Copy to pSadr the last peer address of a server
*/
Int32 ClientCopyPeer(pCLIENT pClient, pSERVER pServer)
{
  pSRV2 pSrv2 = (pSRV2)pServer;
  pCLI2 pCli2 = (pCLI2)pClient; /*World*/
  if((pSrv2==NULL)||(pSrv2->Sock==INVALID_SOCKET)) return -1;
  if(pCli2==NULL) return -1;
  /*
  ** Check if there is a last peer
  */
  if(pSrv2->HasPeer!=TRUE)
  { return -1; }
  /* Copy address or server's peer */
  SadrCpy(&(pCli2->Peer), &(pSrv2->Peer));
  /* Connect to this peer */
  return ClientConnect(pCli2);
}
/*
** ServerSend(&Server, Data);
**  Send Data to the Server's last peer
**  Data must be initialised and filled with the message
*/
Int32 ServerSend(pSERVER pServer, pDTA pDta)
{
  pSRV2 pSrv2 = (pSRV2)pServer;
  /* Check that data storage is valid*/
  Int32 sz= DtaSize(pDta);
  Int32 res;
  if(sz<=0) return -1;
  if(pSrv2->HasPeer!=TRUE)
  { return -1; }
  /* Send data to peer, no special flags needed*/
  DtaRewind(pDta); /*Ensure read pointer is at 0*/
  res = sendto(pSrv2->Sock, DtaData(pDta), sz, 0, (pSADR)&(pSrv2->Peer), sizeof(pSrv2->Peer));
  return ((res<sz)? -1: 1);
}
/*
** ServerRecv(&Server, Data);
**  Receive data from the server's peer
**  Data must be an initialised, but filled with nothing
*/
Int32 ServerRecv(pSERVER pServer, pDTA pDta)
{
  pSRV2 pSrv2 = (pSRV2)pServer;
  Int32 sz= DtaMaxSize(pDta);
  SADR_IN tmpPeer;
  Int tmpPeerSz = sizeof(tmpPeer);
  /* Check that data storage is valid*/
  if(sz<0) return -1;
  /* Receive data from peer, no special flags needed*/
  DtaClear(pDta); /*restart from scratch*/
  sz= recvfrom(pSrv2->Sock,  DtaData(pDta), sz, 0,(pSADR)(&tmpPeer),&tmpPeerSz);
  if(sz<0) return -1;
#if 0
  /*
  ** WARNING: POSSIBLE BUG
  ** The Server remembers ONLY THE LAST PEER WHO TALK.
  ** So if two machines talk to the server, the server will be
  ** totally confused, and could mixup messages.
  */

  /*
  ** If already has a peer, check that new peer is acceptable
  */
  if((pSrv2->HasPeer==TRUE)&&(SadrAllowed(&(pSrv2->Peer), &tmpPeer)!=TRUE))
  {
#if DEBUG
    printf("Server rejected: %ld bytes (bad peer).\n",(long)sz);
#endif
    return -1;
  }
#endif
  /* Peer is valid*/
  SadrCpy(&(pSrv2->Peer), &tmpPeer);
  pSrv2->HasPeer=TRUE;
  /* Set actual size of data storage */
  DtaSetSize(pDta,sz);
#if DEBUG
  printf("Server received: %ld bytes.\n", (long)sz);
#endif
  return 1;
}


/****************************************************\
*
*  Call Back Functions
*
\****************************************************/

void CbSet(pMESSAGECB pCb, Int32(*Function) (pVoid Context, pDTA Dta), pVoid Context)
{ /* Context can be NULL */
  pCb->Function=Function;
  pCb->Context=Context;
}
static Int32 CbCall(pMESSAGECB pCb, pDTA Dta)
{ /* Dta can be NULL */
  if(pCb->Function==NULL)
  { return 0; }
  return (pCb->Function)(pCb->Context, Dta);
}
/****************************************************\
*
*  Dispatcher
*
\****************************************************/

static Int32 DispatchClear(pDISPATCH pDisp)
{
  pDisp->StdinFd=0; /*file descriptor to wait on*/
  pDisp->IddleTime=100; /*Time out, 100th of second*/
  /* Clear every callback, as a security */
  CbSet(&(pDisp->IddleCb),NULL,NULL);
  CbSet(&(pDisp->StdinCb),NULL,NULL);
  CbSet(&(pDisp->ClientCb),NULL,NULL);
  CbSet(&(pDisp->ServerCb),NULL,NULL);
  CbSet(&(pDisp->WorldCb),NULL,NULL);
  return 1;
}
/*
** DISPATCH Disp;
** DispatchInit(&Disp)
*/

Int32 DispatchInit(pDISPATCH pDisp, pInt8 ServerHost, Int32 ServerPort, Int32 MyPort)
{
  if(pDisp==NULL)
  { return -1; }
  /* Init client */
  if(ClientInit(&(pDisp->Client), ServerHost, ServerPort)<0)
  { return -1;}
  /* Init server */
  if(ServerInit(&(pDisp->Server), MyPort )<0)
  { return -1;}
  /* Init world, with no known peer */
  if(ClientInit(&(pDisp->World), "NONE", 0)<0)
  { return -1;}
  return DispatchClear(pDisp);
}
/*
** DispatchFree(&Disp)
*/
Int32 DispatchFree(pDISPATCH pDisp)
{
  if(pDisp==NULL)
  { return -1; }
  /* Init client */
  ClientFree(&(pDisp->Client));
  /* Init server */
  ServerFree(&(pDisp->Server));
  /* Init world */
  ClientFree(&(pDisp->World));
  return DispatchClear(pDisp);
}

/*
** DispatchRun(&Disp)
*/
Int32 DispatchRun(pDISPATCH pDisp)
{
  fd_set inputs;	/*file descriptor array, for input sockets*/
  Int32 fdmax;		/*Max id of file descriptors*/
  Int32 res;              /*Result*/
  DTA TmpDta;
  DTA StdinDta;
  struct timeval tmout,tmout2;
#if ISWINSOCK
  Int key;
#endif
  /*
  ** Init temporary data storage
  */
  if(DtaInit(&TmpDta, 0x4000)<0) return -1;
  if(DtaInit(&StdinDta,0x200)<0) return -1;
  /*
  ** init timeout
  */
  tmout2.tv_usec=(pDisp->IddleTime % 100)*10000;  /*microsoeconds, even on a PC*/
  tmout2.tv_sec =pDisp->IddleTime / 100;
  /*
  ** Init file descriptors
  */
  pDisp->ClientFd = ((pCLI2)&(pDisp->Client))->Sock;
  pDisp->ServerFd = ((pSRV2)&(pDisp->Server))->Sock;
  pDisp->WorldFd  = ((pCLI2)&(pDisp->World))->Sock;
  /* Calculate max, among all file descriptors*/
#if ISWINSOCK
  /*Winsock doesn't support Stdin as a valid fd for select*/
  fdmax = 0;
#else
  fdmax = pDisp->StdinFd;
#endif
  fdmax = max(fdmax, pDisp->ClientFd);
  fdmax = max(fdmax, pDisp->ServerFd);
  fdmax = max(fdmax, pDisp->WorldFd);
  /* Loop until exit*/
  while(1)
  {
    /*
    ** Reset timeval
    */
    Memcpy(&tmout, &tmout2, sizeof(tmout2));
    /*
    ** Clear file descriptor array
    */
    FD_ZERO (&inputs);
    /*
    ** Set file descriptors that need to be listened to
    */
#if ISWINSOCK
    /*Winsock doesn't support Stdin as a valid fd for select*/
#else
    FD_SET (pDisp->StdinFd,&inputs);
#endif  /*ISWINSOCK*/
    if(pDisp->ClientFd!=INVALID_SOCKET)
    { FD_SET ((Int)(pDisp->ClientFd), &inputs);}
    if(pDisp->ServerFd!=INVALID_SOCKET)
    { FD_SET ((Int)(pDisp->ServerFd), &inputs);}
    if(pDisp->WorldFd!=INVALID_SOCKET)
    { FD_SET ((Int)(pDisp->WorldFd), &inputs);}
    /*
    ** Wait until one of the sockets receives data
    */
    res= select((Int)(1+fdmax), &inputs, NULL, NULL, &tmout);
    /*
    ** Check if an error happened
    */
    if(res<0)
    {
      printf("Socket error: %ld\n", (long)(-res));
#if ISWINSOCK
      printf("WsaError %d\n", (int)WSAGetLastError());
#endif /*ISWINSOCK*/
      break;
    }
    /*
    ** Check if time out
    */
    if(res==0)
    {
#if DEBUG
      printf("Iddle...\n");
#endif
      res = CbCall(&(pDisp->IddleCb), NULL);
      if(res<0) break;
    }
    /*
    ** Check if Message from Client's peer
    */
    if (FD_ISSET (pDisp->ClientFd, &inputs))
    {
#if DEBUG
      printf("Client's Peer talking.\n");
#endif
      /* Get data from peer*/
      res=ClientRecv(&(pDisp->Client),&TmpDta);
      if(res>=0)
      { /* Process data, by calling PeerCb*/
        res = CbCall(&(pDisp->ClientCb), &TmpDta);
        /* Exit if result <0 */
        if(res<0)
        {
#if DEBUG
          printf("Client CB reports an error: exiting.\n");
#endif
          break;
        }
        /* Warning: &TmpDta may have been modified*/
      }
    }
    /*
    ** Check if Message from Server's peer
    */
    if (FD_ISSET (pDisp->ServerFd, &inputs))
    {
#if DEBUG
      printf("Server received a message.\n");
#endif
      /* Get data from peer*/
      res=ServerRecv(&(pDisp->Server),&TmpDta);
      if(res>=0)
      { /* Process data, by calling PeerCb*/
        res = CbCall(&(pDisp->ServerCb), &TmpDta);
        /* Exit if result <0 */
        if(res<0)
        {
#if DEBUG
          printf("Server CB reports an error: exiting.\n");
#endif
          break;
        }
        /* Warning: &Dta may have been modified*/
      }
    }
    /*
    ** Check if Message from World's peer
    */
    if (FD_ISSET (pDisp->WorldFd, &inputs))
    {
#if DEBUG
      printf("World's Peer talking.\n");
#endif
      /* Get data from peer*/
      res=ClientRecv(&(pDisp->World),&TmpDta);
      if(res>=0)
      { /* Process data, by calling WorldCb*/
        res = CbCall(&(pDisp->WorldCb), &TmpDta);
        /* Exit if result <0 */
        if(res<0)
        {
#if DEBUG
          printf("World CB reports an error: exiting.\n");
#endif
          break;
        }
        /* Warning: &Dta may have been modified*/
      }
    }
    /*
    ** message from stdin
    */
#if ISWINSOCK
    /* Winsock doesn't support Stdin as a valid fd for select*/
    if(kbhit()!=0) /*detect if a key was pressed*/
    {
      /* Get key, echo to console */
      key = getche();
      /* Transform ESC, INVALID, RETURN into '\n' */
      switch(key)     /**/
      { case '\0': case 13: case 27: key='\n'; break;}
      DtaPutInt8(&StdinDta, (Int8)key);
      if(key=='\n')
      {
#if DEBUG
        printf("Keyboard message.\n");
#endif
        DtaPutInt8(&StdinDta, '\0');
        res = CbCall(&(pDisp->StdinCb), &StdinDta);
        /* Exit if result <0 */
        if(res<0) break;
        /* restart StdinDta from scratch */
        DtaClear(&StdinDta);
      }
    }
#else  /* Winsock*/
    if (FD_ISSET(pDisp->StdinFd, &inputs))
    {
#if DEBUG
      printf("Keyboard message.\n");
#endif
      /* Read data from Stdin*/
      res = DtaRead(&StdinDta, pDisp->StdinFd);
      if(res>=0)
      { /* Process data, by calling StdinCb*/
        res = CbCall(&(pDisp->StdinCb), &StdinDta);
        /* Exit if result <0 */
        if(res<0) break;
        /* Warning: &StdinDta may have been modified*/
      }
    }
#endif    /*ISWINSOCK*/

  }
  /* End */
  DtaFree(&TmpDta);
  DtaFree(&StdinDta);
  return res;
}
