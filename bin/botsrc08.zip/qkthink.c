/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"  /*Always first to be included*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>     /*time()*/
#include <math.h>
#include "common.h"
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkent.h"    /*Entity and model lists*/
#include "qkbot.h"    /*Bot inteface*/
#include "qkmove.h"   /*Movements*/
#include "qkbsp.h"    /*BSP stuff*/
#include "qkthink.h"

#define DEBUG 1
/*
** 
*/
static Int32 THINKbaseTime=0;
static Int32 THINKboredom=0;
/*
** Function definitions
*/
static void THINKbanner(pBOT pBot);
 
/*
** Action callback
*/
void (*THINKcb)(pBOT pBot) = NULL;
/*
** Init
*/
void THINKinitCb(pBOT pBot)
{
  THINKbaseTime = (Float32)time(NULL);
  THINKcb =  THINKbanner;
  (void)pBot;
  return;
}
/*
** Free
*/
void THINKfreeCb(pBOT pBot)
{
  (void)pBot;
  return;
}
/*
** Prespawn. Called once, when models and sounds
** precaches have just been defined.
** BEWARE: DO NOT ATTEMPT ANY BOT ACTION (LIKE CONSOLE COMMANDS)
** HERE, IT WOULD KILL THE BOT STARTUP SEQUENCE.
*/
void THINKprespawnCb(pBOT pBot)
{
  THINKcb =  THINKbanner;
  /*should load level model*/
  (void)pBot;
  return;
}


/**************************************************************\
**
**   Bot wants a random move
**
\**************************************************************/
static Int32 RandMoveCount=0;
static VEC3  RandMoveCourse;
/*
** Initiate a move. Count >0 for sure move, <0 for suggested.
*/
static void THINKrandMoveInit(Int32 Count)
{
  if(Count<0)
  {
    if(RandMoveCount>0) { return; }
    else {Count= -Count;} /* accept*/
  }
  RandMoveCount= max(0,Count);
  VecSet(&RandMoveCourse, RandF(-10,10), RandF(-10,10), RandF(-10,10));
#if 0
  printf("Random move: %6.3f %6.3f %6.2f\n",
    (float)RandMoveCourse.X, (float)RandMoveCourse.Y, (float)RandMoveCourse.Z);
#endif
}
static Bool THINKrandMove(pVEC3 pCourse)
{
  if(RandMoveCount<=0) return FALSE;
  RandMoveCount--;
  VecCpy(pCourse, &RandMoveCourse);
  return TRUE;
}

/**************************************************************\
**
**   Weapon Handing
**
\**************************************************************/
/*
** Select Weapon based on distance to target.
** returns 0 if ok, otherwise, an impulse.
*/
Int16 ThinkWeapon(pBOT pBot, SCALAR Dist)
{
  /*ensure the bot is using his best weapon*/
  if((pBot->Cells>0)&&(pBot->Items&IT_LIGHTNING))
  {
    if(!(BSPpointInLeaf(NULL, &(pBot->Self->Origin))& AREA_INWATER))
    { return (Int16) ((pBot->Weapon & WEAPON_LIGHTNING)? 0:8); }
  }
  if(pBot->Rockets>0)
  {
    if((pBot->Items&IT_ROCKET_LAUNCHER)&&(Dist>200.0))
    { return (Int16) ((pBot->Weapon &WEAPON_ROCKET_LAUNCHER)? 0:7);}
    if((pBot->Items&IT_GRENADE_LAUNCHER)&&(Dist>100.0))
    { return (Int16) ((pBot->Weapon &WEAPON_GRENADE_LAUNCHER)? 0:6);}
  }
  if(pBot->Nails>0)
  {
    if(pBot->Items&IT_SUPER_NAILGUN)
    { return (Int16) ((pBot->Weapon &WEAPON_SUPER_NAILGUN)? 0:5);}
    if(pBot->Items&IT_NAILGUN)
    { return (Int16) ((pBot->Weapon &WEAPON_NAILGUN)? 0:4);}
  }
  if(pBot->Shells>0)
  {
    if(pBot->Items&IT_SUPER_SHOTGUN)
    { return (Int16) ((pBot->Weapon &WEAPON_SUPER_SHOTGUN)? 0:3);}
    if(pBot->Items&IT_SHOTGUN )
    { return (Int16) ((pBot->Weapon &WEAPON_SHOTGUN)? 0:2);}
  }
  return 1; /*the axe... shame.*/
}
/*
** Returns TRUE if bot can safely fire on target
** Actually, it should rather check what the bot is facing to!
*/
Bool THINKsafeFire(pBOT pBot, pVEC3 Target, pInt16 pImpulse)
{
  VEC3   Hit;
  SCALAR Dist;
  Int32 Typ;
  /* Yeah! some action at least! */
  THINKboredom =0;
  /* If dead, do not press the weapon trigger, otherwise the Bot never respawns */
  if(pBot->Health<=0) return FALSE;
  /* Trace a line */
  Typ = BSPtrace(&Hit, NULL, &Dist, &(pBot->Self->Origin), Target);
  /* Check weapon is suitable */
  if(pBot->Weapon & WEAPON_LIGHTNING)
  { /* Check if in water, or too far to use the lightning */
    if(BSPpointInLeaf(NULL,&(pBot->Self->Origin))& AREA_INWATER)
    { /* suggest a nailgun*/
      *pImpulse = (Int16)((pBot->Items&IT_SUPER_NAILGUN)? 5: (pBot->Items&IT_NAILGUN)? 4: 2);
      return FALSE;
    }
    if(Dist>600.0)
    { /* suggest a rocket launcher*/
      *pImpulse = (Int16)((pBot->Items&IT_ROCKET_LAUNCHER)? 7: 2);
      return FALSE;
    }
  }
  if(pBot->Weapon & (WEAPON_GRENADE_LAUNCHER|WEAPON_ROCKET_LAUNCHER))
  {  /* Check if too close*/
     if(Dist<400.0)
     { /* suggest a nailgun*/
       *pImpulse = (Int16)((pBot->Items&IT_SUPER_NAILGUN)? 5: (pBot->Items&IT_NAILGUN)? 4: 2);
       return FALSE;
     }
  }
  /* Check if the trace hit a wall */
  if(Typ & AREA_INWALL)
  { /* if trace hit wall, but with a rocket, and close enought to target, it's ok*/
    if((pBot->Weapon & WEAPON_ROCKET_LAUNCHER)&&(VecDiff(&Hit,Target)<200.0))
    { return TRUE; }
    /* refuse to fire if a wall is hit */
    return FALSE;
  }
  return TRUE;
}


/**************************************************************\
**
**   Bot is thinking (err.. that is... sort of)
**
\**************************************************************/
/*
** Banner printed first time
*/
static void THINKbanner2(pBOT pBot);
static void THINKbanner(pBOT pBot)
{
  printf("Map is: %.32s\n",pBot->MapName);
  printf("Bot is player: %d\n", (int)pBot->Me);
  BotLocalPrintf(pBot, HIGHLIGHT, "Cyberdyne System Model 1.01.\n");
  THINKcb = THINKbanner2;
  /* Declare bot to the server */
  if((pBot->Self!=NULL)&&(pBot->Self->pPlay!=NULL))
  { BotActionConsole(pBot, "echo Bot %s v%s is %32.32s", BOTNETNAME,BOTVERSION, &(pBot->Self->pPlay->Name[0]));}
  (void)pBot;
}
static void THINKbanner3(pBOT pBot);
static void THINKbanner2(pBOT pBot)
{
  BotLocalPrintf(pBot, HIGHLIGHT, "Mission profile: Termination.\n");
  THINKcb = THINKbanner3;
  (void)pBot;
}
static void THINKnewGoal(pBOT pBot);
static void THINKbanner3(pBOT pBot)
{
  BotLocalPrintf(pBot, HIGHLIGHT, "Scanning for targets.\n");
  THINKcb = THINKnewGoal;
  (void)pBot;
}
static void THINKnewGoal(pBOT pBot)
{
  Int16 Impulse;
  VEC3  Course,IdealSpeed;
  /*
  ** Get a new weapon
  */
  Impulse = ThinkWeapon(pBot, 10000.0);
  if(Impulse!=0)
  { BotActionMove(pBot, NULL, NULL, BOT_NONE,Impulse);}
  /*
  ** Should find a goal and move toward it
  ** But currently, just move randomly, when bored.
  */
  THINKboredom++;
  if(THINKboredom>20)
  {
    THINKrandMoveInit(4);
    THINKrandMove(&Course);
    MOVEalongCourse(&IdealSpeed, &(pBot->Self->Angles), &Course);
    BotActionMove(pBot,NULL,&IdealSpeed,0,0);
  }
}

/**************************************************************\
**
**   Bot Got an update
**
\**************************************************************/
static THINKupdates=0;
void THINKupdateCb(pBOT pBot)
{
  /* Slow updates */
  if(pBot->Self==NULL) { return;}
  THINKupdates++;
  if((THINKupdates&0x3)==0)
  { /* if dead, come back in game, else send update to stop firing */
    if(pBot->Health<=0)
    { BotActionMove(pBot, NULL, NULL, BOT_FIRE,0);}
  }
  if((THINKupdates&0xF)==0)
  { /* Think */
    (*THINKcb)(pBot);
  }
#if 0
  if((THINKupdates&0x3F)!=0) return;
  /*check if game time is derivating...*/
  printf("GameTime - RealTime: %8.2f\n", (float)BotGlobals.Time - (float)((Int32)time(NULL)-THINKbaseTime));
#endif
  return;
}
/**************************************************************\
**
**   Special
**
\**************************************************************/
/*
**  Tell if a player is dead
**  This is an ugly hack, only valid for the standard player model
**  it will not work if player.qc has been modified.
*/
Bool THINKisDead(pELIVING pEnt)
{
  if((pEnt==NULL)||(pEnt->pPlay==NULL))
  { return FALSE;}
  /*
  ** the values 1-40 and 103-255 appear to be live frames
  ** and others are death. from player.qc
  */
  if(pEnt->Frame==0)
  { return TRUE; }
  if((pEnt->Frame > 40)&&(pEnt->Frame< 103))
  { return TRUE;}
  return FALSE;
}


/**************************************************************\
**
**   Bot Sees some entities
**
\**************************************************************/
/* speed of rockets, in unities per second*/
#define ROCKETSPEED 1000.0
/* square of distance under which a player is dangerous */
#define DISTANCEFIGHT2 (1500.0*1500.0)
/* square of distance for locking aim on a player */
#define DISTANCELOCK2  (1500.0*1500.0)
/* Minimum level of hate to aim and fire*/
#define HATETRIGGER    (20)
#define HATEFIRE       1   /*1 = fire when aim player */
/*
** Give the range under which an entity is dangerous (approximately)
*/
SCALAR THINKdangerRange(pELIVING Ent)
{
  if(Ent==NULL) return 0.0;
  switch(Ent->ETyp & ETYPE_MASK)
  {
    case ETYPE_MISSILE: return 300.0;
    case ETYPE_GRENADE: return 200.0;
	 case ETYPE_SPIKE:   return 80.0;
    case ETYPE_LAVA:    return 70.0;
    case ETYPE_FOE:     return 100.0;
 }
 return 100.0;
}
/*
** Called each time some entities are seen
*/
void THINKsawEntitiesCb(pBOT pBot, ppELIVING List, Int32 ListSz)
{
  pELIVING Ent;
  Int32 i;
  /* desired movement */
  ANGLES IdealAngles;
  VEC3   IdealSpeed;
  /* look for closest player */
  pELIVING Ent0; SCALAR dist0;
  /* Course */
  VEC3   CourseTmp, Course;
  SCALAR range;
  /* bot action flags */
  Int16 Flags = BOT_NONE;
  Int16 Impulse= 0;
  Bool Turned=FALSE;  /* TRUE if bot turned */
  Bool Ok;
  /* TRUE if bot moved this round*/
  Bool Moved;
  /* TRUE if bot moved last time */
  static Bool PreviousMoved=FALSE;
  /*
  ** Default orientation angles
  */
  if(pBot->Self==NULL)
  { return;}
  AngCpy(&IdealAngles, &(pBot->Self->Angles));
  /*
  ** Check if random move under way
  */
  Moved = THINKrandMove(&Course);
  /*
  ** Calculate entity distances and speed
  */
  for(i=0; i<ListSz; i++)
  { MOVEprepare(List[(Int)i] , &(pBot->Self->Origin)); }
  /*
  ** Materialise future position of player
  */
  for( i=0; i<ListSz; i++)
  {
	 if( (Ent= List[(Int)i])==NULL) continue;
	 /* check that entity is a player */
	 if(Ent->pPlay==NULL) continue;
	 /* check that entity is not  dead*/
	 if(THINKisDead(Ent)==TRUE) continue;
	 /* dt = time when a ROCKET projectile will meet the player*/
	 MOVEguessPosition(&CourseTmp,  pBot->Time, Ent,
		 sqrt(Ent->DeltaNorm2)/ ROCKETSPEED); /*dt*/
	 /* materialise the forecast position */
	 BotLocalParticle(pBot, &(CourseTmp), NULL, BOT_PARTICLE_RED, 10);
  }
  /*
  ** Orient toward closest hated player, if sees one
  */
  Ent0=NULL; dist0=DISTANCELOCK2;
  for( i=0; i<ListSz; i++)
  {
	 if( (Ent= List[(Int)i])==NULL) continue;
	 /* check that entity is a player */
	 if(Ent->pPlay==NULL) continue;
	 /* check if really hated */
	 if(Ent->pPlay->Hate<HATETRIGGER) continue;
	 /* check that entity is not  dead*/
	 if(THINKisDead(Ent)==TRUE) continue;
	 /* check if distance is lower */
	 if(Ent->DeltaNorm2 < dist0)
	 { dist0= Ent->DeltaNorm2; Ent0=Ent; }
  }
  if((Ent0!=NULL)&&(Ent0->pPlay!=NULL))
  {
    BotLocalPrintf(pBot, CENTERED, "Aquire target: %s.\n",&(Ent0->pPlay->Name[0]));
    /* Angles oriented toward player0 */
    /* Ent->TmpVec = pBot->Self->Origin - Ent->Origin*/
    Turned = MOVEaimEntity(&IdealAngles, Ent0);
#if HATEFIRE
    /* Check if fire is safe, otherwise, suggest another weapon (impulse)*/
    if( THINKsafeFire(pBot, &(Ent0->Origin), &Impulse)==TRUE)
    { Flags |= BOT_FIRE; }
#endif
    /* If has no long range weapon, rush toward the player */
    if((Moved!=TRUE)&&(pBot->Weapon==WEAPON_NONE))
    { /* Course = Ent0->Origin - pBot->Self->Origin*/
      VecCpy(&Course,&(Ent0->Delta)); VecNeg(&Course);
      Moved=TRUE;
    }
  }
  /*
  ** If no random move under way, try to move cleverly
  */
  if(Moved!=TRUE)
  {
    VecSet(&Course,0,0,0); /*Prepare for move*/
    /*
    ** avoid line of sight of player, avoid range of missiles
    */
    for( i=0; i<ListSz; i++)
    {
      if( (Ent= List[(Int)i])==NULL) continue;
      /* dangerous? */
      if(!(Ent->ETyp & EFLAG_DANGER)) continue;
      /* if player, check that really hated */
      if((Ent->pPlay!=NULL)&&(Ent->pPlay->Hate<HATETRIGGER)) continue;
      /* close enough? */
      if( Ent->DeltaNorm2 > DISTANCEFIGHT2) continue;
      /* what is the range of under which there is a danger? */
      range = THINKdangerRange(Ent);
      switch(Ent->ETyp&ETYPE_MASK)
      {
         case ETYPE_FOE: /*avoid line of sight*/
#if 0  /*method 1: if in fire cone, flee from hit point (pretty stupid)*/
           Ok = MoveAvoid1(&CourseTmp, Ent); break;
#else  /*method 2: best course to evade the fire cone */
           Ok = MOVEavoid2(&CourseTmp, Ent); break;
#endif
         default:
           /* flee from a sphere of size range, centered on hit point */
           Ok = MOVEavoid(&CourseTmp, Ent, range); break;
      }
      if(Ok==TRUE)
      { /* sum*/
        Moved = TRUE;
        VecAdd(&Course, &CourseTmp);
      }
#if 0   /*debug info*/
      if(Ok==TRUE)
        switch(Ent->ETyp&ETYPE_MASK)
        {
          case ETYPE_MISSILE:
            printf("Evading Missile!\n"); break;
          case ETYPE_GRENADE:
            printf("Evading Grenade!\n"); break;
          case ETYPE_SPIKE:
            printf("Evading Spike!\n"); break;
          case ETYPE_LAVA:
            printf("Evading Lava ball!\n"); break;
          case ETYPE_FOE:
            printf("Evading Line of fire!\n"); break;
          default:
            printf("Danger type: 0x%04x\n",(int)(Ent->ETyp&ETYPE_MASK));break;
        }
#endif
    }
  }
#if 1 /* THIS CODE  CAN CAUSE A LOT OF TROUBLES */
  if(Moved!=TRUE)
  {
    /*
    ** Seek for back packs, if no better move is proposed.
    */
    for( i=0; i<ListSz; i++)
    {
      if( (Ent= List[(Int)i])==NULL) continue;
      /* goodie? */
      if(!(Ent->ETyp & EFLAG_GOODIE))
      { continue; }
      /* only back pack */
      if((Ent->ETyp & ETYPE_MASK) != ETYPE_AMMO_PACK)
      { continue; }
      /* run toward goodie */
      /* Course = Ent->Origin - pBot->Self->Origin*/
      VecCpy(&Course, &(Ent->Delta)); VecNeg(&Course);
      Moved=TRUE;
    }
    if(Moved==TRUE)
    { BotLocalPrintf(pBot, CENTERED, "Aquisition of supply.\n");}
  }
#endif
  /*
  ** Detect if the bot is locked in some corner
  ** in that case, do a random movement
  */
  if((Moved==TRUE)&&(PreviousMoved==TRUE))
  {
    range = pBot->Self->Time - pBot->Self->Time1;
    /* if bot position changed, but too little...*/
    if((range>0.0)&&(range< 1.0))
      if( VecDiff(&pBot->Self->Origin,&pBot->Self->Origin1 ) < 2.0)
      {
#if 0
        printf("Blocked! trying some random move...\n");
#endif
        THINKrandMoveInit(4);
        THINKrandMove(&Course);
      }
  }
  /*
  ** Move
  */
  if(Moved==TRUE)
  {
    /* Set speed according to course, without changing orientation angles */
    /* assume that, when moving, direction angles are changed instantaneously */
    MOVEalongCourse(&IdealSpeed, &IdealAngles, &Course);
  }
  /* Send action message, if needed */
  if((Flags!=BOT_NONE)||(Turned==TRUE)||(Moved==TRUE))
  {
    BotActionMove(pBot,
      (Turned==TRUE)? &IdealAngles: NULL, /*set angles if needed*/
      (Moved==TRUE)?  &IdealSpeed:  NULL, /*set speed if needed*/
      Flags, Impulse);
  }
  PreviousMoved = Moved;
}




/**************************************************************\
**
**   Bot Is Removed from the game
**
\**************************************************************/

void THINKendCb(pBOT pBot)
{
  printf("THINK: Bot was disconnected!\n");
#if 0  /* doesn't work */
  BotLocalPrintf(pBot, HIGHLIGHT, "Self destruction sequence.\n");
#endif
  (void)pBot;
  return;
}




/**************************************************************\
**
**   Bot Is Hurt
**
\**************************************************************/
static pInt8 HurtSoft[]=
{
  "T'was but a scratch!",
  "What a nuisance.",
  "I'm not impressed.",
  "Pityfull...",
  "Try again!",
  "I'll survive this.",
  "It almost hit me.",
  "No problemo",
  "Consider me dead.",
  "missed!",
  "That's all you can do?",
  "Human casualties: zero.",
  "Hasta la vista, baby.",
  "It just bounced off me.",
  "Go look for a Psy.",
  NULL,
  NULL,
};
static pInt8 HurtHard[]=
{
  "Hey, that hurts!",
  "Stop it, you pest!",
  "I need some holidays...",
  "I feel the power of the Force.",
  "I hate this when it happens.",
  "Engaging alternate power.",
  "I'm not amused.",
  "Keep cool, baby!",
  "Expect some retaliation.",
  "Time to die.",
  "Hey, I'm not Saddam!",
  "I'm badly hurt.",
  "What a bestiality!",
  "Anyone lend me a Medikit?",
  "I'm still alive.",
  "Near death experience.",
  "So what?",
};
static pInt8 HurtDie[]=
{
  "Bus error: core dumped.",
  "Add more coins to play again.",
  "You know what? I'm dead.",
  "Please upgrade my chips.",
  "Caught a SIGKILL, exiting.",
  "I'll be back... soon.",
  "Experiencing post-natal aborption.",
  "Shutdown -F r",
  "Unhandled exception.",
  "Please rewrite my AI routines!",
  "Peace and love, brothers!",
  "Never mind, I beleive in resurection.",
  "Rebooting.",
  "See you in hell.",
  "Yet another cheap frag.",
  "My Defense Systems has a bug.",
  "Scanning for alternative.",
};
/*
** Bot is hit by something
**  Suspect = NULL if no suspect known
**          = pBot->Self if damage done by water or lava
**          = player if known player
*/
void THINKisHitCb(pBOT pBot, pELIVING Suspect, Int16 Taken, Int16 NewHealth)
{
  pInt8 Text=NULL;
  Int32 Hate;
  pEPLAYER pPlay;
  /* local messages */
  if(NewHealth<=0)
  { BotLocalPrintf(pBot, HIGHLIGHT, "System failure in all sectors.\n");}
  else if(NewHealth<=30)
  { BotLocalPrintf(pBot, CENTERED, "Alert: Damage critical.\n");}
  /*
  ** Action
  */
  if(Suspect==pBot->Self)
  { /* Damage by water: jump to swim back to surface.. if any. */
    BotActionMove(pBot, NULL, NULL, BOT_JUMP, 0);
    /* For lava damage... there is no cure! */
  }
  else
  { /* send a stupid message to other players*/
    if(NewHealth<=0)
    { Hate = RandI(0,60); if(Hate<15) Text= HurtDie[(Int)Hate];}
    else if(Taken>10)
    { Hate = RandI(0,60); if(Hate<15) Text= HurtHard[(Int)Hate];}
    else
    { Hate = RandI(0,100); if(Hate<15) Text= HurtSoft[(Int)Hate];}
    if(Text!=NULL)
    { BotActionPrintf(pBot, Text); }
  }
  /*
  ** print status
  */
  if(NewHealth>0)
  { printf("DAMAGE: %d points!\n", (int)Taken); }
  else
  {
    printf("DEAD:   %d health\n", (int)NewHealth);
    /* try to come back to life */
    BotActionMove(pBot, NULL, NULL, (UInt16)((pBot->Health<=0)? BOT_FIRE:BOT_NONE),0);
  }
  /*
  ** Increase Hate
  */
  if(Suspect==NULL)
  { /* unknown suspect, increase hate toward everyone */
    BotPlayerHate(pBot, 0, 10);
  }
  else if((Suspect!=pBot->Self)&&(Suspect->pPlay!=NULL))
  { /* known suspect*/
    Hate = BotPlayerHate(pBot, Suspect->Me, Taken);
    pPlay = Suspect->pPlay;
    if(Hate<=HATETRIGGER)
    { BotActionPrintf(pBot, "%s had better keep tame.", &(pPlay->Name[0]));}
#if 1
    BotLocalPrintf(pBot, NORMAL, "Threat level %d: %s\n",pPlay->Hate,&(pPlay->Name[0]));
#endif
  }
  return;
}

/**************************************************************\
**
**   Real Client send a movement and impulse order (via the Bot)
**
\**************************************************************/
Int16 THINKdebugImpulse(pBOT pBot, Int16 Impulse);
/*
** Called each time a message is received from player
** (handle client movements and impulse command).
** return the actual impulse desired (0, if no impulse)
** Note: DO NOT MODIFY Angles and Speeds IT WILL BE IGNORED.
*/
Int16 THINKplayerMoveCb(pBOT pBot, pVEC3 pSpeeds, Int16 Impulse)
{
  /* for misc impulses */
  Int32 Typ;
  ANGLES Angles;
  /* for weapon check */
  pELIVING Ent;  pInt8 Name; ETYPE ETyp;
  /* If player has control the bot is not bored */
  THINKboredom=0;

#if 0 /*DEBUG: print player moves */
  printf("Move Tilt=%6.1f Yaw=%6.1f",
    (float)ANGLE2DEG(pAngles->Tilt),(float)ANGLE2DEG(pAngles->Yaw));
  if((pSpeeds->X!=0.0)||(pSpeeds->Y!=0.0)||(pSpeeds->Z!=0.0))
  { printf(" F=%6.1f  R=%6.1f U=%6.1f",
      (float)pSpeeds->X,(float)pSpeeds->Y,(float)pSpeeds->Z);}
  printf("\n");
#else
  (void)pSpeeds;
#endif
  if(pBot->Self==NULL){ return Impulse; }
  /*
  ** Do not catch 0 and quad cheat
  */
  if((Impulse==255)||(Impulse==0))
  { return Impulse; }  /*quad cheat*/
  /*
  ** Catch impulses 2-8. detect if no weapon, find closest
  */
  if(Impulse<=10) /*weapons*/
  { switch(Impulse)
    {
      case 3:
        Typ=IT_SUPER_SHOTGUN;   ETyp=ETYPE_WEAPON_SHOT;
        Name = "Shotgun";        break;
      case 4:
        Typ=IT_NAILGUN;         ETyp=ETYPE_WEAPON_NAIL;
        Name = "NailGun";        break;
      case 5:
        Typ=IT_SUPER_NAILGUN;   ETyp=ETYPE_WEAPON_SUPN;
        Name = "SuperNail";        break;
      case 6:
        Typ=IT_GRENADE_LAUNCHER;ETyp=ETYPE_WEAPON_GREN;
        Name = "GrendLnch";        break;
      case 7:
        Typ=IT_ROCKET_LAUNCHER; ETyp=ETYPE_WEAPON_ROCK;
        Name = "RocktLnch";        break;
      case 8:
        Typ=IT_LIGHTNING;       ETyp=ETYPE_WEAPON_LITE;
        Name = "Lighting";        break;
      default: /*axe,shotgun*/
        return Impulse;
	 }
	 /* Check if already has item. If so, impulse is valid.*/
    if(pBot->Items & Typ) return Impulse;
    Ent=BotEntiFindClosest(&(pBot->Self->Origin), ETyp, pBot->Self);
    if(Ent==NULL)
    { BotLocalPrintf(pBot, CENTERED,"Can't find %s", Name);}
    else
    {
#if 1 /*ORIENT TOWARD AIMED ENTITY*/
      /* Caculate Delta */
      MOVEprepare(Ent, &(pBot->Self->Origin));
      /* Change angles in the current movement */
      MOVEaimEntity(&Angles, Ent);
      BotActionMove(pBot, &Angles, NULL, BOT_NONE, 0);
      /* Print time and distance */
      BotLocalPrintf(pBot, CENTERED,"t=%4.1fs d=%5.1f %.32s",(float)(pBot->Time - Ent->Time), (float)sqrt(Ent->DeltaNorm2), Name);
#else /*GIVE RELATIVE POSITION OF ENTITY (FRONT/UP/DOWN) */
      /* Origin = VEC3(Front, Right, Up)*/
      MOVEgetRelativePos(&Origin, &(pBot->Self->Origin), &(pBot->Self->Angles), Ent);
      BotLocalPrintf(pBot, CENTERED,"%s %s",Name, MOVEprintRelativePos(&Origin));
#endif
    }
    return 0; /*cancel impulse */
  }
  /*
  ** Enable/disable bot movement actions.
  */
  if(Impulse==16)
  {
    BotActionAllowedToggle();
    return 0;
  }
  /*
  ** Lock on player
  */
  if((Impulse>=100)&&(Impulse<=116))
  {
    if(Impulse==100) /* Closest player */
    { Ent=BotEntiFindClosest(&(pBot->Self->Origin), EFLAG_PLAYER, pBot->Self);}
    else            /* Player = Impulse - 100 */
    {
      Ent=BotEntiGet(Impulse-100);
      if(Ent== pBot->Self) return 0; /* Check that not bot*/
    }
    /* Check that entity is a player */
    if((Ent==NULL)||(Ent->pPlay==NULL)) return 0; /*cancel impulse */
	 /* Check if ever got an update on this entity */
	 if(Ent->Time==0.0) return 0;
    /* Caculate Delta */
    MOVEprepare(Ent, &(pBot->Self->Origin));
    /* Change angles in the current movement */
    MOVEaimEntity(&Angles, Ent);
    BotActionMove(pBot, &Angles, NULL, BOT_NONE, 0);
    /* Print time and distance */
    BotLocalPrintf(pBot, CENTERED,"t=%4.1fs d=%5.1f %.32s",(float)(pBot->Time - Ent->Time), (float)sqrt(Ent->DeltaNorm2),Ent->pPlay->Name);
    return Impulse; /*don't cancel impulse */
  }
  /*  */
  if(Impulse==60)
  {
    BotLocalPrintf(pBot, CENTERED, "(%6.1f,%6.1f,%6.1f)\n",
		  pBot->Self->Origin.X,pBot->Self->Origin.Y,pBot->Self->Origin.Z);
  }
  else
  {
    Impulse = THINKdebugImpulse(pBot, Impulse);
  }
  return Impulse;
}


/*
** Real client (player) sent a console order
*/
Bool THINKplayerConsoleCb(pBOT pBot, pInt8 Text, Int32 TextSz)
{
  (void)pBot;
  (void)TextSz; /*only useful if modifying text*/
  /* print, for debug*/
  printf("Player command: %s\n",Text);
#if 0 /*REMOVED: makes the bot appear as "unconnected" (no name)*/
  /* Disable name and color changes */
  if(Strncmpi(Text,"name", 4)>0) return FALSE;
  if(Strncmpi(Text,"color", 5)>0) return FALSE;
#endif
  /* message is ok */
  return TRUE;
}


/*
** Another player is talking
*/
void THINKtalkingCb(pBOT pBot, pELIVING Talker, pInt8 Text)
{
  if((Text==NULL)||(Talker==NULL)||(Talker->pPlay==NULL))
  { return; }
  /* stop firing at people who say they love bots*/
  if(Strncmpi(Text,"I love bots",11)>0)
  { Talker->pPlay->Hate=0; }
  /* disconnect, if unwanted */
  if(Strncmpi(Text,"no bots please",13)>0)
  { BotActionDisconnect(pBot); }
}
/*
** Called each time a print message is received
*/
void THINKprintingCb(pBOT pBot, pInt8 Text)
{
  /* disconnect, if unwanted */
  if(Strncmpi(Text,"no bots please",13)>0)
  { BotActionDisconnect(pBot); }
}


/****************************************************\
*
*   Code needed for debug. Forget about it.
*
\****************************************************/

/*
** Debug Impulse
*/
Int16 THINKdebugImpulse(pBOT pBot, Int16 Impulse)
{
  Int32 Typ;
  ANGLES Angles;
  VEC3 Origin;
  VEC3 End;
  /* Leaf*/
  static Int32 Leaf=0;
  Int32 Leaf2;
  /* Trace*/
  SCALAR Len;
  VEC3  Direc;
  /*
  ** Generate a fake entity (DEBUG)
  */
  if((Impulse >= 80)&&(Impulse<92))
  {
	 /* Calculate direction from angles*/
    Ang2Vec(&Origin, &(pBot->Self->Angles));
    VecCpy(&End,&Origin);
    /* Origin *= 200 */
    VecScale(&Origin, 200);
	 VecScale(&End, 400);
	 /* Origin += Bot.Origin*/
    VecAdd(&Origin, &(pBot->Self->Origin));
    VecAdd(&End, &(pBot->Self->Origin));
    printf("TempEntity at  %8.2f %8.2f %8.2f\n",
      (float)Origin.X,(float)Origin.Y,(float)Origin.Z);
    switch(Impulse)
    {
      case 80: Typ = TE_SPIKE;break;
      case 81: Typ = TE_SUPERSPIKE;break;
      case 82: Typ = TE_GUNSHOT;break;
      case 83: Typ = TE_EXPLOSION;break;
      case 84: Typ = TE_TAREXPLOSION;break;
		case 85: Typ = TE_LIGHTNING1;break;
      case 86: Typ = TE_LIGHTNING2;break;
      case 87: Typ = TE_WIZSPIKE;break;
      case 88: Typ = TE_KNIGHTSPIKE;break;
      case 89: Typ = TE_LIGHTNING3;break;
		case 90: Typ = TE_LAVASPLASH;break;
      case 91: Typ = TE_TELEPORT;break;
    }
    /* Apparently, Trace_End is useless for entities */
    /* Make temporary entity, Me is the creator */
	 BotLocalEntity(pBot, Typ, &Origin, &End);
	 Impulse =0; /*no impulse*/
  }
  /*
  ** Say what leaf
  */
  switch(Impulse)
  {
	 case 95:
		BSPpointInLeaf(&Leaf2,&(pBot->Self->Origin));
		BSPleafGet(&Origin, &Typ, Leaf2);
		/*orient toward leaf center*/
		MOVEaimPoint(&Angles, &(pBot->Self->Origin), &Origin);
		BotActionMove(pBot, &Angles, NULL, BOT_NONE, 0);
		/*make particle at center*/
		VecSet(&End, 0,0,-1); /*Velocity*/
		BotLocalParticle(pBot, &Origin, &End, BOT_PARTICLE_GOLD, 20);
		/*print infos*/
		VecSub(&Origin,&(pBot->Self->Origin));
		BotLocalPrintf(pBot, CENTERED,"L%4ld T%4lx D%6.2f",(long)Leaf2,
		  (long)Typ, (float)VecNorm(&Origin));
		Impulse =0;
	 break;
	 case 96:
		Leaf+=9;
	 case 97:
		Leaf++;
	 case 98:
		if(BSPleafGet(&Origin, &Typ, Leaf)!=TRUE)
		{ Leaf=0;}
		else
		{
		  BSPpointInLeaf(&Leaf2,&Origin);
		  printf("Leaf:%4ld in %4ld [%8lx]   %6.1f %6.1f %6.1f\n",(long)Leaf, (long)Leaf2,
			  (long)Typ, (float)Origin.X, (float)Origin.Y, (float)Origin.Z);
		  /*orient toward leaf center*/
		  MOVEaimPoint(&Angles, &(pBot->Self->Origin), &Origin);
		  BotActionMove(pBot, &Angles, NULL, BOT_NONE, 0);
		  /*make particle at center*/
		  VecSet(&End, 0,0,-1); /*Velocity*/
		  BotLocalParticle(pBot, &Origin, &End, BOT_PARTICLE_GOLD, 20);
		}
		Impulse=0; /*no impulse*/
		break;
  }
  /*
  ** Print all close leaves
  */
  if(Impulse==99)
  {
	 Int32 n,nb;
	 pInt32 pLeaves;
	 /* Leaf2 = leaf where the bot is */
	 BSPpointInLeaf(&Leaf2,&(pBot->Self->Origin));
	 /* List all waypoints */
	 nb=-1;
	 pLeaves=BSPleafListWays(&nb, Leaf2);
	 printf("Leaf %5d  NbWays=%5d\n",(int)Leaf2, (int)nb);
	 if(pLeaves!=NULL)
	 {
		for(n=0; n<nb; n++)
		{ /*Get origin of leaf*/
		  BSPleafGet(&Origin, &Typ, pLeaves[n]);
        /*make particle at center*/
        VecSet(&End, 0,0,0); /*Velocity*/
        BotLocalParticle(pBot, &Origin, &End, BOT_PARTICLE_GOLD, 10);
		}
	 }
  }
  /*
  ** Fire a ray, and hit wall
  */
  if(Impulse==50)
  {
    /* Calculate direction from angles*/
    Ang2Vec(&End, &(pBot->Self->Angles));
    /* Origin *= 400 */
    VecScale(&End, 400.0);
    /* Origin += Bot.Origin*/
    VecAdd(&End, &(pBot->Self->Origin));
    /* Fire a ray from bot to end. hit at Origin */
    Typ = BSPtrace(&Origin, &Direc, &Len, &(pBot->Self->Origin), &End);
    if(Typ&AREA_INWALL)
    { /* Move back a bit*/
      VecScale(&Direc, -2.0);
      VecAdd(&Origin,&Direc);
    }
    BotLocalParticle(pBot, &Origin, NULL, BOT_PARTICLE_GREEN, 10);
    BotLocalPrintf(pBot, CENTERED,"D%6.2f  %c%c%c%c",(float)Len,
      (Typ&AREA_INWALL)?  '#':' ',
      (Typ&AREA_INWATER)? 'W':' ',
      (Typ&AREA_INLAVA)?  'L':' ',
      (Typ&AREA_INSLIME)? 'S':' ');
  }

#if 0
  /*
  ** Generate a fake PARTICLE
  */
  if((Impulse >= 200)&&(Impulse<250))
  {
    /* Calculate direction from angles*/
    Ang2Vec(&Origin, &(pBot->Self->Angles));
    /* Origin *= 200 */
    VecScale(&Origin, 50);
    /* Origin += Bot.Origin*/
    VecAdd(&Origin, &(pBot->Self->Origin));
    /* Velocity */
    printf("Particle at %8.2f %8.2f %8.2f\n",
      (float)Origin.X,(float)Origin.Y,(float)Origin.Z);
    /* Make particle, color =  (Int8)(Impulse-100) */
    BotLocalParticle(pBot, &Origin, NULL, (Int8)(Impulse-200), 10);
    Impulse=0; /*no impulse*/
  }
#endif /*DEBUG*/
  return Impulse;
}

