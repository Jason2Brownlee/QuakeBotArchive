/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"  /*Always first to be included*/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>  /*variable lenght arguments*/
#include <ctype.h>
#include "common.h"
#include "data.h"     /*Data storage*/
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkpto.h"    /*Protocol machine*/
#include "qkent.h"    /*Entity and model lists*/
#include "qkbot.h"    /*Bot inteface*/
#include "qkentbot.h" /*Entity list, for bot */
#include "qkbotpto.h" /*Bot interface to Protocol machine*/
#include "qkbotmsg.h" /*Bot Messages*/
#include "qkmsgbot.h" /*Quake Message parsing for Bot*/
#include "qkthink.h"
#include "qkpak.h"    /*Pak files*/
#include "qkbsp.h"    /*Bsp level*/

#define DEBUG  1


/*
** Static data
*/
BOT Bot;
static Int8 BotBuff[256]; /*buffer for vprintf*/


/****************************************************\
*
*         Bot
*
\****************************************************/

void BotActionClear(void);
void BotReinit(void);
/*
** Init Bot
*/
Int32 BotInit(pPTO pPto, pPTO pPtoW)
{
  /*
  ** Client and messages
  */
  Bot2.Pto = pPto;
  Bot2.PtoW= pPtoW;
  DtaInit(&Bot2.Dta, 0x1000);
  DtaInit(&Bot2.DtaW, 0x1000);
  /**/
  BSPinit();
  /*
  ** Init entities
  */
  Bot2.EStatic = Malloc(ESTATICMAX * sizeof(ELIVING));
  Bot2.ELiving = Malloc(ELIVINGMAX * sizeof(ELIVING));
  if((Bot2.EStatic==NULL)||(Bot2.ELiving==NULL))
  { BotFree(); return ERRfault(ERR_MEM);}
  /*
  ** Bot Globals
  */
  Bot.Passive = FALSE; /*by default, start a game when possible*/
  Strncpy(Bot.Name, BOTNETNAME, sizeof(Bot.Name));
  Bot.Color = BOTNETCOLOR;
  /*
  ** Reinit
  */
  BotReinit();
  /*
  ** Init Thinks
  */
  THINKinitCb(&Bot);
  return 1;
}
/*
** Restart bot. Called when signon state = PRESPAWN
*/
void BotReinit(void)
{
  /*
  */
  BotModelSoundReInit();
  /*
  ** Clear list of entities
  */
  BotPlayerReInit();
  BotEntiReInit();
  /*
  ** Bot globals
  */
  Bot.Time = 0.0;
  Bot.Signon = 0;
  Bot.Paused = FALSE;
  Bot.TheEnd = FALSE;
  Bot.MapName[0] = '\0';
  /**/
  Bot.Me = 0;    /*Bot is no one in particular*/
  Bot.Self=NULL;
  Bot.Health= 0;
  Bot.Unkn= 0;
  Bot.Weaponmodel= 0;
  Bot.Ammo= 0;
  Bot.Armor= 0;
  Bot.Weaponframe= 0;
  Bot.Shells= 0;
  Bot.Nails= 0;
  Bot.Rockets= 0;
  Bot.Cells= 0;
  Bot.Weapon= 0;
  Bot.Total_secrets= 0;
  Bot.Total_monsters= 0;
  Bot.Found_secrets= 0;
  Bot.Killed_monsters= 0;
  /* clear the pending action */
  Bot2.ActionAllowed=TRUE;
  BotActionClear();
  /* clear list of entities seen */
  SEENclear();
}
/*
** Free Bot
*/
void BotFree(void)
{
  /*
  ** Think end
  */
  THINKfreeCb(&Bot);
  /*
  ** Client and messages
  */
  Bot2.Pto = NULL;
  Bot2.PtoW= NULL;
  DtaFree(&Bot2.Dta);
  DtaFree(&Bot2.DtaW);
  /**/
  if(Bot2.EStatic!=NULL) Free(Bot2.EStatic);
  if(Bot2.ELiving!=NULL) Free(Bot2.ELiving);
  /**/
  Bot.Time = 0.0;
  Bot.Signon = 0;
  Bot.Paused = TRUE;
  Bot.TheEnd = TRUE;
  /**/
  BSPfree();
  return;
}
/*
** Restart a bot
*/
void BotRestart(pBOT pBot)
{
  /* restart protocol stuff */
  /* Warning: possible bug here */
  if(Bot2.Pto!=NULL) PtoReInit(Bot2.Pto, NULL);
  if(Bot2.PtoW!=NULL) PtoReInit(Bot2.PtoW, NULL);
 /* reinit bot*/
 BotReinit();
 (void)pBot;
}
/*
** Make a bot passive:
** it will not control the startup shakehand sequence,
** and let it be handled by the real game client.
*/
void BotPassive(void)
{
  Bot.Passive=TRUE;
}
/*
** bot received no messages for a long time
*/
void BotIddle(void)
{
  static Count;
  Count +=1;
  if(Count&0x3FFF) return;
  printf("I'm really bored.\n");
}

/****************************************************\
*
*         Bot Actions
*
\****************************************************/
/*
** Toggle bot actions
*/
void BotActionAllowedToggle(void)
{
  Bot2.ActionAllowed= (Bot2.ActionAllowed==TRUE)? FALSE:TRUE;
  BotLocalPrintf(&Bot, HIGHLIGHT, "Defense systems %s.\n",
    (Bot2.ActionAllowed==TRUE)?"ON":"OFF");
}
/*
** Clear pending action
*/
void BotActionClear(void)
{
  Bot2.ActionPending=FALSE;  /*no current action*/
  Bot2.ActionBot=FALSE;      /*bot didn't change angles*/
  if(Bot.Self!=NULL)
  {
    AngCpy(&(Bot2.ActionAngles),&(Bot.Self->Angles));
    AngCpy(&(Bot.Angles),&(Bot.Self->Angles));
  }
  else
  { AngCpy(&(Bot2.ActionAngles),&(Bot.Angles)); }
  VecSet(&Bot2.ActionSpeed,0.0,0.0,0.0);
  Bot2.ActionFlags=BOT_NONE;
  Bot2.ActionImpulse=0;
}

/*
** Flush all pending actions
** This ensures only one move is attempted at the time
*/
void BotActionFlush(pBOT pBot)
{
  Int8 Flags=0;
  (void)pBot;
  /* Check that action is not outdated*/
  if(Bot2.ActionPending!=TRUE)
  { /*a trick to stop firing regularly*/
    if(Bot2.ActionFireCount>=0)
    { Bot2.ActionFireCount--; }
    /*At zero, stop firing*/
    if(Bot2.ActionFireCount!=0) { return; }
  }
  /* Flags and impulses */
  if(Bot2.ActionFlags& BOT_FIRE) Flags |= QACTION_FIRE;
  if(Bot2.ActionFlags& BOT_JUMP) Flags |= QACTION_JUMP;
  Bot2.ActionImpulse &= (UInt16)BOT_MASK;
  /* Compose and send action message to the server*/
  DtaClear(&Bot2.Dta);
  QPlayMakAction(&Bot2.Dta, Bot.Time, &(Bot2.ActionAngles), &(Bot2.ActionSpeed), Flags, (Int8)Bot2.ActionImpulse);
  if(Bot2.Pto!=NULL)
    PtoSendUnreliable(Bot2.Pto,&Bot2.Dta);
  /* If bot moved, send a set angles message to the client */
  if(Bot2.ActionBot==TRUE)
  { /* Needed only when Bot.Angle != Bot2.ActionAngles? */
    DtaClear(&Bot2.DtaW);
    QSrvMakSetView(&Bot2.DtaW, -1, &(Bot2.ActionAngles));
    if(Bot2.PtoW!=NULL)
      PtoSendUnreliable(Bot2.PtoW,&Bot2.DtaW);
  }
  /* Clear action */
  BotActionClear();
}
/*
** Movement/action desired by the bot
*/
void BotActionMove(pBOT pBot, pANGLES pAngles, pVEC3 pSpeed, UInt16 Flags, UInt16 Impulse)
{
  /* Check that bot actions are allowed */
  if(Bot2.ActionAllowed==FALSE) { return; }
  /* Ensure action will be executed this round*/
  Bot2.ActionPending=TRUE;
  if(pAngles!=NULL)
  {
    /* Bug fix: update bot angles to desired angles*/
    if(Bot.Self!=NULL)
    { AngCpy(&(Bot.Self->Angles), pAngles); }
    /* Set action angles*/
    AngCpy(&(Bot2.ActionAngles), pAngles);
    Bot2.ActionBot=TRUE; /*bot moved his angles*/
  }
  /* update speed... only if allowed */
  if(pSpeed!=NULL)
  { VecCpy(&(Bot2.ActionSpeed), pSpeed); }
  /* update flags */
  Bot2.ActionFlags  |= Flags;
  /* stop firing n updates later */
  if(Flags&BOT_FIRE)
  { Bot2.ActionFireCount=2; }
  /* update impulse */
  if(Impulse!=0)
  { Bot2.ActionImpulse = Impulse;}
  (void)pBot;
}
/*
** Movement issued by the real client (NOT THE BOT ITSELF)
*/
void BotActionMoveClient(pBOT pBot, pANGLES Angles, pVEC3 Speed, UInt16 Flags, UInt16 Impulse)
{
  /* Ensure action will be executed this round*/
  Bot2.ActionPending=TRUE;
  /* if bot didn't already changed angles, change them */
  if(Bot2.ActionBot!=TRUE)
  {
    if(Angles!=NULL)
    { AngCpy(&(Bot2.ActionAngles), Angles);}
  }
  /* update flags */
  if(Flags&QACTION_FIRE) { Bot2.ActionFlags  |= BOT_FIRE;}
  if(Flags&QACTION_JUMP) { Bot2.ActionFlags  |= BOT_JUMP;}
  /* update impulse */
  if(Impulse!=0)   { Bot2.ActionImpulse = Impulse; }
  /* update speeds */
  if(Speed!=NULL)  { VecCpy(&(Bot2.ActionSpeed), Speed);}
  (void)pBot;
}
/*
** Talk to all
*/
void BotActionPrintf(pBOT pBot, pInt8 Text, ...)
{
  va_list argptr;
  Strncpy(BotBuff,"say  ",5);
  va_start(argptr, Text);
  vsprintf(&(BotBuff[4]), Text, argptr);
  va_end(argptr);
  Strcat(BotBuff,"\n");
  DtaClear(&Bot2.Dta);
  QPlayMakConsole(&Bot2.Dta, BotBuff);
  if(Bot2.Pto!=NULL)
  { PtoSendReliable(Bot2.Pto,&Bot2.Dta);}
 (void)pBot;
}
/*
** Send a command to server
*/
void BotActionConsole(pBOT pBot, pInt8 Text, ...)
{
  va_list argptr;
  va_start(argptr, Text);
  vsprintf(&(BotBuff[0]), Text, argptr);
  va_end(argptr);
  Strcat(BotBuff,"\n");
  DtaClear(&Bot2.Dta);
  QPlayMakConsole(&Bot2.Dta, BotBuff);
  if(Bot2.Pto!=NULL)
  { PtoSendReliable(Bot2.Pto,&Bot2.Dta);}
 (void)pBot;
}


/*
** Send a disconnect command to server
*/
void BotActionDisconnect(pBOT pBot)
{
  DtaClear(&Bot2.Dta);
  QPlayMakDisconnect(&Bot2.Dta);
  if(Bot2.Pto!=NULL)
  { PtoSendReliable(Bot2.Pto,&Bot2.Dta);}
  /* restart bot */
  BotRestart(pBot);
}

/****************************************************\
*
*   Spawn: load level
*
\****************************************************/
void BotSpawn(void)
{
  pInt8 Lmp;  Int32 LmpSz;
  pInt8 Level;
  Level = BotEntiGetModel(0);
  if(Level==NULL)
  { ERRwarn("No level BSP.");}
  /* Get model of entity zero */
  Lmp =  DBget(&LmpSz, Level);
  if(Lmp==NULL)
  { ERRwarn("Cannot read BSP %s",Level); return;}
  if(BSPreInit(Lmp,LmpSz)<0)
  { ERRwarn("Cannot parse BSP %s",Level);}
  Free(Lmp);
}


/****************************************************\
*
*   Bot handles messages from Server
*
\****************************************************/
/*
** Receive message from server
*/
void BotReceive(pDTA pDta, Bool Reliable)
{
  ppELIVING List;
  Int32   ListSz;
  /* Interpret each message and send it to the right part*/
  if(QSrvReceive(&Bot, pDta)==666) /*666=nop*/
  { return;}
  /* Message dependant actions*/
  if(Reliable==TRUE)
  { return; }
  /* If not finished, declare update */
  if(Bot.TheEnd==TRUE)
  { return; }
  /*
  ** Declare that an update message was received
  */
  THINKupdateCb(&Bot);
  /*
  ** Declare entities that were seen
  */
  List = SEENgetList(&ListSz);
  if((List!=NULL)&&(ListSz>0))
  {
    THINKsawEntitiesCb(&Bot, List, ListSz);
  }
  SEENclear();
  /*
  ** Execute all movement received before this update
  ** And all movements calculated within this update
  */
  BotActionFlush(&Bot);
  return;
}
/*
** Server sent a request to Disconnect
*/
void BotSrvDisconnect(pBOT pBot)
{
  THINKendCb(&Bot);
  /* restart bot */
  BotRestart(pBot);
}
/*
** Server restarted the game (server Infos message)
*/
void BotSrvRestart(pBOT pBot, pInt8 Mapname, Int16 Players, Bool Multi)
{
  /* reinit bot */
  BotReinit();
  pBot->Players = Players;
  pBot->Multi = Multi;
  Strncpy(pBot->MapName,(Mapname==NULL)? ((pInt8)"Unknown"): Mapname,sizeof(pBot->MapName));
}
/*
** Sign-on state
*/
void BotSrvSignonState(pBOT pBot, Int32 State)
{
  /* Try to start a game*/
  if(pBot==NULL) return;
  switch(State)
  { case SIGNONPRESPAWN:
      /* execute callback */
      THINKprespawnCb(&Bot);
      if(pBot->Passive!=TRUE)
      { /* send message prespawn */
        DtaClear(&Bot2.Dta); /*restart from scratch*/
        QPlayMakConsole(&Bot2.Dta,"prespawn");
        PtoSendReliable(Bot2.Pto,&Bot2.Dta);
      }
      break;
    case SIGNONINITLITE:
      /* Execute callback */
      /*ThinkSpawnCb(&Bot);*/
      if(pBot->Passive!=TRUE)
      { /* Send message "spawn" */
        DtaClear(&Bot2.Dta); /*restart from scratch*/
        QPlayMakPlayer(&Bot2.Dta, pBot->Name, pBot->Color);
        QPlayMakConsole(&Bot2.Dta, "spawn ");
        PtoSendReliable(Bot2.Pto, &Bot2.Dta);
      }
      break;
    case SIGNON3DRENDER:
      /* load level */
      BotSpawn();
      /* Say that bot is running */
      pBot->TheEnd = FALSE;
      pBot->Paused = FALSE;
      /* clear list of entities seen */
      SEENclear();
      /* Execute callback */
      /*ThinkBeginCb(&Bot);*/
      if(pBot->Passive!=TRUE)
      { /* Send message "begin" */
        DtaClear(&Bot2.Dta); /*restart from scratch*/
        QPlayMakConsole(&Bot2.Dta,"begin");
        PtoSendReliable(Bot2.Pto,&Bot2.Dta);
      }
      break;
    case SIGNONINTERMISSION:
      pBot->Paused = TRUE;
      break;
    case SIGNONSELLSCREEN:
      pBot->TheEnd=TRUE;
      break;
   }
  return;
}
/*
** List of Precaches
*/
/* Models */
void BotSrvPrecacheModel(pBOT pBot, Int32 i, pInt8 Name)
{
  /*Warning: Copy Name to a safe place*/
  BotModelSet(i,Name);
  (void)pBot;
  return;
}
/* Sound */
void BotSrvPrecacheSound(pBOT pBot, Int32 i, pInt8 Name)
{ /*Warning: Copy name to a safe place*/
  BotSoundSet(i,Name);
  (void)pBot;
  return;
}
/*
** Bot players infos
*/
/*entity from which view is cast*/
void BotSrvViewSet(pBOT pBot, ENTITY Enti)
{
  /* Check enti is a valid player entity*/
  if(BotIsPlayer(pBot,Enti)!=TRUE) return;
  if(pBot->Me<=0)
  { pBot->Me = Enti;} /*First time, View sets the player's id.*/
  else if(Enti != pBot->Me)
  { /* Dammit! the Bot is going schizophrenic! */
    printf("WARNING: Bot=%d but it views from %d!\n",(int)pBot->Me,(int)Enti);
  }
  pBot->Self = BotEntiGet(pBot->Me);
  /*should also check with player names*/
  return;
}
/*
** bot was hit
*/
void BotSrvDamage(pBOT pBot, pVEC3 pOrigin, Int16 Taken, Int16 Absorbed)
{
  Int16 NewHealth= (Int16)(pBot->Health - Taken);
  ENTITY enti;
  pELIVING Ent; SCALAR Dist;
  pELIVING Suspect=NULL; /* suspected Murderer */
  SCALAR Dist0=500.0;   /* Suspicion distance */
#if 0
    printf("Hit origin: %6.1f %6.1f %6.1f\n",(float)pOrigin->X, (float)pOrigin->Y, (float)pOrigin->Z);
#endif
  /*
  ** if pOrigin = (0,0,0) if damage from water
  ** else  (x,y,z) = Origin of a weapon or a missile or the like
  */
  if((pOrigin->X==0.0) && (pOrigin->Y==0.0) && (pOrigin->Z==0.0))
  {
     Suspect = Bot.Self;
  }
  else
  { /*Hit comes from weapon of missile*/
    /*Locate the closest player*/
    for(enti=1; enti<=Bot.Players; enti++)
    {
      Ent=BotEntiGet(enti);
      if(Ent==NULL) continue;
      /* Discard non-player entities */
      if(Ent->pPlay==NULL) continue;
      /* Not the Bot himslef */
      if(Ent == Bot.Self) continue;
      /* Check minimum distance */
      Dist = VecDiff(&(Ent->Origin),pOrigin);
      if(Dist<Dist0) { Suspect=Ent; Dist0=Dist; }
    }
    if((Suspect!=NULL)&&(Suspect->pPlay!=NULL))
    { printf("SUSPECT: %s\n", &(Suspect->pPlay->Name[0]));}
  }
  /* inform bot */
  THINKisHitCb(pBot, Suspect, Taken, NewHealth);
  (void)Absorbed;
  return;
}
/*
** Console command
*/
void BotSrvExec(pBOT pBot, const pInt8 Text)
{ /*WARNING: Text must be copied to a safe place*/
  printf("EXEC: %s\n", Text);
  (void)pBot;
  return;
}
/*
** Print message
*/
static Int32 BotPrintPos=0;
static Int8  BotPrintBuff[128];
void BotSrvPrint(pBOT pBot, pInt8 Text, Bool Centered)
{
  Int32 i,namelen;
  Int8 c;
  pELIVING Ent;
  /*WARNING: Text must be copied to a safe place*/
  if(Text==NULL) return;
  if(Centered==TRUE)
  { /* Centered message */
    printf("PRINTC: %s\n", Text);
  }
  else if(((UInt8)Text[0])<'\n') /*should be '\002' only*/
  {
    Text = &(Text[1]);
    /* System message */
    printf("SERVER: %s\n",Text);
    /*
    ** Player to player messages are received here
    ** PLAYERNAME: MESSAGE
    */
    /*Detect a player message*/
    namelen = Strfind(Text,": ",40);
    if(namelen>0)
    {
      Ent = BotPlayerGetByName(pBot, &(Text[0]), namelen);
      if(Ent!=NULL)
      {
        Strncpy(BotBuff,&Text[namelen+2],sizeof(BotBuff)-1);
        THINKtalkingCb(&Bot, Ent, BotBuff);
      }
    }
  }
  else
  {
    for(i=0; i<256;i++)
    {
      c= Text[(Int)i];
      if(c=='\0')
      { break; }
      if(c=='\n')
      {
        if(BotPrintPos>=sizeof(BotPrintBuff))
        { BotPrintPos=sizeof(BotPrintBuff)-1; }
        BotPrintBuff[(Int)BotPrintPos]='\0';
        printf("PRINT: %s\n",&(BotPrintBuff[0]));
        /* interpret messages */
        THINKprintingCb(pBot, &(BotPrintBuff[0]));
        /* restart buffer */
        BotPrintPos=0;
        continue;
      }
      /* Normal character */
      if(isprint(c))
      { /* Add to buffer */
        if(BotPrintPos<sizeof(BotPrintBuff))
        { BotPrintBuff[(Int)(BotPrintPos++)]=c; }
      }
    }
  }
  (void)pBot;
  return;
}
/*
** Entities
*/
/*add a static entity (127), returns entity<0*/
pELIVING BotSrvEntiStatic(pBOT pBot,UInt8 Model)
{
  pELIVING Ent=BotEntiStaticNew();
  if(Ent==NULL) return NULL;
  /* declare updated*/
  Ent->Time = Bot.Time;
  /* declare type = f(model)*/
  Ent->Model = Model;
  Ent->ETyp  = (ETYPE) (EFLAG_STATIC | Bot2.Models[Model].ETyp);
  Ent->pPlay = NULL;
  (void)pBot;
  return Ent;
}
/*add an entity (449)*/
pELIVING BotSrvEntiInit(pBOT pBot,ENTITY Enti,UInt8 Model)
{
  pELIVING Ent=BotEntiGet(Enti);
  if(Ent==NULL) return NULL;
  /* declare type = f(model)*/
  Ent->Model = Model;
  Ent->ETyp  = Bot2.Models[Model].ETyp;
  if(BotIsPlayer(pBot,Enti)==TRUE)
  {
    Ent->ETyp |= EFLAG_PLAYER|EFLAG_DANGER|ETYPE_FOE;
    Ent->pPlay= BotPlayerGet(pBot, Enti);
  }
  else
  {
    Ent->pPlay=NULL;
    if(Enti==0)
    { Ent->ETyp|= EFLAG_WORLD;}
  }
  return Ent;
}
/* preserve position */
void BotSrvEntiChanging(pBOT pBot,ENTITY Enti)
{
  pELIVING Ent = BotEntiGet(Enti);
  if(Ent==NULL) return;
  /*
  ** Preserve two previous positions, to caclulate evolutions
  */
  Ent->Time2=Ent->Time1;
  VecCpy(&Ent->Origin2,&Ent->Origin1);
  AngCpy(&Ent->Angles2,&Ent->Angles1);
  Ent->Time1=Ent->Time;
  VecCpy(&Ent->Origin1,&Ent->Origin);
  AngCpy(&Ent->Angles1,&Ent->Angles);
  /**/
  Ent->Time = pBot->Time; /*declare updated*/
#if 0 /*debug*/
  if(Ent==pBot->Self)
  { printf("Bot Time= %8.3f   OldTime= %8.3f\n", (float)Ent->Time, (float)Ent->Time1); }
#endif
}
/* got an update for this entity */
void BotSrvEntiSeen(pBOT pBot, ENTITY Enti)
{
#if 0
  pEPLAYER pPlay;
  pInt8 Name;
#endif
  /* Do not see oneself */
  if(Enti==pBot->Me) return;
  /* Add to the list of entities seen */
  SEENput(Enti);
#if 0
  pPlay = BotPlayerGet(&Bot,Enti);
  if(pPlay!=NULL)
  { printf("Saw player %5d  %.32s\n",(int)Enti, &(pPlay->Name[0]));}
  else
  {
    Name= BotEntiGetModel(Enti);
    if(Name==NULL)
    { printf("Saw entity %5d INVALID!\n",(int)Enti);}
    else
    { printf("Saw entity %5d  %.56s\n",(int)Enti, Name);}
  }
#endif
  return;
}
/*
** Sound
*/
void BotSrvSound(pBOT pBot, Int32 Soundnb, pVEC3 Origin, ENTITY Enti, Int16 Channel, Int16 Volume)
{
  pELIVING Ent;
#if 0
  pEPLAYER pPlay;
#endif
  /*get sound from Soundnb, entity from Enti*/
  if((Soundnb<0)||(Soundnb>=SOUNDSMAX)) { return;}
  if(Origin==NULL) return;
  /*locate entity from sound*/
  Ent= BotEntiGet(Enti);
  if(Ent!=NULL)
  { /* Check if origin already set by a previous update message */
    if(Ent->Time==pBot->Time)
    { return; }
    /* Update origin of entity, trusting it on sound */
    VecCpy(&(Ent->Origin),Origin);
    /* Tell player */
#if 0
    printf("At %6.1f %6.1f %6.1f", (float)Origin->X, (float)Origin->Y, (float)Origin->Z);
    pPlay = BotPlayerGet(pBot,Enti);
    if(pPlay==NULL)
    { printf("Entity %5d chan:%3d",(int)Enti, (int)Channel); }
    else
    { printf("Player %.32s chan:%3d",pPlay->Name,(int)Channel);}
    printf(" sound %s\n", Bot2.Sounds[(Int)Soundnb].File);
#else
  (void)Channel;
#endif
  }
  (void) Volume;
  return;
}
/****************************************************\
*
*   Bot handles messages from player
*
\****************************************************/
/*
** Bot receives message from player  (intercepts)
*/
void BotReceivePlayer(pDTA pDta)
{
  /*
  ** Interpret each message and send it to the right function
  ** Beware, the reply is constructed into Bot2.Dta
  */
  DtaClear(&Bot2.Dta);
  QPlayReceive(pDta, &Bot2.Dta);
  if(Bot2.Pto!=NULL)
    PtoSendUnreliable(Bot2.Pto,&Bot2.Dta);
  return;
}
/*
** Called when player issues a Keep Alive message
*/
void BotPlayKeepAlive(pDTA pReply)
{
  /* Add "keep alive" to Bot2.Dta*/
#if 1
  printf("Client->Server  Keep Alive\n");
#endif
  QPlayMakKeepAlive(pReply);
}
/*
** Called when player issues a Disconnect message
*/
void BotPlayDisconnect(pDTA pReply)
{
  /* Add "disconnect" to the reply*/
  QPlayMakDisconnect(pReply);
  /* don't add, if we want to survive the real client */
}
/*
** Called when player issues an Action message
*/
void BotPlayAction(pDTA pReply, TIME Time, pANGLES Angles, pVEC3 Speeds, Int16 Flags, Int16 Impulse)
{
  /*Intercept some impulse*/
  Impulse = THINKplayerMoveCb(&Bot, Speeds, Impulse);
  /*Preserve desired player angles*/
  AngCpy(&(Bot.Angles), Angles);
  BotActionMoveClient(&Bot, Angles, Speeds, Flags, Impulse);
  (void)pReply;  /* do not send movement in the same message */
  (void)Time;
}
/*
** Called when player issues a Console command message
*/
void BotPlayCommand(pDTA pReply, pInt8 Str)
{ /*Warning, string is unreliable*/
  if(Str==NULL) return;
  Strncpy(BotBuff, Str, sizeof(BotBuff)-1);
  if(THINKplayerConsoleCb(&Bot, BotBuff, sizeof(BotBuff))!=FALSE)
  { /* Add "Command" to the reply*/
    QPlayMakConsole(pReply, Str);
  }
}

/****************************************************\
*
*  Local messages (sent only yo player connected to the bot)
*
\****************************************************/
/*
** Send a single text message to the player connected to the bot
*/
void BotLocalPrintf(pBOT pBot, Int32 How, pInt8 Message, ...)
{
  va_list argptr;
  /* highlighted text*/
  BotBuff[0]= (Int8)((How&HIGHLIGHT)? '\02': '\0');
  /* sprintf */
  va_start(argptr, Message);
  vsprintf(&(BotBuff[(How&HIGHLIGHT)?1:0]), Message, argptr);
  va_end(argptr);
  DtaClear(&Bot2.DtaW);
  QSrvMakSprint(&Bot2.DtaW, BotBuff, ((How&CENTERED)?TRUE:FALSE));
  if(Bot2.PtoW!=NULL)
  { PtoSendUnreliable(Bot2.PtoW,&Bot2.DtaW);}
  (void)pBot;
}
/*
** Send a particle
*/
void BotLocalParticle(pBOT pBot, pVEC3 Origin, pVEC3 Velocity, Int16 Color, Int16 Nb)
{
  switch(Color)
  { case BOT_PARTICLE_RED: Color =PARTICLE_COLOR_BOOD; break;
    case BOT_PARTICLE_GREEN: Color =PARTICLE_COLOR_SLIME; break;
    case BOT_PARTICLE_GREY: Color =PARTICLE_COLOR_GREY; break;
    case BOT_PARTICLE_GOLD: Color =PARTICLE_COLOR_YELLOW; break;
    default: Color &= 0xFF;
  }
  DtaClear(&Bot2.DtaW);
  QSrvMakParticle(&Bot2.DtaW, Origin, Velocity, (UInt8)Color, (UInt8)(Nb&0xFF));
  if(Bot2.PtoW!=NULL)
  { PtoSendUnreliable(Bot2.PtoW,&Bot2.DtaW);}
  (void)pBot;
}
/*
** create a fake entity on local display
*/
void BotLocalEntity(pBOT pBot, Int32 Typ, pVEC3 Origin, pVEC3 TraceEnd)
{
  DtaClear(&Bot2.DtaW);
  if(QSrvMakTempEntity(&Bot2.DtaW, Typ, Bot.Me, Origin, TraceEnd)<0)
  { ERRwarn("Invalid entity type %04x", Typ); return;}
  if(Bot2.PtoW!=NULL)
  { PtoSendUnreliable(Bot2.PtoW,&Bot2.DtaW);}
  (void)pBot;
}
/****************************************************\
*
*   Bot handles messages from Stdin
*
\****************************************************/

/*
** Called when bot receives a message from keyboard
*/
void BotReceiveStdin(pDTA pDta)
{
  static Int8 Cmd[256];
  int sz,s;
  pInt8 Param;
  /* copy string to Str, and put zero at the end */
  sz = DtaSize(pDta);
  sz = min(sz,sizeof(Cmd)-1);
  Strncpy(Cmd, DtaData(pDta), sz); /*Str[sz]='\0';*/
  /* find parameter string*/
  for(s=0; (s<sz)&&(!isspace(Cmd[s])); s++);
  Cmd[s]='\0';
  for(; (s<sz)&& (isspace(Cmd[s])); s++);
  Param = &Cmd[s];
  /*
  ** Check for commands
  */
  if(PtoIsConnected(Bot2.Pto)!=TRUE)
  {
    switch(tolower(Cmd[0])) /*first character is a command*/
    {
      case 'c': /*connect*/
        printf("Sending connect request\n");   
        /* update host name */
        if(Param[0]!='\0')
        { PtoReInit(Bot2.Pto, Param); }
        PtoSendConnect(Bot2.Pto);
        break;
      case 'i': /*info*/
        printf("Sending server info request\n");
        PtoSendAskInfos(Bot2.Pto);
        break;
      case 'p': /*player info*/
        printf("Sending player info request\n");
        PtoSendAskPlayer(Bot2.Pto,1);
        break;
      case 'q': /*quit*/
        exit(0);
        break;
      case 'r': /*rule*/
        printf("Sending rule info request\n");
        PtoSendAskRule(Bot2.Pto,NULL);
        break;
      case 's': /*slist*/
        printf("SLIST is not implemented yet\n");
        break; /*should do a SLIST*/
      default:
        printf("Commands for the bot (only first character is needed)\n");
        printf("slist               List all local servers.\n");
        printf("info                Request server infos.\n");
        printf("player              Request player infos\n.");
        printf("rule                Request rule infos.\n");
        printf("connect [host:port] Connect and start playing.\n");
        printf("quit                Exit from the bot");
        break;
    }
  }
  else /* Bot is connected */
  {
    switch(tolower(Cmd[0])) /*first character is a command*/
    {    
      case 'q': /*quit*/
        printf("Disconnect\n");
        BotActionDisconnect(&Bot);
        break;
		case 'p': /*player*/
        BotPlayerDebug(&Bot);
        break;
		case 'n': /*netstat*/
		  PtoPrintStats(Bot2.Pto);
		case 's': /*say*/
		  printf("Say %.256s\n", Param);
		  BotActionPrintf(&Bot, "%.256s", Param);
		  break;
      case 'f': /*fire*/
        printf("Fire!\n");
        BotActionMove(&Bot, NULL,NULL, BOT_FIRE,0);
        break;
      case 'j': /*jump*/
        printf("Jump!\n");
        BotActionMove(&Bot, NULL,NULL, BOT_JUMP,0);
        break;
      case 'k': /*kill*/ 
        BotPlayerHate(&Bot, 0, 100); /* Hate all players */
        break;
#if DEBUG
		case 'a': /*player*/
		  BotEntiDebugPos(EFLAG_PLAYER);
		  break;
      case 'e': /*entities*/
		  BotEntiDebug(EFLAG_MASK);
		  break;
		case 'd': /*show only danger*/
        BotEntiDebugPos(EFLAG_DANGER);
		  break;
		case 'z':
        if(Bot.Self!=NULL)
        {
          printf("Bot.Angles tilt=%6.1f yaw=%6.1f\n",
             (float)ANGLE2DEG(Bot.Angles.Tilt),
             (float)ANGLE2DEG(Bot.Angles.Yaw));
          printf("Bot.Self0  tilt=%6.2f yaw=%6.2f  (%6.2f %6.2f %6.2f) t=%8.3f\n",
             (float)ANGLE2DEG(Bot.Self->Angles.Tilt),
             (float)ANGLE2DEG(Bot.Self->Angles.Yaw),
             (float)Bot.Self->Origin.X, (float)Bot.Self->Origin.Y, (float)Bot.Self->Origin.Z,
             (float)Bot.Self->Time);
          printf("Bot.Self1  tilt=%6.2f yaw=%6.2f  (%6.2f %6.2f %6.2f) t=%8.3f\n",
             (float)ANGLE2DEG(Bot.Self->Angles1.Tilt),
             (float)ANGLE2DEG(Bot.Self->Angles1.Yaw),
             (float)Bot.Self->Origin1.X, Bot.Self->Origin1.Y, Bot.Self->Origin1.Z,
             (float)Bot.Self->Time1);
        }
        break;
      case 'x':
        BotEntiDebugPos(EFLAG_MASK);
        break;
      case 'm':
        BotModelDebug();
        break;
#endif
      default:
        printf("Commands for the bot (only first character is needed)\n");
        printf("quit                Quit, stop playing.\n");
        printf("player              List all players\n");
        printf("netstat             Print network statistics.\n");
        printf("say <message>       Say something.\n");
        printf("fire                Fire.\n");
        printf("jump                Jump.\n");
#if DEBUG
        printf("entities            List all entities.\n");
        printf("danger              List all dangerous stuff.\n");
#endif
        break;
    }
  }
  return;
}


