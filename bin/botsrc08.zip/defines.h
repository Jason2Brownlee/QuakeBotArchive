/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy 
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/
#ifdef __cplusplus
extern "C" {            /* Assume C declarations for C++ */
#endif  /* __cplusplus */
/*
** Select system
*/
#define SYS_WIN32CSL  0
#define SYS_WIN32     0
#define SYS_WIN16     0
#define SYS_DOS       0
#define SYS_UNIX      0
#define SYS_AIX       0
#define SYS_LINUX     0

#if (defined __CONSOLE__)
#undef  SYS_WIN32CSL
#define SYS_WIN32CSL  1
#elif (defined __WIN32__)
#undef  SYS_WIN32
#define SYS_WIN32     1
#elif (defined __WINDOWS__)||(defined _Windows)
#undef  SYS_WIN16
#define SYS_WIN16     1
#elif (defined __DOS__)
#undef  SYS_DOS
#define SYS_DOS       1
#else
/*Unix and variants*/
#undef  SYS_UNIX
#define SYS_UNIX      1
/* detect if system is AIX (IBM O/S, non standard) */
#if (defined _AIX)||(defined _AIX32)
#undef SYS_AIX
#define SYS_AIX 1
#endif
#if (defined _LINUX)
#undef SYS_LINUX
#define SYS_LINUX 1
#endif
#endif
/*
** Big Endian or little endian?
*/
#define SYS_BIGENDIAN  ((SYS_DOS)||(SYS_WIN16)||(SYS_WIN32)||(SYS_WIN32CSL)||(SYS_LINUX))
/*
** Borlands C++  allow the use of sizeof() with C PreProcessor
*/
#define SYS_CPPSIZEOF  ((SYS_DOS)||(SYS_WIN16)||(SYS_WIN32)||(SYS_WIN32CSL))
/*
** Windows DLL specific
*/
#if (SYS_WIN16)&&( defined __DLL__)
#define EXPORT   _far PASCAL _export
#define _WINDLL
#elif (SYS_WIN32)||(SYS_WIN32CSL)
#define EXPORT
#else
#define EXPORT
#define PASCAL _pascal
#endif
/*
** Huge pointer  for 16-bit DOS/Windows
*/
#if (SYS_DOS)||(SYS_WIN16)
#define PTR huge
#else
#define PTR
#endif
/*
** Type definitions, assume 32 bit processor
*/
typedef char 		Int8;
typedef unsigned char 	UInt8;
typedef short 		Int16;
typedef unsigned short 	UInt16;
typedef long 		Int32;
typedef unsigned long 	UInt32;
typedef float           Float32;
typedef double          Float64;
typedef void   PTR    * pVoid;
typedef Int8   PTR    * pInt8;
typedef UInt8  PTR    * pUInt8;
typedef Int16  PTR    * pInt16;
typedef UInt16 PTR    * pUInt16;
typedef Int32  PTR    * pInt32;
typedef UInt32 PTR    * pUInt32;
typedef Float32 PTR   * pFloat32;
typedef Float64 PTR   * pFloat64;
/*
** To resolve conflicts with Windoze API
*/
typedef char            Char;
typedef unsigned char   UChar;
typedef char   PTR    * pChar;     /* char FAR* */
typedef short  PTR    * pShort;
typedef unsigned short  UShort;
typedef int             Int;       /* default int, for %d*/
typedef int    PTR    * pInt;      /* int FAR * */
typedef unsigned int    UInt;      /* default int, for %d*/
typedef long            Long;      /* default long, for %ld*/
typedef long   PTR    * pLong;
/*
**  Special types
*/
typedef short 		Bool;
#define TRUE 		((Bool)1)
#define FALSE 		((Bool)0)

#define max(a,b)    (((a) > (b)) ? (a) : (b))
#define min(a,b)    (((a) < (b)) ? (a) : (b))

#ifdef __cplusplus
}            /* Assume C declarations for C++ */
#endif  /* __cplusplus */

