/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"
#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "data.h"
#include "udp.h"
#include "qkpto.h"
#include "qkptomsg.h"  /*Protocol machine init/free*/
#include "qkdefs.h"   /*Quake Defs*/
#include "qkpak.h"    /*Quake pak stuff */

#define DEBUG 0

/*
** 129.199.96.11 (dmi)
*/
#define DEFAULTPORT (26000)
#define MYPORT      (26000)
#if 1
#define DEFAULTHOST "161.104.10.99:26000"
#else
#define DEFAULTHOST  "LOCAL:26000"
#endif

/****************************************************\
*
*  Quake client
*
\****************************************************/
static DISPATCH Disp;   /* Dispatcher*/
static PTO      Pto;    /* Quake client Protocol machine */
static PTO      PtoW;   /* Quake world protocol machine */
/**/
int Run(pInt8 ServerHost, Int32 ServerPort, Int32 MyPort, Bool Auto)
{
  /*
  ** Print status
  */
  printf("Bot listening on port: %ld.\n",(long)MyPort);
  /*
  ** Init dispatcher
  */
#if DEBUG
  printf("Init Dispatcher\n");
#endif
  if(DispatchInit(&Disp,ServerHost,ServerPort, MyPort)<0)
  {
    return ERRwarn("initialisation failed");
  }
  /* print peer */
  if(ClientPeerAdrsPrint(&(Disp.Client), Buff, sizeof(Buff)-1)>0)
  { printf("Game Server: %s.\n",Buff); }
  else
  { ERRwarn("initialisation failed"); }
  /*
  ** Init protocol machine and bot, for this client
  */
#if DEBUG
  printf("Init Protocol\n");
#endif
  /*
  ** Pto for messages from Client
  ** Assoc: normal messages to PtoW, controls to Disp.Server
  */
  if(PtoInit(&Pto, &(Disp.Client), &PtoW, &(Disp.Server))<0)
  { return -1; }
  /*
  ** PtoW for messages from World
  ** Assoc: normal messages to Pto, controls to NULL
  */
  if(PtoInit(&PtoW, &(Disp.World), &Pto, NULL)<0)
  { return -1; }
  /*
  ** Run client with protocol machine
  */
  /* Callback for messages from keyboard */
  CbSet(&Disp.StdinCb, PtoReceiveStdin, &Pto);
  /* Callback for server messages */
  CbSet(&Disp.ClientCb, PtoReceive, &Pto);
  /* Callback for Iddle times */
  CbSet(&Disp.IddleCb, PtoIddle, &Pto);
  Disp.IddleTime = 10; /*one 10th of second*/
  /* Callback for messages from real client to fake world */
  CbSet(&Disp.WorldCb, PtoReceive, &PtoW);
  /* Callback for messages from real client to fake server */
  CbSet(&Disp.ServerCb, PtoReceiveServer, &Pto);
  /*
  ** Start game, if needed
  */
  if(Auto==TRUE)
  {
    printf("Sending Ask Info request\n");
    PtoSendAskInfos(&Pto);
    printf("Sending Connect request\n");
    PtoSendConnect(&Pto);
  }
#if DEBUG
  printf("Bot is now running.\n");
#endif
  /* Run */
  DispatchRun(&Disp);
  printf("Bot Exited\n");
  /*
  ** End Protocol machine and bot
  */
  PtoFree(&Pto);
  PtoFree(&PtoW);
  /*
  ** End dispatcher
  */
  DispatchFree(&Disp);
  return 1;
}

int main(int argc, char **argv)
{
  pInt8 GameDir = "id1";
  pInt8 ServerHost = DEFAULTHOST;
  Int32 ServerPort = DEFAULTPORT;
  Int32 MyPort = MYPORT;
  Bool Auto= FALSE;
  Int i;
#if ISWINSOCK
  /*Start Winsock*/
  ClientWSAStartup();
#endif
  /*
  ** Decode command line arguments
  */
  printf("Quake Proxy Bot version %s\n", BOTVERSION);
  printf("Copyright (c) 1996 Olivier.Montanuy@wanadoo.fr\n");
  printf("Type: bot -h  to get some help\n");
  for(i=1; i<argc; i++)
  {
    if(argv[i]==NULL) break;
    if(argv[i][0]=='\0') continue;
    if((argv[i][0]=='-')||(argv[i][0]=='/'))
    {
      switch(argv[i][1])
      {
        case 'a': case 'A':  /* -a*/
          Auto = TRUE;
          break;
        case 'p': case 'P':  /* -p */
          if((++i)<argc) MyPort= atoi(argv[i]);
          break;
        case 'g': case 'G':  /* -g */
          if((++i)<argc) GameDir= argv[i];
          break;
        case 'h': case 'H': case '?':
          printf("\nCommand line:\n");
          printf("  bot SERVER_IP_ADDRESS:SERVER_PORT \n");
          printf("Options:\n");
          printf("    -p BOT_PORT       Port for proxy mode (26000)\n");
          printf("    -auto             Automatic, proxy mode off.\n");
          printf("    -game DIRECTORY   Directory for custom files (id1)\n");
          printf("Example:\n");
          printf("  bot choke.tax.gov:26000 -auto  -game theft \n\n");
          printf("If this proxy bot is run from the same directory as Quake.exe,\n");
          printf("it will check that each model and sounds is really available.\n");
          printf("\n");
          printf("Once the bot is started, you can connect to it as if it was a\n");
          printf("genuine Quake server. But you can also let it play in automatic.\n");
          return 0;
        default:
          ERRwarn("Unknown command %s", &(argv[i][1]));
          break;
      }
    }
    else
    { ServerHost = argv[i]; }
  }
  /*
  ** Init file database. The list must end with NULL.
  */
  DBinit(GameDir,"id1/pak0.pak","id1/pak1.pak", NULL);
  /*
  ** Run client
  */
  Run(ServerHost,ServerPort,MyPort,Auto);
  /*
  ** Free file database
  */
  DBfree();
#if ISWINSOCK
  /*Stop Winsock*/
  ClientWSACleanup();
#endif
  return 1;
}

