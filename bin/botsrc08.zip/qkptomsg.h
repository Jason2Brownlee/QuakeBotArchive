/****************************************************\
*
*  PTO2 = Non-opaque version of PTO
*
\****************************************************/
typedef struct _PTO2
{
  pCLIENT pClient;       /* Packet Emission*/
  struct _PTO2 PTR *AssocPto2;      /* Associated Pto, if NULL, invalid*/
  pSERVER AssocSrv;      /* Associated server, if NULL, invalid*/
  Int32 RecvTotal;       /* Total size received*/
  Int32 SendTotal;       /* Total size sent*/
  Int32 SendReliable;    /* last reliable message sent*/
  Int32 RecvReliable;    /* nb of reliable messages*/
  Int32 SendUnreliable;  /* last unreliable message sent*/
  Int32 RecvUnreliable;  /* nb of unreliable messages*/
  DTA   SendDta;         /* sending reliable message*/
  DTA   RecvDta;         /* receiving reliable message*/
  DTA   SDta;            /* sending ordinary messages*/
  DTA   TmpDta;          /* Temporary data*/
  Bool  PackComplete;
  Bool  IsConnected;     /* connected to server */
  Bool  IsClient;        /* TRUE if is the fake client*/
  Int16 IsAuto;          /* <0 if faking ckient, >0 if playing in automatic */
                         /* 0 if not decided */
} PTO2;
typedef PTO2 PTR *pPTO2;
#if SYS_CPPSIZEOF
#if (sizeof(PTO2) > sizeof(PTO))
#error Size of PTO is too small, please make it > PTO2
#endif
#endif

/****************************************************\
*
*  Functions to init and free a protocol machine
*
\****************************************************/
/*
** Init
*/
Int32 PtoInit(pPTO pPto, pCLIENT pClient, pPTO pAssocPto ,pSERVER pAssocServer);
/*
** Free
*/
Int32 PtoFree(pPTO pPto);
/*
** Use as callback, for iddle times. pDta is NULL.
*/
Int32 PtoIddle(pVoid pPtoV, pDTA pDta);
/*
** Use as callback, to treat a message received from peer
*/
Int32 PtoReceive(pVoid pPtoV, pDTA pDta);
/*
** Use as callback, to treat a message received from Stdin
*/
Int32 PtoReceiveStdin(pVoid pPtoV, pDTA pDta);
/*
** Use as callback, to treat a message received by assoc fake server
*/
Int32 PtoReceiveServer(pVoid pPtoV, pDTA pDta);


/*
** Functions that are to be called only by the decoder of control
** messages. DO NOT USE for anything else
*/
/* Handle requests from client */
Int32 PtoRecvConnect(pPTO2 pPto2, const pInt8 Game, Int32 Version);
/*
** Received a query for informations
*/
Int32 PtoRecvAskInfos(pPTO2 pPto2, const pInt8 Game, Int32 Version);
/*
** Received a query for player info.
** player = 1...maxplayers
*/
Int32 PtoRecvAskPlayer(pPTO2 pPto2, Int32 Player);
/*
** Received a query for rules
*/
Int32 PtoRecvAskRule(pPTO2 pPto2, const pInt8 Rule);
/* Handle requests from server */
/*
**  Received an answer: connection accepted
*/
Int32 PtoRecvAccept(pPTO2 pPto2, Int32 Port);
/*
**  Received an answer: connection refused
**  Text = reasonfor refusal
*/
Int32 PtoRecvRefuse(pPTO2 pPto2, const pInt8 Text);
/*
**  Received an answer: game infos
**  Adrs = "ip:port" like "gizmo.lame.gov:26000"
*/
Int32 PtoRecvGameInfos(pPTO2 pPto2, const pInt8 Adrs, const pInt8 Host, const pInt8 Map, Int16 Players, Int16 Playmax, Int16 Version);
/*
**  Received an answer: player infos
** Player = 1... Playermax
*/
Int32 PtoRecvPlayerInfos(pPTO2 pPto2, Int32 Player, const pInt8 Name, const pInt8 Adrs, Int32 Color, Int32 Frags, Int32 Time);
/*
**  Received an answer: rule infos
** Name = rule name
*/
Int32 PtoRecvRuleInfos(pPTO2 pPto2, const pInt8 Name,const pInt8 Value);
