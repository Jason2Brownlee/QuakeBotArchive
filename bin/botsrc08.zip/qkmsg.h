/*
** Quake message handling
**
** Conventions:
**  Pck = Packets received from either client or server
**  Cmd = Commands send by the Quake client (the player)
**  Msg = Messages from the Quake server (the world)
*/

/****************************************************\
*
*    Quake Packets
*
\****************************************************/
/*
** Type of packets
*/
#define QPCK_CONTROL	(0x8000L)
#define QPCK_LMPART	(0x01L)
#define QPCK_LMACK	(0x02L)
#define QPCK_LMEND  	(0x09L)
#define QPCK_UPDATE     (0x10L)
/*
** Prints the entire packet contents
** (Warning: this sets the pointer to zero)
*/
Int32 QPckDump(pDTA pDta); 
/*
** Get Quake Packet header
**  Typ   = type of packet
**  Order = sequence order of packet
**  return Size of packet, or <0 if error
*/
Int32 QPckGetHeader(pDTA pDta, pInt32 pTyp, pInt32 pOrder);
#if 1
/*
** Make Packet
**  Typ       = type of packet
**  Order     = sequence order
**  Content   = pointer to the contents of message
**  ContentSz = size of content
*/
Int32 QPckMakPacket(pDTA pDta, Int32 Typ, Int32 Order, pInt8 Content, Int32 ContentSz);
#else /*Outdated*/
/*
** Make Packet  
**  Typ = type of packet
**  Order = sequence order
**  pContent = contents of message, copied into packet
*/
Int32 QPckMakPacket(pDTA pDta, Int32 Typ, Int32 Order, pDTA pContent);

/*
** OBSOLETE: Make Quake Packet header
**  Call first, before writing orders
**  (set write pointer correctly, for adding orders)
*/
Int32 QPckMakHeader(pDTA pDta, Int32 Typ, Int32 Order);
/*
** OBSOLETE: Finish Quake Packet, and set the right size
**  Call this after writing orders
**  (set write pointer to zero, do not write more orders)
*/
Int32 QPckMakSize(pDTA pDta);
#endif /*Outdated*/

/****************************************************\
*
*    Quake Controls
*
\****************************************************/
#define QCTL_CONNECT   (0x01)   /*CCREQ_CONNECT*/
#define QCTL_ASKINFO   (0x02)   /*CCREQ_SERVER_INFO*/
#define QCTL_ASKPLAYER (0x03)   /*CCREQ_PLAYER_INFO*/
#define QCTL_ASKRULE   (0x04)   /*CCREQ_RULE_INFO*/
#define QCTL_ACCEPT    (0x81)   /*CCREP_ACCEPT*/
#define QCTL_REFUSE    (0x82)   /*CCREP_REJECT*/
#define QCTL_GIVINFO   (0x83)   /*CCREP_SERVER_INFO*/
#define QCTL_GIVPLAYER (0x84)   /*CCREP_PLAYER_INFO*/
#define QCTL_GIVRULE   (0x85)   /*CCREP_RULE_INFO*/
/* disconnect message, while playing */
#define QPLAY_DISCONNECT (0x02)
/*
** Make some CTRL message
*/
/* Connect request*/
Int32 QCtlMakConnect(pDTA pDta);
/* Ask Game Infos */
Int32 QCtlMakAskInfos(pDTA pDta);
/* Ask Player infos */
Int32 QCtlMakAskPlayer(pDTA pDta, Int32 Player);
/* Ask Rule (Rule==NULL, for first rule)*/
Int32 QCtlMakAskRule(pDTA pDta, pInt8 Rule);
/* Accept connection*/
Int32 QCtlMakAccept(pDTA pDta, Int32 Port);
/* Refuse connection*/
Int32 QCtlMakRefuse(pDTA pDta, pInt8 Reason);
/* Give game informations */
Int32 QCtlMakGiveInfos(pDTA pDta,  pInt8 Adrs, pInt8 Host, pInt8 Map, Int16 Players, Int16 Playmax, Int16 Version);
/*
** Interpret messages for a given Protocol machine
*/
Int32 QCtlInterpret(pPTO2 pPto2, pDTA pDta);



