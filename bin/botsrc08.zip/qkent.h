/****************************************************\
*
*  Models and Sound precaches
*
\****************************************************/
/*
** Get pointer to model file, or NULL if not valid
*/
pInt8 BotModelGet(Int32 Index);
/*
** Get pointer to sound file, or NULL if not valid
*/
pInt8 BotSoundGet(Int32 Index);

/****************************************************\
*
*  Player infos
*
\****************************************************/
/*
** Players
*/
typedef struct
{
  /* Custom */
  Int32 Hate;    /*How much Bot hates this player*/
  /* Quake */
  Int16 Frags;   /*number of frags*/
  Int8  Pants;   /*color of pants (team)*/
  Int8  Shirt;   /*color of shirt*/
  Int8  Name[32]; /*player name*/
} EPLAYER;
typedef EPLAYER PTR  *pEPLAYER;

/****************************************************\
*
*  Entity List
*
\****************************************************/
/*
** Entity Informations
*/
typedef struct
{
  /*
  ** entity number, a reference used by Quake
  */
  Int32 Me; /* if <0, then the entity is static*/
  /*
  ** Stuff calculated by the bot
  ** (by function MovePrepare() in qkmove.h)
  */
  VEC3   Delta;       /* pBot->Self->Origin - Ent->Origin */
  SCALAR DeltaNorm2;  /* Norm of Delta */
  /*
  ** if entity is a player, points to Player infos
  ** if entity is not a player, NULL
  */
  pEPLAYER pPlay;
  /*
  ** Last Known Position
  */
  TIME   Time;   /*last time it was touched*/
  VEC3   Origin; /*Origin*/
  ANGLES Angles; /*Angles*/
  /*
  ** Previously known position
  */
  TIME   Time1;  /*previous time*/
  VEC3   Origin1;
  ANGLES Angles1;
  /*
  ** Previously previously known position
  */
  TIME   Time2;  /*previous time*/
  VEC3   Origin2;
  ANGLES Angles2;
  /*
  ** Entity flags and type
  */
  ETYPE  ETyp;
  /*
  ** Model related stuff
  */
  Int16  Model;   /* Index of model*/
  Int16  Frame;   /* Frame number, in model*/
  Int16  Skin;    /* Skin number, in model*/
  Int16  Colormap;/* Colormap*/
  Int16  Attack;  /* see ATTACK TYPE in qkdefs.h  (AS_xxxx) */
  Int16  Dummy;   /* padding */
} ELIVING;
typedef ELIVING PTR  *pELIVING;
typedef ELIVING PTR *PTR *ppELIVING; /*table of pointers*/
/*
** Get pointer to an Entity, or NULL if no entity
*/
pELIVING BotEntiGet(ENTITY Enti);
/*
** Get pointer to a static entity, or NULL if no entity
*/
pELIVING BotEntiStaticGet(ENTITY Enti);
/*
** Find closest entity of a given type
**  if ETyp & EFLAG_MASK !=0, check that all flags are up
**  if ETyp & ETYPE_MASK !=0, consider only that type
**  EntSkip = entity that must be skipped (typically, Self)
** returns NULL if nothing found
*/
pELIVING BotEntiFindClosest(pVEC3 pOrigin, ETYPE ETyp, pELIVING EntSkip);



