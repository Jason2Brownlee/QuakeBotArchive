/****************************************************\
*
*  Functions needed to start/stop a bot
*   Used only be protocol machine
*
\****************************************************/
/*
** Initialise the bot
*/
Int32 BotInit(pPTO pPto, pPTO pPtoW);
/*
** Free the bot
*/
void BotFree(void);
/*
** bot received no messages for a long time
*/
void BotIddle(void);
/*
** bot becomes passive. A real client is about to take over
*/
void BotPassive(void);
/*
** bot receives a message
*/
void BotReceive(pDTA pDta, Bool Reliable);
/*
** Bot receives message from player  (intercepts)
*/
void BotReceivePlayer(pDTA pDta);
/*
** bot receives a message from keyboard
*/
void BotReceiveStdin(pDTA pDta);


