/****************************************************\
*
*     Bot Type
*
\****************************************************/
#define BOTNETNAME  "TERMINATOR"
#define BOTNETCOLOR (0x11)
#define BOTVERSION  "0.8"
/****************************************************\
*
*    Type defintions
*
\****************************************************/
/*
** Entity  (<0=static, 0=world, >0= non static)
*/
typedef Int32        ENTITY;  /*must be signed*/
typedef ENTITY PTR *pENTITY;
/*
** Entity type
*/
typedef UInt32       ETYPE;
typedef ETYPE PTR  *pETYPE;

/****************************************************\
*
*    ENTITIES FLAGS AND TYPES
*
\****************************************************/
/*
**            ######## #### ####
** Structure:   flags |type|ident
*/
#define ETYPE_MASK    (0x00FF) /* Mask to get only the generic type*/
#define EFLAG_NONE    (0x0000) /* No flag */
#define EFLAG_MASK    (0xFF00) /* No flag */
#define EFLAG_STATIC  (0x0100) /* Flag: Entity is static */
#define EFLAG_WORLD   (0x0200) /* Flag: World entity, or part of world */
#define EFLAG_PLAYER  (0x0400) /* Flag: A Player */
#define EFLAG_MONSTER (0x0800) /* Flag: A Monster */
/*Dangers*/
#define EFLAG_DANGER  (0x1000) /* A Dangerous thing */
#define ETYPE_MISSILE (0x0001) /* slow missile */
#define ETYPE_GRENADE (0x0002) /* bouncing missile */
#define ETYPE_SPIKE   (0x0003) /* fast missile */
#define ETYPE_LAVA    (0x0004) /* lava, lava ball */
#define ETYPE_FOE     (0x0005) /* monster or player */
/*Goodies*/
#define EFLAG_GOODIE  (0x2000) /* A Good thing */
#define  ETYPE_WEAPON (0x0010) /* weapon */
#define   ETYPE_WEAPON_SHOT (0x0013) /* weapon shotgun */
#define   ETYPE_WEAPON_NAIL (0x0014) /* weapon nailgun */
#define   ETYPE_WEAPON_SUPN (0x0015) /* weapon quper nailgun */
#define   ETYPE_WEAPON_GREN (0x0016) /* weapon grenade launcher */
#define   ETYPE_WEAPON_ROCK (0x0017) /* weapon rocket launcher */
#define   ETYPE_WEAPON_LITE (0x0018) /* weapon lightning */
#define  ETYPE_HEALTH (0x0020) /* health */
#define  ETYPE_AMMO   (0x0030) /* Ammo */
#define   ETYPE_AMMO_SHOT (0x0031) /* Ammo shot */
#define   ETYPE_AMMO_NAIL (0x0032) /* Ammo nail */
#define   ETYPE_AMMO_ROCK (0x0034) /* Ammo rocket */
#define   ETYPE_AMMO_CELL (0x0038) /* Ammo cell */
#define   ETYPE_AMMO_PACK (0x003F) /* Ammo backpack*/
#define  ETYPE_ARMOR  (0x0040) /* Power-up*/
#define  ETYPE_POWER  (0x0050) /* Power-up*/
/*
** Attack types
*/
#define AS_NONE       0 /* don't attack */
#define AS_STRAIGHT   1 /* straight shot */
#define AS_SLIDING    2 /* move to a side */
#define AS_MELEE      3 /* single combat (dog, ogre) */
#define AS_MISSILE    4 /* shooting attack */

/****************************************************\
*
*    ITEMS
*
\****************************************************/
/* Weapons*/
#define	IT_AXE               (0x00001000L)
#define IT_SHOTGUN           (1)
#define IT_SUPER_SHOTGUN     (2)
#define IT_NAILGUN           (4)
#define IT_SUPER_NAILGUN     (8)
#define IT_GRENADE_LAUNCHER  (16)
#define IT_ROCKET_LAUNCHER   (32)
#define IT_LIGHTNING	     (64)
#define IT_EXTRA_WEAPON	     (128)
/* Ammo */
#define IT_SHELLS            (256)
#define IT_NAILS             (512)
#define IT_ROCKETS           (1024)
#define IT_CELLS             (2048)
/* Green, yellow, red armors */
#define IT_ARMOR1            (0x00002000L)
#define IT_ARMOR2            (0x00004000L)
#define IT_ARMOR3            (0x00008000L)
/* mega health */
#define IT_SUPERHEALTH       (0x00010000L)
/* key is Silver */
#define IT_KEY1              (0x00020000)
/* key is Gold */
#define IT_KEY2              (0x00040000)
/* Ring of shadows */
#define IT_INVISIBILITY      (0x00080000L)
/* Pentagram of protection */
#define IT_INVULNERABILITY   (0x00100000L)
/* Bio suit */
#define IT_SUIT              (0x00200000L)
/* Quad damages */
#define IT_QUAD              (0x00400000L)
/* Runes */
#define IT_RUNE1             (0x10000000L)
#define IT_RUNE2             (0x20000000L)
#define IT_RUNE3             (0x40000000L)
#define IT_RUNE4             (0x80000000L)


/****************************************************\
*
*    CURRENT WEAPON
*
\****************************************************/
#define WEAPON_NONE              (0x00)
#define WEAPON_SHOTGUN           (0x01)
#define WEAPON_SUPER_SHOTGUN     (0x02)
#define WEAPON_NAILGUN           (0x04)
#define WEAPON_SUPER_NAILGUN     (0x08)
#define WEAPON_GRENADE_LAUNCHER  (0x10)
#define WEAPON_ROCKET_LAUNCHER   (0x20)
#define WEAPON_LIGHTNING         (0x40)
#define WEAPON_EXTRA             (0x80)

/****************************************************\
*
*    TEMPORARY ENTITIES
*
\****************************************************/
#define TE_SPIKE         0  /*spike hits (small, grey), sound: pik/fizz */
#define TE_SUPERSPIKE    1  /*superspike hits (spike traps), sound: pik/fizz*/
#define TE_GUNSHOT       2  /*hits, small, grey (Axe, Shotgun), no sound*/
#define TE_EXPLOSION     3  /*missile explosion, big, sound= explode*/
#define TE_TAREXPLOSION  4  /*explosion, purple, big, sound= explode*/
#define TE_WIZSPIKE      7  /*wizard's hit, small, dark green, sound= tak*/
#define TE_KNIGHTSPIKE   8  /*hell knight's shot hit, red, small, no sound*/
#define TE_LAVASPLASH    10 /*really huge splash, horizontal, red*/
#define TE_TELEPORT      11 /*teleport end, vertical, white*/
/* Plane-like entities, TraceEnd is needed*/
#define TE_LIGHTNING1    5  /*wide flash (Shambler)*/
#define TE_LIGHTNING2    6  /*thin flash (Lightning gun)*/
#define TE_LIGHTNING3    9  /*very big and wide flash*/

