/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy 
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"  /*Always first to be included*/
#include <ctype.h>
#include <stdio.h>
#include "common.h"
#include "data.h"     /*Data storage*/
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkent.h"    /*Quake entities*/
#include "qkbot.h"    /*Bot interface*/
#include "qkbotmsg.h" /*Bot Messages*/
#include "qkpak.h"    /*Pak files*/

#include <stdarg.h>   /*variable argument number*/

#define DEBUG 0



typedef struct
{
  Int8 Path[0x56];
  Int8 Name[0x16];
  Int8 Ext[0x4];
}FILENAME;
typedef FILENAME PTR *pFILENAME;

Int32 DBfileSplit(pFILENAME pFname, pInt8 File)
{
  Int32 len = Strlen(File,1024);
  Int32 n, slash, dot;
  for(slash=0, dot=0, n=0;n<len;n++)
  {
    switch(File[n])
    { case '/': case '\\':
        slash = n; break;
      case '.':
        dot = n;break;
    }
  }
  pFname->Ext[0]='\0';
  if(dot<=slash)
  {
    dot = len;
    pFname->Ext[0]='\0';
  }
  else /* dot<len */
  {
    n=len-(dot+1);
    Strncpy(&(pFname->Ext[0]), &File[dot+1], min(sizeof(pFname->Ext)-1,n));
  }
  Strncpy(&(pFname->Path[0]), &File[0], min(sizeof(pFname->Path)-1,slash));
  if(slash>=len)
  { pFname->Name[0]='\0'; }
  else
  {
    n = dot-(slash+1);
    Strncpy(&(pFname->Name[0]), &File[slash+1], min(sizeof(pFname->Name)-1,n));
  }
  return 1;
}

struct PAKKNOWN { pInt8 Name; ETYPE ETyp;};
struct PAKKNOWN PakKnown []=
{
  { "player",   EFLAG_NONE },  /*player or dead corpse*/
  /*armor*/
  { "armor",    EFLAG_GOODIE|ETYPE_ARMOR },
  /*ammo*/
  { "backpack", EFLAG_GOODIE|ETYPE_AMMO_PACK },
  { "b_shell0", EFLAG_GOODIE|ETYPE_AMMO_SHOT },
  { "b_shell1", EFLAG_GOODIE|ETYPE_AMMO_SHOT },
  { "b_nail0",  EFLAG_GOODIE|ETYPE_AMMO_NAIL },
  { "b_nail1",  EFLAG_GOODIE|ETYPE_AMMO_NAIL },
  { "b_rock0",  EFLAG_GOODIE|ETYPE_AMMO_ROCK },
  { "b_rock1",  EFLAG_GOODIE|ETYPE_AMMO_ROCK },
  { "b_batt0",  EFLAG_GOODIE|ETYPE_AMMO_CELL },
  { "b_batt1",  EFLAG_GOODIE|ETYPE_AMMO_CELL },
  /*health*/
  { "b_bh10",   EFLAG_GOODIE|ETYPE_HEALTH },
  { "b_bh25",   EFLAG_GOODIE|ETYPE_HEALTH },
  { "b_bh100",  EFLAG_GOODIE|ETYPE_HEALTH },
  /*weapons*/
  { "g_shot",   EFLAG_GOODIE|ETYPE_WEAPON_SHOT }, /*double shotgun*/
  { "g_rock",   EFLAG_GOODIE|ETYPE_WEAPON_GREN },
  { "g_rock2",  EFLAG_GOODIE|ETYPE_WEAPON_ROCK },
  { "g_nail",   EFLAG_GOODIE|ETYPE_WEAPON_NAIL },
  { "g_nail2",  EFLAG_GOODIE|ETYPE_WEAPON_SUPN },
  { "g_light",  EFLAG_GOODIE|ETYPE_WEAPON_LITE },
  /*power-ups*/
  { "quaddama", EFLAG_GOODIE|ETYPE_POWER },
  { "invulner", EFLAG_GOODIE|ETYPE_POWER },
  { "invisibl", EFLAG_GOODIE|ETYPE_POWER },
  { "suit",     EFLAG_GOODIE|ETYPE_POWER },
  /*missiles*/
  { "missile",  EFLAG_DANGER|ETYPE_MISSILE },
  { "grenade",  EFLAG_DANGER|ETYPE_GRENADE },
  /*fast missiles*/
  { "spike",    EFLAG_DANGER|ETYPE_SPIKE },
  { "s_spike",  EFLAG_DANGER|ETYPE_SPIKE },
  { "k_spike",  EFLAG_DANGER|ETYPE_SPIKE }, /* hell knight spike */
  { "v_spike",  EFLAG_DANGER|ETYPE_SPIKE }, /* shalrath spikes? */
  /*ball */
  { "lavaball", EFLAG_DANGER|ETYPE_LAVA }, /* lava ball */

  { NULL, EFLAG_NONE }
};
/*
** Give file type
*/
ETYPE DBfileType(pInt8 File)
{
  FILENAME Fname;
  Int n;
  if(File==NULL)
  { return EFLAG_NONE;}
  /* detect *1 *2, parts of world */
  if(File[0]=='*')
  { return EFLAG_WORLD; }
  /* split file name*/
  DBfileSplit(&Fname, File);
  for(n=0;n< (sizeof(PakKnown)/sizeof(struct PAKKNOWN)) ;n++)
  {
    if(PakKnown[n].Name==NULL) break;
    if(Strncmpi( &(Fname.Name[0]),&(PakKnown[n].Name[0]), sizeof(Fname.Name))>0)
    { return PakKnown[n].ETyp; }
  }
  return EFLAG_NONE;
}
/****************************************************\
*
*  PAK: pack files or directory structure
*
\****************************************************/

/*
** Pak entry
*/
typedef struct
{
  Int8 Name[0x38];
  Int32 Start;
  Int32 Size;
}PKDIR;
typedef PKDIR PTR *pPKDIR;
/*
** Pack entry
*/
typedef struct
{
  Int32 Size;
  Int32 Start;
  Int32 Key;   /*Hash key of name*/
  Int8  Name[0x38];
}PKENTRY;
typedef PKENTRY PTR *pPKENTRY;
/*
** Pak file, or directory
*/
typedef struct
{
  Int32    LstNb;
  pPKENTRY Lst;   /*NULL if directory*/
  Int8     Path[0x100];
} PAK;
typedef PAK PTR *pPAK;
/*
** Init pack
*/
static Int32 PakInit(pPAK pPak, pInt8 Path)
{
  Int32 e;
  struct
  { Int8 Magic[4];
    Int32 DirPos;
    Int32 DirSz;
  } Header;
  pPKENTRY TLst;
  pPKDIR Dir, TDir;
  if((pPak==NULL)||(Path==NULL))
  { return ERRfault(ERR_BUG);}
  /* Copy name*/
  PATHjoin(&(pPak->Path[0]),  sizeof(pPak->Path)-1, ".", Path);
  /* Test if directory */
  if(PATHexists(pPak->Path, TRUE)==TRUE)
  { /*is a directory*/
    pPak->LstNb=0;
    pPak->Lst=NULL;
    return 1;
  }
  /* Test if file */
  if(PATHexists(pPak->Path, FALSE)!=TRUE)
  {
    ERRwarn("Invalid path: %s", pPak->Path);
    return -1;
  }

  /* Try to read header */
  if(FILEreadData((pInt8)&Header, 0, sizeof(Header), pPak->Path)<0)
  { return ERRfault(BAD_FILE); }
  /* Convert to big endian*/
  Header.DirSz = Int32BE(Header.DirSz);
  Header.DirPos = Int32BE(Header.DirPos);
  /* Check that file is a pack file */
  if(Strncmp(&(Header.Magic[0]),"PACK",4)<0)
  { return ERRwarn("Not a Pack file: %s", pPak->Path); }
  if((Header.DirSz< sizeof(PKDIR))||(Header.DirSz>=0x1000L*sizeof(PKDIR)))
  { return ERRfault(BAD_HEAD); }
  if(Header.DirPos<sizeof(Header))
  { return ERRfault(BAD_HEAD); }
  /* Alloc memory to store entries */
  pPak->LstNb = Header.DirSz / sizeof(PKDIR);
  Dir = (pPKDIR)Malloc(pPak->LstNb * sizeof(PKDIR));
  if(Dir==NULL)
  { return ERRfault(ERR_MEM);}
  /* Read entries */
  if(FILEreadData((pInt8)Dir, Header.DirPos, pPak->LstNb * sizeof(PKDIR), pPak->Path)<0)
  { return ERRfault(BAD_FILE); }
  /* Allocate directory */
  pPak->Lst = (pPKENTRY)Malloc(pPak->LstNb * sizeof(PKENTRY));
  if(pPak->Lst==NULL)
  { Free(Dir); return ERRfault(ERR_MEM);}
  /* Convert from big to little endian */
  for(e=0,TDir=Dir, TLst=pPak->Lst; e<pPak->LstNb; e++, TDir+=1, TLst+=1)
  {
    TLst->Size = Int32BE(TDir->Size);
    TLst->Start= Int32BE(TDir->Start);
    Strncpy(TLst->Name, TDir->Name, sizeof(TLst->Name)-1);
    TLst->Key= HASHkeyS(TLst->Name);
  }
  Free(Dir);
  return 1;
}
/*
** Free pack
*/
static Int32 PakFree(pPAK pPak)
{
  if(pPak==NULL)
  { return ERRfault(ERR_BUG);}
  if(pPak->Lst!=NULL)
  { Free(pPak->Lst); }
  pPak->Lst = NULL;
  pPak->LstNb=0;
  pPak->Path[0]='\0';
  return 1;
}
/*
** Find an entry in a pack file
**  returns entry number if found (0 if directory)
**  set PakPath with file name if needed
*/
static Int8 PakPath[0x200];
static Int32 PakEntryFind(pPAK pPak, pInt8 Name)
{
  Int32 e;
  pPKENTRY TLst;
  Int32 key;
  if((pPak==NULL)||(pPak->Path[0]=='\0'))
  { return ERRfault(ERR_BUG);}
  if(pPak->Lst==NULL)
  { /* Join paths*/
    if(PATHjoin(&(PakPath[0]),sizeof(PakPath),&(pPak->Path[0]), Name)<0)
    { return -1;}
    /* Check that file exists */
    if(PATHexists(&(PakPath[0]), FALSE)!=TRUE)
    { return -1; }
    return 0; /* success */
  }
  /* search in pak file */
  key = HASHkeyS(Name);
  for(e=0, TLst=pPak->Lst; e< pPak->LstNb; e++, TLst+=1)
  {
    if(TLst->Key!=key) continue;
    if(Strncmpi(TLst->Name, Name, sizeof(TLst->Name))>0)
    { return e;}
  }
  return -1;
}
/*
** Get Entry from pack
** PakPath must be set, if directory
*/
static pInt8 PakEntryGet(pPAK pPak, pInt32 pSize, Int32 Entry)
{
  Int32 start, LmpSz;
  pInt8 path;
  pPKENTRY TLst;
  pInt8 Lmp;
  if(pPak->Lst==NULL)
  { /* from a file in a directory*/
    path = &(PakPath[0]);
    LmpSz = FILEgetSize(path);
    start = 0;
  }
  else
  { /* from pak file*/
    path = pPak->Path;
    TLst= &(pPak->Lst[(Int)Entry]);
    start= TLst->Start;
    LmpSz= TLst->Size;
  }
  /* Read data */
  if(LmpSz<=0)
  { return NULL;}
  Lmp = Malloc(LmpSz);
  if(Lmp==NULL)
  { return NULL;}
  if(FILEreadData(Lmp,start,LmpSz,path)<0)
  { return NULL;}
  if(pSize!=NULL)
  { *pSize = LmpSz; }
  return Lmp;
}

/****************************************************\
*
*  List of pack files
*
\****************************************************/
/*
** IMPROVEMENTS NEEDED:
**  should use a hash table for key search
**  should keep PAK file always opened
**  should associate each key to the PAK/entry that define it
**
*/
/*
** Static storage for the list of files
*/
#define PAKNBMAX 6
static Int32 DBpakNb=0;
static PAK   DBpak[PAKNBMAX];

#if DEBUG
static void DBdebug(void)
{
  DBget(NULL,"sound/items/r_item1.wav");
  DBget(NULL,"gfx/pop.lmp");
}
#endif

Int32 DBinit(pInt8 Path0, ...)
{
  va_list ap;
  pInt8 Path;
  /*read optional paths*/
  va_start(ap, Path0);
  DBpakNb=0;
  while((Path = va_arg(ap,pInt8))!=NULL)
  {
    if(DBpakNb<PAKNBMAX)
    {
      if(PakInit(&(DBpak[(Int)DBpakNb]), Path)>=0)
      { DBpakNb++; }
    }
  }
  /*read path of main PAK file*/
  if(PakInit( &DBpak[(Int)(DBpakNb++)], Path0)<0)
  { DBpakNb=0; return -1;}
  va_end(ap);
#if DEBUG
  DBdebug();
#endif
  return 1;
}
Int32 DBfree(void)
{
  Int i;
  /* free all pack files */
  for(i=0;i<DBpakNb;i++)
  { PakFree(&DBpak[i]); }
  return 1;
}
Bool DBcheck(pInt8 File)
{
  /* if no database, all file exist*/
  if(DBpakNb<=0)
  { return TRUE; }
  return DBexists(File);
}

Bool DBexists(pInt8 File)
{
  Int i;
  Int32 entry;
  /* search in all pack files */
  for(i=0;i<DBpakNb;i++)
  {
    entry = PakEntryFind(&DBpak[i], File);
    if(entry>=0) return TRUE;
  }
  return FALSE;
}
pInt8 DBget(pInt32 pSize, pInt8 File)
{
  Int i;
  Int32 entry;
  pInt8 Lmp;
  /* if no database, no file exist*/
  /* search in all pack files */
  for(i=0;i<DBpakNb;i++)
  {
    entry = PakEntryFind(&DBpak[i], File);
    if(entry>=0)
    { /* found an entry, try to get it */
      Lmp= PakEntryGet( &DBpak[i] ,pSize ,entry);
      /* if got it, then return, else continue*/
      if(Lmp!=NULL)
      { return Lmp; }
    }
  }
  /* search failed*/
  return NULL;
}


