/*
** Get from net packets
*/
TIME  DtaGetTime(pDTA pDta);
ANGLE DtaGetAngle(pDTA pDta);
ANGLE DtaGetAngleTilt(pDTA pDta); /*special for tilt angle*/
Int32 DtaGetAngles(pDTA pDta, pANGLES Angles);
SCALAR DtaGetCoord(pDTA pDta);
Int32 DtaGetCoords(pDTA pDta, pVEC3 Coords);
/*
** Put into net packets
*/
Int32 DtaPutTime(pDTA pDta, TIME Time);
Int32 DtaPutAngles(pDTA pDta, pANGLES Angles);
Int32 DtaPutCoord(pDTA pDta, SCALAR Coord);
Int32 DtaPutCoords(pDTA pDta, pVEC3 Coords);
/*
** Special for angles sent by player moves (tilt angle is strange???)
*/
Int32 DtaGetAnglesSpecial(pDTA pDta, pANGLES pAngles);
Int32 DtaPutAnglesSpecial(pDTA pDta, pANGLES Angles);
/*
** Put angles, for player's camera view  (tilt angle is inverted???)
*/
Int32 DtaPutAnglesCamera(pDTA pDta, pANGLES pAngles);
