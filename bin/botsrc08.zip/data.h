/****************************************************\
*
*  DTA, Implementation of a safe buffer structure
*
\****************************************************/
/*
** Usage:
**   DTA Dta;
**   DtaInit(&Dta, 1000);
**   DtaPut(&Dta, Buffer, sizeof(Buffer))
**   DtaPutStr(&Dta, "hello")
**   DtaPutInt8(&Dta, 4)
**   DtaSize(&Dta) 		// get size of data
**   DtaData(&Dta) 		// get pointer on data
**   Dta.D[100]	
**   string = Dta.GetStr(&Dta)
**   val = Dta.GetInt8(&Dta)
**   DtaFree(&Dta);
*/
typedef struct
{ Int32 Size;     /* Size and write pointer < Data.MaxSize */
  pInt8 Data;     /* Dta.Data[n]  0<n<Data.Size */
  Int32 MaxSize;  /* Max Size of data */
  Int32 CurrRd;   /* 0 < Read pointer < Data.Size */
} DTA;
typedef DTA PTR * pDTA;
  /*
  ** DataInit(&Data,MaxSize)
  **  Returns Null if fails, pData otherwise
  */
Int32 DtaInit(pDTA pDta, Int32 MaxSize);
  /*
  ** DtaFree(&Data)
  **  Free a data buffer
  */
Int32 DtaFree(pDTA pDta);
  /*
  ** DtaClear(&Data)
  **  Clear buffer, restart from scratch
  */
Int32 DtaClear(pDTA pDta);
/****************************************************\
*
*  Input/Outputs
*
\****************************************************/
  /*
  ** DtaPrintDump(pDta, TRUE)
  **  Debug: dump data buffer to stdout.
  */
Int32 DtaPrintDump(pDTA pDta, Bool All);
  /*
  ** DtaWrite(&Dta, fd)
  **   fd= file descriptor
  **  Write data to a file descriptor
  */
Int32 DtaWrite(pDTA pDta, Int32 fd);  
  /*
  ** DtaRead(&Dta, fd)
  **   fd= file descriptor
  **  Read data from a file descriptor
  */
Int32 DtaRead(pDTA pDta, Int32 fd);

/****************************************************\
*
*  Put strings and values in a buffer
*
\****************************************************/
  /*
  ** DataPutDta(&Data, &Source);
  **  Warning: this starts from current read/write position!
  **  Rewind pSrcDta if you need to copy the whole packet.
  */
Int32 DtaPutDta(pDTA pDta, pDTA pSrcDta);
  /*
  ** DataPut(&Data, "hello", strlen("hello"));
  **  Copy into data buffer
  */
Int32 DtaPut(pDTA pDta, pInt8 Buffer, Int32 BufferSz);
  /*
  ** Put string 
  */
Int32 DtaPutStr(pDTA pDta, pInt8 Str);
  /*
  ** Put  (U)Int(8,16,32)(BigEndian,LittleEndian) 
  */
Int32   DtaPutInt8     (pDTA pDta, Int8 Val);
#define DtaPutUInt8(pDta, Val)   DtaPutInt8(pDta, (Int8)(Val))
Int32   DtaPutInt16BE  (pDTA pDta, Int16 Val);
#define DtaPutUInt16BE(pDta, Val)   DtaPutInt16BE(pDta,(Int16)Val)
Int32   DtaPutInt32BE  (pDTA pDta, Int32 Val);
#define DtaPutUInt32BE(pDta, Val)   DtaPutInt32BE(pDta,(Int32)Val)
Int32   DtaPutFloat32BE(pDTA pDta, Float32 Val);
Int32   DtaPutInt16LE  (pDTA pDta, Int16 Val);
#define DtaPutUInt16LE(pDta, Val)   DtaPutInt16LE(pDta,(Int16)Val)
Int32   DtaPutInt32LE  (pDTA pDta, Int32 Val);
#define DtaPutUInt32LE(pDta, Val)   DtaPutInt32LE(pDta,(Int32)Val)
Int32   DtaPutFloat32LE(pDTA pDta, Float32 Val);
/****************************************************\
*
*  Get strings and values from buffer
*
\****************************************************/
  /*
  ** Ptr = DtaGet(&Data, 4);
  **  Get a pointer to a size bytes, move to next
  */
pInt8 DtaGet(pDTA pDta, Int32 Size); /*Do not use*/
  /*
  ** String= DtaGetStr(Data);
  **  Get a pointer to a string in data
  **  Or fill a buffer, and return size
  */
pInt8 DtaGetStr(pDTA pDta);                          /*not mutable*/
Int32 DtaGetStrM(pDTA pDta, pInt8 Str, Int32 StrSz); /*mutable*/
  /*
  ** Get(U)Int(8,16,32)(Bigendian,LittleEndian)
  */
Int8    DtaGetInt8     (pDTA pDta);
#define DtaGetUInt8(pDta)       ((UInt8)DtaGetInt8(pDta))
Int16   DtaGetInt16BE  (pDTA pDta);
#define DtaGetUInt16BE(pDta)  	((UInt16)DtaGetInt16BE(pDta))
Int32   DtaGetInt32BE  (pDTA pDta);
#define DtaGetUInt32BE(pDta)  	((UInt32)DtaGetInt32BE(pDta))
Float32 DtaGetFloat32BE(pDTA pDta);
Int16   DtaGetInt16LE  (pDTA pDta);
#define DtaGetUInt16LE(pDta)  	((UInt16)DtaGetInt16LE(pDta))
Int32   DtaGetInt32LE  (pDTA pDta);
#define DtaGetUInt32LE(pDta)  	((UInt32)DtaGetInt32LE(pDta))
Float32 DtaGetFloat32LE(pDTA pDta);


/****************************************************\
*
*  Miscellaneous advanced functions (DO NOT USE)
*
\****************************************************/
  /*
  ** Get size of data
  */
Int32 DtaSize(pDTA pDta);
  /*
  ** Get max size of data
  */
Int32 DtaMaxSize(pDTA pDta);
  /*
  ** Get Pointer to data
  */
pInt8 DtaData(pDTA pDta);
  /*
  ** DtaRewind(&Dta);  
  **  Rewind buffer to start
  */
Int32 DtaRewind(pDTA pDta);
  /*
  ** r= DtaGetRemains(pDta);
  **  Returns remaining size to read
  */
Int32 DtaRemaining(pDTA pDta);
  /*
  ** pInt8 DtaPeek(pDta, size)
  **  Get a pointer to size bytes, or NULL
  **  Do not move to next positions
  */
pInt8 DtaPeek(pDTA pDta, Int32 Size);
  /*
  ** Internal function. DO NOT USE.
  */
Int32 DtaSetSize(pDTA pDta, Int32 Size);
  