/****************************************************\
*
*  Functions needed to interpret Quake Server Messages
*  Used only by QMsg
*
\****************************************************/
/*
** Get player infos
*/
pEPLAYER BotPlayerGet(pBOT pBot, ENTITY Player);
/*
** Diconnect
*/
void BotSrvDisconnect(pBOT pBot);
/*
** Server restarted the game (server Infos message)
*/
void BotSrvRestart(pBOT pBot, pInt8 Mapname, Int16 Players, Bool Multi);
/*
** Sign-on state
*/
#define SIGNONPRESPAWN     0x1
#define SIGNONINITLITE     0x2
#define SIGNON3DRENDER     0x3
#define SIGNONINTERMISSION 0x1000
#define SIGNONSELLSCREEN   0x1001
void BotSrvSignonState(pBOT pBot, Int32 State);
/*
** Bot variables
*/
/* Pause state*/
void BotSrvPaused(Bool Paused);
/* Precache Models */
void BotSrvPrecacheModel(pBOT pBot, Int32 i,const pInt8 Name);
/* Precache Sound */
void BotSrvPrecacheSound(pBOT pBot, Int32 i,const pInt8 Name);
/*
** Bot players infos
*/
/*entity from which view is cast*/
void BotSrvViewSet(pBOT pBot, ENTITY Enti);
/*bot was hit*/
void BotSrvDamage(pBOT pBot, pVEC3 Origin, Int16 Taken, Int16 Absorbed);
/*
** Console command
*/
void BotSrvExec(pBOT pBot, const pInt8 Text);
/*
** Print message
*/
void BotSrvPrint(pBOT pBot, const pInt8 Msg, Bool Centered);
/*
** Entities
*/
/* returns pointer to a new static entity, or NULL*/
pELIVING BotSrvEntiStatic(pBOT pBot,UInt8 Model);
/* returns pointer to a new living entity (449) or NULL*/
pELIVING BotSrvEntiInit(pBOT pBot, ENTITY Enti,UInt8 Model);
/* preserve old positions of this entity */
void BotSrvEntiChanging(pBOT pBot, ENTITY Enti);
/* called when this entity is updated (new values, or moved) */
void BotSrvEntiSeen(pBOT pBot, ENTITY Enti);
/*
** Sound
*/
void BotSrvSound(pBOT pBot, Int32 Soundnb, pVEC3 Origin, ENTITY Enti, Int16 Channel, Int16 Volume);



/*
** Called when player issues a Keep Alive message
*/
void BotPlayKeepAlive(pDTA pReply);
/*
** Called when player issues a Disconnect message
*/
void BotPlayDisconnect(pDTA pReply);
/*
** Called when player issues an Action message
*/
void BotPlayAction(pDTA pReply, TIME Time, pANGLES Angles, pVEC3 Speeds, Int16 Flags, Int16 Impulse);
/*
** Called when player issues a Console command message
*/
void BotPlayCommand(pDTA pReply, pInt8 Str);

