/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy 
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"  /*Always first to be included*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "common.h"
#include "data.h"     /*Data storage*/
#include "udp.h"      /*Useless except for types*/
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkpto.h"    /*Protocol machine*/
#include "qkptomsg.h" /*Protocol machine*/
#include "qkmsg.h"    /*Quake Message parsing*/
#include "qkent.h"    /*Quake entities*/
#include "qkbot.h"    /*Bot interface*/
#include "qkbotmsg.h" /*Bot Messages*/


#define GAMENAME      "QUAKE"
#define GAMEVERSION   (3)

/****************************************************\
*
*
*    Quake Packets
*
*
\****************************************************/
/*
** Prints the entire packet contents
*/
Int32 QPckDump(pDTA pDta)
{
  Int32 typ,sz,sz2;
  /**/
  DtaRewind(pDta);
  sz  = DtaSize(pDta);
  printf("--------------Quake Packet----------------\n");
  if(sz<4)
  {
    printf("Invalid packet size: %ld\n", (long)sz);
    return -1;
  }
  /*Type*/
  typ = DtaGetUInt16LE(pDta);
  printf("Type:       %4x     ", (int)typ);
  if(typ&QPCK_CONTROL) printf("Control\n");
  else switch(typ)
  {
    case QPCK_LMPART:  printf("Msg Part\n"); break;
    case QPCK_LMACK:   printf("Acknowledge\n"); break;
    case QPCK_LMEND:   printf("Msg End\n"); break;
    case QPCK_UPDATE:  printf("Update\n"); break;
    default:           printf("Unknown!\n"); break;
  }
  /*length, little endian*/
  sz2  = DtaGetUInt16LE(pDta);
  printf("TotalSize:  %6ld ", (long)sz2);
  if(sz2==sz)     printf("\n");
  else if(sz2<sz) printf("Extra bytes: %ld\n", (long)(sz-sz2));
  else            printf("Missing bytes: %ld\n", (long)(sz2-sz));
  /* Sequence Order*/
  if(!(typ & QPCK_CONTROL))
    printf("Sequence order: %d\n", (int) DtaGetUInt32LE(pDta));
  DtaPrintDump(pDta, FALSE);
  return DtaRewind(pDta);
}  
/*
** Decode message header
*/
Int32 QPckGetHeader(pDTA pDta, pInt32 pTyp, pInt32 pOrder)
{
  Int32 typ,sz;
  /*type, little endian*/
  typ = DtaGetUInt16LE(pDta);
  /*length, little endian*/
  sz  = DtaGetUInt16LE(pDta);
  /* Not a valid Quake message, ignore it */
  if(sz > DtaSize(pDta)){ return -1; }
  /* Sequence Order*/
  if(typ&QPCK_CONTROL)
  {
    *pOrder=0;
    sz -= 2*sizeof(UInt16);
  }
  else
  {
    *pOrder= DtaGetUInt32LE(pDta);
    sz -= (2*sizeof(UInt16) + sizeof(UInt32));
  }
  *pTyp= typ;
  return sz;
} 
#if 1
/*
** Make Packet
*/
Int32 QPckMakPacket(pDTA pDta, Int32 Typ, Int32 Order, pInt8 Content, Int32 ContentSz)
{
  if(ContentSz<0) 
  { return ERRfault(ERR_BUG); }
  /* Clear buffer*/
  DtaClear(pDta);
  /* Message structure differ for control and others*/
  if(Typ&QPCK_CONTROL)
  { /* Write type of message*/
    DtaPutInt16LE(pDta, (Int16)Typ);
    /* Write size*/
    DtaPutInt16LE(pDta, (Int16)(2*sizeof(UInt16) + ContentSz));
  }
  else
  {
    switch(Typ)
    { case QPCK_LMPART: case QPCK_LMACK: case QPCK_LMEND: case QPCK_UPDATE: 
        break;
      default: /*bad packet type*/
        return ERRfault(ERR_BUG);
    }
    /* Write type of message*/
    DtaPutInt16LE(pDta,(Int16)Typ);
    /* Write default size*/
    DtaPutInt16LE(pDta, (Int16)(2*sizeof(UInt16)+sizeof(Int32)+ContentSz));   /*size of empty*/
    /* Write sequence order, little endian*/
    DtaPutInt32LE(pDta,Order);
  }
  /* Copy the totality of pContents into packet */
  if((Content==NULL)||(ContentSz<=0)) 
  { return 1;}
  return DtaPut(pDta, Content, ContentSz);
}
#else /*Outdated*/
/*
** Make Packet
*/
Int32 QPckMakPacket(pDTA pDta, Int32 Typ, Int32 Order, pDTA pContent)
{
  Int32 sz;
  sz = (pContent==NULL)? 0 : DtaSize(pContent);
  if(sz<0) 
  { return ERRfault(ERR_BUG); }
  /* Clear buffer*/
  DtaClear(pDta);
  /* Message structure differ for control and others*/
  if(Typ&QPCK_CONTROL)
  { /* Write type of message*/
    DtaPutInt16LE(pDta, (Int16)Typ);
    /* Write size*/
    DtaPutInt16LE(pDta, (Int16)(2*sizeof(UInt16) + sz));
  }
  else
  {
    switch(Typ)
    { case QPCK_LMPART: 
      case QPCK_LMACK: 
      case QPCK_LMEND:
      case QPCK_UPDATE: 
        break;
      default: /*bad packet type*/
        return ERRfault(ERR_BUG);
    }
    /* Write type of message*/
    DtaPutInt16LE(pDta,(Int16)Typ);
    /* Write default size*/
    DtaPutInt16LE(pDta, (Int16)(2*sizeof(UInt16)+sizeof(Int32)+sz));   /*size of empty*/
    /* Write sequence order, little endian*/
    DtaPutInt32LE(pDta,Order);
  }
  /* Copy the totality of pContents into packet */
  /*DtaRewind(pContent); * Start read from begining of packet*/
  return DtaPutDta(pDta,pContent);
}

/*
** Make message header
**  Call first, before writing orders in message
*/
Int32 QPckMakHeader(pDTA pDta, Int32 Typ, Int32 Order)
{
  /* Clear buffer*/
  DtaClear(pDta);
  /* Message structure differ for control and others*/
  if(Typ&QPCK_CONTROL)
  { /* Write type of message*/
    DtaPutInt16LE(pDta,(Int16)Typ);
    /* Write default size*/
    DtaPutInt16LE(pDta,0x4);   /*size of empty*/
  }
  else
  {
    switch(Typ)
    { case QPCK_LMPART: case QPCK_LMACK: case QPCK_LMEND:
      case QPCK_UPDATE:
        break;
      default: /*bad packet type*/
        return ERRfault(ERR_BUG);
    }
    /* Write type of message*/
    DtaPutInt16LE(pDta,(Int16)Typ);
    /* Write default size*/
    DtaPutInt16LE(pDta,0x8);   /*size of empty*/
    /* Write sequence order, little endian*/
    DtaPutInt32LE(pDta,Order);
  }
  return 1;
}
/*
** Fix message size
**  Call last, just before sending message, to set
**  the right message size
*/
Int32 QPckMakSize(pDTA pDta)
{
  Int32 sz;
  pInt16 Ptr;
  sz = DtaSize(pDta);
  if(sz< 2*sizeof(UInt16)) return -1;
  Ptr = (pInt16) DtaData(pDta);
  /* write size*/
  Ptr[1] = Int16LE((Int16)(sz&0xFFFFL)); 
  /* DtaRewind(pDta); rewind write pointer to start of buffer*/
  return 1;
}
#endif /*Outdated*/
/****************************************************\
*
*
*    Quake Controls
*
*
\****************************************************/
Int32 QCtlMakConnect(pDTA pDta)
{
  DtaClear(pDta);
  DtaPutInt8(pDta, QCTL_CONNECT); /*01 connect*/
  DtaPutStr(pDta, GAMENAME);
  DtaPutInt8(pDta, GAMEVERSION);
  return 1;
}
Int32 QCtlMakAskInfos(pDTA pDta)
{
  DtaClear(pDta);
  DtaPutInt8(pDta, QCTL_ASKINFO); /*02 ask server infos*/
  DtaPutStr(pDta, GAMENAME);
  DtaPutInt8(pDta, GAMEVERSION);
  return 1;
}
/*
** Ask player infos   Player = 1...num player
*/
Int32 QCtlMakAskPlayer(pDTA pDta, Int32 Player)
{
  DtaClear(pDta);
  DtaPutInt8(pDta, QCTL_ASKPLAYER); /*03 ask player infos*/
  if(Player==0) Player=1;
  DtaPutInt8(pDta, (Int8)((Player-1) &0x3FL));
  return 1;
}
Int32 QCtlMakAskRule(pDTA pDta, pInt8 Rule)
{
  DtaClear(pDta);
  DtaPutInt8(pDta, QCTL_ASKRULE); /*04=ask rule infos*/
  if(Rule==NULL)
    DtaPutInt8(pDta, '\0');
  else
    DtaPutStr(pDta, Rule);
  return 1;
}
Int32 QCtlMakAccept(pDTA pDta, Int32 Port)
{
  DtaClear(pDta);
  DtaPutInt8(pDta, QCTL_ACCEPT); /*81=accept*/
  DtaPutInt32BE(pDta, Port);
  return 1;
}
Int32 QCtlMakRefuse(pDTA pDta, pInt8 Reason)
{
  DtaClear(pDta);
  DtaPutInt8(pDta, QCTL_REFUSE); /*82=refuse*/
  DtaPutStr(pDta, Reason);
  return 1;
}
Int32 QCtlMakGiveInfos(pDTA pDta,  pInt8 Adrs, pInt8 Host, pInt8 Map, Int16 Players, Int16 Playmax, Int16 Version)
{
  DtaClear(pDta);
  DtaPutInt8(pDta, QCTL_GIVINFO); /*83=Give infos*/
  DtaPutStr(pDta,Adrs);
  DtaPutStr(pDta,Host);
  DtaPutStr(pDta,Map);
  DtaPutInt8(pDta,Players);
  DtaPutInt8(pDta,Playmax);
  DtaPutInt8(pDta, Version);
  return 1;
}
/*
** Interpret messages for a Protocol machine
*/
Int32 QCtlInterpret(pPTO2 pPto2, pDTA pDta)
{
  Int32 Cmd,Port;
  pInt8 address, hostname, mapname,name;
  Int16 players, playmax, version;
  Int32 color, frags, time;
  Cmd = DtaGetUInt8(pDta);
  switch(Cmd)
  {
    case QCTL_CONNECT: /* Connection request*/
      name = DtaGetStr(pDta);
      version= DtaGetInt8(pDta);
      return PtoRecvConnect(pPto2, name, version);
    case QCTL_ASKINFO: /* Ask Game infos*/
      name = DtaGetStr(pDta);
      version= DtaGetInt8(pDta);
      return PtoRecvAskInfos(pPto2, name, version);
    case QCTL_ASKPLAYER: /* Ask Player infos */
      players= (Int16) (DtaGetInt8(pDta)+1);
      return PtoRecvAskPlayer(pPto2, players);
    case QCTL_ASKRULE: /* Ask Rule infos*/
      name = DtaGetStr(pDta);
      return PtoRecvAskRule(pPto2, name);
    case QCTL_ACCEPT: /* Accept connection */
      Port = DtaGetInt32BE(pDta);
      return PtoRecvAccept(pPto2, Port);
    case QCTL_REFUSE: /* Refuse connection */
      address = DtaGetStr(pDta);    /*reason for rejection*/
      return PtoRecvRefuse(pPto2, address);
    case QCTL_GIVINFO: /* Game Infos*/
      address = DtaGetStr(pDta);
      hostname= DtaGetStr(pDta);
      mapname = DtaGetStr(pDta);
      players = DtaGetUInt8(pDta);
      playmax = DtaGetUInt8(pDta);
      version = DtaGetUInt8(pDta);
      return PtoRecvGameInfos(pPto2, address, hostname, mapname, players, playmax, version);
    case QCTL_GIVPLAYER: /* Player infos*/
      players = (Int16)(DtaGetUInt8(pDta)+1); /* player number, from 0 to 15 */
      name    = DtaGetStr(pDta);   /* name of the player */
      color   = DtaGetInt32BE(pDta); /* shirt/pants colors, as Int32??? */
      frags   = DtaGetInt32BE(pDta); /* Number of frags */
      time    = DtaGetInt32BE(pDta); /* Connection time in seconds */
      address = DtaGetStr(pDta);   /* ip address and port, or "LOCAL" */
      return PtoRecvPlayerInfos(pPto2, players, name, address, color, frags, time);
    case QCTL_GIVRULE: /* Rule Info*/
      /* those strings are NULL if message is empty */
      name    = DtaGetStr(pDta);   /* name of the rule*/
      address = DtaGetStr(pDta);   /* value of the rule*/
      return PtoRecvRuleInfos(pPto2, name, address);
    default:
      ERRwarn("Invalid control message: %02x", (Int)Cmd);
      break;
  }
  return 0;
}


