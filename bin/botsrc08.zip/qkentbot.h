/*
**
** Bot global data, hidden
**
*/
#define FILENAMEMAX (0x38)
#define MODELSMAX   (256)
#define SOUNDSMAX   (256)
#define ESTATICMAX  (256)
#define ELIVINGMAX  (512)
#define MAXPLAYERS (32)
/**/
typedef struct
{
  /*
  ** Fake client who is running the bot
  */
  pPTO Pto;
  /*
  ** World who is talking to real client
  */
  pPTO PtoW;
  /*
  ** Data to let the bot compose messages
  */
  DTA  Dta;  /*used to talk to client*/
  DTA  DtaW; /*used to talk to world*/
  /*
  ** Players
  */
  EPLAYER EPlayers[MAXPLAYERS+2];
  /*
  ** Model File names. NULL if undefined
  */
  struct
  { ETYPE ETyp;  /*entity type, according to file*/
    Int8  File[FILENAMEMAX];  /*file name*/
  } Models[MODELSMAX];
  /*
  ** Sound file names. NULL if undefined.
  */
  struct
  { Int8 File[FILENAMEMAX];   /*file name*/
  } Sounds[SOUNDSMAX];
  /*
  ** Static entities
  */
  pELIVING EStatic;
  ENTITY EStaticNb;
  /*
  ** Living entities
  */
  ENTITY ELivingNb;
  pELIVING ELiving;
  /*
  ** Last movement
  */
  ANGLES ActionAngles;
  VEC3   ActionSpeed;
  UInt16 ActionImpulse;
  UInt16 ActionFlags;
  Int16  ActionFireCount;/*remaining rounds to fire*/
  Bool   ActionPending;  /*TRUE if an action must be executed*/
  Bool   ActionBot;      /*TRUE if bot desired to move angles*/
  Bool   ActionAllowed;
} BOT2;
typedef BOT2 PTR * pBOT2;

extern BOT2 Bot2;

/****************************************************\
*
*    List of Models and Sounds
*
\****************************************************/
void BotModelSoundReInit(void);
/*
** Set
*/
void BotModelSet(Int32 Index, pInt8 Name);
void BotSoundSet(Int32 Index, pInt8 Name);
/*
** Get
*/
pInt8 BotModelGet(Int32 Index);
pInt8 BotSoundGet(Int32 Index);
/*
** DEBUG
*/
void BotModelDebug(void);


/****************************************************\
*
*    Entities
*
\****************************************************/

void BotEntiReInit(void);
/*
** Add
*/
pELIVING BotEntiStaticNew(void);
/*
** Get
*/
pELIVING BotEntiStaticGet(ENTITY Enti);
/*
** Get the model of an entity
*/
pInt8 BotEntiGetModel(ENTITY Enti);
/*
** DEBUG
*/
void BotEntiDebugPos(ETYPE Flag);
void BotEntiDebug(ETYPE Flag);


/****************************************************\
*
*    Players
*
\****************************************************/

void BotPlayerReInit(void);
Bool BotIsPlayer(pBOT pBot, ENTITY Player);
pELIVING BotPlayerGetByName(pBOT pBot, pInt8 Name, Int32 NameSz);
/*
** DEBUG
*/
void BotPlayerDebug(pBOT pBot);

/****************************************************\
*
*    List of entities seen
*
\****************************************************/
/*
** Clear the list
*/
void SEENclear(void);
/*
** Add an entity into the list
*/
void SEENput(ENTITY Enti);
/*
** Get the list of entities
**  pListSz = returns the size of the list
*/
ppELIVING SEENgetList(pInt32 pListSz);

