/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/

#include "defines.h"  /*Always first to be included*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "common.h"
#include "data.h"     /*Data storage*/
#include "udp.h"      /*Generic UDP*/
#include "qkdefs.h"   /*Quake Defs*/
#include "qkmath.h"   /*Quake Maths*/
#include "qkdta.h"    /*Quake types in messages*/
#include "qkpto.h"    /*Protocol machine*/
#include "qkent.h"    /*Quake entities*/
#include "qkbot.h"    /*Bot interface*/
#include "qkmsgbot.h" /*Quake Message parsing*/
#include "qkbotmsg.h" /*Bot Messages*/

#define DEBUGSRVMSG  1


/*
** Dump Message, from last interpreted command
*/
Int32 QSrvDump(pDTA pDta, Int32 From)
{
  Int32 saved=pDta->CurrRd;
  if(From>=0) pDta->CurrRd=min(From,DtaSize(pDta)); /*hack*/
  DtaPrintDump(pDta, FALSE);
  if(From>=0) pDta->CurrRd=saved;
  return 1;
}

/****************************************************\
*
*
*    Quake Client Commands
*
*
\****************************************************/
/*
** Keep Alive
*/
Int32 QPlayMakKeepAlive(pDTA pDta)
{
  return DtaPutInt8(pDta, QPLAY_KEEPALIVE);
}
/*
** Disconnect
*/
Int32 QPlayMakDisconnect(pDTA pDta)
{
  return DtaPutInt8(pDta, QPLAY_DISCONNECT);
}
/*
** Action
*/
Int32 QPlayMakAction(pDTA pDta, TIME Time, pANGLES pAngles, pVEC3 pSpeeds, Int8 Flags, Int8 Impulse)
{
  Int32 res;
  res  =DtaPutInt8(pDta, QPLAY_ACTION);          /* 0x3 = ACTION*/
  res |=DtaPutTime(pDta, Time);          /* Action time*/
  /* Tilt angle is special, on player action messages */
  res |=DtaPutAnglesSpecial(pDta, pAngles);      /* Desired angles*/
  res |=DtaPutCoords(pDta, pSpeeds);      /* Desired speeds*/
  res |=DtaPutUInt8(pDta,  Flags );
  res |=DtaPutUInt8(pDta,  Impulse );
#if 0 /*Debug of TILT*/
    printf("ACTION  Tilt=%8.3f Yaw=%8.3f Flip=%8.3f\n",
        (float)ANGLE2DEG(pAngles->Tilt), (float)ANGLE2DEG(pAngles->Yaw), (float)ANGLE2DEG(pAngles->Flip));
#endif
  return res;
}
/*
** Console message
*/
Int32 QPlayMakConsole(pDTA pDta, pInt8 Command)
{
  Int32 res;
  res = DtaPutInt8(pDta, QPLAY_CONSOLE); /*Console order*/
  res |= DtaPutStr(pDta, Command);
  return res;
}
/*
** Name and color command
*/
Int32 QPlayMakPlayer(pDTA pDta, pInt8 Name,Int8 Color)
{
  int Shirt, Pants;
  sprintf(Buff,"name \"%s\"",Name);
  QPlayMakConsole(pDta, Buff);
  Shirt = (Color>>4)&0xF;
  Shirt = max(13,Shirt);
  Pants = (Color)&0xF;
  Pants = max(13,Pants);
  sprintf(Buff,"color %d %d",(int)Shirt,(int)Pants);
  return QPlayMakConsole(pDta, Buff);
}
/*
** Called by bot each time a message is received from player
*/
Int32 QPlayReceive(pDTA pDta, pDTA pReply)
{
  static ANGLES Angles;
  static VEC3 Speeds;
  static pInt8 Str;
  static Int16 Impulse, Flags;
  static Float32 Time;
  Int32 Cmd, sz, old;
  sz = DtaSize(pDta);
  while(pDta->CurrRd < sz)
  {
    old = pDta->CurrRd;
    Cmd = DtaGetUInt8(pDta);
    switch(Cmd)
    {
      case QPLAY_KEEPALIVE:
        BotPlayKeepAlive(pReply);
        break;
      case QPLAY_DISCONNECT:
        BotPlayDisconnect(pReply);
        break;
      case QPLAY_ACTION:
        Time = DtaGetTime(pDta);
        /* tilt angle is particular, on player actions */
        DtaGetAnglesSpecial(pDta,&Angles);
        DtaGetCoords(pDta,&Speeds);
        Flags = DtaGetUInt8(pDta);
        Impulse = DtaGetUInt8(pDta);
        BotPlayAction(pReply, Time, &Angles, &Speeds, Flags, Impulse);
        break;
      case QPLAY_CONSOLE:
        Str = DtaGetStr(pDta);
        BotPlayCommand(pReply, Str);
        break;
      default:
        printf("Unknown player code 0x%02x\n", (int)Cmd);
        QSrvDump(pDta, old);
        break;
    }
  }
  return 1;
}
/****************************************************\
*
*
*    Quake Server Messages
*
*
\****************************************************/
#if DEBUGSRVMSG
static Int32 QSrvRcvError = 0;
#endif
/* 03 Update Stat */
static Int32 QSrvRcvUpdateStat(pBOT pBot, pDTA pDta)
{
  Int16 Variable;
  Int32 Value;
  Variable = DtaGetUInt8(pDta);     /* variable*/
  Value    = DtaGetInt32BE(pDta);   /* value*/
#if DEBUGSRVMSG
  QSrvRcvError = Variable;
#endif
  switch(Variable)
  {
    case 0:  pBot->Health= Value; break;
    case 1:  pBot->Unkn= Value; break;
    case 2:  pBot->Weaponmodel= Value; break;
    case 3:  pBot->Ammo= Value; break;
    case 4:  pBot->Armor= Value; break;
    case 5:  pBot->Weaponframe= Value; break;
    case 6:  pBot->Shells= Value; break;
    case 7:  pBot->Nails= Value; break;
    case 8:  pBot->Rockets= Value; break;
    case 9:  pBot->Cells= Value; break;
    case 10: pBot->Weapon= Value; break;
    case 11: pBot->Total_secrets= Value; break;
    case 12: pBot->Total_monsters= Value; break;
    case 13: pBot->Found_secrets= Value; break;
    case 14: pBot->Killed_monsters= Value; break;
  }
  return 1;
}
/* 04 Protocol Version  */
static Int32 QSrvRcvProtocol(pBOT pBot, pDTA pDta)
{
  (void)pBot;
  (void)DtaGetInt32BE(pDta); /*ignore*/
  return 1;
}
/* 05 Set View  */
static Int32 QSrvRcvSetView(pBOT pBot, pDTA pDta)
{
  ENTITY enti;
  enti = DtaGetUInt16BE(pDta);
  /*Treat*/
  BotSrvViewSet(pBot,enti);
  return 1;
}
/* 06 Sound  */
static Int32 QSrvRcvSound(pBOT pBot, pDTA pDta)
{
  ENTITY enti;
  VEC3 Origin;
  Int16 mask,dumm, soundnb, channel,vol,att;
  mask = DtaGetInt8(pDta);
#if DEBUGSRVMSG
  QSrvRcvError = mask;
#endif
  vol= (Int16)((mask & 0x01)? DtaGetInt8(pDta) : 255); /* 255 */
  att= (Int16)((mask & 0x02)? DtaGetInt8(pDta) : 64);  /* 64  */
  dumm = DtaGetUInt16BE(pDta);
  soundnb = DtaGetUInt8(pDta);
  channel = (Int16)(dumm & 0x07);
  enti = (dumm >>3) & 0x1FFF;
  DtaGetCoords(pDta, &Origin);
  BotSrvSound(pBot, soundnb, &Origin, enti, channel, vol);
  (void)att;
  return 1;
}
/* 07 Server time stamp */
static Int32 QSrvRcvTime(pBOT pBot, pDTA pDta)
{
  TIME time= DtaGetTime(pDta);
#if 0 /* CHECK DISABLED BECAUSE TIME SEEMS TO BE SOMETIME NEGATIVE!!! */
  /* time should be kept increasing */
  if(time<= pBot->Time) return 0;
#endif
  pBot->Time= time;  /*current time*/
  pBot->Touch+= 1;   /*make updates obsoletes*/
  return 1;
}
/* 08 Server print */
static Int32 QSrvRcvSprint(pBOT pBot, pDTA pDta)
{
  pInt8 msg;
  msg = DtaGetStr(pDta);
  BotSrvPrint(pBot, msg,FALSE);
  return 1;
}
/* 09 Stuff Txt */
static Int32 QSrvRcvStuffTxt(pBOT pBot, pDTA pDta)
{
  pInt8 msg;
  msg = DtaGetStr(pDta);
  /* Check string is valid string */
  if(msg==NULL) return 0;
  BotSrvExec(pBot, msg);
  return 1;
}
/* 0A Set Angle */
static Int32 QSrvRcvSetAngle(pBOT pBot, pDTA pDta)
{
  /* pBot->Angles = Angles */
  DtaGetAngles(pDta, &(pBot->Angles));
  return 1;
}
/* 0B Server info */
static Int32 QSrvRcvServerInfo(pBOT pBot, pDTA pDta)
{
  Int32 i;
  pInt8 Name;
  Int32 version;
  Int16 players;
  Bool  multi;
  version = DtaGetInt32BE(pDta);  /* version, must be 0xF */
  if(version!=0xF){ ERRwarn("Bad game version: %d", (Int)version); }
  players= (Int16)(DtaGetUInt8(pDta)&0x3F);    /* num players*/
  multi  = (Bool)((DtaGetUInt8(pDta)==0)? FALSE:TRUE); /* multi*/
  Name    = DtaGetStr(pDta);      /*map name*/
  BotSrvRestart(pBot, Name, players, multi);
  /* models*/
  for(i=1; i<512;i++) /*start at 1*/
  {
    Name = DtaGetStr(pDta);       /* precache models*/
    /* Check string is valid string */
    if(Name==NULL) 
    {
      printf("Could not read model %d\n",(int)i);
      return -1;
    }
    if(Name[0]=='\0') break;
    BotSrvPrecacheModel(pBot,i,Name);
  }
  /* sounds*/
  for(i=1; i<512;i++) /*start at 1*/
  {
    Name = DtaGetStr(pDta);       /* precache sounds*/
    if(Name==NULL)
    {
      printf("Could not read sound %d\n",(int)i);
      return -1;
    }
    if(Name[0]=='\0') break;
    BotSrvPrecacheSound(pBot,i,Name);
  }
  return 1;
}
/* 0C Light style */
static Int32 QSrvRcvLightStyle(pBOT pBot, pDTA pDta)
{
  Int16 style= DtaGetUInt8(pDta); /*light style*/
  pInt8 def=   DtaGetStr(pDta);   /*definition string*/
#if DEBUGSRVMSG
  QSrvRcvError = style;
#endif
  (void)style;
  (void)def;
  (void)pBot;
  return 1;
}
/* 0D Update Name */
static Int32 QSrvRcvUpdateName(pBOT pBot, pDTA pDta)
{
  ENTITY player;   /*player*/
  pInt8 name; /*net name*/
  player= 1+DtaGetUInt8(pDta);   /*player*/
  name=   DtaGetStr(pDta); /*net name*/
#if DEBUGSRVMSG
  QSrvRcvError = player;
#endif
  BotPlayerSetName(pBot, player, name);
  return 1;
}
/* 0E Update frags */
static Int32 QSrvRcvUpdateFrags(pBOT pBot, pDTA pDta)
{
  Int16 player= (Int16)(1+DtaGetUInt8(pDta));   /*player*/
  UInt16 frags=  DtaGetUInt16BE(pDta); /*frags*/
  pEPLAYER pPlay;
  pPlay = BotPlayerGet(pBot, player);
  if(pPlay==NULL) { return 0;}
  pPlay->Frags = frags;
#if DEBUGSRVMSG
  QSrvRcvError = player;
#endif
  return 1;
}
/* 0F Client data */
static Int32 QSrvRcvClientData(pBOT pBot, pDTA pDta)
{
  Int32 mask;
  /**/
  mask = DtaGetUInt16BE(pDta);
#if DEBUGSRVMSG
  QSrvRcvError = mask;
#endif
  /*view height above entity origin (22.0)*/
  if(mask & 0x0001){ pBot->ViewHeight= DtaGetInt8(pDta);}
  /*angle offset*/
  if(mask & 0x0002){ pBot->ViewFlip= DtaGetAngle(pDta);}
  /*angle and velocity */
  if(mask & 0x0004){ pBot->Angles.Tilt = DtaGetAngleTilt(pDta);}
  if(mask & 0x0020){ pBot->Velocity.X  = DtaGetInt8(pDta); }
  if(mask & 0x0008){ pBot->Angles.Yaw  = DtaGetAngle(pDta);}
  if(mask & 0x0040){ pBot->Velocity.Y  = DtaGetInt8(pDta); }
  if(mask & 0x0010){ pBot->Angles.Flip = DtaGetAngle(pDta);}
  if(mask & 0x0080){ pBot->Velocity.Z = DtaGetInt8(pDta); }
  /*Get Items*/
  if(mask & 0x0200){ pBot->Items= DtaGetInt32BE(pDta);}
#if 0 /*DEBUG*/
  if(mask & 0x0400) /*This often happens, but is of no consequence*/
  { printf("Update Entity: 400 is set in mask.\n");}
  if(mask & 0x0800)
  { printf("Update Entity: 800 is set in mask.\n");}
#endif
  if(mask & 0x1000){ (void)DtaGetUInt8(pDta);} /* weaponframe */
  if(mask & 0x2000){ pBot->Armor=DtaGetUInt8(pDta);} /* armorvalue */
  if(mask & 0x4000){ (void)DtaGetUInt8(pDta);} /* weaponmodel */
  /**/
  pBot->Health = DtaGetInt16BE(pDta);
  pBot->Ammo   = DtaGetUInt8(pDta);
  pBot->Shells = DtaGetUInt8(pDta);  /*shells*/
  pBot->Nails  = DtaGetUInt8(pDta);  /*nails*/
  pBot->Rockets= DtaGetUInt8(pDta);  /*rockets*/
  pBot->Cells  = DtaGetUInt8(pDta);  /*cells*/
  pBot->Weapon = DtaGetUInt8(pDta);  /*weapon selected*/
  return 1;
}
/* 10 Stop sound */
static Int32 QSrvRcvStopSound(pBOT pBot, pDTA pDta)
{
  (void)pBot;
  DtaGetInt16BE(pDta); /*soundnb to stop*/
  return 1;
}
/* 11 Update player colors */
static Int32 QSrvRcvUpdateColors(pBOT pBot, pDTA pDta)
{
  Int16 player;
  Int16 color ;
  pEPLAYER pPlay;
  player = (Int16)(1+DtaGetInt8(pDta)); /*player*/
  color  = DtaGetInt8(pDta);/*colors = shirt<<4+pants*/
  pPlay = BotPlayerGet(pBot, player);
  if(pPlay==NULL) { return 0;}
  pPlay->Shirt = (Int16)((color>>4)&0xF);
  pPlay->Pants = (Int16)((color)&0xF);
  return 1;
}
/* 12 Particle */
static Int32 QSrvRcvParticle(pBOT pBot, pDTA pDta)
{
  VEC3 Origin;
#if 0
  VEC3 Velocity;
#endif
  DtaGetCoords(pDta,&Origin);
#if 0
  Velocity.X = ((Float32)DtaGetInt8(pDta))*0.0625;/* 1/16*/
  Velocity.Y = ((Float32)DtaGetInt8(pDta))*0.0625;/* 1/16*/
  Velocity.Z = ((Float32)DtaGetInt8(pDta))*0.0625;/* 1/16*/
#else
  (void)DtaGetInt8(pDta);
  (void)DtaGetInt8(pDta);
  (void)DtaGetInt8(pDta);
#endif
  (void)DtaGetUInt8(pDta); /*color*/
  (void)DtaGetUInt8(pDta); /*count*/
  (void)pBot;
  return 1;
}
/* 13 Damage */
static Int32 QSrvRcvDamage(pBOT pBot, pDTA pDta)
{
  VEC3 Origin;
  Int16 absorbed, taken;
  absorbed = DtaGetUInt8(pDta); /* armor */
  taken    = DtaGetUInt8(pDta); /* damage */
  DtaGetCoords(pDta,&Origin);   /* origin */
  BotSrvDamage(pBot,&Origin, taken, absorbed);
  return 1;
}
/* 14 spawn static entity */
static Int32 QSrvRcvSpawnStatic(pBOT pBot, pDTA pDta)
{
  pELIVING Ent;
  UInt8 model;
  model = DtaGetUInt8(pDta);  /*model*/
  Ent = BotSrvEntiStatic(pBot, model);
  if(Ent==NULL)
  {
    (void)DtaGetUInt8(pDta);  /*frame*/
    (void)DtaGetUInt8(pDta);/*colormap*/
    (void)DtaGetUInt8(pDta);  /*skin*/
    (void)DtaGetCoord(pDta);
    (void)DtaGetAngle(pDta);  
    (void)DtaGetCoord(pDta);
    (void)DtaGetAngle(pDta);
    (void)DtaGetCoord(pDta);
    (void)DtaGetAngle(pDta);
    return 0;
  }
  /**/
  Ent->Frame   = DtaGetUInt8(pDta);  /*frame*/
  Ent->Colormap= DtaGetUInt8(pDta);/*colormap*/
  Ent->Skin    = DtaGetUInt8(pDta);  /*skin*/
  /**/
  Ent->Origin.X   = DtaGetCoord(pDta);
  Ent->Angles.Tilt= DtaGetAngleTilt(pDta);
  Ent->Origin.Y   = DtaGetCoord(pDta);
  Ent->Angles.Yaw = DtaGetAngle(pDta);
  Ent->Origin.Z   = DtaGetCoord(pDta);
  Ent->Angles.Flip= DtaGetAngle(pDta);
  return 1;
}
/* 16 Baseline Entity */
static Int32 QSrvRcvSpawnBaseline(pBOT pBot, pDTA pDta)
{
  ENTITY enti;
  UInt8 model;
  pELIVING Ent;
  enti  = DtaGetUInt16BE(pDta);
#if DEBUGSRVMSG
  QSrvRcvError = enti;
#endif
  model = DtaGetUInt8(pDta);  /*model*/
  Ent   = BotSrvEntiInit(pBot, enti, model);
  /**/
  if(Ent==NULL)
  {
    (void)DtaGetUInt8(pDta);  /*frame*/
    (void)DtaGetUInt8(pDta);/*colormap*/
    (void)DtaGetUInt8(pDta);  /*skin*/
    (void)DtaGetCoord(pDta);
    (void)DtaGetAngle(pDta);
    (void)DtaGetCoord(pDta);
    (void)DtaGetAngle(pDta);
    (void)DtaGetCoord(pDta);
    (void)DtaGetAngle(pDta);
    return 0;
  }
  Ent->Frame   = DtaGetUInt8(pDta);  /*frame*/
  Ent->Colormap= DtaGetUInt8(pDta);/*colormap*/
  Ent->Skin    = DtaGetUInt8(pDta);  /*skin*/
  /**/
  Ent->Origin.X   = DtaGetCoord(pDta);
  Ent->Angles.Tilt= DtaGetAngleTilt(pDta);
  Ent->Origin.Y   = DtaGetCoord(pDta);
  Ent->Angles.Yaw = DtaGetAngle(pDta);
  Ent->Origin.Z   = DtaGetCoord(pDta);
  Ent->Angles.Flip= DtaGetAngle(pDta);
  /**/
  Ent->Attack=0;
  /* update time and positions */
  BotSrvEntiChanging(pBot,enti);
  return 1;
}
/* 17 Temporary entity */
static Int32 QSrvRcvTempEntity(pBOT pBot, pDTA pDta)
{
  Int16 typ;
  VEC3 Origin;   /*origin of entity*/
  VEC3 TraceEnd; /*end of trace(?)*/
  /*typ must be in range(0,12)*/
  typ = DtaGetUInt8(pDta);
#if DEBUGSRVMSG
  QSrvRcvError = typ;
#endif
  /**/
  switch(typ)
  {
    case TE_SPIKE:       case TE_SUPERSPIKE:   case TE_GUNSHOT:
    case TE_EXPLOSION:   case TE_TAREXPLOSION: case TE_WIZSPIKE:
    case TE_KNIGHTSPIKE: case TE_LAVASPLASH:   case TE_TELEPORT:
      DtaGetCoords(pDta,&Origin);
      break;
    case TE_LIGHTNING1:  case TE_LIGHTNING2:   case TE_LIGHTNING3:
      (void)DtaGetInt16BE(pDta);     /* entity */
      DtaGetCoords(pDta,&Origin);    /* origin */
      DtaGetCoords(pDta,&TraceEnd);  /* trace_end, destination*/
      break;
    default:
      DtaGetCoords(pDta,&Origin);
      ERRwarn("Invalid temporary entity %d", (int)typ);
      break;
  }
  (void)pBot;
  return 1;
}
/* 18 Pause */
static Int32 QSrvRcvPause(pBOT pBot, pDTA pDta)
{
  pBot->Paused= (Bool)((DtaGetUInt8(pDta)==0)? FALSE: TRUE);
  return 1;
}
/* 19 Signon state */
static Int32 QSrvRcvSignonState(pBOT pBot, pDTA pDta)
{
  BotSrvSignonState(pBot, DtaGetUInt8(pDta));
  return 1;
}
/* 1A Center print */
static Int32 QSrvRcvCenterPrint(pBOT pBot, pDTA pDta)
{
  pInt8 text;
  text = DtaGetStr(pDta);
  /* Check string is valid */
  if(text==NULL)
  { return -1;}
  BotSrvPrint(pBot, text, TRUE);
  return 1;
}
/* 1B killed monster */
static Int32 QSrvRcvKilledMonster(pBOT pBot, pDTA pDta)
{
  (void)pDta;
  pBot->Killed_monsters+=1;
  return 1;
}
/* 1C found secrets */
static Int32 QSrvRcvFoundSecrets(pBOT pBot, pDTA pDta)
{
  (void)pDta;
  pBot->Found_secrets+=1;
  return 1;
}
/* 1D Static sound */
static Int32 QSrvRcvStaticSound(pBOT pBot, pDTA pDta)
{
  VEC3 Origin;
  (void)pBot;
  /*Float32 vol,att;*/
  DtaGetCoords(pDta,&Origin); /* origin*/
  (void)DtaGetUInt8(pDta);    /* sound number*/
  (void)(DtaGetInt8(pDta));   /* volume  =    x / 255.0;*/
  (void)(DtaGetInt8(pDta));   /* attenuation =  x / 64.0;*/
  return 1;
}
/* 1E Intermission */
static Int32 QSrvRcvIntermission(pBOT pBot, pDTA pDta)
{
  (void)pDta;
  BotSrvSignonState(pBot,SIGNONINTERMISSION);
  return 1;
}
/* 1F Finale */
static Int32 QSrvRcvFinale(pBOT pBot, pDTA pDta)
{
  pInt8 msg;
  msg = DtaGetStr(pDta);
  /* Check string is valid */
  if(msg==NULL)
  { return 0; }
  BotSrvPrint(pBot, msg, FALSE);
  return 1;
}
/* 20 CD-ROM track*/
static Int32 QSrvRcvCdTrack(pBOT pBot, pDTA pDta)
{
  (void)pBot;
  (void)DtaGetInt8(pDta); /*from track*/
  (void)DtaGetInt8(pDta); /*to track*/
  return 1; 
}
/* 21 Sell Screen */
static Int32 QSrvRcvSellScreen(pBOT pBot, pDTA pDta)
{
  (void)pDta;
  BotSrvSignonState(pBot, SIGNONSELLSCREEN);
  return 1;
}
/* 80 Update entity */
static Int32 QSrvRcvEntity(pBOT pBot, pDTA pDta, Int8 Cmd)
{
  Int16 mask;
  ENTITY enti;
  pELIVING Ent;
  /**/
  mask = (Int16)(Cmd & 0x7F);
  if(mask & 0x0001) mask |= (Int16)(DtaGetUInt8(pDta) << 8);
#if DEBUGSRVMSG
  QSrvRcvError = mask;
#endif
  /**/
  enti = (mask& 0x4000)? DtaGetUInt16BE(pDta) : DtaGetUInt8(pDta);
  /* get pointer to entity*/
  Ent=BotEntiGet(enti);
  if(Ent==NULL)
  {
    if(mask & 0x0400) (void)DtaGetUInt8(pDta);/*model*/
    if(mask & 0x0040) (void)DtaGetUInt8(pDta);/*frame*/
    if(mask & 0x0800) (void)DtaGetUInt8(pDta);/*colormap*/
    if(mask & 0x1000) (void)DtaGetUInt8(pDta);/*skin*/
    if(mask & 0x2000) (void)DtaGetUInt8(pDta);/*attack*/
    if(mask & 0x0002) (void)DtaGetCoord(pDta);/*X*/
    if(mask & 0x0100) (void)DtaGetAngle(pDta);/*tilt*/
    if(mask & 0x0004) (void)DtaGetCoord(pDta);/*Y*/
    if(mask & 0x0010) (void)DtaGetAngle(pDta);/*yaw*/
    if(mask & 0x0008) (void)DtaGetCoord(pDta);/*Z*/
    if(mask & 0x0200) (void)DtaGetAngle(pDta);/*flip*/
    return 0;
  }
  /*
  ** Update the model, frame and skin of an entity
  */
  if(mask & 0x0400) { Ent->Model   = DtaGetUInt8(pDta);} /*model*/
  if(mask & 0x0040) {Ent->Frame = DtaGetUInt8(pDta);}  /*frame*/
  if(mask & 0x0800) { Ent->Colormap= DtaGetUInt8(pDta);} /*colormap*/
  if(mask & 0x1000) { Ent->Skin    = DtaGetUInt8(pDta);} /*skin*/
  /*
  ** Entity gets some new model value
  */
  if(mask & 0x0420) /* 0x0020 = new value, 0x0400 = model */
  { BotSrvEntiInit(pBot,enti,Ent->Model);}  /* update ETyp according to model*/
  /*
  ** Attack state (AS_STRAIGHT, AS_SLIDING, AS_MELEE, AS_MISSILE)
  */
  if(mask & 0x2000) { Ent->Attack  = DtaGetUInt8(pDta);}
  /*
  ** Preserve positions, before they change
  */
  if(mask & 0x031E) { BotSrvEntiChanging(pBot,enti);}
  /*
  ** Change positions
  */
  if(mask & 0x0002) { Ent->Origin.X =  DtaGetCoord(pDta);}
  if(mask & 0x0100) { Ent->Angles.Tilt=DtaGetAngleTilt(pDta);}
  if(mask & 0x0004) { Ent->Origin.Y=   DtaGetCoord(pDta);}
  if(mask & 0x0010) { Ent->Angles.Yaw= DtaGetAngle(pDta);}
  if(mask & 0x0008) { Ent->Origin.Z=   DtaGetCoord(pDta);}
  if(mask & 0x0200) { Ent->Angles.Flip=DtaGetAngle(pDta);}
  if(mask & 0x033E)   /*entity moved or got some new value */
  { BotSrvEntiSeen(pBot, enti);}
  return 1;
}
/*
** Interpret messages
**  returns <0 if error
**  returns 666 if NOP
**  returns >0 if all ok.
*/
Int32 QSrvReceive(pBOT pBot, pDTA pDta)
{
  Int32 res=1;
  Int32 sz,old;
  Int8 Cmd, OldCmd;
#if DEBUGSRVMSG
  QSrvRcvError = 0x66666666L; /*invalid value*/
#endif
  if(pBot==NULL)
  { return ERRfault(ERR_BUG);}
  sz = DtaSize(pDta);
  OldCmd=0;
  while(pDta->CurrRd < sz)
  {
    old = pDta->CurrRd;
    Cmd = DtaGetUInt8(pDta);
    if(Cmd & 0x80)
    {
      res = QSrvRcvEntity(pBot, pDta, Cmd);
    }
    else switch(Cmd)
    {
      /* 00 Bad Command */
      case 0x00: break;
      /* 01 No Operations */
      case 0x01: res=666; break;
      /* 02 Disconnect */
      case 0x02:  BotSrvDisconnect(pBot); break;
      /* 03 Update Stat */
      case 0x03: res=QSrvRcvUpdateStat(pBot, pDta); break;
      /* 04 Protocol Version  */
      case 0x04: res=QSrvRcvProtocol(pBot, pDta); break;
      /* 05 Set View  */
      case 0x05: res=QSrvRcvSetView(pBot, pDta); break;
      /* 06 Sound  */
      case 0x06: res=QSrvRcvSound(pBot, pDta); break;
      /* 07 Server time stamp */
      case 0x07: res=QSrvRcvTime(pBot, pDta); break;
      /* 08 Server print */
      case 0x08: res=QSrvRcvSprint(pBot, pDta); break;
      /* 09 Stuff Txt */
      case 0x09: res=QSrvRcvStuffTxt(pBot, pDta); break;
      /* 0A Set Angle */
      case 0x0A: res=QSrvRcvSetAngle(pBot, pDta); break;
      /* 0B Server info */
      case 0x0B: res=QSrvRcvServerInfo(pBot, pDta); break;
      /* 0C Light style */
      case 0x0C: res=QSrvRcvLightStyle(pBot, pDta); break;
      /* 0D Update Name */
      case 0x0D: res=QSrvRcvUpdateName(pBot, pDta); break;
      /* 0E Update frags */
      case 0x0E: res=QSrvRcvUpdateFrags(pBot, pDta); break;
      /* 0F Client data */
      case 0x0F: res=QSrvRcvClientData(pBot, pDta); break;
      /* 10 Stop sound */
      case 0x10: res=QSrvRcvStopSound(pBot, pDta); break;
      /* 11 Update player colors */
      case 0x11: res=QSrvRcvUpdateColors(pBot, pDta); break;
      /* 12 Particle */
      case 0x12: res=QSrvRcvParticle(pBot, pDta); break;
      /* 13 Damage */
      case 0x13: res=QSrvRcvDamage(pBot, pDta); break;
      /* 14 spawn static entity */
      case 0x14: res=QSrvRcvSpawnStatic(pBot, pDta); break;
      /*0x15 is obsolete*/
      /* 16 Baseline Entity */
      case 0x16: res=QSrvRcvSpawnBaseline(pBot, pDta); break;
      /* 17 Temporary entity */
      case 0x17: res=QSrvRcvTempEntity(pBot, pDta); break;
      /* 18 Pause */
      case 0x18: res=QSrvRcvPause(pBot, pDta); break;
      /* 19 Signon state */
      case 0x19: res=QSrvRcvSignonState(pBot, pDta); break;
      /* 1A Center print */
      case 0x1A: res=QSrvRcvCenterPrint(pBot, pDta); break;
      /* 1B killed monster */
      case 0x1B: res=QSrvRcvKilledMonster(pBot, pDta); break;
      /* 1C found secrets */
      case 0x1C: res=QSrvRcvFoundSecrets(pBot, pDta); break;
      /* 1D Static sound */
      case 0x1D: res=QSrvRcvStaticSound(pBot, pDta); break;
      /* 1E Intermission */
      case 0x1E: res=QSrvRcvIntermission(pBot, pDta); break;
      /* 1F Finale */
      case 0x1F: res=QSrvRcvFinale(pBot, pDta); break;
      /* 20 CD-ROM track*/
      case 0x20: res=QSrvRcvCdTrack(pBot, pDta); break;
      /* 21 Sell Screen */
      case 0x21: res=QSrvRcvSellScreen(pBot, pDta); break;
      /* */
      default:
        printf("Unknown server command 0x%02x (previous: 0x%02x)\n", (int)Cmd, (int)OldCmd);
        res= -666;
    }
    /* res=0 if something weird happened */
    /* res<0 if a parse error happened */
    if(res<0)
    {
      if(res!=-666)
      { printf("Error while parsing command 0x%02x:\n", (int)(Cmd&0xFF)); }
#if DEBUGSRVMSG
      printf("Last Position=%04xh   Help: %08xh.\n",(int)old, (int)QSrvRcvError);
      QSrvDump(pDta, 0);
#else
      QSrvDump(pDta, old);
#endif
      break;
    }
    OldCmd = Cmd;
  }
  return res;
}


/****************************************************\
*
*  Fake server messages, to be sent to a client
*
\****************************************************/

/*
** Make a set view message
*/
Int32 QSrvMakSetView(pDTA pDta, Int32 Enti, pANGLES pAngles)
{
  static Int32 res=0;
  if(Enti>=0)
  {
    res |= DtaPutInt8(pDta, 0x05); /* 05 = set view*/
    res |= DtaPutInt16BE(pDta, (Int16)(Enti&0xFFFFL));
  }
  if(pAngles!=NULL)
  {
    res |= DtaPutInt8(pDta, 0x0A); /* 0A = set angles*/
    res |= DtaPutAnglesCamera(pDta, pAngles);
#if 0 /*Debug of TILT*/
    printf("SETVIEW Tilt=%8.3f Yaw=%8.3f Flip=%8.3f\n",
    (float)ANGLE2DEG(pAngles->Tilt), (float)ANGLE2DEG(pAngles->Yaw), (float)ANGLE2DEG(pAngles->Flip));
#endif
  }
  return res;
}
/*
** Server print
*/
Int32 QSrvMakSprint(pDTA pDta, pInt8 Text, Bool Centered)
{
  static Int32 res;
  /* 08 = sprint  1A = center print */
  res =  DtaPutInt8(pDta, (UInt8)((Centered==TRUE)? 0x1A: 0x08));
  res |= DtaPutStr(pDta, Text);
  return res;
}
/*
** Stuff text to console
*/
Int32 QSrvMakStuffTxt(pDTA pDta, pInt8 Command)
{
  static Int32 res;
  res =  DtaPutInt8(pDta, 0x09); /* 09 = stuff text*/
  res |= DtaPutStr(pDta, Command);
  return res;
}
/*
** Make a few random Particle
**  Origin = origin of particles
**  Velocity.X (.Y) = speed toward X (toward Y)
**  Velocity.Z      = speed toward -Z (positive means down)
*/
Int32 QSrvMakParticle(pDTA pDta, pVEC3 pOrigin, pVEC3 pVelocity, UInt8 Color, UInt8 Count)
{
  static Int32 res;
  static struct { Int8 vX; Int8 vY; Int8 vZ; UInt8 count; UInt8 color;} particle;
  if(pOrigin==NULL) return 0;
  /* ??? Z is inverted (+Z is downward) */
  if(pVelocity==NULL)
  { particle.vX = 0.0;particle.vY = 0.0;particle.vZ = 20.0; }
  else
  {
    particle.vX = (Int8)(pVelocity->X*16.0);
    particle.vY = (Int8)(pVelocity->Y*16.0);
    particle.vZ = (Int8)((pVelocity->Z)*16.0);
  }
  particle.count = Count;
  particle.color = Color;
  res =  DtaPutInt8(pDta, 0x12); /* 12 = Particle*/
  res |= DtaPutCoord(pDta, pOrigin->X);
  res |= DtaPutCoord(pDta, pOrigin->Y);
  /* ??? Z is inverted (+Z is downward) */
  res |= DtaPutCoord(pDta, pOrigin->Z);
  res |= DtaPut(pDta, (pInt8)&particle, sizeof(particle));
  return res;
}
/*
** Temporary entity, point like or plane like
**   Enti = entity that created it (only needed for plane-like)
*/
Int32 QSrvMakTempEntity(pDTA pDta, Int32 Typ, ENTITY Enti, pVEC3 pOrigin, pVEC3 pEnd)
{
  static Int32 res;
  if(pOrigin==NULL)
  { return ERRfault(ERR_BUG);}
  switch(Typ)
  {
    case TE_SPIKE:       case TE_SUPERSPIKE:   case TE_GUNSHOT:
    case TE_EXPLOSION:   case TE_TAREXPLOSION: case TE_WIZSPIKE:
    case TE_KNIGHTSPIKE: case TE_LAVASPLASH:   case TE_TELEPORT:
      res =  DtaPutInt8(pDta, 0x17); /* 17 = Temp entity*/
      res |= DtaPutInt8(pDta, (Int8)Typ);
      res |= DtaPutCoords(pDta, pOrigin);
      break;
    case TE_LIGHTNING1:  case TE_LIGHTNING2:   case TE_LIGHTNING3:
      if((pEnd==NULL)||(Enti<0))
      { return ERRfault(ERR_BUG);}
      res =  DtaPutInt8(pDta, 0x17); /* 17 = Temp entity*/
      res |= DtaPutInt8(pDta, (Int8)Typ);
      res |= DtaPutInt16BE(pDta, (Int16)Enti); /*entity that created this*/
      res |= DtaPutCoords(pDta, pOrigin); /*origin position*/
      res |= DtaPutCoords(pDta, pEnd);    /*end position*/
      break;
    default:  /*invalid type, would kill the game*/
      return ERRfault(ERR_BUG);
  }
  return res;
}