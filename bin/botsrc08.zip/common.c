/****************************************************\
*
*  Copyright (c) 1996 by O.Montanuy 
*   (Olivier.Montanuy@wanadoo.fr)
*
\****************************************************/


/****************************************************\
*
*  This module is NOT designed to be multithread safe
*
\****************************************************/

#include "defines.h"
#if (SYS_WIN16)||(SYS_WIN32)
#include <windows.h>
#include <io.h>      /*setsize, getsize*/
#elif (SYS_WIN32CSL)
#include <io.h>      /*setsize, getsize*/
#include <malloc.h>  /*malloc*/
#elif (SYS_DOS)
#include <malloc.h>  /*far malloc*/
#elif (SYS_UNIX)
#include <malloc.h>  /*malloc*/
#endif
#include <sys/stat.h>/* file path access */
#include <stdlib.h>  /* standard stuff */
#include <stdio.h>   /* file i/o */
#include <stdarg.h>  /* variable lenght arguments */
#include <ctype.h>   /* character identification macros */
#include <utime.h>   /*time stamp*/
#include <string.h>  /*memcpy*/
/**/
#include "common.h"
/**/
#ifndef SEEK_SET
#define SEEK_SET (0)
#endif

/****************************************************\
*
*  Common buffer, for temporary storage of data
*
\****************************************************/
Int8 Buff[MAXBUFFSZ];
/****************************************************\
*
*  Error Handling
*
\****************************************************/
static Int32 ERRcurrentWnd;
static Bool  ERRok=TRUE;
void ERRsetWnd(Int32 Wnd)
{
  ERRcurrentWnd=Wnd;
}
/*
** Warning function
*/
Int32  ERRwarn(pInt8 Format, ...)
{
  va_list argptr;
  va_start(argptr, Format);
  vsprintf(Buff, (char *)Format, argptr);
  va_end(argptr);
#if (SYS_WIN16)||(SYS_WIN32)
  MessageBox((HWND)ERRcurrentWnd,Buff,(LPCSTR)"Warning",MB_ICONSTOP|MB_OK/*|MB_SYSTEMMODAL*/);
#else
  fprintf(stderr,"** Warning: %s **\n",Buff);
#endif
  return ERR_SURE;
}
/* TRUE = disable error report
** FALSE = enable
*/
void ERRquiet(Bool ok)
{
  ERRok = (short) ((ok)? FALSE: TRUE);
}
static Int8 *ERRmsgCommon[] =
{ "",
  "The End",  /*-1*/
  "Error",
  "Internal bug",
  "Out of memory",
  "Corrupt Memory",
  "Can't write file",
  "Can't read file",
  "File Read error",
  "File Seek Error",
  "Windows error",
  "Invalid object ref.",
  "Bad size",
  "Bad file",
  "Bad header",
  "Bad entry",
  "Incorrect data",
  "Bad parameter",
  NULL
};
/*
** Error function. Doesn't exit. Returns <0.
*/
Int32 ERRfaultI(Int32 Line, Int32 Type, pInt8 Module)
{
  Int8 ErrorTxt[64+2];
  Int32 n;
  if(ERRok==TRUE)
  { /* Error [<module><line>]*/
    ErrorTxt[0]='\0';
    for(n=0;ERRmsgCommon[(Int)n]!=NULL;n++)
    { if(n==(-Type))
      { Strncpy(ErrorTxt,ERRmsgCommon[(Int)n],64-1);
        break;
      }
    }
    sprintf(Buff,"Error [%s %ld]: %s.", Module,(long)Line,ErrorTxt);
#if (SYS_WIN16)||(SYS_WIN32)
    MessageBox((HWND)ERRcurrentWnd,Buff,(LPCSTR)"Error",MB_ICONSTOP|MB_OK/*|MB_SYSTEMMODAL*/);
#else
    fprintf(stderr,"\n** %s **\n",Buff);
#endif
  }
  return ERR_SURE;
}





/****************************************************\
*
*
*  Memory Management. For Windoze.
*
*
\****************************************************/
/*
** The MEM structure is a header with memory info
** and a checkword, that is used to store the global
** handle to memory.
** THIS STRUCTURE MUST BE PADDED 16 FOR SECURITY
** (May help with a bug of Borland C++ related to
**  tables. Foo[n] is not made into a huge pointer)
*/
#if (SYS_WIN16)||(SYS_WIN32)
struct HMEM
{
  Int8 Padding[0x10-sizeof(Int32)-2*sizeof(GLOBALHANDLE)];
  GLOBALHANDLE hMem;
  GLOBALHANDLE hChk;
  Int32 Size;
};
typedef struct HMEM PTR *pHMEM;
#define Hchk(a) (GLOBALHANDLE)(~((Int32)a)+0x666L)
static pVoid MemOut(GLOBALHANDLE hmem,Int32 Size)
{ pHMEM mem;
  if(hmem==NULL) {ERRfault(ERR_MEM);return NULL;}
  mem=(pHMEM)GlobalLock(hmem);
  if(mem==NULL) {ERRfault(ERR_MEM);return NULL;}
  mem->Size= Size;
  mem->hMem= hmem;
  mem->hChk= Hchk(hmem);  	/*Security check*/
  return (pVoid )(mem+1);	/*plus sizeof(struct HMEM)*/
}
static pHMEM MemIn(pVoid Data)
{ pHMEM mem=(pHMEM)Data;
  if(mem==NULL)
  { ERRfault(BAD_PARM);return NULL;} /*Protection*/
  mem = mem -1;                   /*minus sizeof(struct HMEM)*/
  if(mem->hChk != Hchk(mem->hMem))
  { ERRfault(ERR_CORR);return NULL;} /*Check fails*/
  return mem;
}
#endif /*(SYS_WIN16)||(SYS_WIN32)*/

/* Emulation of Malloc*/
pVoid Malloc(Int32 Size)
{
#if (SYS_WIN16)||(SYS_WIN32)
  GLOBALHANDLE hmem;
  if(Size<=0) return NULL;
  /*memory must be fixed*/
  hmem=GlobalAlloc(GMEM_FIXED,Size+sizeof(struct HMEM));
  return MemOut(hmem,Size);
#elif (SYS_DOS)
  return (pVoid)farmalloc(Size);
#else
  return (pVoid)malloc(Size);
#endif
}
/* Emulation of Malloc. MOVEABLE*/
pVoid MallocSpecial(Int32 Size)
{
#if (SYS_WIN16)||(SYS_WIN32)
  GLOBALHANDLE hmem;
  if(Size<=0) return NULL;
  /*memory must be MOVEABLE for sndPlaySound*/
  hmem=GlobalAlloc(GMEM_MOVEABLE,Size+sizeof(struct HMEM));
  return MemOut(hmem,Size);
#elif (SYS_DOS)
  return (pVoid)farmalloc(Size);
#else
  return (pVoid)malloc(Size);
#endif
}

/* Emulation of Calloc*/
pVoid Calloc(Int32 Nb, Int32 Size)
{
#if (SYS_WIN16)||(SYS_WIN32)
  pVoid ptr;
  Size= Size * Nb;
  if(Size<0) return NULL;
  ptr=Malloc(Size);
  if(ptr==NULL) return NULL;
  Memset(ptr,0,Size);
  return ptr;
#elif (SYS_DOS)
  return (pVoid)farcalloc(Nb,Size);
#else
  return (pVoid)calloc(Nb,Size);
#endif
}
/* Emulation of Realloc*/
pVoid Realloc(pVoid Data,Int32 Size)
{
#if (SYS_WIN16)||(SYS_WIN32)
  GLOBALHANDLE hmem;
  pHMEM mem;
  if(Size<=0) return NULL;
  mem=MemIn(Data);
  if(mem==NULL)return NULL;
  hmem = mem->hMem;
  GlobalUnlock(hmem);
  /*memory is fixed, but can it be moved, due to GMEM_MOVEABLE*/
  hmem = GlobalReAlloc(hmem,Size+sizeof(struct HMEM),GMEM_MOVEABLE);
  return MemOut(hmem,Size);
#elif (SYS_DOS)
  return (pVoid)farrealloc(Data,Size);
#else
  return (pVoid)realloc(Data,Size);
#endif
}
/* Emulation of Free*/
void Free(pVoid Data)
{
#if (SYS_WIN16)||(SYS_WIN32)
  GLOBALHANDLE hmem;
  pHMEM mem;
  /*if(Data==NULL)return;*/
  mem=MemIn(Data);
  if(mem==NULL)return;
  hmem=mem->hMem;
  GlobalUnlock(hmem);
  GlobalFree(hmem);
#elif (SYS_DOS)
  farfree(Data);
#else
  free(Data);
#endif
}
/*
** Size of memory object
*/
Int32 Memsize(pVoid Data)
{
#if (SYS_WIN16)||(SYS_WIN32)
  pHMEM mem;
  mem=MemIn(Data);
  if(mem==NULL)return NULL;
  return mem->Size;
#else
  (void) Data;
  return 0;
#endif
}
/*
** Copy memory
*/
Int32 Memcpy(pVoid Data,pVoid Src,Int32 Size)
{
#if (SYS_WIN16)||(SYS_DOS)
 /*return (_fmemcpy(Data,Src,Size)!=NULL);*/
  pInt8 d=(pInt8 )Data;
  pInt8 s=(pInt8 )Src;
  Int32 i;
  if((Data==NULL)||(Src==NULL))
  { return 0; }
  if(Size<=0)return 0;
  for(i=0;i<Size;i++, d+=1, s+=1) *d=*s;
#else
  memcpy(Data,Src, (size_t)Size);
#endif
  return 1;
}
/*
** Set memory
*/
Int32 Memset(pVoid Data,Int8 Src,Int32 Size)
{ /*return (_fmemset(Data,Src,Size)!=NULL);*/
#if (SYS_WIN16)||(SYS_DOS)
  pInt8 d=(pInt8 )Data;
  Int32 i;
  if((Data==NULL)||(Size<=0))
  { return 0; }
  for(i=0;i<Size;i++,d+=1) *d=Src;
#else
  if((Data==NULL)||(Size<=0))
  { return 0; }
  memset(Data, Src, Size);
#endif
  return 1;
}
/*
** Set memory by double word
*/
Int32 MemsetL(pVoid Data,Int8 Src,Int32 Size)
{
  pInt32 d=(pInt32)Data;
  Int32 i,size;
  Int32 src;
  if((Data==NULL)||(Size<=0))
  { return 0; }
  i=((Int32)Src)&0xFF;
  src=(((((i<<8)|i)<<8)|i)<<8)|i;
  if(Size<=0)return 0;
  size= Size/sizeof(Int32);
  for(i=0;i<size;i++,d+=1) *d=src;
  return 1;
}
/****************************************************\
*
*
*  Single-File management.
*  Only one file at the time. Avoids troubles.
*
\****************************************************/




/*
** This module should *really* be more optimised.
*/
/*
** This module handle only one single file at
** the time. This is voluntary. Avoids troubles.
*/
static FILE *FILEfp;
static Bool FILEfpOk=FALSE;
#define FMODORCREATE (4)
#define FMODORCREATETXT (5)
#define FREADTXT (6)
Int32 FILEopen(pInt8 File,Int32 Mode)
{
  Int8 *mode;
  if(File==NULL)
  { ERRfault(ERR_BUG); return 0;}
#if (SYS_MSDOS)||(SYS_WIN31)
  Strncpy(Buff,File, sizeof(Buff)-1); File = Buff;
#endif
  switch(Mode)
  { case FCREATE:
		mode="wb"; break;  /*create*/
	 case FMODORCREATE:        /*modify, or create*/
	 case FMODIFY:
		 mode="r+b";break; /*modify*/
	 case FMODORCREATETXT:
		 mode="r+t";break; /*modify*/
	 case FREADTXT:
		 mode="rt";break;
	 default:
	 case FREAD:
		 mode="rb"; break; /*read*/
  }
  if(FILEfpOk!=FALSE) return ERRfault(ERR_BUG);
  FILEfp=fopen((char *)File,mode);
  /*second chance, if modify or create*/
  if(FILEfp==NULL)
  { switch(Mode)
	 { case FMODORCREATE:
		 FILEfp=fopen((char *)File,"wb");break;
		case FMODORCREATETXT:
		  FILEfp=fopen((char *)File,"wt");break;
	 }
  }
  if(FILEfp==NULL)
  { switch(Mode)
	 { case FREAD:
		case FREADTXT:
		  return ERRfault(ERR_OPENR);
		default:
		  return ERRfault(ERR_OPENW);
	 }
  }
  FILEfpOk=TRUE;
  return 1;
}
Int32 FILEclose(void)
{ if(FILEfpOk!=TRUE) return ERRfault(ERR_BUG);
  fclose(FILEfp);
  FILEfpOk=FALSE;
  return 1;
}
Int32 FILEread(pInt8 Data,Int32 Start,Int32 Size)
{ static Int32 wsize,sz=0;
  static Int32 res;
  if(FILEfpOk!=TRUE) return ERRfault(ERR_BUG);
  if(Start>=0)
  { if(fseek(FILEfp,Start,SEEK_SET)!=0)
		return ERRfault(ERR_FSEEK);
  }
  if(Data==NULL) return 0;
  if(Size==0) return 0;
  if(Size<0) return ERRfault(BAD_PARM);
  if(Start>0x4000000L) return ERRfault(BAD_PARM);/*64 meg*/
  if(Size>0x1000000L) return ERRfault(BAD_PARM); /*16 meg*/
  for(wsize=sz=0;wsize<Size;wsize+=sz)
  { sz = ((Size-wsize)>0x4000L)? 0x4000L:Size-wsize;
	 res=fread(&Data[wsize],1,(size_t)sz,FILEfp);
	 if(res<(size_t)sz){ break; /*no more to read*/}
  }
  if(res<0) { return ERRfault(ERR_FREAD);}
  return wsize;
}
Int32 FILEwrite(pInt8 Data,Int32 Start,Int32 Size)
{ static Int32 wsize,sz=0;
  static Int32 res;
  if(FILEfpOk!=TRUE) return ERRfault(ERR_BUG);
  if(Start>=0)
  { if(fseek(FILEfp,Start,SEEK_SET)!=0)
	 { return ERRfault(ERR_FSEEK); }
  }
  if(Data==NULL) return 0;
  if(Size==0) return 0;
  if((Size<0)||(Start>0x4000000L)||(Size>0x1000000L))
  { return ERRfault(BAD_PARM);} /*16 meg*/
  for(wsize=sz=0;wsize<Size;wsize+=sz)
  {
	 sz = ((Size-wsize)>0x4000L)? 0x4000L:Size-wsize;
	 res=fwrite(&Data[wsize],1,(size_t)sz,FILEfp);
	 if(res<(size_t)sz){ break; /*no more to write*/}
  }
  return wsize;
}
/*
** File: load a huge lump of data, of size Size,
** from file File, at position Start.
** into a pre-allocated memory zone, Data
** returns size read
*/
Int32 FILEreadData(pInt8 Data,Int32 Start,Int32 Size, pInt8  File)
{ Int32 res;
  res=FILEopen(File,FREAD);
  if(res<0)return res;
  res=FILEread(Data,Start,Size);
  FILEclose();
  return res; /*size read*/
}
/*
** File: load a huge lump of text, of size Size,
** from file File, at position Start.
** into a pre-allocated memory zone, Data
** returns size read
*/
Int32 FILEreadText(pInt8 Data,Int32 Start,Int32 Size, pInt8  File)
{ Int32 res;
  res=FILEopen(File,FREADTXT);
  if(res<0)return res;
  res=FILEread(Data,Start,Size);
  FILEclose();
  return res; /*size read*/
}
/*
** File: save a huge lump of data, of size Size,
** to file File, at position Start.
** from a pre-allocated memory zone, Data
** returns size written
*/                        /*pInt8 */
Int32 FILEwriteData(pInt8 Data,Int32 Start,Int32 Size, pInt8  File)
{ Int32 res;
  res=FILEopen(File,FMODORCREATE);  /*modify or create file*/
  if(res<0)return res;
  res=FILEwrite(Data,Start,Size);
  FILEclose();
  return res; /*size read*/
}
/*
** File: save a huge lump of data, of size Size,
** to file File, at position Start.
** from a pre-allocated memory zone, Data
** returns size written
*/                        /*pInt8 */
Int32 FILEwriteText(pInt8 Data,Int32 Start,Int32 Size, pInt8  File)
{ Int32 res;
  res=FILEopen(File,FMODORCREATETXT);  /*modify or create text file*/
  if(res<0)return res;
  res=FILEwrite(Data,Start,Size);
  FILEclose();
  return res; /*size read*/
}
/*
** Get a file time stamp. (date of last modification)
*/
Int32 FILEgetTime(pInt8  File)
{
  struct stat statbuf;
  if(File==NULL)
  { ERRfault(ERR_BUG); return 0;}
#if (SYS_MSDOS)||(SYS_WIN31)
  Strncpy(Buff,File, sizeof(Buff)-1); File = Buff;
#endif
  if(stat((char *)File,&statbuf)<0) return 0;
  return (Int32)statbuf.st_ctime;
}
/*
** Set a file time stamp.
*/
void FILEsetTime(pInt8  File, Int32 Time)
{
  struct utimbuf stime;
  if(File==NULL)
  { ERRfault(ERR_BUG); return;}
#if (SYS_MSDOS)||(SYS_WIN31)
  Strncpy(Buff,File, sizeof(Buff)-1); File = Buff;
#endif
  stime.modtime=stime.actime=Time;
  utime((char *)File, &stime);
}
/*
** get file size
*/
Int32 FILEgetSize(pInt8  File)
{
  struct stat statbuf;
  if(File==NULL)
  { ERRfault(ERR_BUG); return 0;}
#if (SYS_MSDOS)||(SYS_WIN31)
  Strncpy(Buff,File, sizeof(Buff)-1); File = Buff;
#endif
  if(stat((char *)File,&statbuf)<0) return 0L;
  return (Int32)statbuf.st_size;
}
/*
**  change size of a file
*/
Int32 FILEsetSize(pInt8  File, Int32 Size)
{
  FILE *fp;
  if(File==NULL)
  { ERRfault(ERR_BUG); return 0;}
#if (SYS_MSDOS)||(SYS_WIN31)
  Strncpy(Buff,File, sizeof(Buff)-1); File = Buff;
#endif
  fp = fopen((char *)File,"rb+");
  if(fp==NULL) return -1;
#if (SYS_WIN16)||(SYS_WIN32)||(SYS_WIN32CSL)||(SYS_DOS)
  chsize(fileno(fp),Size);
#else
  ftruncate(fileno(fp), Size);
#endif
  fclose(fp);
  return 1;
}
/*
** Join paths
*/
#if (SYS_WIN16)||(SYS_DOS)||(SYS_WIN32)||(SYS_WIN32CSL)
#define PATHSEPARATOR    '\\'
#define PATHBADSEPARATOR '/'
#else
#define PATHSEPARATOR    '/'
#define PATHBADSEPARATOR '\\'
#endif
/*
** return >0 if file exists
*/
static struct stat FILEst;
Bool PATHexists(pInt8 Path, Bool Dir)
{
  if(Path==NULL)
  { ERRfault(ERR_BUG); return 0;}
#if (SYS_MSDOS)||(SYS_WIN31)
  Strncpy(Buff,Path, sizeof(Buff)-1); Path = Buff;
#endif
  FILEst.st_mode=0;
  if(stat((char *)Path,&FILEst)!=0)return FALSE;
  if((Dir==TRUE)&&(FILEst.st_mode & S_IFDIR)) return TRUE;
  if((Dir==FALSE)&&(FILEst.st_mode & S_IFREG)) return TRUE;
  return FALSE;
}
Int32 PATHcleanup(pInt8 Path, Int32 PathSz)
{
  Int i;
  pInt8 p;
  for(i=0,p=Path; i<PathSz; i++, p+=1)
  {
    if(p[0]=='\0') break;
    if(p[0]== PATHBADSEPARATOR)
    { p[0] = PATHSEPARATOR; }
  }
  return 1;
}
/*
** Join paths  Dir + / + File
*/
Int32 PATHjoin(pInt8 Path, Int32 PathSz, pInt8 Dir, pInt8 File)
{
  Int8 Separator[] = { PATHSEPARATOR, '\0'};
  if((Path==NULL)||(Dir==NULL)||(File==NULL))
  { return ERRfault(ERR_BUG);}
  /* Check size if valid*/
  if((Strlen(Dir,0x100)+Strlen(File,0x100)+2) > PathSz)
  { return ERRfault(ERR_BUG);}
  /* Concatenate path*/
  Strcpy(Path, Dir);
  Strcat(Path, Separator);
  Strcat(Path, File);
  PATHcleanup(Path,PathSz);
  return 1;
}
/*
** Split paths
*/
Int32 PATHsplit(pPATHSPLIT pSplit, pInt8 Path)
{
  Int32 len = Strlen(Path,1024);
  Int32 n, slash, dot;
  if(pSplit==NULL)
  { return -1;}
  /* Clear all*/
  Memset((pInt8) pSplit, '\0', sizeof( PATHSPLIT));
  if(len<=0)
  { return 0; }
  /* Detect DOS drive */
  if(Path[1]==':') /*DOS drive separator*/
  {
    pSplit->Drive = Path[0];
    Path = &Path[2]; len -=2;
  }
  /* Find last slash */
  for(slash=0, n=0; n<len; n++)
  {
    if((Path[n]== PATHSEPARATOR)||(Path[n]== PATHBADSEPARATOR))
    { slash = n;}
  }
  /* Find first dot after last slash */
  for(dot=slash; dot<len; dot++)
  { if(Path[dot]=='.') break; } /*extension separator*/
  /* Copy directory */
  if(slash<len)
  {
    n = slash-1;
    Strncpy(pSplit->Dir,&(Path[0]),min(n, (sizeof(pSplit->Dir)-1)));
  }
  /* Copy name*/
  slash += 1; /*slash = begining of name*/
  if(slash<len)
  {
    n = (dot-1) - slash;
    Strncpy(pSplit->Name,&(Path[slash]),min(n, (sizeof(pSplit->Name)-1)));
  }
  dot+=1;    /*dot= begining of extension*/
  if(dot<len)
  {
    n = len - dot;
    Strncpy(pSplit->Ext,&(Path[dot]),min(n, (sizeof(pSplit->Ext)-1)));
  }
#if 0
  /* Cleanup directory name */
  PATHcleanup(pSplit->Dir,sizeof(pSplit->Dir));
#endif
  return 1;
}



/****************************************************\
*
*
*  String Handling.
*
*
\****************************************************/

/*
** String finding, case sensitive
** returns index where it patched, <0 if failed
*/
Int32 Strfind(pInt8 Data,pInt8 Match,Int32 Size)
{ Int32 remn,n;
  pInt8 d;
  /* check if there is something to match */
  if((Match==NULL)||(Match[0]=='\0'))
  { return 0;}
  /* Search. trivial method (not efficient at all) */
  for(remn=Size, d=Data;remn>0;remn--,d+=1)
  { /*doesn't match*/
    if((*d)!=(Match[0])) continue;
    /*header matches, check if equal*/
    for(n=1;n<remn;n++)
    {
      if(Match[n]=='\0')   /* found it*/
      { return Size-remn;} /* return index*/
      if(d[n]!=Match[n])   /* failed */
      { break; }           /* keep searching */
    }
  }
  return -1; /* doesn't match*/
}
/*
** string matching, case insensitive, early stop
** returns 1 if matches, 0 if fails
*/
#if 0
Int32 Strmatch(pInt8 Data,pInt8 Match,Int32 Size)
{ Int32 n;
  pInt8 m=Match;
  pInt8 d=Data;
  for(n=0;n<Size;n++, m+=1,d+=1)
  { if((*m)=='\0') break;
	 if((*d)!=(*m)) /*check if different*/
	 { if(toupper(((Int)*d)&0xFF)!=toupper(((Int)*m)&0xFF))
	return 0; /*fails*/
	 }
  }
  return 1; /*matches*/
}
#endif
/*
** String comparison, case insensitive
** returns 1 if match, 0 if fails.
*/
#if 1
Int32 Strncmpi(pInt8 Data,pInt8 Match,Int32 Size)
{ Int32 n;
  pInt8 m=Match;
  pInt8 d=Data;
  for(n=0;n<Size;n++,m+=1,d+=1)
  { if((*d)!=(*m)) /*check if different*/
    { if(toupper(((Int)*d)&0xFF)!=toupper(((Int)*m)&0xFF))
       return 0; /*fails*/
    }
    if((*m)=='\0') break;
  }
  return 1; /*matches*/
}
#endif
/*
** String comparison, case sensitive
** returns 1 if match, 0 if fails.
*/
Int32 Strncmp(pInt8 Data,pInt8 Match,Int32 Size)
{ Int32 n;
  pInt8 m=Match;
  pInt8 d=Data;
  for(n=0;n<Size;n++,m+=1,d+=1)
  { if((*d)!=(*m)) /*check if different*/
    { return 0; /*fails*/ }
    if((*m)=='\0') break;
  }
  return 1; /*matches*/
}
/*
** Length of string
*/
Int32  Strlen(pInt8 Src, Int32 Size)
{ Int32 i;
  pInt8 s=Src;
  if(Src==NULL) return 0;
  for(i=0;i<Size;i++,s+=1)
  { if((*s)=='\0') break;
  }
  return i;/*needs +1*/
}
/*
** String copy.
**  Windows-like: adds a '\0' at the end
**  Dest must have Size+1 bytes.
*/
pInt8 Strncpy(pInt8 Dest, pInt8 Src, Int32 Size)
{ Int32 i;
  pInt8 d=Dest;
  pInt8 s=Src;
  for(i=0; i<Size;i++, d+=1, s+=1)
  { if((*s)=='\0') break;
    *d=*s;
  }
  *d='\0';
  return Dest;
}
pInt8 Strcpy(pInt8 Dest,pInt8 Src)
{
  return Strncpy(Dest,Src,0x4000-1);
}
pInt8 Strcat(pInt8 Dest, pInt8 Src)
{ Int32 i;
  pInt8 d=Dest;
  if(Dest==NULL) return 0;
  for(i=0;i<0x4000;i++,d+=1)
  { if(*d=='\0')break;
  }
  return Strncpy(d,Src,0x4000-1);
}
/*
** Append Number
*/
pInt8 StrcatNum(pInt8 Dest, Int32 Nb, Int32 Base)
{
  static Int8 Asc[32+4];
#if (SYS_WIN16)||(SYS_WIN32)||(SYS_WIN32CSL)||(SYS_DOS)
  ltoa(Nb,Asc,(Int)Base);
#else
  if(Base==16)
    sprintf(Asc,"%.32x",(Int)Nb);
  else  /*BUG only works for base 10*/
    sprintf(Asc,"%.32d",(Int)Nb);
#endif
  Asc[32]='\0';
  return Strcat(Dest,Asc);
}
/*
** Get value of a string.
** returns 0 if invalid
*/
Int32 Strval(pInt8 Src)
{
#if (SYS_MSDOS)||(SYS_WIN16)
  Int8 Tmp[16];
  Strncpy(Tmp,Src,sizeof(Tmp)-1);
  return atoi(Tmp);
#else
  if(Src==NULL) return 0;
  return atoi(Src);
#endif
}
/****************************************************\
*
*  Entry name Normalisation
* (remove spaces, pad with zeroes)
*
\****************************************************/

/*
** Normalize, dest of size NORMALISELEN
*/
Int32 StrClean(pInt8 Text,pInt8 Src, Int32 TextSz)
{
  Int32 n,r;
  Bool pad=FALSE;
  Int8 c='A';
  if(Text==NULL) return BAD_PARM;
  if(Src==NULL)
  { Text[0]='\0'; return 0;}
  for(r=n=0;n<TextSz;n++)
  { if(pad!=TRUE)
    { c=Src[n]; r++; }
    if((c=='\0')||(c<=' '))
    { pad=TRUE; }
    else if(iscntrl(c))
    { c = ' '; }
    else if(!isprint(c))
    { pad=TRUE; }
#if 0
    else
    { c = (Int8)tolower(c);}
#endif
    c= (Int8) ((pad==TRUE)? '\0': c);
    Text[n] = c;
  }
  return r;
}
/*
** normalise with space. in Dest[NORMALISELEN+2]
*/
Int32 StrCleanS(pInt8 Text,pInt8 Src, Int32 TextSz)
{
  Int32 n;
  n=StrClean(Text,Src,TextSz);
  if(n<0)return n;
  for(n=0;n<TextSz;n++) if(Text[n]=='\0') Text[n]=' ';
  Text[TextSz-1]='\0';
  return TextSz;
}
/*
** print a 4-digit number, space padded in Dest[4+1]
*/
Int32 StrCleanN(pInt8 Text,Int32 nb)
{
  Int32 n;
  Int8 Number[16+2];
  if(Text==NULL) return BAD_PARM;
  if(nb<-999) n=-999;else if(nb>9999) n=9999; else n=nb;
#if (SYS_WIN16)||(SYS_WIN32)||(SYS_WIN32CSL)||(SYS_DOS)
  itoa((Int)n,Number,10);
#else
  sprintf(Number, "%.16d", (int)nb);
#endif
  for(n=0;n<4;n++)
  { if(Number[(Int)n]=='\0')break;
	 Text[(Int)n]=Number[(Int)n];
  }
  for(;n<4;n++)
  { Text[n]=' '; }
  return 4;
}

/****************************************************\
*
*  Swap, Big Endian <-> little endian
*
\****************************************************/
typedef union
{ Int32 l;
  float f;
  Int16 s;
  Int8 x[4];
} SWAPPY;
static SWAPPY SwapS;
static SWAPPY SwapD;
Int32 SwapInt32(Int32 Val)
{
  SwapS.l=Val;
  SwapD.x[0]=SwapS.x[3];
  SwapD.x[1]=SwapS.x[2];
  SwapD.x[2]=SwapS.x[1];
  SwapD.x[3]=SwapS.x[0];
  return SwapD.l;
}
Float32 SwapFloat32(Float32 Val)
{
  SwapS.f=Val;
  SwapD.x[0]=SwapS.x[3];
  SwapD.x[1]=SwapS.x[2];
  SwapD.x[2]=SwapS.x[1];
  SwapD.x[3]=SwapS.x[0];
  return SwapD.f;
}
Int16 SwapInt16(Int16 Val)
{
  SwapS.s=Val;
  SwapD.x[0]=SwapS.x[1];
  SwapD.x[1]=SwapS.x[0];
  return SwapD.s;
}
/****************************************************\
*
*  Swap, Big Endian <-> little endian
*
\****************************************************/
#define HASHINIT(a)   (a)=0x4561234L
#define HASH(a,val)   (a)+= ((((a)<<4)&0xF7F9FCF0L)+((((val)<<15) + (val))^0x756E34L))
/*
** Hash table
*/
Int32 HASHkey(pVoid Data, Int32 DataSz)
{
  Int32 i,Magic;
  pUInt8 p;
  if((Data==NULL)||(DataSz<=0)){ return 0; }
  HASHINIT(Magic);
  for(i=0, p=(pUInt8)Data; i<DataSz; i++, p+=1)
  { HASH(Magic, *p); }
  return Magic;
}
Int32 HASHkeyS(pInt8 String)
{
  Int32 Magic; pUInt8 p;
  HASHINIT(Magic);
  if(String==NULL){ return 0; }
  for(p=(pUInt8)String; *p != '\0'; p+=1)
  {
    switch(*p)
    {
      case '\\': case '/':
        HASH(Magic, '/'); break;
      case '\n':
        HASH(Magic, '\n'); break;
      default:
        if((*p)<0x20) HASH(Magic, ' ');
        else HASH(Magic, *p);
        break;
    }
  }
  return Magic;
}
/*
** Returns a random number
*/
Float32 RandF(Float32 Min, Float32 Max)
{
#if (SYS_DOS)||(SYS_WIN16)||(SYS_WIN32)||(SYS_WIN32CSL)
  return (((Float32)rand())*(1/(Float32)RAND_MAX)* (Max-Min))+ Min;
#else
  static unsigned short xsubi[3]= {0x666, 0xDEAF, 0xACDC};
  return (erand48(xsubi)*(Max-Min))+Min;
#endif
}
Int32   RandI(Int32 Min, Int32 Max)
{ /* Not actually an uniform distribution, but close enough */
  return Min + (rand()%(Max-Min));
}
