/****************************************************\
*
*  Fake  Quake Client Commands
*
\****************************************************/
#define QPLAY_BAD        (0x0)
#define QPLAY_KEEPALIVE  (0x01)
#define QPLAY_DISCONNECT (0x02)
#define QPLAY_ACTION     (0x03)
#define QPLAY_CONSOLE    (0x04)
/*
** Add a "Keep Alive"
*/
Int32 QPlayMakKeepAlive(pDTA pDta);
/*
** Add a "Disconnect"
*/
Int32 QPlayMakDisconnect(pDTA pDta);
/*
** Add an "Action"
*/
#define QACTION_FIRE  (0x1)
#define QACTION_JUMP  (0x2)
Int32 QPlayMakAction(pDTA pDta, TIME Time, pANGLES Angles, pVEC3 Speeds, Int8 Flags, Int8 Impulse);
/*
** Add a "Console message from client"
*/
Int32 QPlayMakConsole(pDTA pDta, pInt8 Command);
  /* Console message for player name and color */
Int32 QPlayMakPlayer(pDTA pDta, pInt8 Name, Int8 Color);
/*
** Called by bot each time a message is received from player
*/
Int32 QPlayReceive(pDTA pDta, pDTA pReply);


/****************************************************\
*
*  Interpret  Quake Server Messages
*
\****************************************************/
/*
** Dump contents of message
** starting from the last interpreted command
** From = starting point (or -1 for current read pointer)
*/
Int32 QSrvDump(pDTA pDta, Int32 From);
/*
** Interpret a Quake server message 
** Call just after PckGetHeader()
** Executes a set of Server commands
*/
Int32 QSrvReceive(pBOT pBot,pDTA pDta);

/****************************************************\
*
*  Fake server messages, to be sent to a client
*
\****************************************************/
/*
** if Enti>=0, Add message "Set view on entity Enti"
** if pAngles!=NULL, Add message "Set view angles"
*/
Int32 QSrvMakSetView(pDTA pDta, Int32 Enti, pANGLES pAngles);
/*
** Add a "Sprint message for client"
*/
Int32 QSrvMakSprint(pDTA pDta, pInt8 Text, Bool Centered);
/*
** Add a "Command for client console"
*/
Int32 QSrvMakStuffTxt(pDTA pDta, pInt8 Command);
/*
** Add a "Particle for client"
*/
#define PARTICLE_COLOR_GREY (4) /*grey*/
#define PARTICLE_COLOR_SLIME (23) /*green yellow*/
#define PARTICLE_COLOR_YELLOW (26) /*yellow*/
#define PARTICLE_COLOR_BOOD (73) /*color of Blood*/
Int32 QSrvMakParticle(pDTA pDta, pVEC3 Origin, pVEC3 Velocity, UInt8 Color, UInt8 Count);
/*
** Temporary entity
*/
/* Point-like entity */
#define TE_SPIKE         0  /*spike hits (like GUNSHOT) */
#define TE_SUPERSPIKE    1  /*superspike hits (spike traps)*/
#define TE_GUNSHOT       2  /*hits, small, grey (Axe, Shotgun)*/
#define TE_EXPLOSION     3  /*grenade/missile explosion, big*/
#define TE_TAREXPLOSION  4  /*explosion, purple, big */
#define TE_WIZSPIKE      7  /*wizard's hit, small, dark grey*/
#define TE_KNIGHTSPIKE   8  /*hell knight's shot hit, red, small*/
#define TE_LAVASPLASH    10 /*huge splash, horizontal*/
#define TE_TELEPORT      11 /*teleport end, vertical, white*/
/* Plane-like entities */
#define TE_LIGHTNING1    5  /*wide flash (Shambler)*/
#define TE_LIGHTNING2    6  /*thin flash (Lightning gun)*/
#define TE_LIGHTNING3    9  /*very big and wide flash*/
/* Enti = entity that is the origin of the flash */
Int32 QSrvMakTempEntity(pDTA pDta, Int32 Typ, ENTITY Enti, pVEC3 Origin, pVEC3 End);

