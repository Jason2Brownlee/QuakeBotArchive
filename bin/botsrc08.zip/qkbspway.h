/*
** Set to 1 if ways are needed
*/
#define USEWAYS 1
/*
** Find waypoints
*/
Int32 BSPwayInit(pBSPDEF Bsp);
