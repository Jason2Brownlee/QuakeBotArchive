/****************************************************\
*
*
* Quake BSP elements
*
*
\****************************************************/
/*
** Vertices
*/
typedef struct
{
   VEC3 Origin;
   Int32 Tag;   /*general purpose tag*/
} QVERTEX;
typedef QVERTEX PTR *pQVERTEX;
/*
** List of Edges (element)
*/
typedef struct
{
  pQVERTEX Vtx0; /*begin*/
  pQVERTEX Vtx1; /*end*/
} QLEDGE;
typedef QLEDGE PTR *pQLEDGE;
/*
** Polygon face
*/
typedef struct
{
  pQKPLANE    Plan;   /*Plane id*/
  UInt16      Side;    /*0=front 1=back*/
  UInt16      LEdgNb;  /*Number of edges in list*/
  pQLEDGE     LEdg;    /*First item in list of edges*/
  pQKTEXINFO  Tinf;    /*Texture info*/
  UInt8       LType;   /* light type -1=no light maps*/
  UInt8       Shadow;  /* base light level for the surface */
  UInt8       Lite1;   /* more light models*/
  UInt8       Lite2;   /* more light models*/
  pInt8       LiteMap; /* NULL or pointer in lightmap */
} QFACE;
typedef QFACE PTR *pQFACE;
typedef pQFACE PTR *ppQFACE;
/*
** Models
*/
typedef struct
{ BOUNDBOX Bound;   /* The bounding box of the Hull */
  VEC3     Origin;  /* Origin of model */
  UInt32   Node;    /* id of top Hull internal BSP node */
  UInt32   Clip;    /* id of first top Hull Bound BSP node */
  UInt32   Clip2;   /* id of second top Hull Bound BSP node */
  UInt32   Clip3;   /* = 0 */
  UInt32   LeafNb;  /* number of Hull BSP leaves, not including leaf 0*/
  pQFACE   Face;    /* First face */
  UInt32   FaceNb;  /* number faces */
}QMODEL;
typedef QMODEL PTR *pQMODEL;
/*
** Leaf for graph
*/
typedef struct _QLEAF
{
  Int32  Visi;     /* -1 or beginning of visibility list*/
  ppQFACE LFac;    /* NULL or first item of the list of faces*/
  Int32  LFacNb;   /* Number of poly in the list */
  UInt8  SndWater; /* sound level*/
  UInt8  SndSky;   /* sound level*/
  UInt8  SndSlime; /* sound level*/
  UInt8  SndLava;  /* sound level*/
  /* Should contain current flow values*/
  /* Should contain threat level*/
  /* list of possible courses to near leaves */
  Int32       Qway;   /* first course*/
  Int32       QwayNb; /* nb of courses*/
} QLEAF;
typedef QLEAF PTR *pQLEAF;
/*
** Nodes for trace
*/
typedef struct _QNODE
{
  VEC3   Normal;    /* if node, split plane's Normal*/
                    /* if leaf, leaf origin*/
  SCALAR Dist;      /* if node, split Distance*/
  struct _QNODE PTR *Front; /* front child node*/
  struct _QNODE PTR *Back;  /* back child node*/
  struct _QNODE PTR *Father;/* father node. if NULL, top node */
  /* leaf */
  Int32 Leaf;       /* if >= 0, then node is a leaf*/
  Int32 Content;    /* if leaf, leaf content*/
                    /* if node, plane type? */
  UInt16 Face;      /* if node, first face*/
  UInt16 FaceNb;    /* if node, nb of faces*/
  /* Bound Box for node or leaf*/
  BOUNDBOX Bound;
}QNODE;
typedef QNODE PTR *pQNODE;
#if SYS_CPPSIZEOF
#if sizeof(QNODE)!= 0x40
#error "size of QNODE should be a power of two, for greater speed"
#endif
#endif


typedef struct
{
  Int32 Leaf;    /* target leaf */
  VEC3  Direc;   /* direction */
} QWAY;
typedef QWAY PTR* pQWAY;
/*
** Level
*/
typedef struct
{
  /* Entities*/
  Int32      EntiSz;      /* size of entities*/
  pInt8      Enti;        /* entities text*/
  /* Planes*/
  Int32      PlanNb;          /* Nb of planes*/
  pQKPLANE   Plan;         /* planes list*/
  /* MIP textures*/
  Int32      TexuNb;
  ppQKMIPTEX Texu;
  /* Vertex*/
  Int32      VrtxNb;      /* nb of vertex*/
  pQVERTEX   Vrtx;        /* vertex list*/
  /* Visibility Lists*/
  Int32      VisiSz;
  pInt8      Visi;
  /* Leaves*/
  Int32      LeafNb;
  pQLEAF     Leaf;
  /* Nodes for world leaves */
  Int32      LfNodeNb;  /* =LeafNb*/
  pQNODE     LfNode;
  /* Nodes*/
  Int32      NodeNb;
  pQNODE     Node;
  /* Surfaces*/
  Int32      TinfNb;
  pQKTEXINFO Tinf;
  /* Polygon faces*/
  Int32      FaceNb;
  pQFACE     Face;
  /* Lightmaps*/
  Int32      LiteSz;
  pInt8      Lite;
  /* Bound Nodes*/
  Int32      ClipNb;
  pQKCLIPNOD Clip;
  /* List of surfaces*/
  Int32      LFacNb;
  ppQFACE    LFac;
  /* Edges*/
  Int32      EdgeNb;
  pQKEDGE    Edge;
  /* List of Edges*/
  Int32      LEdgNb;
  pQLEDGE    LEdg;
  /* Hull*/
  Int32      ModlNb;
  pQMODEL    Modl;
  /*
  ** General infos
  */
  Int32      WorldNode;
  Int32      WorldLeaves;
  /*
  ** list of waypoints
  */
  pQWAY      QWay;
  Int32      QWayNb;
  Int32      QWayTop;
  /*
  ** Misc
  */
  Bool      Ok;       /* TRUE if level was loaded */
  Bool      Dummy;    /* pad */
}BSPDEF;
typedef BSPDEF PTR *pBSPDEF;

/*
** Entities
*/
Int32 BSPentiInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
Int32 BSPentiCheck(pBSPDEF Bsp);
/*
** Planes
*/
Int32 BSPplanInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Textures
*/
#if 0
Int32 BSPtexuSz(pQKMIPTEX Texu);
Int32 BSPtexuInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
Int32 BSPtexuFree(pBSPDEF Bsp);
Int32 BSPtexuCheck(pBSPDEF Bsp, pTXTOBJ Txt);
pQKMIPTEX BSPtexuGetI(pBSPDEF Bsp, Int16 Texu);
#endif
/*
** Vertices
*/
Int32 BSPvrtxInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/* Set tags*/
Int32 BSPvrtxSetTags(pBSPDEF Bsp, Int32 Value);
/*
** Visi Lists
*/
Int32 BSPvisiInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Nodes
*/
Int32 BSPnodeInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Leaves
*/
Int32 BSPleafInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Lights
*/
Int32 BSPliteInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Surfaces TexInfo
*/
Int32 BSPtinfInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Faces
*/
Int32 BSPfaceInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Bound Nodes
*/
Int32 BSPclipInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Lst Surf
*/
Int32 BSPlfacInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Edges
*/
Int32 BSPedgeInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Lst Edges
*/
Int32 BSPledgInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);
/*
** Hull Model
*/
Int32 BSPmodlInit(pBSPDEF Bsp, pInt8 Lmp, Int32 LmpSz);



