/*
** These callback functions MUST be defined in qkthink.c 
** They are called when specific events happen.
**
** Do anything you want in these functions, but return
** as fast as possible, since the Bot is not multithreaded.
*/

/*
** Called when bot is instanciated
*/
void THINKinitCb(pBOT pBot);
/*
** Called when bot is deinstanciated
*/
void THINKfreeCb(pBOT pBot);
/*
** Called after prespawn, when all file names are available
*/
void THINKprespawnCb(pBOT pBot);
/*
** Called each time an update message is received
*/
void THINKupdateCb(pBOT pBot);
/*
** Called when bot takes some damage
**  Suspect = player entity, if a suspect was identified
**          = pBot->Self, if damage by drowning or burning
**          = NULL if no-one suspect (missile, grenade)
*/
void THINKisHitCb(pBOT pBot, pELIVING Suspect, Int16 Taken, Int16 NewHealth);
/*
** Called when some entities are seen
**  List = list of pointers toward entities
**  ListSz = size of list
*/
void THINKsawEntitiesCb(pBOT pBot, ppELIVING List, Int32 ListSz);
/*
** Called each time a message is received from the player
** that is controling the bot.
** return the actual impulse desired (0, if no impulse)
** Note: DO NOT MODIFY Angles and Speeds IT WILL BE IGNORED.
*/
Int16 THINKplayerMoveCb(pBOT pBot, pVEC3 pSpeeds, Int16 Impulse);
/*
** Called each time a console command is sent by the player
** that is controling the bot.
**  Text = console order (like "name player", "color 1 1")
**  Modify Text if needed
** return FALSE
*/
Bool THINKplayerConsoleCb(pBOT pBot, pInt8 Text, Int32 TextSz);
/*
** Called when a player (not the bot itself) is talking
**  Player = player who talked (guessed from the name)
**  Text   = what he said
*/
void THINKtalkingCb(pBOT pBot, pELIVING Player, pInt8 Text);
/*
** Called when a message is received from the server
**  Text   = message (the kind that is usually printed in white)
*/
void THINKprintingCb(pBOT pBot, pInt8 Text);
/*
** Called when the bot is disconnected
*/
void THINKendCb(pBOT pBot);




