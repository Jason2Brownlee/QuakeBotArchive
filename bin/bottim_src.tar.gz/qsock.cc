/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  Routines to handle sockets under Unix OS.  Standard routines.
 * ------------------------------------------------------------------------ */
#include "qsock.h"

/* -------------------------------------------------------------------------
 * Converts ascii text to in_addr struct.  NULL is returned if the address
 * can not be found.
 */
struct in_addr * qsock::atoaddr(char * address)
{
struct hostent *host;
static struct in_addr saddr;
	
		/* First try it as aaa.bbb.ccc.ddd. */
	if((saddr.s_addr = inet_addr(address)) != (unsigned long)(-1)) return &saddr;

	if((host = gethostbyname(address)) != NULL)
		return (struct in_addr *) *host->h_addr_list;

	return NULL;
}


/* -------------------------------------------------------------------------
 * Set a remote connection socket
 */
qsock::qsock(char * addr, int port)
{
struct in_addr *temp;

	if((temp = atoaddr(addr)) == NULL)
		{
		printf("Invalid network address: %s\n", addr);
		exit(-1);
		}

		/* Set up the remote server info */
	memset((char *)&remote, 0, sizeof(remote));
	remote.sin_family = AF_INET;
	remote.sin_addr.s_addr = temp->s_addr;
	remote.sin_port = htons(port);

		/* Set up another structure for our local socket */
	memset((char *)&local, 0, sizeof(local));
	local.sin_family = AF_INET;
	local.sin_addr.s_addr = htonl(INADDR_ANY);
	local.sin_port = htons(0);

	if((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		{
		perror("socket");
		exit(-1);
		}

	if(bind(fd, (struct sockaddr *) &local, sizeof(local)) < 0)
		{
		perror("bind");
		exit(-1);
		}
}


/* -------------------------------------------------------------------------
 * Set a local only connection socket for listening
 */
qsock::qsock(int port)
{
		/* Set up the remote server info */
	memset((char *)&remote, 0, sizeof(remote));
	remote.sin_family = AF_INET;
	remote.sin_addr.s_addr = htonl(INADDR_ANY);
	remote.sin_port = htons(port);

		/* Set up another structure for our local socket */
	memset((char *)&local, 0, sizeof(local));
	local.sin_family = AF_INET;
	local.sin_addr.s_addr = htonl(INADDR_ANY);
	local.sin_port = htons(port);

	if((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
		{
		perror("socket");
		exit(-1);
		}

	if(bind(fd, (struct sockaddr *) &local, sizeof(local)) < 0)
		{
		perror("bind");
		exit(-1);
		}
}


/* -------------------------------------------------------------------------
 * Disconnect socket
 */
qsock::~qsock()
{
	close( fd );
	fd = 0;
}


/* ------------------------------------------------------------------------- */
int qsock::send(char * b, int s)
{
	return sendto(fd, b, s, 0, (struct sockaddr *)&remote, sizeof(remote));
}


/* ------------------------------------------------------------------------- */
int qsock::receive(char * buff, int max)
{
int r, s = sizeof(remote);

	r = recvfrom(fd, buff, max, 0, (struct sockaddr *)&remote, &s);
	buff[r] = '\0';
	return r;
}

