/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _NODES_H_
#define _NODES_H_

#include "vector.h"

class bsp_node
{
	long plane_id, front, back;
	char front_is_leaf;
	char back_is_leaf;
	vector bbox_min;
	vector bbox_max;
	unsigned short face_id;
	unsigned short face_num;

	public:
		bsp_node(QFILE *qf, int v) { read(qf, v); }
		void read(QFILE *qf, int version) { plane_id = qf->get_long();
			if(version == 38) { front = qf->get_long(); back = qf->get_long(); }
			else { front = qf->get_short(); back = qf->get_short(); }
			bbox_min.setx((float)qf->get_short());
			bbox_min.sety((float)qf->get_short());
			bbox_min.setz((float)qf->get_short());
			bbox_max.setx((float)qf->get_short());
			bbox_max.sety((float)qf->get_short());
			bbox_max.setz((float)qf->get_short());
			face_id = qf->get_ushort(); face_num = qf->get_ushort();
			if(front < 0) { front = -(front+1); front_is_leaf = 1; }
			else front_is_leaf = 0;
			if(back < 0) { back = -(back + 1); back_is_leaf = 1; }
			else back_is_leaf = 0; }

		void write(QFILE *qf, int version) { qf->put_long(plane_id);
			if(version == 38) {
				qf->put_long((front_is_leaf ? -(front-1) : front));
				qf->put_long((back_is_leaf ? -(back-1) : back)); }
			else {
				qf->put_short((front_is_leaf ? -(front-1) : front));
				qf->put_short((back_is_leaf ? -(back-1) : back)); }
			qf->put_short((short)bbox_min.getx());
			qf->put_short((short)bbox_min.gety());
			qf->put_short((short)bbox_min.getz());
			qf->put_short((short)bbox_max.getx());
			qf->put_short((short)bbox_max.gety());
			qf->put_short((short)bbox_max.getz());
			qf->put_short(face_id); qf->put_short(face_num); }

	long get_plane_id() { return plane_id; }
	unsigned short get_front() { return (int)front; }
	unsigned short get_back() { return (int)back; }
	vector get_bbox_min() { return bbox_min; }
	vector get_bbox_max() { return bbox_max; }
	unsigned short get_face_id() { return (int)face_id; }
	unsigned short get_face_num() { return (int)face_num; }
	int is_front_leaf() { return front_is_leaf; }
	int is_back_leaf() { return back_is_leaf; }
	void print() { printf("%ld %c:%ld %c:%ld ", plane_id, (front_is_leaf ? 'L':'N'),
		front, (back_is_leaf?'L':'N'), back);
		printf("%d %d\n", face_id, face_num); }
};

class bsp_nodes
{
	bsp_node **nodes;
	int nodes_loaded;

	public:
		bsp_nodes(QFILE *qf, int n, int v) { nodes = new bsp_node* [n];
			for(int i = 0; i < n; i++) nodes[i] = 0; nodes_loaded = 0;
			read(qf, n, v); }
		~bsp_nodes() { for(int i = 0; i < nodes_loaded; i++) delete nodes[i];
			delete nodes; }

		void read(QFILE *qf, int n, int v) { for(int i = 0; i < n; i++)
			nodes[i] = new bsp_node(qf, v); nodes_loaded = n; }
		void write(QFILE *qf, int v) { for(int i = 0; i < nodes_loaded; i++) nodes[i]->write(qf, v); }
		bsp_node * get_node(int x) { return(x >= 0 && x < nodes_loaded ? nodes[x] : (bsp_node *)NULL); }
		int get_num() { return nodes_loaded; }
		void print() { for(int i = 0; i < nodes_loaded; i++) { printf("%d : ", i); nodes[i]->print(); } }
};


#endif

