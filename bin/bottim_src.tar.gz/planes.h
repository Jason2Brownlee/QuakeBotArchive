/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _PLANES_H_
#define _PLANES_H_

#include "qfile.h"
#include "vector.h"

class bsp_plane
{
	public:
		enum type_t { x, y, z, unknown };

	private:
		vector normal;
		float distance;
		type_t type;
		long stype;

	public:
		bsp_plane(QFILE *qf) { read(qf); }

		void read(QFILE *qf) { normal.setx(qf->get_float());
			normal.sety(qf->get_float()); normal.setz(qf->get_float());
			distance = qf->get_float();
			switch((stype = qf->get_long())) { case 0:case 3: type = x; break; case 1:case 4: type=y; break; case 2: case 5: type=z; break; default: type=unknown; break; } }
		void write(QFILE *qf) { qf->put_float(normal.getx());
			qf->put_float(normal.gety()); qf->put_float(normal.getz());
			qf->put_float(distance); qf->put_long(stype); }
		vector get_normal(void) { return normal; }
		float get_distance(void) { return distance; }
		type_t get_type(void) { return type; }
		void print() { normal.print(); printf(" %f, %d\n", distance, type ); }
};


class bsp_planes
{
	bsp_plane **planes;
	int loaded_planes;

	public:
		bsp_planes(QFILE *qf, int num) { planes = new bsp_plane* [num];
			for(int i = 0; i < num; i++) planes[i] = NULL;
			loaded_planes = 0; read(qf, num); }
		~bsp_planes(void) { for(int i = 0; i < loaded_planes; i++)
			delete planes[i]; delete planes; }

		void read(QFILE *qf, int num) {
			for(int i = 0; i < num; i++) planes[i] = new bsp_plane(qf);
			loaded_planes = num; }
		void write(QFILE *qf) {
			for(int i = 0; i < loaded_planes; i++) planes[i]->write(qf); }
		void print(void) { for(int i = 0; i < loaded_planes; i++ ) { printf("%d : ", i); planes[i]->print(); } }
		int get_num(void) { return loaded_planes; }
		bsp_plane *get_plane(int x) { if( x < loaded_planes && x >= 0) return planes[x]; else return NULL; }
};


#endif



