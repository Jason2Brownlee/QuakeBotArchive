/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _FACELIST_H_
#define _FACELIST_H_

#include "qfile.h"

class bsp_facelist
{
	unsigned short * facelists;
	int loaded_facelists;

	public:
		bsp_facelist(QFILE *qf, int n) { facelists = new unsigned short[n];
			loaded_facelists = 0; read(qf, n); }
		~bsp_facelist(void) { delete facelists; }

		void read(QFILE *qf, int n) { for(int i = 0; i < n; i++)
			facelists[i] = qf->get_ushort(); loaded_facelists = n; }
		void write(QFILE *qf) { for(int i = 0; i < loaded_facelists; i++) qf->put_short(facelists[i]); }
		unsigned short get_facelist(int x) { return(x >= 0 && x < loaded_facelists ? (int)facelists[x] : 0); }
		int get_num(void) { return loaded_facelists; }
		void print(void) { for(int i = 0; i < loaded_facelists; i++)
			printf("%d : %d\n", i, facelists[i]); }
};

#endif

