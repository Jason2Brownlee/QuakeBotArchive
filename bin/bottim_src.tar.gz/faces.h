/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _FACES_H_
#define _FACES_H_

#include "qfile.h"

class bsp_face
{
	unsigned short plane_id;
	unsigned short side;		// 0 == on front of plane, 1==back
	long edge_list_id;
	unsigned short edge_list_num; 
	unsigned short texture_index;	// unused by me
	long lights;			// should be 4 char's, but i don't use it...
	long light_map;		// index into lightmap

	public:
		bsp_face(QFILE *qf) { read(qf); }
		void read(QFILE *qf) { plane_id = qf->get_ushort();
			side = qf->get_ushort(); edge_list_id = qf->get_long();
			edge_list_num = qf->get_ushort();
			texture_index = qf->get_ushort();
			lights = qf->get_long(); light_map = qf->get_long(); }
		void write(QFILE *qf) { qf->put_short(plane_id);
			qf->put_short(side); qf->put_long(edge_list_id);
			qf->put_short(edge_list_num); qf->put_short(texture_index);
			qf->put_long(lights); qf->put_long(light_map); }
		unsigned short get_plane_id(void) { return (int)plane_id; }
		unsigned short is_on_front(void) { return !side; }
		long get_edge_list_id(void) { return edge_list_id; }
		int get_edge_list_num(void) { return (int)edge_list_num; }
		int get_texture_index(void) { return (int)texture_index; }
		int get_light_map(void) { return light_map; }
		void print(void) { printf("%d %c %ld %d\n", plane_id, (side?'B':'F'), edge_list_id, edge_list_num); }
};


class bsp_faces
{
	bsp_face **faces;
	int loaded_faces;

	public:
		bsp_faces(QFILE *qf, int n) { faces = new bsp_face* [ n ];
			for(int i = 0; i < n; i++) faces[i] = 0;
			loaded_faces=0; read(qf, n); }
		~bsp_faces(void) { for(int i = 0; i < loaded_faces; i++) delete faces[i];
			delete faces; }

		void read(QFILE *qf, int n) { for(int i = 0; i < n; i++)
			faces[i] = new bsp_face(qf); loaded_faces = n; }
		void write(QFILE *qf) { for(int i = 0; i < loaded_faces; i++) faces[i]->write(qf); }
		bsp_face *get_face(int x) { return(x >= 0 && x < loaded_faces ? faces[x] : (bsp_face *)NULL); }
		int get_num(void) { return loaded_faces; }
		void print(void) { for(int i=0; i < loaded_faces; i++) { printf("%d : ", i); faces[i]->print(); } }
};


#endif

