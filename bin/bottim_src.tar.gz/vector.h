/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _VECTOR_H_
#define _VECTOR_H_

#define _PI 3.1415926535897932846
#define _PI2 1.57079632679489661923
#define FABS(x) (((x) > (float)0.0) ? (x) : (-x))

class vector
{
private:
	float x, y, z;

public:
	vector() { x = y = z = 0.0; }
	vector( int ) { x=(float)0; y=(float)0; z=(float)0; }
	vector( float a, float b, float c ) { x=a; y=b; z=c; }
	~vector() {}

	vector operator + (vector &);	// wheee...add two vectors
	vector operator - (vector &);	// subtract two (duh)
	vector operator - ();		// unary minus (negate)
	float operator * (const vector &);	// dot product, really
	void operator /= ( float ); // divide by a scaler
	void operator *= ( float a ) { x *=a; y *= a; z *= a; }
	void operator += (vector &);
	void operator -= (vector &);
	vector X(vector &);		// cross product

	void scale( int x );		// make the vector x long

	void normalize();		// normalize vector
	float length();		// get its length
	float length2D();		// get its length for x & y only

	void set( float a, float b, float c ) { x=a; y=b; z=c; }
	void setx( float a ) { x=a; }
	void sety( float a ) { y=a; }
	void setz( float a ) { z=a; }
	void set_from_PY(float pitch, float yaw);

	int operator == (const vector & r) { return (x==r.x && y==r.y && z==r.z); }
	int operator != (vector & r) { return !( *this == r ); }
	int xequal (vector & r) { return( x==r.x ); }
	int yequal (vector & r) { return( y==r.y ); }
	int zequal (vector & r) { return( z==r.z ); }
	float getx(){ return x; }
	float gety(){ return y; }
	float getz(){ return z; }

	float get_yaw();
	float get_pitch();
	float get_roll()	{return (float)0;}

	void print(void);
	void print1(void) { printf("(%.1f, %.1f, %.1f)", x, y, z); }
};

#endif

