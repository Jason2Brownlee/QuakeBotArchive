/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _QSOCK_H_
#define _QSOCK_H_

#define Q_DEFAULT_SERVER    "0.0.0.0"
#define Q_DEFAULT_PORT       27500

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include <limits.h>
#include <netdb.h>
#include <arpa/inet.h>

class qsock
{
	struct sockaddr_in remote;		// address of client and server
	struct sockaddr_in local;		// client is me, server is them
	int fd;

	struct in_addr * atoaddr( char * address );
	
	public:
		qsock(char * addr=Q_DEFAULT_SERVER, int port=Q_DEFAULT_PORT);
		qsock(int port);	/* "listen" socket */
		~qsock();
		int send( char *, int );
		int receive( char *, int );
		struct in_addr lastPacketIP() { return remote.sin_addr; }
		void changePort( int p ) {remote.sin_port = htons( p );local.sin_port = htons( p );}
		int getLocalPort() { return ntohs( local.sin_port ); }
		int getRemotePort() { return ntohs( remote.sin_port ); }
		long getRemoteAddr() { return ntohl( remote.sin_addr.s_addr ); }
		int getFD() { return fd; }
};


#endif
