/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  Main header file for the QuakeWorld Bot.
 * ------------------------------------------------------------------------ */
typedef union {
	unsigned char uc[4];
	float fl;
} freorder;

#define ESWAP_FLOAT(x) {  \
unsigned char _tmp;  \
freorder _fr; \
	_fr.fl = (x);  \
	_tmp = _fr.uc[0]; _fr.uc[0] = _fr.uc[3]; _fr.uc[3] = _tmp;  \
	_tmp = _fr.uc[2]; _fr.uc[2] = _fr.uc[1]; _fr.uc[1] = _tmp;  \
	(x) = _fr.fl;  \
}


#if i80x86
#	define MSB_FLOAT(x)	ESWAP_FLOAT(x)
#	define LSB_FLOAT(x)
#else
#	define MSB_FLOAT(x)
#	define LSB_FLOAT(x)	ESWAP_FLOAT(x)
#endif

/* ------------------------------------------------------------------------- */
	/* major entity types */

#define ET_AMMO   1
#define ET_WEAPON 2
#define ET_HEALTH 3
#define ET_PROJECTILE 4
#define ET_ITEM   5
#define ET_MISC   6
#define ET_ARMOR  7
#define ET_VIEWMODEL 8
#define ET_ENEMY  9
#define ET_RUNE 10

	/* minor entity types */

	/* ammo types */
#define ET_A_SHELLS 1
#define ET_A_CELLS  2
#define ET_A_ROCKETS 3
#define ET_A_NAILS  4

	/* weapon types */
#define ET_W_SSG  5
#define ET_W_NG   6
#define ET_W_SNG  7
#define ET_W_GL   8
#define ET_W_RL   9
#define ET_W_LG   10

	/* health types */
#define ET_H_15  11
#define ET_H_25  12
#define ET_H_100 13

	/* projectile defines */
#define ET_P_MISSILE 14
#define ET_P_SNG_NAIL 15		// perforator
#define ET_P_NG_NAIL 16
#define ET_P_GRENADE 53

	/* item types */
#define ET_I_BIOSUIT 17
#define ET_I_POP 18
#define ET_I_RING 19
#define ET_I_QUAD 20
#define ET_I_BACKPACK 44

	/* armour types */

#define ET_A_GREEN 21
#define ET_A_YELLOW 22
#define ET_A_RED 23

	/* viewmodel types */
#define ET_V_AXE 43
#define ET_V_SG 24
#define ET_V_SSG 25
#define ET_V_NG 26
#define ET_V_SNG 27
#define ET_V_GL 28
#define ET_V_RL 29
#define ET_V_LG 30

	/* rune types */
#define ET_R_E1 31
#define ET_R_E2 32
#define ET_R_E3 33
#define ET_R_E4 34

	/* enemy types */
#define ET_E_PLAYER 35
#define ET_E_GIBS 36
#define ET_E_DOG 37
#define ET_E_OGRE 38
#define ET_E_KNIGHT 39
#define ET_E_HELLKNIGHT 40
#define ET_E_FISH 41
#define ET_E_SHALRATH 42

	/* misc types */
#define ET_M_BODY 50
#define ET_M_ENTITY 51

/* ------------------------------------------------------------------------- */
#define W_AXE	0x00000000
#define W_SG	0x00000001
#define W_SSG	0x00000002
#define W_NG	0x00000004
#define W_SNG	0x00000008
#define W_GL	0x00000010
#define W_RL	0x00000020
#define W_LG	0x00000040

