/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _BSPHEAD_H_
#define _BSPHEAD_H_

#include "qfile.h"

#define IDBSPHEADER (('P'<<24)+('S'<<16)+('B'<<8)+'I')	/* little-endian "IBSP" */

class bsp_entry
{
	long offset;
	long size;
	
	public:
		bsp_entry(void) { offset=0; size=0; }
		bsp_entry(QFILE *qf) { read(qf); }

		void read(QFILE *qf) { offset = qf->get_long(); size = qf->get_long(); }
		void write(QFILE *qf) { qf->put_long(offset); qf->put_long(size); }
		void set_entry(long soffset, long ssize) { offset = soffset;  size = ssize; }
		long get_offset(void) { return offset; }
		long get_size(void) { return size; }
};


class bsp_head
{
	long version, num_entry;
	bsp_entry *entries[20];
	
	public:
		bsp_head(void) { for(int i = 0; i < 15; i++) entries[i]=new bsp_entry(); }
		bsp_head(QFILE *qf) { read(qf); }
	
		void read(QFILE *qf) { version = qf->get_long();
			if(version == IDBSPHEADER) version = qf->get_long();
			if(version == 38) num_entry = 19;
			else num_entry = 15;
			for(int i = 0; i < num_entry; i++) entries[i] = new bsp_entry(qf); }
		void write(QFILE *qf) { qf->put_long(version); for(int i = 0; i < 15; i++) entries[i]->write(qf); }
		bsp_entry *get_entry(int index) { return entries[index]; }
		int get_version() { return version; }
};

#endif

