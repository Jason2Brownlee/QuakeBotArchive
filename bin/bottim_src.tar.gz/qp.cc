/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 * An interface to test the pack file handling routines.  Provides a `shell'
 * type interface with cd, dir, etc type commands.  Not intended for any
 * real use.
 * ------------------------------------------------------------------------ */
#include <stdio.h>
#include <math.h>
#include "bspfile.h"
#include "qfile.h"

#if IMG
#include "imglib.h"	/* used to display bsp files in X11 */
							/* cannot distribute - part of PhD work. */
#endif

float x_scale, y_scale, z_scale, x_offset, y_offset, z_offset;
long dpoints;

#if IMG
/* ------------------------------------------------------------------------- */
void draw_face(bsp_file *bsp, pic_info *fpic, vector *tr_vects, int face_num, int floor)
{
class bsp_face *bf;
long edge_list_strt, src, dst, i, edli;

	bf = bsp->faces->get_face(face_num);

	if(!floor)
		{
		bsp_plane *pln = bsp->planes->get_plane(bf->get_plane_id());
		if(!(bf->is_on_front())) return;
		if(pln->get_normal().getz() < 0.7) return;
		}

	edge_list_strt = bf->get_edge_list_id();

	fpic->set_pen_rgb(255, 255, 255);

	for(i = 0; i < bf->get_edge_list_num(); i++)
		{
		edli = bsp->edgelists->get_edge_list(edge_list_strt + i);
		if(edli < 0) edli = - edli;
		src = bsp->edges->get_edge(edli)->get_vertex(0);
		dst = bsp->edges->get_edge(edli)->get_vertex(1);
		dpoints++;

		fpic->line((int)tr_vects[src].getx(), (int)tr_vects[src].gety(),
			(int)tr_vects[dst].getx(), (int)tr_vects[dst].gety());
		}
}
#endif


/* ------------------------------------------------------------------------- */
void print_leaf_type_str(long l)
{
int i = 0;

	if(l & 1) { printf("solid "); i++; }
	if(l & 2) { printf("window "); i++; }
	if(l & 4) { printf("aux "); i++; }
	if(l & 8) { printf("lava "); i++; }
	if(l & 16) { printf("slime "); i++; }
	if(l & 32) { printf("water "); i++; }
	if(l & 64) { printf("mist "); i++; }
	if(l & 128) { printf("sky "); i++; }
	if(l & 0x10000) { printf("playerclip "); i++; }
	if(l & 0x20000) { printf("monsterclip "); i++; }
	if(l & 0x20000000) { printf("ladder "); i++; }
	if(l & 0x8000000) { printf("detail "); i++; }
	if(i == 0) printf("normal (0x%08lx) ", l);
}


#if IMG
/* ------------------------------------------------------------------------- */
void draw_leaf(bsp_file *bsp, pic_info *fpic, vector *tr_vects, int leaf_num, int floor)
{
class bsp_leaf *bleaf;
int i, face_num, face_list_strt;

	bleaf = bsp->leaves->get_leaf(leaf_num);
	face_list_strt = bleaf->get_face_list_id();

	printf("> "); print_leaf_type_str(bleaf->get_type()); printf("\n");

	for(i = 0; i < bleaf->get_face_list_num(); i++)
		{
		face_num = bsp->facelist->get_facelist(face_list_strt + i);
		draw_face(bsp, fpic, tr_vects, face_num, floor);
		}

//	fpic->set_pen_rgb(190, 190, 190);
//	fpic->boxxy((bleaf->get_bbox_min().getx() * x_scale) + x_offset,
//		(bleaf->get_bbox_min().gety() * y_scale) + y_offset,
//		(bleaf->get_bbox_max().getx() * x_scale) + x_offset,
//		(bleaf->get_bbox_max().gety() * y_scale) + y_offset);
}


/* ------------------------------------------------------------------------- */
#define eye2screen	2100
#define eye2world    8

#define DB_WIDTH	800
#define DB_HEIGHT	700

void disp_bsp(bsp_file *bsp)
{
vector *tr_vects;
float min_x = 0, min_y = 0, min_z = 0, max_x = 0, max_y = 0, max_z = 0,
	x, y, z, tv;
int i, j, col;
long src, dst;
bsp_vertex *bv;

	for(i = 0; i < bsp->vertices->get_num(); i++)
		{
		bv = bsp->vertices->get_vertex(i);
		x = bv->get_position().getx();
		y = bv->get_position().gety();
		z = bv->get_position().getz();

		if(i == 0)
			{
			min_x = max_x = x;
			min_y = max_y = y;
			min_z = max_z = z;
			}
		else
			{
			if(x > max_x) max_x = x;
			if(x < min_x) min_x = x;
			if(y > max_y) max_y = y;
			if(y < min_y) min_y = y;
			if(z > max_z) max_z = z;
			if(z < min_z) min_z = z;
			}
		}

	printf("X: %.2f to %.2f  Y: %.2f to %.2f  Z: %.2f to %.2f\nSize: (%.2f x %.2f x %.2f)\n",
		min_x, max_x, min_y, max_y, min_z, max_z,
		max_x - min_x, max_y - min_y, max_z - min_z);

	x_scale = (max_x - min_x)/2;
	y_scale = (max_y - min_y)/2;
	z_scale = (max_z - min_z)/1;

	x_offset = (min_x + max_x)/2;
	y_offset = (min_y + max_y)/2;
	z_offset = (min_z + max_z)/2;

	tr_vects = new vector[bsp->vertices->get_num() + 20];
	for(i = 0; i < bsp->vertices->get_num(); i++)
		{
		bv = bsp->vertices->get_vertex(i);
		x = (bv->get_position().getx() - x_offset)/x_scale;
		y = (bv->get_position().gety() - y_offset)/y_scale;
		z = (bv->get_position().getz() - z_offset)/z_scale;

#define ANG		45
		tv = (y * cos((ANG * M_PI)/180)) - (z * sin((ANG * M_PI)/180));
		z = (y * sin((ANG * M_PI)/180)) + (z * cos((ANG * M_PI)/180));
		y = tv;

		tr_vects[i].set(((x * eye2screen)/(eye2world - z) + DB_WIDTH/2),
			((y * eye2screen)/(eye2world - z) + DB_HEIGHT/2),
			50 + ((z + 1) * 100));
		}

	pic_info fpic(DB_WIDTH + 20, DB_HEIGHT + 20, C_Y);
	x11_window xwin(10, 10, fpic.pwidth(), fpic.pheight(), "BSP Display");
	xwin.window_colours(fpic.pcolour_format(), fpic.pr_cmap(), fpic.pg_cmap(), fpic.pb_cmap());
	fpic.clear();

	for(i = 0; i < bsp->edges->get_num(); i++)
		{
		src = bsp->edges->get_edge(i)->get_vertex(0);
		dst = bsp->edges->get_edge(i)->get_vertex(1);
		col = (int)tr_vects[src].getz();
		fpic.set_pen_rgb(col, col, col);

		fpic.line((int)tr_vects[src].getx(), (int)tr_vects[src].gety(),
			(int)tr_vects[dst].getx(), (int)tr_vects[dst].gety());
		}

	xwin.display_image(fpic.ppic_a(), fpic.ppic_b(), fpic.ppic_c());
	xwin.wait_mouse();

	fpic.clear();
#if 1
		fpic.set_pen_rgb(100, 100, 100);
		for(i = 0; i < bsp->edges->get_num(); i++)
			{
			src = bsp->edges->get_edge(i)->get_vertex(0);
			dst = bsp->edges->get_edge(i)->get_vertex(1);
			fpic.line((int)tr_vects[src].getx(), (int)tr_vects[src].gety(),
				(int)tr_vects[dst].getx(), (int)tr_vects[dst].gety());
			}
#endif
	dpoints = 0;
	for(j = 0; j < bsp->leaves->get_num(); j++)
		draw_leaf(bsp, &fpic, tr_vects, j, 0);
	printf("%ld floor points.\n", dpoints);
	xwin.display_image(fpic.ppic_a(), fpic.ppic_b(), fpic.ppic_c());
	xwin.wait_mouse();

	for(j = 0; j < bsp->leaves->get_num(); j++)
		{
		if(bsp->leaves->get_leaf(j)->get_type() != bsp_leaf::normal &&
			bsp->leaves->get_leaf(j)->get_type() != bsp_leaf::solid)
			{
			fpic.clear();
			for(i = 0; i < bsp->edges->get_num(); i++)
				{
				src = bsp->edges->get_edge(i)->get_vertex(0);
				dst = bsp->edges->get_edge(i)->get_vertex(1);
				fpic.set_pen_rgb(100, 100, 100);
	
				fpic.line((int)tr_vects[src].getx(), (int)tr_vects[src].gety(),
					(int)tr_vects[dst].getx(), (int)tr_vects[dst].gety());
				}

			draw_leaf(bsp, &fpic, tr_vects, j, 1);

			xwin.display_image(fpic.ppic_a(), fpic.ppic_b(), fpic.ppic_c());
			xwin.wait_mouse();
			}
		}

	delete tr_vects;
	xwin.close_window();
}

#endif

/* ------------------------------------------------------------------------- */
void trunc_map(qdirectory *qdir, char *fname, char *dst)
{
QFILE *qpf;
bsp_file *bsp;

	if((qpf = qdir->qpopen(fname)) != NULL)
		{
		bsp = new bsp_file(qpf);
		delete qpf;

		qpf = new QFILE(dst);
		bsp->write_bsp_file(qpf);
		delete qpf;

		delete bsp;
		}
	else printf("`%s' not found.\n", fname);
}


/* ------------------------------------------------------------------------- */
void trans_file(qdirectory *qdir, char *fname, char *dst)
{
QFILE *qpf;
FILE *fp;
int ch;

	if((fp = fopen(dst, "wb")) == NULL)
		{
		printf("Error creating `%s'\n", dst);
		return;
		}

	if((qpf = qdir->qpopen(fname)) != NULL)
		{
		while((ch = qpf->get_byte()) != EOF) fputc(ch, fp);
		delete qpf;
		}
	else printf("`%s' not found.\n", fname);

	fclose(fp);
}


/* ------------------------------------------------------------------------- */
void copy_maps(qdirectory *qdir)
{
char src[80], dst[80];
int mn, ep;
void (*dmap)(qdirectory *qdir, char *fname, char *dst) = trunc_map;

	dmap(qdir, "/maps/start.bsp", "maps/start.bsp");
	dmap(qdir, "/maps/end.bsp", "maps/end.bsp");

	for(mn = 1; mn <= 6; mn++)
		{
		sprintf(src, "/maps/dm%d.bsp", mn);
		sprintf(dst, "maps/dm%d.bsp", mn);
		dmap(qdir, src, dst);
		}

	for(ep = 1; ep <= 4; ep++)
		{
		for(mn = 1; mn <= 7; mn++)
			{
			sprintf(src, "/maps/e%dm%d.bsp", ep, mn);
			sprintf(dst, "maps/e%dm%d.bsp", ep, mn);
			dmap(qdir, src, dst);
			}
		}
}


/* ------------------------------------------------------------------------- */
void help_cmd(void)
{
	printf("Quake PAK shell.  A quick hack for looking at PAK files.\n");
	printf("T. C. Ferguson, 1997.  Try these commands.  Look at source for more info.\n\n");
	printf("   lsr - recursive directory listing from current directory\n");
	printf("   ls - directory listing of current directory\n");
	printf("   cd <directory> - change directory\n");
	printf("   cp <file name> - copy file to `cp.out'\n");
	printf("   add <directory> - add a real directory to the virtual tree\n");
	printf("   cat and cat2 <file name> - display a text file to screen\n");
	printf("   bspt <map file> - attempt to truncate a bsp file for bots\n");
	printf("   maps - attempt to truncate all map files for bots\n");
	printf("   bsp <map file> - print bsp file information\n");
	printf("   files - list real files added to virtual tree\n");
	printf("   q or quit - quit shell\n\n");
}


/* ------------------------------------------------------------------------- */
int main(int argc, char **argv)
{
qdirectory qdir;
int i, running = 1, ch;
char buf[80];
QFILE *qpf;
bsp_file *bsp;

	qdir.add_dir("id1/");
	qdir.add_dir("qw/");
	qdir.add_dir("baseq2/");
	for(i = 1; i < argc; i++)
		qdir.add_dir(argv[i]);

	printf("Quake Pack Shell.  by T. C. Ferguson, 1997.\nType help for more info\n\n");

	while(running)
		{
		qdir.print_path(qdir.get_cwd());
		printf(" > ");
		gets(buf);

		if(!strncmp(buf, "lsr", 3)) qdir.rdir(qdir.get_cwd());
		else if(!strncmp(buf, "ls", 2)) qdir.dir(qdir.get_cwd());
		else if(!strncmp(buf, "help", 4)) help_cmd();
		else if(!strncmp(buf, "cd", 2))
			{
			if(!qdir.chdir(buf + 3))
				printf("`%s' not found.\n", buf + 3);
			}
		else if(!strncmp(buf, "cp", 2)) trans_file(&qdir, buf + 3, "cp.out");
		else if(!strncmp(buf, "add", 3))
			{
			if(!qdir.add_dir(buf + 4))
				printf("`%s' not found.\n", buf + 4);
			}
		else if(!strncmp(buf, "cat2", 4))
			{
			if((qpf = qdir.qpopen(buf + 5)) != NULL)
				{
				while((ch = qpf->get_byte()) != EOF)
					{
					putchar(ch);
					qpf->get_byte();
					}
				delete qpf;
				}
			else printf("`%s' not found.\n", buf + 4);
			}
		else if(!strncmp(buf, "cat", 3))
			{
			if((qpf = qdir.qpopen(buf + 4)) != NULL)
				{
				while((ch = qpf->get_byte()) != EOF) putchar(ch);
				delete qpf;
				}
			else printf("`%s' not found.\n", buf + 4);
			}
#if IMG
		else if(!strncmp(buf, "dbsp", 4))
			{
			if((qpf = qdir.qpopen(buf + 5)) != NULL)
				{
				bsp = new bsp_file(qpf);
				bsp->print_info();
				disp_bsp(bsp);
				delete qpf;
				delete bsp;
				}
			else printf("`%s' not found.\n", buf + 4);
			}
#endif
		else if(!strncmp(buf, "bspt", 4))
			{
			trunc_map(&qdir, buf + 5, "xx/maps/xxx.bsp");
			}
		else if(!strncmp(buf, "bsp", 3))
			{
			if((qpf = qdir.qpopen(buf + 4)) != NULL)
				{
				bsp = new bsp_file(qpf);
				if(bsp->ok())
					{
					bsp->print_info();
					bsp->print2();
					delete bsp;
					}
				delete qpf;
				}
			else printf("`%s' not found.\n", buf + 4);
			}
		else if(!strncmp(buf, "maps", 4)) copy_maps(&qdir);
		else if(!strncmp(buf, "files", 5)) qdir.print_disk_files();
		else if(!strcmp(buf, "q") || !strcmp(buf, "quit")) running = 0;
		else printf("Unknown command `%s'\n", buf);
		}
}

