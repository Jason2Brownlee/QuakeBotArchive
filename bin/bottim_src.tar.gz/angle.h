/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _ANGLE_H_
#define _ANGLE_H_

#include "vector.h"

class angle
{
private:
	float roll, pitch, yaw;

public:
	angle(void) { roll = pitch = yaw = 0.0; }
	angle(int) { roll = pitch = yaw = 0.0; }
	angle(float r, float p, float y) { roll = r; pitch = p; yaw = y; }
	angle(vector &vect) { roll = vect.get_roll(); pitch = vect.get_pitch();
		yaw = vect.get_yaw(); }
	~angle() {}

	void set(float r, float p, float y) { roll = r; pitch = p; yaw = y; }
	void set_roll(float r) { roll = r; }
	void set_pitch(float p) { pitch = p; }
	void set_yaw(float y) { yaw = y; }

	float get_roll(void) { return roll; }
	float get_pitch(void) { return pitch; }
	float get_yaw(void) { return yaw; }

	vector get_vector(void);
	void get_angle(vector &vect) { roll = vect.get_roll();
		pitch = vect.get_pitch(); yaw = vect.get_yaw(); }
	void get_orientation(vector &front, vector &right, vector &up);

	void print(void) { printf("(R: %.2f, P: %.2f, Y: %.2f)", roll, pitch, yaw); }
};

#endif

