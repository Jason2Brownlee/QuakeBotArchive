/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _ENTITIES_H_
#define _ENTITIES_H_

#include "qfile.h"
#include <fcntl.h>
#include <stdio.h>

class bsp_entities
{
	int data_size;
	char *data;

	public:
		bsp_entities(QFILE *qf, int x) { data_size = x;  data = new char[data_size];
			qf->read(data, 1, x); }
		~bsp_entities(void) { delete data; }

		void write(QFILE *qf) { qf->write(data, 1, data_size); }
		char *get_entities(void) { return data; }
		int get_num(void) { return data_size; }
		void print(void) { for(int i = 0; i < data_size; i++ ) putchar(data[i]); }
};

#endif
