/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *
 *  Routines to handle vectors - an important part of any Quake bot!
 * ------------------------------------------------------------------------ */
#include <math.h>
#include <stdio.h>

#include "vector.h"

/* -------------------------------------------------------------------------
 *   scale : makes the vector x units in length
 */
void vector::scale( int a )
{
	normalize();
	(*this) *= (float) a;
}


/* -------------------------------------------------------------------------
 * set_from_PY : initializes the vector from the pitch, yaw passed
 */
void vector::set_from_PY(float pitch, float yaw)
{
float cosPitch = (float)cos( pitch );
   
	x = (float)cos(yaw) * cosPitch;
	y = (float)sin(yaw) * cosPitch;
	z = (float)sin(pitch);
}


/* -------------------------------------------------------------------------
 *  print() to stdout
 */
void vector::print(void)
{
	printf("(%.3f, %.3f, %.3f)", x, y, z);
}


/* -------------------------------------------------------------------------
 *  operator + () : add two vectors
 */
vector vector::operator + (vector & rhs)
{
vector r;

	r.x = x+rhs.x;
	r.y = y+rhs.y;
	r.z = z+rhs.z;

	return r;
}


/* -------------------------------------------------------------------------
 *  operator - () : substract *this from rhs
 */
vector vector::operator - (vector & rhs)
{
vector r;

	r.x = x - rhs.x;
	r.y = y - rhs.y;
	r.z = z - rhs.z;

	return r;
}


/* -------------------------------------------------------------------------
 *  operator - () : negate vector
 */
vector vector::operator - ( )
{
	return vector( -x, -y, -z );
}


/* -------------------------------------------------------------------------
 *  operator * () : dot product
 */
float vector::operator * (const vector & rhs)
{
float r=(float)0;

	r += x * rhs.x;
	r += y * rhs.y;
	r += z * rhs.z;

	return r;
}


/* -------------------------------------------------------------------------
 *  X() : return cross product of *this and rhs
 */
vector vector::X( vector & rhs )
{
vector r;

	r.x = (y * rhs.z) - (z * rhs.y);
	r.y = (z * rhs.x) - (x * rhs.z);
	r.z = (x * rhs.y) - (y * rhs.x);

	return r;
}


/* -------------------------------------------------------------------------
 *  normalize() : normalized the current vector. no return value.
 */
void vector::normalize()
{
float length = this->length();

	x = x / length;
	y = y / length;
	z = z / length;
}


/* -------------------------------------------------------------------------
 *
 */
void vector::operator /= ( float n )
{
	if( n==0.0)
		return;
	x /= n;
	y /= n;
	z /= n;
}


/* -------------------------------------------------------------------------
 *
 */
void vector::operator += ( vector & v )
{
	x += v.x;
	y += v.y;
	z += v.z;
}


/* -------------------------------------------------------------------------
 *
 */
void vector::operator -= ( vector & v )
{
	x -= v.x;
	y -= v.y;
	z -= v.z;
}



/* -------------------------------------------------------------------------
 *  length() :
 */
float vector::length()
{
	return (float)sqrt(x*x + y*y + z*z);
}


/* -------------------------------------------------------------------------
 *  length2D() :
 */
float vector::length2D()
{
	return (float)sqrt(x*x + y*y);
}


/* -------------------------------------------------------------------------
 *  get_yaw : returns yaw represented by vector. thanks to the terminator code
 */
float vector::get_yaw()
{
float yaw;
int flipv = 1;
int fliph = 1;
float X = x, Y = y;

	if(Y < 0) Y = -Y;
	else flipv = 0;

	if(X < 0) X = -X;
	else fliph = 0;

	if(X < Y) yaw = (float)_PI2 - (float)atan(X/Y);
	else if(X > 0.0) yaw = (float)atan(Y/X);
	else yaw = (float)0;

	if(fliph == 1) yaw = (float)_PI - yaw;
	if(flipv == 1) yaw = -yaw;
	yaw = (float)fmod(yaw, 2*(float)_PI);
	yaw = ((float)180/(float)_PI)*yaw;
	yaw = (float)fmod(yaw + 180.0, (float)360.0);

	return yaw;
}


/* -------------------------------------------------------------------------
 *  get_pitch : returns the pitch represented by the vector. terminator again
 */
float vector::get_pitch()
{ 
float tilt;
int flipv = 1;
float X = (float)sqrt(x * x + y * y);
float Z = z;

	if(Z < 0) Z = -Z;
	else flipv=0;

	if(X < 0) X =- X;
	if(X < Z) tilt = (float)_PI2 - (float)atan(X/Z);
	else if(X > 0.0) tilt = (float)atan(Z/X);
	else tilt = (float)0;

	if(flipv == 1) tilt = -tilt;

	return ((float)180/(float)_PI) * tilt;
}

