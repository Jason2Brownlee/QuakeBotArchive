/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _QPLAYER_H_
#define _QPLAYER_H_

#include "vector.h"
#include "angle.h"

/* ------------------------------------------------------------------------- */
class qplayer
{
public:
	long user;
	char *text;
	char *name;
	int frags;
	int ping;
	float enter_time;
	vector origin;
	int frame;
	unsigned char load;
	angle pangle;
	int speed[3];
	int flags;
	int impulse;
	vector cspeed;
	int model;
	int weapon;
	int weapon_frame;

	qplayer() { text = (char *)0; }
	~qplayer() { delete text; }
};

#endif

