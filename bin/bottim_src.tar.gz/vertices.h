/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _VERTICES_H_
#define _VERTICES_H_

#include "vector.h"
#include "qfile.h"

class bsp_vertex
{
	vector position;

	public:
		bsp_vertex(QFILE *qf) { read(qf); }
		void read(QFILE *qf) { position.setx(qf->get_float());
			position.sety(qf->get_float());
			position.setz(qf->get_float()); }
		void write(QFILE *qf) { qf->put_float(position.getx());
			qf->put_float(position.gety());
			qf->put_float(position.getz()); }
		void print() { position.print(); putchar('\n'); }
		vector get_position(void) { return position; }
};


class bsp_vertices
{
	bsp_vertex **vertices;
	int loaded_vertices;

	public:
		bsp_vertices(QFILE *qf, int x) { vertices = new bsp_vertex* [x];
			loaded_vertices = 0; for(int i=0; i < x; i++) vertices[i] = NULL;
			read(qf, x); }
		~bsp_vertices(void) { for(int i=0; i < loaded_vertices; i++) delete vertices[i];
			delete vertices; }

		void read(QFILE *qf, int n) { for(int i=0; i < n; i++) vertices[i] = new bsp_vertex(qf);
			loaded_vertices = n; }
		void write(QFILE *qf) { for(int i=0; i < loaded_vertices; i++) vertices[i]->write(qf); }
		int get_num() { return loaded_vertices; }
		bsp_vertex * get_vertex(int x) { return(x >= 0 && x < loaded_vertices ? vertices[x] : (bsp_vertex *)NULL); }
		void print() { for(int i = 0; i < loaded_vertices; i++ ) { printf("%d : ", i); vertices[i]->print(); } }
};

#endif
