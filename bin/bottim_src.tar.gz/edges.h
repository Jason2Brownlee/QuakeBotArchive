/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _EDGES_H_
#define _EDGES_H_

#include "qfile.h"

class bsp_edge
{
	unsigned short vertex[2];

	public:
		bsp_edge(QFILE *qf) { read(qf); }

		void read(QFILE *qf) { vertex[0] = qf->get_ushort();
			vertex[1]=qf->get_ushort(); }
		void write(QFILE *qf) { qf->put_short(vertex[0]);
			qf->put_short(vertex[1]); }
		int get_vertex(int x) { return((x == 0 || x == 1) ? (int)vertex[x] : 0); }
		void print() { printf("%d - %d\n", vertex[0], vertex[1]); }
};


class bsp_edges
{
	bsp_edge ** edges;
	int loaded_edges;

	public:
		bsp_edges(QFILE *qf, int n) { edges = new bsp_edge* [n];
			for(int i = 0; i < n; i++) edges[i] = 0; loaded_edges = 0;
			read(qf, n); }

		void read(QFILE *qf, int n) { for(int i=0; i < n; i++)
			edges[i] = new bsp_edge(qf); loaded_edges = n; }
		void write(QFILE *qf) { for(int i=0; i < loaded_edges; i++) edges[i]->write(qf); }
		int get_num() { return loaded_edges; }
		bsp_edge *get_edge(int x) { return(x >= 0 && x < loaded_edges ? edges[x] : 0); }
		void print() { for(int i = 0; i < loaded_edges; i++) { printf("%d : ", i); edges[i]->print(); } }
};


#endif

