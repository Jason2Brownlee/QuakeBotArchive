/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _MODELS_H_
#define _MODELS_H_

#include "qfile.h"
#include "vector.h"

class bsp_model
{
	vector bbox_min;
	vector bbox_max;
	vector origin;
	long bsp_node_id;		// root BSP node
	long clip_node_id0;		// first clip root node
	long clip_node_id1;		// second(?) clip root node
	long node_id;			// unknown
	long num_leaves;
	long face_id;
	long face_num;

	public:
		bsp_model(QFILE *qf, int v) { read(qf, v); }

		void read(QFILE *qf, int version) {
			bbox_min.setx(qf->get_float());
			bbox_min.sety(qf->get_float());
			bbox_min.setz(qf->get_float());
			bbox_max.setx(qf->get_float());
			bbox_max.sety(qf->get_float());
			bbox_max.setz(qf->get_float());
			origin.setx(qf->get_float());
			origin.sety(qf->get_float());
			origin.setz(qf->get_float());
			bsp_node_id = qf->get_long();
			if(version != 38)
				{
				clip_node_id0 = qf->get_long(); clip_node_id1 = qf->get_long();
				node_id = qf->get_long(); num_leaves = qf->get_long();
				}
			face_id = qf->get_long(); face_num = qf->get_long(); }
		void write(QFILE *qf, int version) {
			qf->put_float(bbox_min.getx());
			qf->put_float(bbox_min.gety());
			qf->put_float(bbox_min.getz());
			qf->put_float(bbox_max.getx());
			qf->put_float(bbox_max.gety());
			qf->put_float(bbox_max.getz());
			qf->put_float(origin.getx());
			qf->put_float(origin.gety());
			qf->put_float(origin.getz());
			qf->put_long(bsp_node_id);
			if(version != 38)
				{
				qf->put_long(clip_node_id0); qf->put_long(clip_node_id1);
				qf->put_long(node_id); qf->put_long(num_leaves);
				}
			qf->put_long(face_id); qf->put_long(face_num); }
		vector get_bbox_min(void) { return bbox_min; }
		vector get_bbox_max(void) { return bbox_max; }
		vector get_origin(void) { return origin; }
		long get_bsp_root(void) { return bsp_node_id; }
		long get_clip_node_root0(void) { return clip_node_id0; }
		long get_clip_node_root1(void) { return clip_node_id1; }
		long get_node(void) { return node_id; }
		long get_num_leaves(void) { return num_leaves; }
		long get_face_id(void) { return face_id; }
		long get_face_num(void) { return face_num; }
		void print(void) { printf("%ld %ld %ld\n", bsp_node_id, face_id, face_num ); }
};


class bsp_models
{
	bsp_model ** models;
	int loaded_models;

	public:
		bsp_models(QFILE *qf, int n, int v) { models = new bsp_model* [n];
			for(int i = 0; i < n; i++) models[i] = NULL; loaded_models = 0;
			read(qf, n, v); }

		void read(QFILE *qf, int n, int v) { for(int i = 0; i < n; i++)
			models[i] = new bsp_model(qf, v); loaded_models = n; }
		void write(QFILE *qf, int v) { for(int i = 0; i < loaded_models; i++) models[i]->write(qf, v); }
		bsp_model *get_model(int x) { return(x >= 0 && x < loaded_models ? models[x] : 0); }
		int get_num(void) { return loaded_models; }
		void print(void) { for(int i = 0; i < loaded_models; i++) models[i]->print(); }
};

#endif

