/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *
 *  An attempt at a proxy interface to the bot.  This would alow viewing
 *  of the bots movements, etc. only.  Not as a cheat proxy.
 * ------------------------------------------------------------------------ */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include "qwb.h"
#include "qsock.h"
#include "qpack.h"
#include "qpcodec.h"
#include "proxy.h"

char *welcome_str =
	"\n\200\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\202\n\n"
	"     Welcome to BotTim Proxy\n"
	"(c) Tim Ferguson, 1998.\n"
	"www.dgs.monash.edu.au/~timf/bottim\n"
	"\n\200\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\201\202\n\n"
	"";

/* ------------------------------------------------------------------------- */
proxy::proxy(long port)
{
	qloc = new qsock(port);
	qp_in = new qpack(10000);
	qp_out = new qpack(10000);

	seq_num = last_rec_seq = 0;
	hid_bit = 1;
}


/* ------------------------------------------------------------------------- */
void proxy::send_special(char *msg)
{
	qp_out->start_special();
	qp_out->put_string(msg);
	qp_out->send(qloc);
}


/* ------------------------------------------------------------------------- */
void proxy::decode_packet(void)
{
int opcode, eval = 1, i, mask;
long seq1, seq2, raddr;
char *str;

	seq1 = qp_in->get_long();
	if(seq1 == -1)		/* special message */
		{
		str = qp_in->get_string();
		if(strncmp(str, "connect", 7) == 0)
			{
			raddr = qloc->getRemoteAddr();
			printf("Proxy connect from: %d.%d.%d.%d:%d\n", (int)(raddr >> 24) & 0xff,
				(int)(raddr >> 16) & 0xff, (int)(raddr >> 8) & 0xff, (int)raddr & 0xff,
				qloc->getRemotePort());
			printf("Connect request.\n");
			send_special("j");
			}
		printf("Special message: `%s'\n", str);
		}
	else
		{
		last_rec_seq = seq2 = qp_in->get_long();
		if((seq1 >> 31) & 0x01) hid_bit = !hid_bit;

		qp_out->start_game_packet(seq_num++, last_rec_seq, 0, hid_bit);

		while(eval)
			{
			opcode = qp_in->get_byte();

			switch(opcode)
				{
				case 0x03:
					for(i = 0; i < 3; i++)
						{
						mask = qp_in->get_byte();
						if(mask & 0x01) qp_in->get_angle16();
						qp_in->get_angle16();
						if(mask & 0x02) qp_in->get_angle16();
						if(mask & 0x04) qp_in->get_byte();
						if(mask & 0x08) qp_in->get_byte();
						if(mask & 0x10) qp_in->get_byte();
						if(mask & 0x20) qp_in->get_byte();
						if(mask & 0x40) qp_in->get_byte();
						if(mask & 0x80) qp_in->get_byte();
						}
					break;

				case 0x04:		/* console command */
					str = qp_in->get_string();
					if(strncmp(str, "say", 3) == 0) printf("SAY: %s\n", str + 4);
					else if(strncmp(str, "new", 3) == 0)
						{
						printf("NEW\n");
						qp_out->put_byte(0x08);
						qp_out->put_byte(1);
						qp_out->put_string(welcome_str);
						}
					else if(strncmp(str, "drop", 4) == 0) printf("DROP\n");
					else printf("CC: `%s'\n", str);
					break;

				case 0x05:
					printf("UNK: %d\n", qp_in->get_byte());
					break;

				case 0x06:
					printf("UNK: ");
					for(i = 0; i < 6; i++) printf("%d, ", qp_in->get_byte());
					printf("\n");
					break;

				default:
					eval = 0;
				}
	//		if(qp_in->get_read_pos() >= len) return(0);
			}

		qp_out->send(qloc);
		}
}


/* ------------------------------------------------------------------------- */
void proxy::update(void)
{
int recvd;

	qp_in->reset();
	recvd = qloc->receive(qp_in->get_buffer(), qp_in->get_max_size());
	decode_packet();
}

