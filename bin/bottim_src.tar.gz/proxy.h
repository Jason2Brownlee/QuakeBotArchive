/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _PROXY_H_
#define _PROXY_H_

class proxy
{
	qsock *qloc;
	qpack *qp_in, *qp_out;
	long seq_num, last_rec_seq, hid_bit;

	public:
		proxy(long port);
		void send_special(char *msg);
		void decode_packet(void);
		void update(void);

		void fd_set_loc(fd_set *set) { FD_SET(qloc->getFD(), set); }
		int fd_isset_loc(fd_set *set) { return(FD_ISSET(qloc->getFD(), set)); }
};

#endif

