/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *
 *  A proxy for analysing packets between a QuakeWorld client and a QuakeWorld
 *  server.  This is probably not up to date, so will need reworking for
 *  the latest version of QuakeWorld.
 * ------------------------------------------------------------------------ */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include <limits.h>
#include <netdb.h>
#include <arpa/inet.h>

#include "qwb.h"
#include "qsock.h"
#include "qpack.h"
#include "qplayer.h"
#include "qentity.h"
#include "vector.h"

qplayer players[32];
qentity entities[450];
long player_stats[40];
int hackin = 0, d_rot = 0;
char *precache_models[256], *precache_sounds[256];

#define DBUG	1

/*
unsigned ChecksumQW221(unsigned char *buf, int nbytes, unsigned seqnum);
*/

/* ------------------------------------------------------------------------- */
void hex_dump_buf(unsigned char *buf, int len)
{
int pos = 0, llen, i;

	while(pos < len)
		{
		llen = (len - pos < 16 ? len - pos : 16);
		printf("%08x: ", pos);
		for(i = 0; i < llen; i++) printf("%02x ", buf[pos + i]);
		for(i = 0; i < 16 - llen; i++) printf("   ");
		printf(" | ");

		for(i = 0; i < llen; i++)
			printf("%c", isprint(buf[pos + i]) ? buf[pos + i] : '.');
		for(i = 0; i < 16 - llen; i++) printf(" ");
		printf("\n");
		pos += llen;
		}
}


/* ------------------------------------------------------------------------- */
void ascii_dump_buf(unsigned char *buf, int len)
{
int pos = 0, llen, i;

	while(pos < len)
		{
		llen = (len - pos < 60 ? len - pos : 60);
		printf("%08x: ", pos);
		for(i = 0; i < llen; i++)
			printf("%c", isprint(buf[pos + i]) ? buf[pos + i] : '.');
		printf("\n");
		pos += llen;
		}
}


/* ------------------------------------------------------------------------- */
long last_rec_seq = 0;
int hbit = 0;

int analyze_packet_client(qpack *qp, int len)
{
int opcode, mask, eval = 1, i;
long seq1, seq2, pak_id, cksum_pos, cksum_len;
unsigned int cksum_read, cksum_calc;

	seq1 = qp->get_long();
	if(seq1 == -1)		/* special message */
		{
		printf("Special message: `%s'\n", qp->get_string());
		}
	else
		{
		seq2 = qp->get_long();

		if((seq1 >> 31) & 0x01) printf("CL_RELIABLE\n");
		pak_id = qp->get_ushort();

		while(eval)
			{
			opcode = qp->get_byte();
#if DBUG
			printf("<");
			if((seq1 >> 31) & 0x01) printf("*");
			printf("%ld,", seq1 & 0x7FFFFFFF);
			if((seq2 >> 31) & 0x01) printf("*");
			printf("%ld>  [%ld] 0x%02x: ", seq2 & 0x7FFFFFFF, pak_id, opcode);
			if((seq2 >> 31) & 0x01 != hbit) printf(" ## %d ## ", hbit);
#endif

			switch(opcode)
				{
				case 0x03:
					printf("User move:");
					cksum_read = qp->get_byte();
					printf("  checksum = %02x", cksum_read);
					cksum_pos = qp->get_read_pos();
					for(i = 0; i < 3; i++)
						{
						mask = qp->get_byte();
						printf("\n  mask = %02x", mask);
						if(mask & 0x01) printf("  Tilt: %f", qp->get_angle16());
						printf("  Yaw: %f", qp->get_angle16());
						if(mask & 0x02) printf("  Roll: %f", qp->get_angle16());
						if(mask & 0x04) printf("  Forward: %d", qp->get_byte());
						if(mask & 0x08) printf("  Right: %d", qp->get_byte());

						if(hackin && mask & 0x10)
							qp->get_buffer()[qp->get_read_pos()] = (d_rot++ & 0xff);

						if(mask & 0x10) printf("  Up: %d", qp->get_byte());
						if(mask & 0x20) printf("  Flags: %d", qp->get_byte());
						if(mask & 0x40) printf("  Impulse: %d", qp->get_byte());
						if(mask & 0x80) printf("  Load: %d", qp->get_byte());
						}
					cksum_len = qp->get_read_pos() - cksum_pos;
	/*				cksum_calc = ChecksumQW221((unsigned char *)&((qp->get_buffer()[cksum_pos])), cksum_len, seq1 & 0x7FFFFFFF);
					printf(" <<%02x>> ", cksum_calc);
					if(cksum_read == cksum_calc) printf("*** CHKSUM OK ***");
					else printf("*** CHKSUM ERROR ***"); */
					break;

				case 0x04:		/* console command */
					printf("%s", qp->get_string());
					break;

				case 0x05:
/*					qp->get_buffer()[qp->get_read_pos()] = 50; */
					printf("UNK: %d", qp->get_byte());
					break;

				case 0x06:
					printf("UNK: ");
			/*			{
						char *ch;
						ch = qp->get_buffer() + qp->get_read_pos();
						ch[0] = 0;
						ch[1] = 0;
						ch[2] = 0;
						ch[3] = 0;
						ch[4] = 0;
						ch[5] = 0;
						} */

					for(i = 0; i < 6; i++) printf("%d, ", qp->get_byte());
					break;

				default:
#if 0
					if(opcode & 0x80)
						{
						printf("User move:");
						if(opcode & 0x01) printf("  Tilt: %f", qp->get_angle16());
						printf("  Yaw: %f", qp->get_angle16());
						if(opcode & 0x02) printf("  Roll: %f", qp->get_angle16());
						if(opcode & 0x04) printf("  Forward: %d", qp->get_byte());
						if(opcode & 0x08) printf("  Right: %d", qp->get_byte());

						if(hackin && opcode & 0x10)
							qp->get_buffer()[qp->get_read_pos()] = (d_rot++ & 0xff);

						if(opcode & 0x10) printf("  Up: %d", qp->get_byte());
						if(opcode & 0x20) printf("  Flags: %d", qp->get_byte());
						if(opcode & 0x40) printf("  Impulse: %d", qp->get_byte());
						printf("  Load: %d", qp->get_byte());
						}
					else
#endif
						eval = 0;
				}
#if DBUG
			printf("\n");
#endif
			if(qp->get_read_pos() >= len) return(0);
			}
		}

	return (qp->get_read_pos() >= len ? 0 : 1);
}


/* ------------------------------------------------------------------------- */
void display_players(void)
{
int i;

	printf("                                                              \n");
	for(i = 0; i < 32; i++)
		{
		if(players[i].text != (char *)0 && players[i].text[0] != '\0')
			printf("%2d:`%20s':  %3d  %3d  (%5.2f,%5.2f,%5.2f)\n",
				i, players[i].name, players[i].ping, players[i].frags,
				players[i].origin.getx(), players[i].origin.gety(), players[i].origin.getz());
		}
	printf("                                                              \n");
}


/* ------------------------------------------------------------------------- */
int analyze_packet_server(qpack *qp, int len)
{
qplayer *pl;
qentity *ent;
int opcode, eval = 1, usr, i, num, mask1, mask2 = 0, v1, v2 = 0, v3;
long seq1, seq2, lv1;

	seq1 = qp->get_long();
	if(seq1 == -1)		/* special message */
		{
		printf("Special message: `%s'\n", qp->get_string());
		last_rec_seq = 0;
		hbit = 0;
		}
	else
		{
		last_rec_seq = seq2 = qp->get_long();
		if((seq1 >> 31) & 0x01)
			{
			hbit = !hbit;
			printf("SV_RELIABLE\n");
			}

		while(eval)
			{
			opcode = qp->get_byte();
#if DBUG
			printf("<");
			if((seq1 >> 31) & 0x01) printf("*");
			printf("%ld,", seq1 & 0x7FFFFFFF);
			if((seq2 >> 31) & 0x01) printf("*");
			printf("%ld>  0x%02x: ", seq2 & 0x7FFFFFFF, opcode);
#endif
			switch(opcode)
				{
				case 0x02:		/* leave the games */
					printf(" <Quit> ");
					break;

				case 0x03:		/* update stat */
					i = qp->get_byte();
					player_stats[i] = qp->get_byte();
#if DBUG
					printf("Update stat: index %d  val: %ld", i, player_stats[i]);
#endif
					break;

				case 0x06:		/* Sound */
					lv1 = qp->get_short();
					printf("Play sound: vol: %f", (lv1 & 0x8000 ? (float)qp->get_byte()/255.0 : 1.0));
					printf("  attn: %f", (lv1 & 0x4000 ? (float)qp->get_byte()/64.0 : 1.0));
					printf("  chan: %d", (int)(lv1 & 0x07));
					printf("  entity: %d", (int)((lv1 >> 3) & 0x03ff));
					printf("  sound num: %d", qp->get_byte());
					for(i = 0; i < 3; i++) printf("  coord%d: %f", i+1, qp->get_coord());
					break;

				case 0x08:		/* print */
					printf("[%d]", qp->get_byte());
					printf("%s", qp->get_string());
					break;

				case 0x09:		/* stufftext */
					printf("Stufftext: %s", qp->get_string());
					break;

				case 0x0a:		/* set angle */
					printf("Set Angle:  %f,%f,%f", qp->get_angle(), qp->get_angle(), qp->get_angle());
					break;

				case 0x0b:		/* server data */
					printf("Server data:");
					printf("  Version: %ld", qp->get_long());
					printf("  Client ID: %ld", qp->get_long());
					printf("  Dir: %s", qp->get_string());
					printf("  ID2: %d", qp->get_byte());
					printf("  Map name: %s", qp->get_string());
					for(i = 0; i < 42; i++) qp->get_byte();
					break;

				case 0x0c:		/* light style */
					printf("Light style: %d -", qp->get_byte());
					printf(" %s", qp->get_string());
					break;

				case 0x0e:		/* update frags */
					usr = qp->get_byte();
					players[usr].frags = qp->get_short();
#if DBUG
					printf("Update frags: user %d  frags: %d", usr, players[usr].frags);
#endif
					break;

				case 0x10:		/* stop sound */
					printf("Stop sound: %d", qp->get_short());
					break;

				case 0x13:		/* damage */
					printf("Damage: armor sub: %d  health sub: %d", qp->get_byte(), qp->get_byte());
					printf("  from: %f,%f,%f", qp->get_coord(), qp->get_coord(), qp->get_coord());
					break;

				case 0x14:		/* spawn static */
					v1 = qp->get_byte();
					printf("Spawn static: Model index: %d (%s)", v1, precache_models[v1]);
					printf("  Frame: %d  Colormap: %d  Skin: %d", qp->get_byte(),
						qp->get_byte(), qp->get_byte());
					for(i = 0; i < 3; i++)
						printf("  Org%d: %f  Ang%d: %f", i+1, qp->get_coord(), i+1, qp->get_angle());
					break;

				case 0x16:		/* spawn base line */
					v1 = qp->get_entity();		/* Entity */
					if(v1 > 449) printf("Error: Invalid entity number: %d.\n", v1);
					ent = &entities[v1];
					ent->spawned = 1;

						/* default model index, frame,  colormap, skin */
					ent->default_index = qp->get_byte();
					ent->frame = qp->get_byte();
					v2 = qp->get_byte();
					ent->skin = qp->get_byte();
					ent->origin.setx(qp->get_coord());
					ent->facing.set_pitch(qp->get_angle());
					ent->origin.sety(qp->get_coord());
					ent->facing.set_yaw(qp->get_angle());
					ent->origin.setz(qp->get_coord());
					ent->facing.set_roll(qp->get_angle());

#if DBUG
					printf("Spawn base line: Entity: %d", v1);
					v3 = ent->default_index;
					printf("  Default: model index: %d (%s)  frame: %d  colormap: %d  skin: %d",
						ent->default_index, precache_models[v3],
						ent->frame, v2, ent->skin);
					printf("  org: ");
					ent->origin.print();
					printf("  ang: ");
					ent->facing.print();
#endif
					break;

				case 0x17:		/* temp_entity */
					v1 = qp->get_byte();		/* entity type */
					printf("Temp Entity: type: %d", v1);
					switch(v1)
						{
						case 0:
						case 1:
						case 3:
						case 4:
						case 7:
						case 8:
						case 10:
						case 11:
						case 13:
							printf("  origin: %f,%f,%f", qp->get_coord(), qp->get_coord(), qp->get_coord());
							break;
						case 5:
						case 6:
						case 9:
							printf("  created by: %ld", qp->get_entity());		/* entity that created from */
							printf("  origin: %f,%f,%f", qp->get_coord(), qp->get_coord(), qp->get_coord());
							printf("  trace endpos: %f,%f,%f", qp->get_coord(), qp->get_coord(), qp->get_coord());
							break;
						case 2:
						case 12:
							printf("  count: %d", qp->get_byte());		/* count */
							printf("  origin: %f,%f,%f", qp->get_coord(), qp->get_coord(), qp->get_coord());
							break;
						}
					break;

				case 0x1a:		/* center print */
					printf("Center print: %s", qp->get_string());
					break;

				case 0x1b:		/* killed monster */
					printf("Monster killed");
					break;

				case 0x1c:		/* found secret */
					printf("Found secret");
					break;

				case 0x1d:		/* span static sound */
					printf("Static sound: at %f,%f,%f", qp->get_coord(), qp->get_coord(), qp->get_coord());
					i = qp->get_byte();
					printf("  Num: %d (%s)  Vol: %f  Attn: %f", i, precache_sounds[i],
						(float)qp->get_byte()/255.0, (float)qp->get_byte()/64.0);
					break;

				case 0x22:		/* small kick */
					printf("Small kick");
					break;

				case 0x23:		/* big kick */
					printf("Big kick");
					break;

				case 0x24:		/* update ping */
					usr = qp->get_byte();
					players[usr].ping = qp->get_short();
#if DBUG
					printf("Update ping: user: %d  ping %d", usr, players[usr].ping);
#endif
					break;

				case 0x25:		/* update enter time */
					usr = qp->get_byte();
					players[usr].enter_time = qp->get_float();
#if DBUG
					printf("Update enter time: user: %d  enter time: %f", usr, players[usr].enter_time);
#endif
					break;

				case 0x26:		/* update stat long */
					printf("Update stat l: index: %d  val: %ld", qp->get_byte(), qp->get_long());
					break;

				case 0x27:		/* muzzle flash */
					printf("Muzzle flags: %ld", qp->get_entity());
					break;

				case 0x28:		/* update user info */
					usr = qp->get_byte();
					pl = &players[usr];
					if(pl->text != (char *)0) delete pl->text;
					pl->user = qp->get_long();
					pl->text = qp->get_nstring();
					pl->name = strstr(pl->text, "name\\");
					if(pl->name != NULL)
						{
						pl->name += 5;
						for(i = 0; pl->name[i] != '\\' && pl->name[i] != '\0'; i++);
						pl->name[i] = '\0';
						}
#if DBUG
					printf("Update user info: user: %d  User ID: %ld  Info: %s",
						usr, players[usr].user, players[usr].text);
#endif
					break;

				case 0x29:		/* download */
					printf("Download: %d bytes", v1 = qp->get_short());
					printf(" at %%%d", v2 = qp->get_byte());
					if(v1 == 0xffff && v2 == 0x00) printf(" >> File not found.");
					else for(i = 0; i < v1; i++) qp->get_byte();
					break;

				case 0x2a:		/* player info */
					usr = qp->get_byte();
					pl = &players[usr];
					mask1 = qp->get_short();
					pl->origin.set(qp->get_coord(), qp->get_coord(), qp->get_coord());
					pl->frame = qp->get_byte();
					if(mask1 & 0x0001) /* pl->ping = */ qp->get_byte();
					if(mask1 & 0x0002)
						{
						mask2 = qp->get_byte();
						if(mask2 & 0x01) pl->pangle.set_pitch(qp->get_angle16());
						pl->pangle.set_yaw(qp->get_angle16());
						if(mask2 & 0x02) pl->pangle.set_roll(qp->get_angle16());
						if(mask2 & 0x04) pl->speed[0] = qp->get_byte();
						if(mask2 & 0x08) pl->speed[1] = qp->get_byte();
						if(mask2 & 0x10) pl->speed[2] = qp->get_byte();
						if(mask2 & 0x20) pl->flags = qp->get_byte();
						if(mask2 & 0x40) pl->impulse = qp->get_byte();
						if(mask2 & 0x80) pl->load = qp->get_byte();
						}
					if(mask1 & 0x0004) pl->cspeed.setx(qp->get_coord());
					if(mask1 & 0x0008) pl->cspeed.sety(qp->get_coord());
					if(mask1 & 0x0010) pl->cspeed.setz(qp->get_coord());
					if(mask1 & 0x0020) pl->model = qp->get_byte();
					if(mask1 & 0x0040) qp->get_byte();	/* UNK */
					if(mask1 & 0x0080) pl->weapon = qp->get_byte();
					if(mask1 & 0x0100) pl->weapon_frame = qp->get_byte();
/*
	printf("[2;1H\n");
	display_players();
*/
#if DBUG
					printf("Player info: user %d", usr);
					printf("  Mask: %d", mask1);
					printf("  Origin: "); pl->origin.print();
					printf("  Frame: %d", pl->frame);
					if(mask1 & 0x0001) printf("  Ping: %d", pl->ping);
					if(mask1 & 0x0002)
						{
						if(mask2 & 0x01) printf("  Ang0: %f", pl->pangle.get_pitch());
						printf("  Ang1: %f  ", pl->pangle.get_yaw());
						if(mask2 & 0x02) printf("  Ang2: %f", pl->pangle.get_roll());
						if(mask2 & 0x04) printf("  Speed1: %d", pl->speed[0]);
						if(mask2 & 0x08) printf("  Speed2: %d", pl->speed[1]);
						if(mask2 & 0x10) printf("  Speed3: %d", pl->speed[2]);
						if(mask2 & 0x20) printf("  Flag: %d", pl->flags);
						if(mask2 & 0x40) printf("  Impulse: %d", pl->impulse);
						if(mask2 & 0x80) printf("  Load: %d", pl->load);
						}
					if(mask1 & 0x0004) printf("  CSpeed0: %f", pl->cspeed.getx());
					if(mask1 & 0x0008) printf("  CSpeed1: %f", pl->cspeed.gety());
					if(mask1 & 0x0010) printf("  CSpeed2: %f", pl->cspeed.getz());
					if(mask1 & 0x0020) printf("  Model: %d", pl->model);
					if(mask1 & 0x0080) printf("  Weapon: %d", pl->weapon);
					if(mask1 & 0x0100) printf("  Weapon frame: %d", pl->weapon_frame);
#endif
					break;

				case 0x2c:		/* choke */
					printf("Choke: %d", qp->get_byte());
					break;

				case 0x2d:		/* model list */
					printf("Model list:   Start at %d\n", qp->get_byte());
					num = 0;
					do {
						if(++num > 255) printf("Error: too many models.\n");
						precache_models[num] = qp->get_nstring();
						printf("%s\n", precache_models[num]);
						} while(*precache_models[num] != '\0');
					printf("Get next starting at: %d\n", qp->get_byte());
					break;

				case 0x2e:		/* sound list */
					printf("Sound list:   Start at %d\n", qp->get_byte());
					num = 0;
					do {
						if(++num > 255) printf("Error: too many sounds.\n");
						precache_sounds[num] = qp->get_nstring();
						printf("%s\n", precache_sounds[num]);
						} while(*precache_sounds[num] != '\0');
					printf("Get next starting at: %d\n", qp->get_byte());
					break;

				case 0x2f:		/* packet entities */
					printf("Packet Entities:");
					while((mask1 = qp->get_short()))
						{
						printf("  Entity: %d", mask1 & 0x01ff);
						mask1 &= 0xfe00;
						if(mask1 & 0x8000) mask1 |= qp->get_byte();
						if(mask1 & 0x0004)
							{
							v1 = qp->get_byte();
							printf("  Model index: %d (%s)", v1, precache_models[v1]);
							}
						printf("  Mask: 0x%04x", mask1);
						if(mask1 & 0x4000) printf("  Vanished");
						if(mask1 & 0x2000) printf("  Frame: %d", qp->get_byte());
						if(mask1 & 0x0008) printf("  Colormap: %d", qp->get_byte());
						if(mask1 & 0x0010) printf("  Skin: %d", qp->get_byte());
						if(mask1 & 0x0020) printf("  Effects: %d", qp->get_byte());
						if(mask1 & 0x0200) printf("  Origin1: %f", qp->get_coord());
						if(mask1 & 0x0001) printf("  Angle1: %f", qp->get_angle());
						if(mask1 & 0x0400) printf("  Origin2: %f", qp->get_coord());
						if(mask1 & 0x1000) printf("  Angle2: %f", qp->get_angle());
						if(mask1 & 0x0800) printf("  Origin3: %f", qp->get_coord());
						if(mask1 & 0x0002) printf("  Angle3: %f", qp->get_angle());
						}
					break;

				case 0x30:		/* delta packets */
					i = qp->get_byte();
#if DBUG
					printf("Delta Packet: index: %d", i);
#endif
					while((mask1 = qp->get_short()))
						{
						v1 = mask1 & 0x01ff;
						mask1 &= 0xfe00;
						ent = &entities[v1];
						if(mask1 & 0x8000) mask1 |= qp->get_byte();
						if(mask1 & 0x0004) ent->default_index = qp->get_byte();
						if(mask1 & 0x2000) ent->frame = qp->get_byte();
						if(mask1 & 0x0008) v2 = qp->get_byte();
						if(mask1 & 0x0010) ent->skin = qp->get_byte();
						if(mask1 & 0x0020) ent->effects = qp->get_byte();
						if(mask1 & 0x0200) ent->origin.setx(qp->get_coord());
						if(mask1 & 0x0001) ent->facing.set_pitch(qp->get_angle());
						if(mask1 & 0x0400) ent->origin.sety(qp->get_coord());
						if(mask1 & 0x1000) ent->facing.set_yaw(qp->get_angle());
						if(mask1 & 0x0800) ent->origin.setz(qp->get_coord());
						if(mask1 & 0x0002) ent->facing.set_roll(qp->get_angle());

#if DBUG
						if(precache_models[ent->default_index] != NULL)
							printf("  Entity: %d (%s)", v1, precache_models[ent->default_index]);
						else
							printf("  Entity: %d --UNKNOWN--", v1);
						printf("  Mask: 0x%04x", mask1);
						if(mask1 & 0x4000) printf("  Vanished");
						if(mask1 & 0x0004) printf("  Model index: %d (%s)", ent->default_index, precache_models[ent->default_index]);
						if(mask1 & 0x2000) printf("  Frame: %d", ent->frame);
						if(mask1 & 0x0008) printf("  Colormap: %d", v2);
						if(mask1 & 0x0010) printf("  Skin: %d", ent->skin);
						if(mask1 & 0x0020) printf("  Effects: %d", ent->effects);
						if(mask1 & 0x0200) printf("  Origin1: %f", ent->origin.getx());
						if(mask1 & 0x0001) printf("  Angle1: %f", ent->facing.get_pitch());
						if(mask1 & 0x0400) printf("  Origin2: %f", ent->origin.gety());
						if(mask1 & 0x1000) printf("  Angle2: %f", ent->facing.get_yaw());
						if(mask1 & 0x0800) printf("  Origin3: %f", ent->origin.getz());
						if(mask1 & 0x0002) printf("  Angle3: %f", ent->facing.get_roll());
#endif
						}
					break;

				default:
					eval = 0;
				}
#if DBUG
			printf("\n");
#endif
			fflush(stdout);
			if(qp->get_read_pos() >= len) return(0);
			}
		}

	return (qp->get_read_pos() >= len ? 0 : 1);
}


/* ------------------------------------------------------------------------- */
int main(int argc, char **argv)
{
fd_set a;
struct timeval tv;
char temp[30];
int recvd, running = 1;

	if(argc < 2)
		{
		printf("qprox <host> <port>\n");
		return 0;
		}

	qsock qrem(argv[1], atol(argv[2])), qloc(27501);
	qpack qp(10000);
	qpack qsnd(100);


	// timeval tv code moved inside while statement!
	while(running)
		{

		  // Code moved by Conan Ford conanford@hotmail.com
		  // so as to not take 100% cpu time...

		  tv.tv_sec = 2;
		  tv.tv_usec = 2000;


		FD_ZERO(&a);
		FD_SET(0, &a);
		FD_SET(qrem.getFD(), &a);
		FD_SET(qloc.getFD(), &a);
		if((select(100, &a, 0, 0, &tv)) < 0) perror("select");

		if(FD_ISSET(qrem.getFD(), &a))
			{
			qp.reset();
			recvd = qrem.receive(qp.get_buffer(), qp.get_max_size());

#if DBUG
			printf("\n>>>>>>>>>>>>>>>>>>>>> server to client %d bytes:\n", recvd);
#endif
			if(analyze_packet_server(&qp, recvd))
				{
				ascii_dump_buf((unsigned char *)qp.get_buffer(), recvd);
				hex_dump_buf((unsigned char *)qp.get_buffer(), recvd);
				}

			qloc.send(qp.get_buffer(), recvd);
			}

		if(FD_ISSET(qloc.getFD(), &a))
			{
			qp.reset();
			recvd = qloc.receive(qp.get_buffer(), qp.get_max_size());

#if DBUG
			printf("\n<<<<<<<<<<<<<<<<<<<<< client to server %d bytes:\n", recvd);
#endif
			if(analyze_packet_client(&qp, recvd))
				{
				ascii_dump_buf((unsigned char *)qp.get_buffer(), recvd);
				hex_dump_buf((unsigned char *)qp.get_buffer(), recvd);
				}

			qrem.send(qp.get_buffer(), recvd);
			}

		if(FD_ISSET(0, &a))
			{
			read(0, temp, 1024);
			switch(temp[0])
				{
				case 'q':
					printf("Quit...\n");
					running = 0;
					break;
				case 'i':
					printf("Sending request:\n");
					qsnd.start_special();
					qsnd.put_string("status\n");
					qsnd.send(&qrem);
					break;
				case 'h':
					hackin = !hackin;
					break;
				default:
					printf("Dunno that one.\n");
					break;
				}
			}
		

		}
}




