/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *
 *  The program makes a connection to a QuakeWorld server, opens an x11
 *  window and displays the map the server is running.  It attempts to
 *  update the location of each player on the server on the displayed map.
 *  Does not work well due to QW's non visibility clipping in the network
 *  protocol.
 * ------------------------------------------------------------------------ */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include <limits.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <math.h>

#include "qwb.h"
#include "qsock.h"
#include "qpack.h"
#include "qpcodec.h"
#include "qentity.h"
#include "imglib.h"

#define DISP_3D	1

/* ------------------------------------------------------------------------- */
#define DB_WIDTH	800
#define DB_HEIGHT	700

pic_info *qwmap_pic, *qwpic;
x11_window *xwin;
float p_x = 999999999.0, p_y = 0, p_z = 24;
qplayer *pl_me;
float x_scale, y_scale, z_scale, x_offset, y_offset, z_offset;
vector *tr_vects;

void init_qw_display(void)
{
	qwpic = new pic_info(DB_WIDTH + 20, DB_HEIGHT + 20, C_LOOKUP);
	qwmap_pic = new pic_info(DB_WIDTH + 20, DB_HEIGHT + 20, C_LOOKUP);
	qwpic->set_grey_cmap();
	qwpic->set_cmap(10, 255, 0, 0);
	qwpic->set_cmap(11, 0, 255, 0);
	qwpic->set_cmap(12, 0, 0, 255);
	qwmap_pic->set_grey_cmap();
	qwmap_pic->set_cmap(10, 255, 0, 0);
	qwmap_pic->set_cmap(11, 0, 255, 0);
	qwmap_pic->set_cmap(12, 0, 0, 255);

	xwin = new x11_window(10, 10, qwpic->pwidth(), qwpic->pheight(), "BSP Display");
	xwin->window_colours(qwpic->pcolour_format(), qwpic->pr_cmap(), qwpic->pg_cmap(), qwpic->pb_cmap());
}


/* ------------------------------------------------------------------------- */
void draw_face(bsp_file *bsp, pic_info *fpic, vector *tvect, int face_num, int floor)
{
class bsp_face *bf;
long edge_list_strt, src, dst, i, edli;

	bf = bsp->faces->get_face(face_num);

	if(!floor)
		{
		bsp_plane *pln = bsp->planes->get_plane(bf->get_plane_id());
		if(!(bf->is_on_front())) return;
		if(pln->get_normal().getz() < 0.9) return;
		}

	edge_list_strt = bf->get_edge_list_id();

	fpic->set_pen_rgb(255, 0, 0);

	for(i = 0; i < bf->get_edge_list_num(); i++)
		{
		edli = bsp->edgelists->get_edge_list(edge_list_strt + i);
		if(edli < 0) edli = - edli;
		src = bsp->edges->get_edge(edli)->get_vertex(0);
		dst = bsp->edges->get_edge(edli)->get_vertex(1);

		fpic->line((int)tvect[src].getx(), (int)tvect[src].gety(),
			(int)tvect[dst].getx(), (int)tvect[dst].gety());
		}
}


/* ------------------------------------------------------------------------- */
void draw_leaf(bsp_file *bsp, pic_info *fpic, vector *tvect, int leaf_num, int floor)
{
class bsp_leaf *bleaf;
int i, face_num, face_list_strt;

	bleaf = bsp->leaves->get_leaf(leaf_num);
	face_list_strt = bleaf->get_face_list_id();

//	printf("> "); print_leaf_type_str(bleaf->get_type()); printf("\n");

	for(i = 0; i < bleaf->get_face_list_num(); i++)
		{
		face_num = bsp->facelist->get_facelist(face_list_strt + i);
		draw_face(bsp, fpic, tvect, face_num, floor);
		}
}

#if DISP_3D
/* ------------------------------------------------------------------------- */
#define eye2screen	2100
#define eye2world    8
#define DISP_ANG		45

void qw_draw_map(pic_info *qwp, bsp_file *bsp)
{
float min_x = 0, min_y = 0, min_z = 0, max_x = 0, max_y = 0, max_z = 0,
	x, y, z, tv;
int i, col;
long src, dst;
bsp_vertex *bv;

	for(i = 0; i < bsp->vertices->get_num(); i++)
		{
		bv = bsp->vertices->get_vertex(i);
		x = bv->get_position().getx();
		y = bv->get_position().gety();
		z = bv->get_position().getz();

		if(i == 0)
			{
			min_x = max_x = x;
			min_y = max_y = y;
			min_z = max_z = z;
			}
		else
			{
			if(x > max_x) max_x = x;
			if(x < min_x) min_x = x;
			if(y > max_y) max_y = y;
			if(y < min_y) min_y = y;
			if(z > max_z) max_z = z;
			if(z < min_z) min_z = z;
			}
		}

	x_scale = (max_x - min_x)/2;
	y_scale = (max_y - min_y)/2;
	z_scale = (max_z - min_z)/1;

	x_offset = (min_x + max_x)/2;
	y_offset = (min_y + max_y)/2;
	z_offset = (min_z + max_z)/2;

	tr_vects = new vector[bsp->vertices->get_num() + 20];
	for(i = 0; i < bsp->vertices->get_num(); i++)
		{
		bv = bsp->vertices->get_vertex(i);
		x = (bv->get_position().getx() - x_offset)/x_scale;
		y = (bv->get_position().gety() - y_offset)/y_scale;
		z = (bv->get_position().getz() - z_offset)/z_scale;

		tv = (y * cos((DISP_ANG * M_PI)/180)) - (z * sin((DISP_ANG * M_PI)/180));
		z = (y * sin((DISP_ANG * M_PI)/180)) + (z * cos((DISP_ANG * M_PI)/180));
		y = tv;

		tr_vects[i].set(((x * eye2screen)/(eye2world - z) + DB_WIDTH/2),
			((y * eye2screen)/(eye2world - z) + DB_HEIGHT/2),
			50 + ((z + 1) * 100));
		}

	qwp->clear();

	for(i = 0; i < bsp->edges->get_num(); i++)
		{
		src = bsp->edges->get_edge(i)->get_vertex(0);
		dst = bsp->edges->get_edge(i)->get_vertex(1);
		col = (int)tr_vects[src].getz();
		qwp->set_pen_rgb(col, col, col);

		qwp->line((int)tr_vects[src].getx(), (int)tr_vects[src].gety(),
			(int)tr_vects[dst].getx(), (int)tr_vects[dst].gety());
		}
}

#else

/* ------------------------------------------------------------------------- */
void qw_draw_map(pic_info *qwp, bsp_file *bsp)
{
float min_x = 0, min_y = 0, min_z = 0, max_x = 0, max_y = 0, max_z = 0,
	x, y, z;
int i, col;
long src, dst;
bsp_vertex *bv;

	for(i = 0; i < bsp->vertices->get_num(); i++)
		{
		bv = bsp->vertices->get_vertex(i);
		x = bv->get_position().getx();
		y = bv->get_position().gety();
		z = bv->get_position().getz();

		if(i == 0)
			{
			min_x = max_x = x;
			min_y = max_y = y;
			min_z = max_z = z;
			}
		else
			{
			if(x > max_x) max_x = x;
			if(x < min_x) min_x = x;
			if(y > max_y) max_y = y;
			if(y < min_y) min_y = y;
			if(z > max_z) max_z = z;
			if(z < min_z) min_z = z;
			}
		}

	x_scale = DB_WIDTH/(max_x - min_x);
	y_scale = DB_HEIGHT/(max_y - min_y);
	z_scale = 224/(max_z - min_z);
	x_offset = (x_scale * -min_x) + 5;
	y_offset = (y_scale * -min_y) + 5;
	z_offset = (z_scale * -min_z) + 30;

	tr_vects = new vector[bsp->vertices->get_num() + 10];
	for(i = 0; i < bsp->vertices->get_num(); i++)
		{
		bv = bsp->vertices->get_vertex(i);
		tr_vects[i].set((bv->get_position().getx() * x_scale) + x_offset,
			(bv->get_position().gety() * y_scale) + y_offset,
			(bv->get_position().getz() * z_scale) + z_offset);
		}

	qwp->clear();

	for(i = 0; i < bsp->edges->get_num(); i++)
		{
		src = bsp->edges->get_edge(i)->get_vertex(0);
		dst = bsp->edges->get_edge(i)->get_vertex(1);
		col = (int)tr_vects[src].getz();
		qwp->set_pen_rgb(col, col, col);

		qwp->line((int)tr_vects[src].getx(), (int)tr_vects[src].gety(),
			(int)tr_vects[dst].getx(), (int)tr_vects[dst].gety());
		}
}
#endif


/* ------------------------------------------------------------------------- */
void qw_display(qbot *qb)
{
qplayer *pls;
int st;

	qwpic->copy_pic(*qwmap_pic, 0, 0);

	st = 0;
	qwpic->set_pen_rgb(0, 255, 0);
	for(pls = qb->players; pls < qb->players + 32; pls++)
		{
		if(pls != pl_me && qb->is_player(pls) && qb->player_in_range(pls))
			{

#if DISP_3D
			{
			float x, y, z, tv;
			x = (pls->origin.getx() - x_offset)/x_scale;
			y = (pls->origin.gety() - y_offset)/y_scale;
			z = (pls->origin.getz() - z_offset)/z_scale;

			tv = (y * cos((DISP_ANG * M_PI)/180)) - (z * sin((DISP_ANG * M_PI)/180));
			z = (y * sin((DISP_ANG * M_PI)/180)) + (z * cos((DISP_ANG * M_PI)/180));
			y = tv;

			qwpic->box((int)((x * eye2screen)/(eye2world - z) + DB_WIDTH/2) - 2,
				(int)((y * eye2screen)/(eye2world - z) + DB_HEIGHT/2) - 2, 4, 4);
			}
#else
			qwpic->box((int)((pls->origin.getx() * x_scale) + x_offset - 2),
				(int)((pls->origin.gety() * y_scale) + y_offset - 2), 4, 4);
#endif
			if(!st)
				{
				st = 1;
				p_x = pls->origin.getx();
				p_y = pls->origin.gety();
				p_z = pls->origin.getz();
				}

			draw_leaf(qb->bsp, qwpic, tr_vects, qb->bsp->find_leaf(pls->origin), 1);
			}
		}

//	delete tr_vects;
	xwin->display_image(qwpic->ppic_a(), qwpic->ppic_b(), qwpic->ppic_c());
}


/* ------------------------------------------------------------------------- */
char *trans_qstr(char *name)
{
static char buf[500];
char *pos;
int ch;

	pos = buf;
	while(*name != '\0')
		{
		ch = *name++;
		if(ch < 0) ch += 128;
		if(ch == '\n') *pos++ = '\n';
		else *pos++ = isprint(ch) ? ch : '.';
		}
	*pos = '\0';

	return(buf);
}


/* ------------------------------------------------------------------------- */
int main(int argc, char **argv)
{
qbot qb;
int recvd, running = 1, scmd = 0, i;
fd_set a;
char temp[80];
struct timeval tv;
qplayer *pls;
bsp_file *bsp = NULL;

	if(argc < 3)
		{
		printf("qww <host> <port>\n");
		return 0;
		}

	qb.qdir.add_dir("id1");
	qb.qdir.add_dir("qw");

	strcpy(qb.bname, "Ima Watchin");
	qb.spectator = 1;
	qb.load = 36;
	qb.connect_server(argv[1], atol(argv[2]));

	if(qb.uid() >= 128) pl_me = &qb.players[qb.uid() - 128];
	else pl_me = &qb.players[qb.uid()];

	if(qb.bsp != NULL)
		{
		init_qw_display();
		bsp = qb.bsp;
		qw_draw_map(qwmap_pic, bsp);
		}

	while(running)
		{
		if(qb.bsp != NULL)
			{
			if(bsp != qb.bsp)
				{
				bsp = qb.bsp;
				qw_draw_map(qwmap_pic, bsp);
				}
			qw_display(&qb);
			}

		qb.qp_out->start_game_packet(qb.seq_num++, qb.last_rec_seq, 0, qb.hid_bit);

		if(p_x < 999999)
			{
			qb.qp_out->put_byte(0x06);
			qb.qp_out->put_coord(p_x);
			qb.qp_out->put_coord(p_y);
			qb.qp_out->put_coord(p_z);
			}

		qb.add_movement();
		qb.qp_out->put_byte(0x05);
		qb.qp_out->put_byte((char)(qb.last_rec_seq & 0xff));
		qb.qp_out->send(qb.qrem);

		FD_ZERO(&a);
		FD_SET(0, &a);
		FD_SET(qb.qrem->getFD(), &a);
		tv.tv_sec = 0;
		tv.tv_usec = 100000;
		if((select(100, &a, 0, 0, &tv)) < 0) perror("select");

		if(FD_ISSET(qb.qrem->getFD(), &a))
			{
			for(pls = qb.players; pls < qb.players + 32; pls++)
				{
				pls->origin.set(0, 0, 0);
				pls->cspeed.set(0, 0, 0);
				pls->speed[0] = 0;
				pls->speed[1] = 0;
				pls->speed[2] = 0;
				pls->model = -1;
				}

			qb.qp_in->reset();
			recvd = qb.qrem->receive(qb.qp_in->get_buffer(), qb.qp_in->get_max_size());
			qb.decode_packet(recvd);
			}

		if(FD_ISSET(0, &a))
			{
			i = read(0, temp, 1024);
			temp[i-1] = '\0';

			switch(temp[0])
				{
				case 'w':
					printf("\n");
					for(i = 0, pls = qb.players; i < 32; i++, pls++)
						{
						if(pls->text != (char *)0 && pls->text[0] != '\0')
							{
							printf("%2d: %20s:  %3d  %3d ",
								i, trans_qstr(pls->name), pls->ping, pls->frags);
							pls->origin.print();
							if(pls == pl_me) printf(" <*> ");
							printf("  %.3f\n", (pl_me->origin - pls->origin).length());
							}
						}
					break;

				case 'q':
					qb.send_con_command("say \"Catcha Later!\"", -1, 1);
					qb.send_con_command("drop", -1, 1);
					qb.send_con_command("drop", -1, 1);
					qb.send_con_command("drop", -1, 1);
					printf("Quit...\n");
					running = 0;
					break;

				case 's':
					qb.send_con_command(temp, -1, 1);
					break;

				case 'c':
					qb.send_con_command(temp+1, -1, 1);
					break;

				case 'x':
					qb.send_special(temp+1);
					break;

				case 'e':
					printf("Entities:\n");
					printf("--------------------------------------------------------\n");
					for(i = 0; i < 450; i++)
						{
						if(qb.entities[i].spawned)
							{
							printf("%d: %d (%s)  %d  %d  ", i,
								qb.entities[i].default_index, qb.precache_models[qb.entities[i].default_index].file,
								qb.entities[i].frame, qb.entities[i].skin);
							qb.entities[i].origin.print1();
							printf("   ");
							qb.entities[i].facing.print();
							printf("\n");
							}
						}
					break;

				case 'm':
					i = 0;
					do {
						i++;
						printf("%s\n", qb.precache_models[i].file);
						} while(*qb.precache_models[i].file != '\0');
					break;

				case '1': scmd = 4; break;
				case '2': qb.flag = 0x02; break;
				case '3': qb.flag = 0x00; break;
				case '4': qb.flag = 0x01; break;
				case '5': qb.flag = 0x00; break;
				case 'p': scmd = 5; break;
				default:
					printf("Dunno that one.\n");
					break;
				}
			}
		}
}

