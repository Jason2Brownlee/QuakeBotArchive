/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  Main bot stuff.  Any `AI' is in here at the moment.  This is VERY crude!
 *  Needs heaps of work! :)
 * ------------------------------------------------------------------------ */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include <limits.h>
#include <netdb.h>
#include <arpa/inet.h>

#include "qwb.h"
#include "qsock.h"
#include "qpack.h"
#include "qpcodec.h"
#include "qentity.h"

#define DB_TXT		0

#define PING_DELAY	30000
#define ALIAS_RUN		1

#define DIED_TXT_NUM	7
char *died_txt[] = {
	"Doh!", "Bugger!", "Sheeeiitt!", "Phuck!", "Arrrgghhh!",
	"Didn't see that one..", "Crap"
};

char *leaf_type_str[] = {
	"normal", "solid", "water", "slime", "lava", "sky", "unknown"
};

/* ------------------------------------------------------------------------- */
void husleep(unsigned long usecs)
{
struct timeval tv;

	tv.tv_sec  = usecs / 1000000L;
	tv.tv_usec = usecs % 1000000L;
	select(0, NULL, NULL, NULL, &tv);
}


/* ------------------------------------------------------------------------- */
char *trans_qstr(char *name)
{
static char buf[500];
char *pos;
int ch;

	pos = buf;
	while(*name != '\0')
		{
		ch = *name++;
		if(ch < 0) ch += 128;
		if(ch == '\n') *pos++ = '\n';
		else *pos++ = isprint(ch) ? ch : '.';
		}
	*pos = '\0';

	return(buf);
}


/* ------------------------------------------------------------------------- */
void hex_dump_buf(unsigned char *buf, int len)
{
int pos = 0, llen, i;

	while(pos < len)
		{
		llen = (len - pos < 16 ? len - pos : 16);
		printf("%08x: ", pos);
		for(i = 0; i < llen; i++) printf("%02x ", buf[pos + i]);
		for(i = 0; i < 16 - llen; i++) printf("   ");
		printf(" | ");

		for(i = 0; i < llen; i++)
			printf("%c", isprint(buf[pos + i]) ? buf[pos + i] : '.');
		for(i = 0; i < 16 - llen; i++) printf(" ");
		printf("\n");
		pos += llen;
		}
}


/* -------------------------------------------------------------------------
 *  Does not work, as far as I know, and is not used :)
 */
vector predict_position(vector target_pos, vector my_pos, vector target_vel)
{
vector tv, target_location;
float time = 0.0, time_estimate, error = 0.0, enemy_vel = target_vel.length();
int loop = 0;

	do {
		tv = target_vel;
		tv.normalize();
		tv *= (enemy_vel * time);
		tv += target_pos;
		time_estimate = ((my_pos - tv).length())/100.0;
		loop++;
		} while(error > 0.01 && loop < 6);
}


/* ------------------------------------------------------------------------- */
static vector move_to, aim_at;

void select_entity(qbot *qb, qplayer *pl_me, int moveat)
{
float best_rate, rate, dist, pitch, range;
vector v;
qentity *ent = NULL;
int i, m_type, type;

	best_rate = 0;

	for(i = 0; i < 450; i++)
		{
		if(qb->entities[i].visible)
			{
			m_type = qb->precache_models[qb->entities[i].default_index].m_type;
			type = qb->precache_models[qb->entities[i].default_index].type;

			if(m_type == ET_HEALTH)
				if(qb->player_stats[0] > 50) rate = (float)(100 - qb->player_stats[0]) * 2;
				else rate = (float)(100 - qb->player_stats[0]) * 4;
			else if(type == ET_A_SHELLS) rate = (float)(100 - qb->player_stats[6]);
			else if(type == ET_A_CELLS)
				{
				if(qb->player_stats[15] & W_LG) rate = (float)(100 - qb->player_stats[9])/2;
				else rate = 10.0;
				}
			else if(type == ET_A_ROCKETS)
				{
				if(qb->player_stats[15] & W_RL) rate = (float)(100 - qb->player_stats[8]) * 2;
				else rate = 10.0;
				}
			else if(type == ET_A_NAILS)
				{
				if(qb->player_stats[15] & (W_NG | W_SNG)) rate = (float)(200 - qb->player_stats[7])/2;
				else rate = 10.0;
				}
			else if(m_type == ET_ARMOR) rate = (float)(100 - qb->player_stats[4])/2;
			else if(type == ET_W_LG && !(qb->player_stats[15] & W_LG)) rate = 110.0;
			else if(type == ET_W_RL && !(qb->player_stats[15] & W_RL)) rate = 100.0;
			else if(type == ET_W_GL && !(qb->player_stats[15] & W_GL)) rate = 100.0;
			else if(type == ET_W_SNG && !(qb->player_stats[15] & W_SNG)) rate = 100.0;
			else if(type == ET_W_SSG && !(qb->player_stats[15] & W_SSG)) rate = 105.0;
			else if(type == ET_W_NG && !(qb->player_stats[15] & W_NG)) rate = 100.0;
			else if(type == ET_I_BACKPACK) rate = 102.0;
			else if(m_type == ET_ITEM) rate = 100.0;
			else rate = 0;

			rate *= (float)100.0;
			dist = (pl_me->origin - qb->entities[i].origin).length();
			pitch = (pl_me->origin - qb->entities[i].origin).get_pitch();
	//		rate /= dist;
	//		if(pitch < 0.0) pitch = -pitch;
	//		if(pitch != 0.0) rate /= pitch;

			if(qb->precache_models[qb->entities[i].default_index].type == ET_P_MISSILE &&
				qb->entities[i].velocity.length() > 0)
				{
				vector v_rp, v_rx, v_Urx, v_xp, p_x;
				float m_rx;

				v_rp = pl_me->origin - qb->entities[i].origin;
#if 0
				v_Urx = qb->entities[i].velocity;
				v_Urx.normalize();
#else
				v_Urx = qb->entities[i].facing.get_vector();
#endif
				m_rx = v_rp * v_Urx;
				v_rx = v_Urx;
				v_rx *= m_rx;
				p_x = qb->entities[i].origin + v_rx;
#if 0
				move_to = p_x;
#else
				v_xp = pl_me->origin - p_x;
				if(v_xp.length() < 250)
					{
					v_xp.normalize();
					v_xp *= 250;
					move_to = p_x;
					move_to +=v_xp;
			//		if(qb->bsp->is_line_blocked(pl_me->origin, move_to, NULL, 2))
			//			{
			//			v_xp *= -1;
			//			move_to = p_x;
			//			move_to +=v_xp;
			//			}
					}
#endif
				return;
				}

			range = qb->danger_range(&(qb->entities[i]));
			if(range > 0.0 && dist < range)
				{
				switch(qb->precache_models[qb->entities[i].default_index].type)
					{
					case ET_P_MISSILE: printf("M"); break;
					case ET_P_GRENADE: printf("G"); break;
					case ET_P_NG_NAIL:
					case ET_P_SNG_NAIL: printf("N"); break;
					default: printf("*");
					}

				printf("(%.2f) ", dist);
				fflush(stdout);
				}

			if(!qb->bsp->is_line_blocked(pl_me->origin, qb->entities[i].origin, NULL, 2) &&
				rate > best_rate)
				{
				best_rate = rate;
				ent = &qb->entities[i];
				}
			}
		}

	if(ent != NULL && moveat && qb->bot_flags & 0x02)
		{
		move_to = ent->origin;
		/* printf(">>> %s IS CLOSE (%.3f)  ", qb->precache_models[ent->default_index].file, dist); */
		}
}


/* ------------------------------------------------------------------------- */
void set_speeds(qbot &qb, qplayer *pl_me, vector aim_at, vector move_to)
{
double dist;
vector v_a, v_m, v_Ua, v_Ur, unit_z(0.0, 0.0, 1.0);

#if 0
	v_m = pl_me->origin - move_to;

	qb.yaw = v_m.get_yaw();
	qb.tilt = v_m.get_pitch();

	dist = v_m.length2D();
	if(dist < 10.0) dist = 0.0;
	else if(dist < 40.0) dist *= 2;

	qb.front = (dist > 127.0 ? 127 : (int)dist);

#else
	v_Ur = v_Ua = v_a = pl_me->origin - aim_at;
	v_Ua.normalize();
	v_Ur = v_Ur.X(unit_z);
	v_Ur.normalize();
	v_m = pl_me->origin - move_to;

	qb.yaw = v_a.get_yaw();
	qb.tilt = v_a.get_pitch();

	dist = v_m.length2D();
	if(dist < 10.0) dist = 0.0;
	else if(dist < 40.0) dist *= 2;
	v_m.scale((dist > 125.0 ? 125 : (int)dist));

	qb.front = (int)(v_Ua * v_m);
	qb.right = (int)(v_Ur * v_m);

//	printf(" f: %d  r: %d ", qb.front, qb.right);
//	move_to.print();
//	printf(" (%02f)\n", dist);
#endif
}


/* ------------------------------------------------------------------------- */
void update_nav(qbot &qb, qplayer *pl_me)
{
static int re_spawn = 0, update_cnt = 0, cir_dir = 1;
float dist, min_visible_dist = 500000.0, min_close_dist = 500000.0;
qplayer *pls_visible = NULL, *pls_close = NULL, *pls;
char temp[80];
vector tv;

	update_cnt++;
	if(update_cnt > 500)
		{
		cir_dir = -cir_dir;
		update_cnt = 0;
		}

	if(re_spawn > 0)
		{
		qb.flag = 0x0;
		if(re_spawn < 20)
			{
			if(qb.player_stats[0] <= 0) qb.flag = 0x02;
			/* qb.send_con_command("say \"Come get some!!\"", -1, 1); */
			}
		if(re_spawn == 1) re_spawn = 30;

		if(qb.player_stats[0] > 0)
			{
			qb.flag = 0x00;
			re_spawn = 0;
			}
		else re_spawn--;
		}
	else
		{
		qb.flag = 0;
		qb.front = 0;
		qb.right = 0;
		for(pls = qb.players; pls < qb.players + 32; pls++)
			{
			if(qb.is_player(pls) && pls != pl_me && qb.player_in_range(pls) &&
				!qb.is_dead(pls) &&
				strcmp(pls->name, "ralph")
				)
				{
				dist = (pl_me->origin - pls->origin).length() + pls->frags;
				if(dist < min_close_dist)
					{
					min_close_dist = dist;
					pls_close = pls;
					}

				if(dist < min_visible_dist &&
					!qb.bsp->is_line_blocked(pl_me->origin, pls->origin, NULL, 0))
					{
					min_visible_dist = dist;
					pls_visible = pls;
					}
				}
			}

		if(pls_visible != NULL) pls = pls_visible;
		else if(pls_close != NULL) pls = pls_close;
		else pls = NULL;

		if(pls != NULL)
			{
			tv = pls->origin;
			tv += pls->cspeed;
			if(qb.bot_flags & 0x02) move_to = tv;
			aim_at = tv;

			dist = (pl_me->origin - aim_at).length();

			if(pls_visible != NULL)
				{
#if DB_TXT
				printf(">>> %s IS IN SIGHT (%.3f: %.2f, %.2f)  ", trans_qstr(cpl->name), dist,
					qb.yaw, qb.tilt);
				cpl->origin.print();
				if(cpl->model > 0)
					printf("(%s) ", qb.precache_models[cpl->model].file);
				printf("  %d  %d\n", cpl->model, cpl->frame);
#endif
				if(qb.bot_flags & 0x01)
					if(dist > 10.0) qb.flag = 0x01;

	//			if(qb.bot_flags & 0x02)
	//				qb.right = 100 * cir_dir;

				select_entity(&qb, pl_me, 0);
				}
			else select_entity(&qb, pl_me, 1);

			if(qb.bsp->is_line_blocked(pl_me->origin, pls->origin, NULL, 1))
				{
#if DB_TXT
				printf("Lava in the way\n");
#endif
				qb.front = 0;
				qb.right = 0;
				}

			}
		else
			{
			select_entity(&qb, pl_me, 1);
			aim_at = move_to;
			}

		set_speeds(qb, pl_me, aim_at, move_to);

		if(qb.player_stats[0] <= 0)
			{
			sprintf(temp, "say \"%s\"", died_txt[rand() % DIED_TXT_NUM]);
			/* qb.send_con_command(temp, -1, 1); */
			printf("Died.  Respawning.\n");
			re_spawn = 30;
			}
		}
}


/* ------------------------------------------------------------------------- */
int main(int argc, char **argv)
{
qbot qb;
int recvd, running = 1, scmd = 0, i, leaf, leaf_type;
fd_set a;
char temp[80];
struct timeval tv;
qplayer *pls, *pl_me;
long port = 27500;

	if(argc < 2)
		{
		printf("qt <host> [port]\n");
		return 0;
		}

	if(argc > 2)
	port = atol(argv[2]);

	qb.qdir.add_dir("id1");
	qb.qdir.add_dir("qw");

#if ALIAS_RUN
	strcpy(qb.bname, "Gibinator");
#endif

	qb.load = 36;
	qb.connect_server(argv[1], port);

	qb.prox = new proxy(27510);

	pl_me = &qb.players[qb.uid()];

	while(running)
		{
		qb.yaw += 20;
		if(qb.yaw > 360) qb.yaw -= 360;
		/* qb.front = 129; */
		qb.up = 100;

		if(qb.bsp != NULL)
			{
			leaf = qb.bsp->find_leaf(pl_me->origin);
			leaf_type = qb.bsp->leaves->get_leaf(leaf)->get_type();
#if DB_TXT
			if(leaf_type > 1) printf("Eeepp: in leaf: %d  type: %s\n", leaf, leaf_type_str[leaf_type]);
#endif
			}

		update_nav(qb, pl_me);

		if(scmd)
			{
			if(scmd == 4) qb.send_con_command("say \"Come get some!\"", -1, 1);
			if(scmd == 5) qb.send_con_command("pings", -1, 1);
			scmd = 0;
			}
		else
			{
			qb.qp_out->start_game_packet(qb.seq_num++, qb.last_rec_seq, 0, qb.hid_bit);
			qb.add_movement();
			qb.qp_out->put_byte(0x05);
			qb.qp_out->put_byte((char)(qb.last_rec_seq & 0xff));
			qb.qp_out->send(qb.qrem);
			}

		FD_ZERO(&a);
		FD_SET(0, &a);
		qb.fd_set_rem(&a);
		qb.prox->fd_set_loc(&a);
		tv.tv_sec = 0;
		tv.tv_usec = 100000;
		if((select(100, &a, 0, 0, &tv)) < 0) perror("select");

		if(qb.prox->fd_isset_loc(&a)) qb.prox->update();

		if(qb.fd_isset_rem(&a))
			{
			for(pls = qb.players; pls < qb.players + 32; pls++)
				{
				pls->origin.set(0, 0, 0);
				pls->cspeed.set(0, 0, 0);
				pls->speed[0] = 0;
				pls->speed[1] = 0;
				pls->speed[2] = 0;
				pls->model = -1;
				}

			qb.qp_in->reset();
			recvd = qb.qrem->receive(qb.qp_in->get_buffer(), qb.qp_in->get_max_size());
			qb.decode_packet(recvd);
#if ALIAS_RUN
#if PING_DELAY > 0
			husleep(PING_DELAY);
#endif
#endif
			}

		if(FD_ISSET(0, &a))
			{
			i = read(0, temp, 1024);
			temp[i-1] = '\0';

			switch(temp[0])
				{
				case 'h':
				case '?':
					printf("   w - People playing quakeworld.\n");
					printf("   e - Visible entities.\n");
					printf("   m - Complete model list.\n");
					printf("   say ... - Have the bot say something.\n");
					printf("   c..... - Concole command.\n");
					printf("   x..... - Special command (eg: xrcon password map dm2.bsp).\n");
					printf("   q - Quit.\n");
					break;

				case 'w':
					printf("\nWho is on:\n");
					printf("--------------------------------------------------------\n");
					for(i = 0, pls = qb.players; i < 32; i++, pls++)
						{
						if(pls->text != (char *)0 && pls->text[0] != '\0')
							{
							printf("%2d: %20s:  %3d  %3d ",
								i, trans_qstr(pls->name), pls->ping, pls->frags);
							pls->origin.print();
							printf("  %.3f\n", (pl_me->origin - pls->origin).length());
							}
						}

					if(qb.bsp != NULL)
						{
						leaf = qb.bsp->find_leaf(pl_me->origin);
						leaf_type = qb.bsp->leaves->get_leaf(leaf)->get_type();
						printf("Leaf: %d  type: %s\n", leaf, leaf_type_str[leaf_type]);
						}

					printf("%d: Health: %ld  Armor: %ld  Shells: %ld  Nails: %ld  Rockets: %ld  Cells: %ld\n", qb.uid(),
						qb.player_stats[0], qb.player_stats[4],
						qb.player_stats[6], qb.player_stats[7],
						qb.player_stats[8], qb.player_stats[9]);
					if(qb.player_stats[15] & W_AXE) printf(" <AXE>");
					if(qb.player_stats[15] & W_SG) printf(" <SG>");
					if(qb.player_stats[15] & W_SSG) printf(" <SSG>");
					if(qb.player_stats[15] & W_NG) printf(" <NG>");
					if(qb.player_stats[15] & W_SNG) printf(" <SNG>");
					if(qb.player_stats[15] & W_GL) printf(" <GL>");
					if(qb.player_stats[15] & W_RL) printf(" <RL>");
					if(qb.player_stats[15] & W_LG) printf(" <LG>");
					printf("\n");
#if 0
					for(i = 0, pls = qb.players; i < 32; i++, pls++)
						{
						if(pls->text != (char *)0 && pls->text[0] != '\0')
							{
							printf("%2d: %20s: ", i, trans_qstr(pls->name));
							if(qb.bsp != NULL)
								{
								leaf = qb.bsp->find_leaf(pls->origin);
								leaf_type = qb.bsp->leaves->get_leaf(leaf)->get_type();
								printf("Leaf: %d  type: %s", leaf, leaf_type_str[leaf_type]);
								}
							printf("\n");
							/*
							printf("(%d, %d, %d)  (%.2f, %.2f, %.2f)  %d\n",
								pls->speed[0], pls->speed[1], pls->speed[2],
								pls->cspeed.getx(), pls->cspeed.gety(), pls->cspeed.getz(), pls->model);
								*/
							}
						}
#endif
					printf("--------------------------------------------------------\n");
					break;

				case 'q':
#if !ALIAS_RUN
					qb.send_con_command("say \"Catcha Later!\"", -1, 1);
#endif
					qb.send_con_command("drop", -1, 1);
					qb.send_con_command("drop", -1, 1);
					qb.send_con_command("drop", -1, 1);
					printf("Quit...\n");
					running = 0;
					break;

				case 's':
					qb.send_con_command(temp, -1, 1);
					break;

				case 'c':
					qb.send_con_command(temp+1, -1, 1);
					break;

				case 'x':
					qb.send_special(temp+1);
					break;

				case 'e':
					printf("Entities:\n");
					printf("--------------------------------------------------------\n");
					for(i = 0; i < 450; i++)
						{
						if(qb.entities[i].visible)
							{
							printf("%d: %d (%s)  %d  %d  ", i,
								qb.entities[i].default_index, qb.precache_models[qb.entities[i].default_index].file,
								qb.entities[i].frame, qb.entities[i].skin);
							qb.entities[i].origin.print1();
							printf("   %.3f\n", (pl_me->origin - qb.entities[i].origin).length());
							}
						}
					break;

				case 'm':
					i = 0;
					do {
						i++;
						printf("%s\n", qb.precache_models[i].file);
						} while(*qb.precache_models[i].file != '\0');
					break;

				case 'g':
					printf("Go to entity: ");
					move_to = qb.entities[atoi(temp+2)].origin;
					move_to.print();
					printf(" (dist: %02f)\n", (pl_me->origin - move_to).length2D());
					break;

				case '1': scmd = 4; break;
				case '2': qb.flag = 0x02; break;
				case '3': qb.flag = 0x00; break;
				case '4': qb.flag = 0x01; break;
				case '5': qb.flag = 0x00; break;
				case 'p': scmd = 5; break;
				case 'z':
					printf("move_to = ");
					move_to.print();
					printf(" (dist: %02f)\n", (pl_me->origin - move_to).length2D());
					break;
				default:
					printf("Dunno that one.\n");
					break;
				}
			}
		}
}

