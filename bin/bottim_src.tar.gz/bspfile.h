/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _BSPFILE_H_
#define _BSPFILE_H_

#include "qfile.h"

#include "bsphead.h"
#include "entities.h"
#include "planes.h"
#include "vertices.h"
#include "nodes.h"
#include "faces.h"
#include "clipnodes.h"
#include "leaves.h"
#include "facelist.h"
#include "edges.h"
#include "edgelist.h"
#include "models.h"

/* ------------------------------------------------------------------------- */
class bsp_file
{
	public:
		int version;

		bsp_head *head;
		bsp_entities *entities;
		bsp_planes *planes;
		bsp_vertices *vertices;
		bsp_nodes *nodes;
		bsp_faces *faces;
		bsp_clipnodes *clipnodes;
		bsp_leaves *leaves;
		bsp_facelist *facelist;
		bsp_edges *edges;
		bsp_edgelists *edgelists;
		bsp_models *models;

		bsp_file(QFILE *qf);
		void write_bsp_file(QFILE *qf);
		void print_info(void);
		void print(void);
		void print2(void);
		int ok(void) { return(head == NULL ? 0 : 1); }
		int find_leaf(vector origin);
		int get_leaf_type(vector origin) { leaves->get_leaf(find_leaf(origin))->get_type(); }
		int is_line_blocked(vector sv, vector ev, vector *hit_point, int lava);
};

/* ------------------------------------------------------------------------- */
			/* Quake (Version: 28, 29) */
#define BSPD_ENTITIES	0
#define BSPD_PLANES		1
#define BSPD_TEXTURES	2
#define BSPD_VERTICES	3
#define BSPD_VISILIST	4
#define BSPD_NODES		5
#define BSPD_TEXINFO		6
#define BSPD_FACES		7
#define BSPD_LIGHTMAPS	8
#define BSPD_CLIPNODES	9
#define BSPD_LEAVES		10
#define BSPD_FACELIST	11
#define BSPD_EDGES		12
#define BSPD_EDGELIST	13
#define BSPD_MODELS		14

#define BSP_ENTITY_SIZE		1
#define BSP_PLANE_SIZE		20
#define BSP_VERTEX_SIZE		12
#define BSP_NODE_SIZE		24
#define BSP_FACE_SIZE		20
#define BSP_CLIPNODE_SIZE	8
#define BSP_LEAF_SIZE		28
#define BSP_FACELIST_SIZE	2
#define BSP_EDGELIST_SIZE	4
#define BSP_EDGE_SIZE		4
#define BSP_MODEL_SIZE		64
#define BSP_FACE_SIZE		20

/* ------------------------------------------------------------------------- */
			/* Quake 2 (Version: 38) */

#define BSPD2_ENTITIES	0
#define BSPD2_PLANES		1
#define BSPD2_VERTICES	2
#define BSPD2_VISILIST	3
#define BSPD2_NODES		4
#define BSPD2_TEXINFO	5
#define BSPD2_FACES		6
#define BSPD2_LIGHTMAPS	7
#define BSPD2_LEAVES		8
#define BSPD2_FACELIST	9
#define BSPD2_BRUSHLIST	10
#define BSPD2_EDGES		11
#define BSPD2_EDGELIST	12
#define BSPD2_MODELS		13
#define BSPD2_BRUSHES	14
#define BSPD2_BRUSHSIDES	15
#define BSPD2_POP			16
#define BSPD2_AREAS		17
#define BSPD2_AREAPORTALS	18


#define BSP2_ENTITY_SIZE	1
#define BSP2_PLANE_SIZE		20
#define BSP2_VERTEX_SIZE	12
#define BSP2_NODE_SIZE		28		// Q2 modif
#define BSP2_FACE_SIZE		20
#define BSP2_CLIPNODE_SIZE	8
#define BSP2_LEAF_SIZE		28
#define BSP2_FACELIST_SIZE	2
#define BSP2_EDGELIST_SIZE	4
#define BSP2_EDGE_SIZE		4
#define BSP2_MODEL_SIZE		48		// Q2 modif
#define BSP2_FACE_SIZE		20

#endif

