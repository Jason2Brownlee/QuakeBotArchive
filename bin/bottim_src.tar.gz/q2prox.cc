/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *
 *  A proxy for analysing packets between a Quake 2 client and a Quake 2
 *  server.  This is probably not up to date, so may need reworking for
 *  the latest version of Quake 2.
 * ------------------------------------------------------------------------ */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include <limits.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <stdarg.h>

#include "qwb.h"
#include "qsock.h"
#include "qpack.h"
#include "vector.h"

#define DBUG	1

/*
unsigned MakeChecksum_310(unsigned char *buf, int nbytes, int extra);
unsigned MakeChecksum_313(unsigned char *buf, int nbytes, int seqnum);
unsigned char ChecksumQ2_317(void *data, int chklen, unsigned int sequence);
*/

int hack_pak = 0;

/* ------------------------------------------------------------------------- */
#define CS_MODELS 32		/* Start of the model precache list. */
#define MAX_MODELS 256	/* Max number of the models in precache list. */

#define CS_SOUNDS (CS_MODELS+MAX_MODELS)	/* Start of the sound precache list. */
#define MAX_SOUNDS 256	/* Maximum number of the sounds in the precache list. */

#define CS_IMAGES (CS_SOUNDS+MAX_SOUNDS)	/* Start of the image list. */
#define MAX_IMAGES 256	/* Maximum numer of the images. */

#define CS_LIGHTS (CS_IMAGES+MAX_IMAGES)	/* Start of the light styles list. */
#define MAX_LIGHTSTYLES 256	/* Maximum number of the light styles. */

#define CS_ITEMS (CS_LIGHTS+MAX_LIGHTSTYLES)	/* Start of the items list. */
#define MAX_ITEMS 256		/* Maximum number of items in the inventory list. */

#define CS_PLAYERSKINS (CS_ITEMS+MAX_ITEMS)	/* Start of the player skin list. */
#define MAX_CLIENTS 256		/* Maximum number of players. */

#define MAX_CONFIGSTRINGS (CS_PLAYERSKINS+MAX_CLIENTS) /* Maximum number of config strings. */

char *config_strings[MAX_CONFIGSTRINGS+20];

typedef enum
{
	TE_GUNSHOT,
	TE_BLOOD,
	TE_BLASTER,
	TE_RAILTRAIL,
	TE_SHOTGUN,
	TE_EXPLOSION1,
	TE_EXPLOSION2,
	TE_ROCKET_EXPLOSION,
	TE_GRENADE_EXPLOSION,
	TE_SPARKS,
	TE_SPLASH,
	TE_BUBBLETRAIL,
	TE_SCREEN_SPARKS,
	TE_SHIELD_SPARKS,
	TE_BULLET_SPARKS,
	TE_LASER_SPARKS,
	TE_PARASITE_ATTACK,
	TE_ROCKET_EXPLOSION_WATER,
	TE_GRENADE_EXPLOSION_WATER,
	TE_MEDIC_CABLE_ATTACK,
	TE_BFG_EXPLOSION,
	TE_BFG_BIGEXPLOSION,
	TE_BOSSTPORT,
	TE_BFG_LASER,
	TE_GRAPPLE_CABLE,
	TE_WELDING_SPARKS,
	TE_PLASMATRAIL,
	TE_GREENBLOOD
} temp_event_t;

/* ------------------------------------------------------------------------- */
void hex_dump_buf(unsigned char *buf, int len)
{
int pos = 0, llen, i;

	while(pos < len)
		{
		llen = (len - pos < 16 ? len - pos : 16);
		printf("%08x: ", pos);
		for(i = 0; i < llen; i++) printf("%02x ", buf[pos + i]);
		for(i = 0; i < 16 - llen; i++) printf("   ");
		printf(" | ");

		for(i = 0; i < llen; i++)
			printf("%c", isprint(buf[pos + i]) ? buf[pos + i] : '.');
		for(i = 0; i < 16 - llen; i++) printf(" ");
		printf("\n");
		pos += llen;
		}
}


/* ------------------------------------------------------------------------- */
void ascii_dump_buf(unsigned char *buf, int len)
{
int pos = 0, llen, i;

	while(pos < len)
		{
		llen = (len - pos < 60 ? len - pos : 60);
		printf("%08x: ", pos);
		for(i = 0; i < llen; i++)
			printf("%c", isprint(buf[pos + i]) ? buf[pos + i] : '.');
		printf("\n");
		pos += llen;
		}
}


/* ------------------------------------------------------------------------- */
int dispt = 1;

int dprintf(const char *fmt, ...)
{
va_list marker;
int len = 0;

	va_start(marker, fmt);
	if(dispt)
		len = vprintf(fmt, marker);
	return len;
}


/* ------------------------------------------------------------------------- */
long last_rec_seq = 0;
int hbit = 0;

int analyze_packet_client(qpack *qp, int len)
{
int opcode, eval = 1, i;
long seq1, seq2, pak_id, cksum_pos, cksum_len;
unsigned int cksum_read, cksum_calc;
unsigned long mask;

	seq1 = qp->get_long();
	if(seq1 == -1)		/* special message */
		{
		dprintf("Special message: `%s'\n", qp->get_string());
		}
	else
		{
		seq2 = qp->get_long();
		pak_id = qp->get_ushort();

//		if((seq1 >> 31) & 0x01) printf("CL_RELIABLE\n");
		while(eval)
			{
			opcode = qp->get_byte();
#if DBUG
			dprintf("<");
			if((seq1 >> 31) & 0x01) dprintf("*");
			dprintf("%ld,", seq1 & 0x7FFFFFFF);
			if((seq2 >> 31) & 0x01) dprintf("*");
			dprintf("%ld>  [%ld] 0x%02x: ", seq2 & 0x7FFFFFFF, pak_id, opcode);
//			if((seq2 >> 31) & 0x01 != hbit) dprintf(" ## %d ## ", hbit);
#endif

			switch(opcode)
				{
				case 0x02:		/* player update */
					dprintf("Player Update:");
					cksum_read = qp->get_byte();
					dprintf("  checksum = %02x", cksum_read);
					cksum_pos = qp->get_read_pos();
					dprintf("  frame = %ld", qp->get_long());
					for(i = 0; i < 3; i++)
						{
						mask = qp->get_byte();
						dprintf("\n  mask = %02lx", mask);
						if(mask & 0x01) dprintf("  pitch = %.2f", qp->get_angle16());
						if(mask & 0x02) dprintf("  yaw = %.2f", qp->get_angle16());
						if(mask & 0x04) dprintf("  roll = %.2f", qp->get_angle16());
						if(mask & 0x08) dprintf("  forward = %d", qp->get_short());
						if(mask & 0x10) dprintf("  right = %d", qp->get_short());
						if(mask & 0x20) dprintf("  up = %d", qp->get_short());
						if(mask & 0x40) dprintf("  button = 0x%02x", qp->get_byte());
						if(mask & 0x80) dprintf("  impulse = %d", qp->get_byte());
							if(hack_pak)
								qp->get_buffer()[qp->get_read_pos()] = 0x01;
						dprintf("  [%02x]", qp->get_byte());
						dprintf(" [%02x]", qp->get_byte());
						}

					cksum_len = qp->get_read_pos() - cksum_pos;
		/*			cksum_calc = MakeChecksum_313(&(qp->get_buffer()[cksum_pos]), cksum_len, seq1 & 0x7FFFFFFF);
					cksum_calc = ChecksumQ2_317(&(qp->get_buffer()[cksum_pos]), cksum_len, seq1 & 0x7FFFFFFF);
					dprintf(" <<%02x>> ", cksum_calc);
					if(cksum_read != cksum_calc) dprintf("*** CHKSUM ERR ***"); */
					break;

				case 0x04:		/* console command */
					dprintf("%s", qp->get_string());
					break;

				default:
					eval = 0;
				}

			dprintf("\n");
			if(qp->get_read_pos() >= len) return(0);
			}
		}

	return (qp->get_read_pos() >= len ? 0 : 1);
}


/* ------------------------------------------------------------------------- */
int read_baseline(qpack *qp, int delta)
{
int entity, v1;
unsigned long mask;

	mask = qp->get_byte();
	if(mask & 0x00000080) mask |= (qp->get_byte() <<  8);
	if(mask & 0x00008000) mask |= (qp->get_byte() << 16);
	if(mask & 0x00800000) mask |= (qp->get_byte() << 24);
	entity = (mask & 0x00000100) ? qp->get_short() : qp->get_byte();
	if(delta)
		{
		if(entity == 0) return(0);
		dprintf("Packetent:");
		}
	dprintf("  entity: %d", entity);
	if(mask & 0x00000040) dprintf("  remove");
	if(mask & 0x00000800)
		{
		dprintf("  modelindex: %d", (v1 = qp->get_byte()));
		dprintf(" (%s)", config_strings[CS_MODELS + v1]);
		}
	if(mask & 0x00100000) dprintf("  modelindex2: %d", qp->get_byte());
	if(mask & 0x00200000) dprintf("  modelindex3: %d", qp->get_byte());
	if(mask & 0x00400000) dprintf("  modelindex4: %d", qp->get_byte());
	if(mask & 0x00000010) dprintf("  frame: %d", qp->get_byte());
	if(mask & 0x00020000) dprintf("  frame: %d", qp->get_short());
	if(mask & 0x00010000)
		{
		if(mask & 0x02000000) dprintf("  skinnum: %ld", qp->get_long());
		else dprintf("  skinnum: %d", qp->get_byte());
		}
	else
		{
		if(mask & 0x02000000) dprintf("  skinnum: %d", qp->get_short());
		}
	if(mask & 0x00004000)
		{
		if(mask & 0x00080000) dprintf("  effects: %ld", qp->get_long());
		else dprintf("  effects: %d", qp->get_byte());
		}
	else
		{
		if(mask & 0x00080000) dprintf("  effects: %d", qp->get_short());
		}
	if(mask & 0x00001000)
		{
		if(mask & 0x00040000) dprintf("  renderfx: %ld", qp->get_long());
		else dprintf("  renderfx: %d", qp->get_byte());
		}
	else
		{
		if(mask & 0x00040000) dprintf("  renderfx: %d", qp->get_short());
		}
	if(mask & 0x00000001) dprintf("  origin[0]: %.2f", qp->get_coord());
	if(mask & 0x00000002) dprintf("  origin[1]: %.2f", qp->get_coord());
	if(mask & 0x00000200) dprintf("  origin[2]: %.2f", qp->get_coord());
	if(mask & 0x00000400) dprintf("  angles[0]: %.2f", qp->get_angle());
	if(mask & 0x00000004) dprintf("  angles[1]: %.2f", qp->get_angle());
	if(mask & 0x00000008) dprintf("  angles[2]: %.2f", qp->get_angle());
	if(mask & 0x01000000)
		{
		dprintf("  old_origin[0]: %.2f", qp->get_coord());
		dprintf("  old_origin[1]: %.2f", qp->get_coord());
		dprintf("  old_origin[2]: %.2f", qp->get_coord());
		}
	if(mask & 0x04000000) dprintf("  sound: %d", qp->get_byte());
	if(mask & 0x00000020) dprintf("  event: %d", qp->get_byte());
	if(mask & 0x08000000) dprintf("  solid: %d", qp->get_short());
	return(1);
}


/* ------------------------------------------------------------------------- */
int analyze_packet_server(qpack *qp, int len)
{
int opcode, eval = 1, v1, i;
long seq1, seq2;
unsigned long mask, mask2;

	seq1 = qp->get_long();
	if(seq1 == -1)		/* special message */
		{
		dprintf("Special message: `%s'\n", qp->get_string());
		last_rec_seq = 0;
		hbit = 0;
		}
	else
		{
		last_rec_seq = seq2 = qp->get_long();
		if((seq1 >> 31) & 0x01)
			{
			hbit = !hbit;
//			printf("SV_RELIABLE\n");
			}

		while(eval)
			{
			opcode = qp->get_byte();
#if DBUG
			dprintf("<");
			if((seq1 >> 31) & 0x01) dprintf("*");
			dprintf("%ld,", seq1 & 0x7FFFFFFF);
			if((seq2 >> 31) & 0x01) dprintf("*");
			dprintf("%ld>  0x%02x: ", seq2 & 0x7FFFFFFF, opcode);
#endif
			switch(opcode)
				{
				case 0x01:		/* muzzle flash */
					dprintf("Muzzle flash:");
					dprintf("  Entity: %d", qp->get_short());
					dprintf("  Value: %d", qp->get_byte());
					break;

				case 0x02:		/* muzzle flash */
					dprintf("Muzzle flash 2:");
					dprintf("  Entity: %d", qp->get_short());
					dprintf("  Value: %d", qp->get_byte());
					break;

				case 0x03:		/* temp entity */
					v1 = qp->get_byte();
					dprintf("Temp entity %d:", v1);
					switch(v1)
						{
							/* point entity */
						case TE_EXPLOSION1:
						case TE_EXPLOSION2:
						case TE_ROCKET_EXPLOSION:
						case TE_GRENADE_EXPLOSION:
						case TE_ROCKET_EXPLOSION_WATER:
						case TE_GRENADE_EXPLOSION_WATER:
						case TE_BOSSTPORT:
							dprintf("   point entity");
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							break;

							/* impact entity */
						case TE_GUNSHOT:
						case TE_BLOOD:
						case TE_BLASTER:
						case TE_SHOTGUN:
						case TE_SPARKS:
						case TE_SCREEN_SPARKS:
						case TE_SHIELD_SPARKS:
						case TE_BULLET_SPARKS:
						case TE_GREENBLOOD:
							dprintf("   impact entity");
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							qp->get_byte();
							break;

							/* line entity */
						case TE_RAILTRAIL:
						case TE_BUBBLETRAIL:
						case TE_BFG_LASER:
						case TE_PLASMATRAIL:
							dprintf("   line entity");
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							qp->get_coord(); qp->get_coord(); qp->get_coord();
								break;

							/* special entity */
						case TE_SPLASH:
							dprintf("   splash entity");
							qp->get_byte();
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							qp->get_byte();
							qp->get_byte();
							break;

						case TE_LASER_SPARKS:
						case TE_WELDING_SPARKS:
							dprintf("   sparks entity");
							qp->get_byte();
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							qp->get_byte();
							qp->get_byte();
							break;

						case TE_PARASITE_ATTACK:
						case TE_MEDIC_CABLE_ATTACK:
							dprintf("   cable entity");
							qp->get_byte();
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							break;

						case TE_GRAPPLE_CABLE:
							dprintf("   grapple entity");
							qp->get_byte();
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							qp->get_coord(); qp->get_coord(); qp->get_coord();
							break;
						}
					break;

				case 0x04:		/* layout */
					dprintf("Layout: `%s'", qp->get_string());
					break;

				case 0x05:		/* inventory */
					dprintf("Inventory:");
					for(i = 0; i < 256; i++) dprintf(" %d,", qp->get_short());
					break;

				case 0x06:		/* nop */
					dprintf(" <NOP> ");
					break;

				case 0x07:		/* disconnect */
					dprintf(" <Disconnect> ");
					break;

				case 0x08:		/* reconnect */
					dprintf(" <Reconnect> ");
					break;

				case 0x09:		/* sound */
					mask = qp->get_byte();
					dprintf("Sound: %d", qp->get_byte());
					if(mask & 0x01) dprintf("  vol: %d", qp->get_byte());
					if(mask & 0x02) dprintf("  atten: %d", qp->get_byte());
					if(mask & 0x10) dprintf("  timeofs: %d", qp->get_byte());
					if(mask & 0x08)
						{
						v1 = qp->get_short();
						dprintf("  entity: %d  channel: %d", v1 >> 3, v1 & 0x07);
						}
					if(mask & 0x04)
						dprintf("  at %.2f,%.2f,%.2f", qp->get_coord(), qp->get_coord(), qp->get_coord());
					break;

				case 0x0a:		/* print */
					dprintf("[%d]", qp->get_byte());
					dprintf("%s", qp->get_string());
					break;

				case 0x0b:		/* stufftext */
					dprintf("Stufftext: `%s'", qp->get_string());
					break;

				case 0x0c:		/* serverdata */
					dprintf("Servdat:");
					dprintf("  Version: %ld", qp->get_long());
					dprintf("  Client ID: %ld", qp->get_long());
					dprintf("  uk_b1: %d", qp->get_byte());
					dprintf("  uk_s1: %s", qp->get_string());
					dprintf("  uk_w1: %d", qp->get_short());
					dprintf("  Map name: %s", qp->get_string());
					break;

				case 0x0d:		/* configstring */
					v1 = qp->get_short();
					dprintf("Confstr: %d ", v1);
					if(v1 >= CS_PLAYERSKINS) dprintf("(PSK %d) ", v1 - CS_PLAYERSKINS);
					else if(v1 >= CS_ITEMS) dprintf("(ITM %d) ", v1 - CS_ITEMS);
					else if(v1 >= CS_LIGHTS) dprintf("(LIT %d) ", v1 - CS_LIGHTS);
					else if(v1 >= CS_IMAGES) dprintf("(IMG %d) ", v1 - CS_IMAGES);
					else if(v1 >= CS_SOUNDS) dprintf("(SND %d) ", v1 - CS_SOUNDS);
					else if(v1 >= CS_MODELS) dprintf("(MDL %d) ", v1 - CS_MODELS);
					config_strings[v1] = qp->get_nstring();
					dprintf("- `%s'", config_strings[v1]);
					break;

				case 0x0e:		/* spawnbaseline */
					dprintf("Spawnbline:");
					read_baseline(qp, 0);
					break;

				case 0x0f:		/* center print */
					printf("Center print: %s", qp->get_string());
					break;

				case 0x11:		/* playerinfo */
					dprintf("Playerinfo:");
					mask = qp->get_short();
					if(mask & 0x0001) dprintf("  pm_type: %d", qp->get_byte());
					if(mask & 0x0002)
						{
						dprintf("  origin[0]: %.2f", qp->get_coord());
						dprintf("  origin[1]: %.2f", qp->get_coord());
						dprintf("  origin[2]: %.2f", qp->get_coord());
						}
					if(mask & 0x0004)
						{
						dprintf("  velocity[0]: %d", qp->get_short());
						dprintf("  velocity[1]: %d", qp->get_short());
						dprintf("  velocity[2]: %d", qp->get_short());
						}
					if(mask & 0x0008) dprintf("  teleport_time: %d", qp->get_byte());
					if(mask & 0x0010) dprintf("  pm_flags: %d", qp->get_byte());
					if(mask & 0x0020) dprintf("  gravity: %d", qp->get_short());
					if(mask & 0x0040)
						{
						dprintf("  delta_angles[0]: %d", qp->get_short());
						dprintf("  delta_angles[1]: %d", qp->get_short());
						dprintf("  delta_angles[2]: %d", qp->get_short());
						}
					if(mask & 0x0080)
						{
						dprintf("  viewoffset[0]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  viewoffset[1]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  viewoffset[2]: %.2f", qp->get_sbyte() / 4.0);
						}
					if(mask & 0x0100)
						{
						dprintf("  viewangles[0]: %.2f", qp->get_angle16());
						dprintf("  viewangles[1]: %.2f", qp->get_angle16());
						dprintf("  viewangles[2]: %.2f", qp->get_angle16());
						}
					if(mask & 0x0200)
						{
						dprintf("  kick_angles[0]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  kick_angles[1]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  kick_angles[2]: %.2f", qp->get_sbyte() / 4.0);
						}
					if(mask & 0x1000) dprintf("  gunindex: %d", qp->get_byte());
					if(mask & 0x2000)
						{
						dprintf("  gunframe: %d", qp->get_byte());
						dprintf("  gunoffset[0]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  gunoffset[1]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  gunoffset[2]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  gunangles[0]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  gunangles[1]: %.2f", qp->get_sbyte() / 4.0);
						dprintf("  gunangles[2]: %.2f", qp->get_sbyte() / 4.0);
						}
					if(mask & 0x0400)
						{
						dprintf("  blend[0]: %.2f", qp->get_byte() / 255.0);
						dprintf("  blend[1]: %.2f", qp->get_byte() / 255.0);
						dprintf("  blend[2]: %.2f", qp->get_byte() / 255.0);
						dprintf("  blend[3]: %.2f", qp->get_byte() / 255.0);
						}
					if(mask & 0x0800) dprintf("  fov: %.2f", (float) qp->get_byte());
					if(mask & 0x4000) dprintf("  rdflags: %d", qp->get_byte());
					mask2 = qp->get_long();
					for(i = 0; i < 32; i++)
						if(mask2 & (0x00000001 << i))
							dprintf("  stats[%d]: %d", i,  qp->get_short());
					break;

				case 0x12:		/* packetentities */
					while(1)
						{
						if(!read_baseline(qp, 1)) break;
						dprintf("  ");
						if(qp->get_read_pos() >= len) return(0);
						}
					break;

				case 0x14:		/* frame */
					dprintf("Frame:");
					dprintf(" <%ld,", qp->get_long());
					dprintf("%ld>", qp->get_long());
					dprintf("  UK = %d", qp->get_byte());
					dprintf("  <%d:", v1 = qp->get_byte());
					for(i = 0; i < v1; i++)
						dprintf(" %02x", qp->get_byte());
					dprintf(">");
					break;

				default:
					eval = 0;
				}

			dprintf("\n");
			fflush(stdout);
			if(qp->get_read_pos() >= len) return(0);
			}
		}

	return (qp->get_read_pos() >= len ? 0 : 1);
}


/* ------------------------------------------------------------------------- */
int main(int argc, char **argv)
{
fd_set a;
struct timeval tv;
char temp[30];
int recvd, running = 1;
long port = 27910;

	if(argc < 2)
		{
		printf("qprox <host> [port]\n");
		return 0;
		}

	if(argc > 2) port = atol(argv[2]);

	qsock qrem(argv[1], port), qloc(27501);
	qpack qp(10000);

	tv.tv_sec = 2;
	tv.tv_usec = 2000;

	while(running)
		{
		FD_ZERO(&a);
		FD_SET(0, &a);
		FD_SET(qrem.getFD(), &a);
		FD_SET(qloc.getFD(), &a);
		if((select(100, &a, 0, 0, &tv)) < 0) perror("select");

		if(FD_ISSET(qrem.getFD(), &a))
			{
			qp.reset();
			recvd = qrem.receive(qp.get_buffer(), qp.get_max_size());

#if DBUG
			dprintf("\n>>>>>>>>>>>>>>>>>>>>> server to client %d bytes (loc: %d, rem: %d):\n",
				recvd, qrem.getLocalPort(), qrem.getRemotePort());
#endif
			if(analyze_packet_server(&qp, recvd))
				{
				if(dispt)
					{
					ascii_dump_buf((unsigned char *)qp.get_buffer(), recvd);
					hex_dump_buf((unsigned char *)qp.get_buffer(), recvd);
					}
				}

			qloc.send(qp.get_buffer(), recvd);
			}

		if(FD_ISSET(qloc.getFD(), &a))
			{
			qp.reset();
			recvd = qloc.receive(qp.get_buffer(), qp.get_max_size());

#if DBUG
			dprintf("\n<<<<<<<<<<<<<<<<<<<<< client to server %d bytes (loc: %d, rem: %d):\n",
				recvd, qloc.getLocalPort(), qloc.getRemotePort());
#endif
			if(analyze_packet_client(&qp, recvd))
				{
				if(dispt)
					{
					ascii_dump_buf((unsigned char *)qp.get_buffer(), recvd);
					hex_dump_buf((unsigned char *)qp.get_buffer(), recvd);
					}
				}

			qrem.send(qp.get_buffer(), recvd);
			}

		if(FD_ISSET(0, &a))
			{
			read(0, temp, 1024);
			switch(temp[0])
				{
				case 'q':
					printf("Quit...\n");
					running = 0;
					break;

				case 'd':
					dispt = !dispt;
					printf("DISPLAY = %d\n", dispt);
					break;

				case 'c':
					printf("%cc\n", 27);
					break;

				case 'h':
					hack_pak = !hack_pak;
					printf("HACK PAK = %d\n", hack_pak);
					break;

				default:
					printf("Dunno that one.\n");
					break;
				}
			}
		}
}

