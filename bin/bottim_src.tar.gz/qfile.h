/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  See the .cc file :)
 * ------------------------------------------------------------------------ */
#ifndef _QFILE_H_
#define _QFILE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define QDT_DIR	1
#define QDT_FILE	2

#ifndef min
#	define min(a, b)  ((a) < (b) ? (a) : (b))
#endif

	/* --------------------------------- */
class QFILE
{
	long start, size, file_pos;
	FILE *fp;

	public:
		QFILE() { fp = NULL; file_pos = 0; }
		QFILE(long sstart, long ssize, char *fname) {
			fp = fopen(fname, "rb");
			start = sstart;
			size = ssize;
			file_pos = 0;
			}
		QFILE(char *fname) {
			fp = fopen(fname, "wb");
			start = 0;
			size = -1;
			file_pos = 0;
			}
		~QFILE() { if(fp != NULL) fclose(fp); }

		long ftell(void) { return file_pos; }
		long filelength(void) { return size; }
		void rewind(void) { file_pos = 0; fseek(fp, start, SEEK_SET); }
		FILE *get_fp(void) { return fp; }
		int get_byte(void);
		short get_short(void);
		unsigned short get_ushort(void);
		long get_long(void);
		unsigned long get_ulong(void);
		float get_float(void);
		void write(void *ptr, long wr_size, long n);
		void put_byte(int val);
		void put_short(short val);
		void put_long(long val);
		void put_float(float val);
		int seek(long sk_offset, int whence);
		long read(void *ptr, long rd_size, long n);
};


	/* --------------------------------- */
class qfile_ent
{
	char *fname;
	long size;
	qfile_ent *next;

	public:
		qfile_ent(char *fn, long s) { fname = strdup(fn); size = s; next = NULL; }
		void add(qfile_ent *&head) { this->next = head; head = this; }
		void print(void) { printf("%-10ld %s\n", size, fname); }

		qfile_ent *get_next(void) { return next; }
		char *get_fname(void) { return fname; }
		long get_size(void) { return size; }
};


	/* --------------------------------- */
class qdirent
{
	char fname[80], type;
	qfile_ent *file;
	qdirent *next;
	union { long size; qdirent *dir; };
	union { long offset; qdirent *parent; };

	public:
		qdirent(void) { dir = next = parent = NULL; }
		qdirent(char *ifname, long ioffset, long isize, qfile_ent *ifile) {
			init(ifname, ioffset, isize, ifile); }		/* FILE */
		qdirent(char *ifname, qdirent *iparent) {
			init(ifname, iparent); }		/* DIRECTORY */
		void init(char *ifname, long ioffset, long isize, qfile_ent *ifile) {
			change(ifname, ioffset, isize, ifile); next = NULL; }		/* FILE */
		void init(char *ifname, qdirent *iparent) {
			strcpy(fname, ifname); type = QDT_DIR; parent = iparent;
			dir = next = NULL; }		/* DIRECTORY */
		void change(char *ifname, long ioffset, long isize, qfile_ent *ifile) {
			strcpy(fname, ifname); type = QDT_FILE; size = isize;
			offset = ioffset; file = ifile; }		/* FILE */
		int cmp_ent(char *fn) { return(strcmp(fn, fname) == 0); }
		void add(qdirent *head) { this->next = head->dir; head->dir = this; }

		qdirent *get_next(void) { return next; }
		qdirent *get_dir(void) { return dir; }
		qdirent *get_parent(void) { return parent; }
		char *get_fname(void) { return fname; }
		char *get_root_file(void) { return file->get_fname(); }
		long get_size(void) { return size; }
		long get_offset(void) { return offset; }
		char get_type(void) { return type; }
		void print(void) {
			if(type == QDT_DIR) printf("%s/\n", fname);
			else printf("%-40s %-8ld %-8ld  < %s\n", fname, size, offset, file->get_fname());
			}
};


	/* --------------------------------- */
class qdirectory
{
	qfile_ent *disk_files;
	qdirent root, *cwd;

	int recurse_disk_dir(char *dir_name);
	void add_disk_file(char *fname, long size) { (new qfile_ent(fname, size))->add(disk_files); }
	int add_qpack_dir(char *fname, qfile_ent *qf);

	public:
		qdirectory(void) { disk_files = NULL; root.init("", &root);
			cwd = &root; }
		qdirent *find_ent(char *fname, qdirent *qd) {
			for( ; qd != NULL; qd = qd->get_next())
				if(qd->cmp_ent(fname)) return qd;
			return NULL;
			}
		int add_dir(char *dir_name);
		void chroot(void) { cwd = &root; }
		int chdir(char *fname);
		int mknode(char *fname, long size, long offset, qfile_ent *qf, qdirent *dir);
		void add_cwd(qdirent *qd) { qd->add(cwd); }
		void rdir(qdirent *qd, int depth = 0);
		void dir(qdirent *qd) { for(qd = qd->get_dir(); qd != NULL; qd = qd->get_next()) qd->print(); }
		qdirent *find_file(char *fname, qdirent *dir);
		QFILE *qpopen(char *fname);
		void print_disk_files(void) { for(qfile_ent *tq = disk_files; tq != NULL; tq = tq->get_next()) tq->print(); }
		void print_path(qdirent *qd) {
			if(qd->get_parent() != qd) print_path(qd->get_parent());
			printf("%s/", qd->get_fname()); }
		qdirent *get_cwd(void) { return cwd; };
};

#endif

