/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _QENTITY_H_
#define _QENTITY_H_

#include "vector.h"
#include "angle.h"

/* ------------------------------------------------------------------------- */
class qentity
{
	public:
		int visible;		// if visible or not
		int index;			// into modeltable[]
		int default_index;
		int frame;			// model's frame (usefull for determing
								// weather player is dead)
		int skin;			// good for determining armour type
		int effects;
		vector origin;		// center of entity
		angle facing;		// which way is it looking?
		vector velocity;		// how fast, which direction moving?
		int spawned;			// TRUE/FALSE if spawnbaseline recieved for this
		int rate;

		qentity() { index = -1; frame = 0; skin = 0;
			origin.set(0.0, 0.0, 0.0); facing.set(0.0, 0.0, 0.0);
			rate = 0; visible = spawned = 0; }
		void update_origin(vector &v) { velocity = v - origin; origin = v; }
};

class precache
{
	public:
		char *file;
		int m_type, type;

		precache() { file = NULL; }
};

#endif

