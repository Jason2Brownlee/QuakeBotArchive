/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _LEAVES_H_
#define _LEAVES_H_

#include "vector.h"
#include "qfile.h"

class bsp_leaf
{
	public:
		enum type_t { normal = 0, solid = 1, window = 2, aux = 4, lava = 8,
			slime = 16, water = 32, mist = 64, sky = 128, unknown };

	private:
		type_t type;
		long stype;
		long visilist;
		vector bbox_min;		// uses shorts, not floats, in file...
		vector bbox_max;
		unsigned short face_list_id;
		unsigned short face_list_num;
		long sounds;			// 4 chars; i don't use 'em

	public:
		bsp_leaf(QFILE *qf, int v) { read(qf, v); }
		void read(QFILE *qf, int version) { stype = qf->get_long();
			if(version == 38) type = (type_t)stype;
			else switch(stype) {
				case -1: type=normal; break; case -2: type=solid; break; case -3:
				type=water; break; case -4: type=slime; break; case -5:
				type=lava; break; case -6: type=sky; break;
				default: type=unknown;break; };
			visilist = qf->get_long();
			bbox_min.setx((float)qf->get_short());
			bbox_min.sety((float)qf->get_short());
			bbox_min.setz((float)qf->get_short());
			bbox_max.setx((float)qf->get_short());
			bbox_max.sety((float)qf->get_short());
			bbox_max.setz((float)qf->get_short());
			face_list_id = qf->get_ushort(); face_list_num = qf->get_ushort();
			sounds = qf->get_long(); }

		void write(QFILE *qf) { qf->put_long(stype); qf->put_long(visilist);
			qf->put_short((short)bbox_min.getx());
			qf->put_short((short)bbox_min.gety());
			qf->put_short((short)bbox_min.getz());
			qf->put_short((short)bbox_max.getx());
			qf->put_short((short)bbox_max.gety());
			qf->put_short((short)bbox_max.getz());
			qf->put_short(face_list_id); qf->put_short(face_list_num);
			qf->put_long(sounds); }

		type_t get_type(void) { return type; }
		long get_visilist(void) { return visilist; }
		vector get_bbox_min(void) { return bbox_min; }
		vector get_bbox_max(void) { return bbox_max; }
		int get_face_list_id(void) { return (int)face_list_id; }
		int get_face_list_num(void) { return (int)face_list_num; }
		void print(void) { printf("%d (%ld) %u %u\n", type, stype, face_list_id, face_list_num ); }
};


class bsp_leaves
{
	bsp_leaf **leaves;
	int loaded_leaves;

	public:
		bsp_leaves(QFILE *qf, int n, int v) { leaves = new bsp_leaf* [ n ];
			for(int i = 0; i < n; i++) leaves[i]=0; loaded_leaves = 0;
			read(qf, n, v); }
		~bsp_leaves(void) { for(int i = 0; i < loaded_leaves; i++)
			delete leaves[i]; delete leaves; }

		void read(QFILE *qf, int n, int v) { for(int i = 0; i < n; i++)
			leaves[i] = new bsp_leaf(qf, v); loaded_leaves = n; }
		void write(QFILE *qf) { for(int i = 0; i < loaded_leaves; i++) leaves[i]->write(qf); }
		bsp_leaf *get_leaf(int x) { return(x>= 0 && x < loaded_leaves ? leaves[x] : (bsp_leaf *)NULL); }
		int get_num(void) { return loaded_leaves; }
		void print(void) { for(int i = 0; i < loaded_leaves; i++) { printf("%d : ", i); leaves[i]->print(); } }
};


#endif


