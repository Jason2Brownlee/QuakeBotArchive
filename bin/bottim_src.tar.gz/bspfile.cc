/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  ::bsp_file: Opens and reads the parts of a Quake 1 or 2 bsp file
 *          which are relevent for the bot navigation.
 *  ::write_bsp_file: Write a bsp file with the parts which are relevent for
 *          bot navigation.
 * ------------------------------------------------------------------------ */
#include "bspfile.h"
#include "vector.h"
#include "stack.h"

/* ------------------------------------------------------------------------- */
bsp_file::bsp_file(QFILE *qf)
{
bsp_entry *be;
int ver;

	head = new bsp_head(qf);
	ver = head->get_version();
	if(!(ver == 29 || ver == 28 || ver == 38))
		{
		printf("Error: Version %d BSP file not supported.\n", ver);
		free(head);
		head = NULL;
		return;
		}

	if(ver == 38)
		{
		be = head->get_entry(BSPD2_ENTITIES);
		qf->seek(be->get_offset(), SEEK_SET);
		entities = new bsp_entities(qf, be->get_size()/BSP2_ENTITY_SIZE);

		be = head->get_entry(BSPD2_PLANES);
		qf->seek(be->get_offset(), SEEK_SET);
		planes = new bsp_planes(qf, be->get_size()/BSP2_PLANE_SIZE);

		be = head->get_entry(BSPD2_VERTICES);
		qf->seek(be->get_offset(), SEEK_SET);
		vertices = new bsp_vertices(qf, be->get_size()/BSP2_VERTEX_SIZE);

		be = head->get_entry(BSPD2_NODES);
		qf->seek(be->get_offset(), SEEK_SET);
		nodes = new bsp_nodes(qf, be->get_size()/BSP2_NODE_SIZE, ver);

		be = head->get_entry(BSPD2_FACES);
		qf->seek(be->get_offset(), SEEK_SET);
		faces = new bsp_faces(qf, be->get_size()/BSP2_FACE_SIZE);

		be = head->get_entry(BSPD2_LEAVES);
		qf->seek(be->get_offset(), SEEK_SET);
		leaves = new bsp_leaves(qf, be->get_size()/BSP2_LEAF_SIZE, ver);

		be = head->get_entry(BSPD2_FACELIST);
		qf->seek(be->get_offset(), SEEK_SET);
		facelist = new bsp_facelist(qf, be->get_size()/BSP2_FACELIST_SIZE);

		be = head->get_entry(BSPD2_EDGES);
		qf->seek(be->get_offset(), SEEK_SET);
		edges = new bsp_edges(qf, be->get_size()/BSP2_EDGE_SIZE);

		be = head->get_entry(BSPD2_EDGELIST);
		qf->seek(be->get_offset(), SEEK_SET);
		edgelists = new bsp_edgelists(qf, be->get_size()/BSP2_EDGELIST_SIZE);

		be = head->get_entry(BSPD2_MODELS);
		qf->seek(be->get_offset(), SEEK_SET);
		models = new bsp_models(qf, be->get_size()/BSP2_MODEL_SIZE, ver);
		}
	else
		{
		be = head->get_entry(BSPD_ENTITIES);
		qf->seek(be->get_offset(), SEEK_SET);
		entities = new bsp_entities(qf, be->get_size()/BSP_ENTITY_SIZE);

		be = head->get_entry(BSPD_PLANES);
		qf->seek(be->get_offset(), SEEK_SET);
		planes = new bsp_planes(qf, be->get_size()/BSP_PLANE_SIZE);

		be = head->get_entry(BSPD_VERTICES);
		qf->seek(be->get_offset(), SEEK_SET);
		vertices = new bsp_vertices(qf, be->get_size()/BSP_VERTEX_SIZE);

		be = head->get_entry(BSPD_NODES);
		qf->seek(be->get_offset(), SEEK_SET);
		nodes = new bsp_nodes(qf, be->get_size()/BSP_NODE_SIZE, ver);

		be = head->get_entry(BSPD_FACES);
		qf->seek(be->get_offset(), SEEK_SET);
		faces = new bsp_faces(qf, be->get_size()/BSP_FACE_SIZE);

		be = head->get_entry(BSPD_CLIPNODES);
		qf->seek(be->get_offset(), SEEK_SET);
		clipnodes = new bsp_clipnodes(qf, be->get_size()/BSP_CLIPNODE_SIZE);

		be = head->get_entry(BSPD_LEAVES);
		qf->seek(be->get_offset(), SEEK_SET);
		leaves = new bsp_leaves(qf, be->get_size()/BSP_LEAF_SIZE, ver);

		be = head->get_entry(BSPD_FACELIST);
		qf->seek(be->get_offset(), SEEK_SET);
		facelist = new bsp_facelist(qf, be->get_size()/BSP_FACELIST_SIZE);

		be = head->get_entry(BSPD_EDGES);
		qf->seek(be->get_offset(), SEEK_SET);
		edges = new bsp_edges(qf, be->get_size()/BSP_EDGE_SIZE);

		be = head->get_entry(BSPD_EDGELIST);
		qf->seek(be->get_offset(), SEEK_SET);
		edgelists = new bsp_edgelists(qf, be->get_size()/BSP_EDGELIST_SIZE);

		be = head->get_entry(BSPD_MODELS);
		qf->seek(be->get_offset(), SEEK_SET);
		models = new bsp_models(qf, be->get_size()/BSP_MODEL_SIZE, ver);
		}
}


/* ------------------------------------------------------------------------- */
void bsp_file::write_bsp_file(QFILE *qf)
{
bsp_head tmp_head;
bsp_entry *be;
int ver;

	ver = head->get_version();

	tmp_head = *head;
	tmp_head.write(qf);

	be = tmp_head.get_entry(BSPD_ENTITIES);
	be->set_entry(qf->ftell(), entities->get_num() * BSP_ENTITY_SIZE);
	entities->write(qf);

	be = tmp_head.get_entry(BSPD_PLANES);
	be->set_entry(qf->ftell(), planes->get_num() * BSP_PLANE_SIZE);
	planes->write(qf);

	be = tmp_head.get_entry(BSPD_VERTICES);
	be->set_entry(qf->ftell(), vertices->get_num() * BSP_VERTEX_SIZE);
	vertices->write(qf);

	be = tmp_head.get_entry(BSPD_NODES);
	be->set_entry(qf->ftell(), nodes->get_num() * BSP_NODE_SIZE);
	nodes->write(qf, ver);

	be = tmp_head.get_entry(BSPD_FACES);
	be->set_entry(qf->ftell(), faces->get_num() * BSP_FACE_SIZE);
	faces->write(qf);

	be = tmp_head.get_entry(BSPD_CLIPNODES);
	be->set_entry(qf->ftell(), clipnodes->get_num() * BSP_CLIPNODE_SIZE);
	clipnodes->write(qf);

	be = tmp_head.get_entry(BSPD_LEAVES);
	be->set_entry(qf->ftell(), leaves->get_num() * BSP_LEAF_SIZE);
	leaves->write(qf);

	be = tmp_head.get_entry(BSPD_FACELIST);
	be->set_entry(qf->ftell(), facelist->get_num() * BSP_FACELIST_SIZE);
	facelist->write(qf);

	be = tmp_head.get_entry(BSPD_EDGES);
	be->set_entry(qf->ftell(), edges->get_num() * BSP_EDGE_SIZE);
	edges->write(qf);

	be = tmp_head.get_entry(BSPD_EDGELIST);
	be->set_entry(qf->ftell(), edgelists->get_num() * BSP_EDGELIST_SIZE);
	edgelists->write(qf);

	be = tmp_head.get_entry(BSPD_MODELS);
	be->set_entry(qf->ftell(), models->get_num() * BSP_MODEL_SIZE);
	models->write(qf, ver);

	qf->rewind();
	tmp_head.write(qf);
}


/* ------------------------------------------------------------------------- */
void bsp_file::print_info(void)
{
	printf("Version: %d\n", head->get_version());
	printf("%d entities\n", entities->get_num());
	printf("%d planes\n", planes->get_num());
	printf("%d vertices\n", vertices->get_num());
	printf("%d nodes\n", nodes->get_num());
	printf("%d faces\n", faces->get_num());
	if(clipnodes != NULL) printf("%d clipnodes\n", clipnodes->get_num());
	printf("%d leaves\n", leaves->get_num());
	printf("%d facelists\n", facelist->get_num());
	printf("%d edges\n", edges->get_num());
	printf("%d edgelists\n", edgelists->get_num());
	printf("%d models\n", models->get_num());

}


/* ------------------------------------------------------------------------- */
void bsp_file::print(void)
{
	printf("entities\n");
	entities->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("planes - normal, distance, type\n");
	planes->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("vertices - x, y, z\n");
	vertices->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("nodes - plane_id, L/R:front, L/R:back, face_id, face_num\n");
	nodes->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("faces - plane_id, B/F, edge_list_id, edge_list_num\n");
	faces->print();
	if(clipnodes != NULL)
		{
		printf("\n----------------------------------------------------------------------------\n");
		printf("clipnodes - plane_id, front, back\n");
		clipnodes->print();
		}
	printf("\n----------------------------------------------------------------------------\n");
	printf("leaves - type, face_list_id, face_list_num\n");
	leaves->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("facelists\n");
	facelist->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("edges - vertex index, vertex index\n");
	edges->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("edgelists\n");
	edgelists->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("models  - bsp_node_id, face_id, face_num\n");
	models->print();
}


/* ------------------------------------------------------------------------- */
void bsp_file::print2(void)
{
	printf("entities\n");
	entities->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("planes - normal, distance, type\n");
	planes->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("vertices - x, y, z\n");
	vertices->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("nodes - plane_id, L/R:front, L/R:back, face_id, face_num\n");
	nodes->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("faces - plane_id, B/F, edge_list_id, edge_list_num\n");
	faces->print();
	if(clipnodes != NULL)
		{
		printf("\n----------------------------------------------------------------------------\n");
		printf("clipnodes - plane_id, front, back\n");
		clipnodes->print();
		}
	printf("\n----------------------------------------------------------------------------\n");
	printf("leaves - type, face_list_id, face_list_num\n");
	leaves->print();
	printf("\n----------------------------------------------------------------------------\n");
	printf("facelists\n");
	for(int i = 0; i < facelist->get_num(); i++)
		{
		printf("%d : %d --> ", i, facelist->get_facelist(i));
		faces->get_face(facelist->get_facelist(i))->print();
		}
	printf("\n----------------------------------------------------------------------------\n");
	printf("edges - vertex index, vertex index\n");
	for(int i = 0; i < edges->get_num(); i++)
		{
		printf("%d : %d - %d --> ", i, edges->get_edge(i)->get_vertex(0),
			edges->get_edge(i)->get_vertex(1));
		vertices->get_vertex(edges->get_edge(i)->get_vertex(0))->get_position().print();
		printf(" - ");
		vertices->get_vertex(edges->get_edge(i)->get_vertex(1))->print();
		}
	printf("\n----------------------------------------------------------------------------\n");
	printf("edgelists\n");
	for(int i = 0; i < edgelists->get_num(); i++)
		{
		long e = edgelists->get_edge_list(i);
		printf("%d : %ld --> ", i, e);
		if(e < 0) e = -e;
		edges->get_edge(e)->print();
		}
	printf("\n----------------------------------------------------------------------------\n");
	printf("models  - bsp_node_id, face_id, face_num\n");
	models->print();
}


/* ------------------------------------------------------------------------- */
int bsp_file::find_leaf(vector origin)
{
bsp_plane *pln;
int node, is_node = 1;
float dist;
	
	node = models->get_model(0)->get_bsp_root();

	while(is_node)
		{
		pln = planes->get_plane(nodes->get_node(node)->get_plane_id());
		dist = (pln->get_normal() * origin) - pln->get_distance();
		if(dist >= 0.0)
			{
			is_node = !(nodes->get_node(node)->is_front_leaf());
			node = nodes->get_node(node)->get_front();
			}
		else
			{
			is_node = !(nodes->get_node(node)->is_back_leaf());
			node = nodes->get_node(node)->get_back();
			}
		}

	return node;
}


/* ------------------------------------------------------------------------- */
int bsp_file::is_line_blocked(vector sv, vector ev, vector *hit_point, int lava)
{
bsp_plane *pln;
stack< vector > st;
stack< int > st1;
vector start = sv, end = ev, tv;
float s, e;
int node, start_node, end_node, is_node = 1;

	node = models->get_model(0)->get_bsp_root();

	while(1)
		{
		if(node == -1) break;

		if(is_node)
			{
			// e = distance from end to plane
			// s = distance from start to plane

			pln = planes->get_plane(nodes->get_node(node)->get_plane_id());
			e = (pln->get_normal() * (end)) - pln->get_distance();
			s = (pln->get_normal() * (start)) - pln->get_distance();

#define RE 0.001

			if(e > 0.0)
				end_node = nodes->get_node(node)->get_front();
			else
				end_node = nodes->get_node(node)->get_back();
			
			if(s > 0.0)
				{
				is_node  = !(nodes->get_node(node)->is_front_leaf());
				start_node = nodes->get_node(node)->get_front();
				}
			else
				{
				is_node  = !(nodes->get_node(node)->is_back_leaf());
				start_node = nodes->get_node(node)->get_back();
				}
			
			if((s < -RE && e > RE) || (s > RE && e < -RE))
				{
				st.push(end);
				st1.push(end_node);
				tv = start;
				tv *= e;
				end *= s;
				end = end - tv;
				end /= (s-e);
				}
			node = start_node;
			}
		else
			{
			if(lava == 0)
				{
				if(leaves->get_leaf(node)->get_type() == bsp_leaf::solid)
					{
					if(hit_point) *hit_point = end;
					return leaves->get_leaf(node)->get_type();
					}
				}
			else if(lava == 1)
				{
				if(leaves->get_leaf(node)->get_type() == bsp_leaf::lava ||
					leaves->get_leaf(node)->get_type() == bsp_leaf::water)
					{
					if(hit_point) *hit_point = end;
					return leaves->get_leaf(node)->get_type();
					}
				}
			else if(lava == 2)
				{
				if(leaves->get_leaf(node)->get_type() != bsp_leaf::normal)
					{
					if(hit_point) *hit_point = end;
					return leaves->get_leaf(node)->get_type();
					}
				}

			start = end;
			if(st.isEmpty()) return 0;
			
			end = st.pop();
			node = st1.pop();
			is_node =1;
			}
		}

	return 0;
}

