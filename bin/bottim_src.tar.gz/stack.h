/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _STACK_H_
#define _STACK_H_

template< class T >
class stack
{
  int size;
  T * items;
  int maxSize;
  
public:

  stack( int x=1024 ) { size=0; items = new T[ x ]; maxSize=x; }
  ~stack() { delete[] items; }

  int push( T x ) { if( size>=maxSize) return 0; items[size++]=x; return 1; }
  T pop() { if( !isEmpty() ) return items[--size]; return 0; }
  T peek() { if( !isEmpty() ) return items[ size-1 ]; return 0; }

  int getSize() { return size; }
  int isEmpty() { return (size==0); }
};


#endif
