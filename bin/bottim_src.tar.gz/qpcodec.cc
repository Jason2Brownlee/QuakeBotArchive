/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  Perhaps the main contribution from this bot, this file contains the
 *  client to server connection set up and communication.  NOTE: this stuff
 *  was developed on a local network, and through lack of time, NO error
 *  detection/correction has been implemented.  For more information in
 *  this area, have a look at the Quake 2 specs and the various pieces of
 *  Quake 2 bot code for more information.  The error routine is more or
 * less the same.
 * ------------------------------------------------------------------------ */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include "qwb.h"
#include "qsock.h"
#include "qpack.h"
#include "qpcodec.h"
#include "qplayer.h"

char *trans_qstr(char *name);
FILE *dl_file = NULL;

/* ------------------------------------------------------------------------- */
void qbot::send_special(char *msg)
{
	qp_out->start_special();
	qp_out->put_string(msg);
	qp_out->send(qrem);
}


/* ------------------------------------------------------------------------- */
void qbot::add_movement(void)
{
int mask, i;

		/* age movement parameters */
	for(i = 0; i < 2; i++)
		memcpy(&move_buf[i], &move_buf[i+1], sizeof(user_move));

	memset(&move_buf[2], 0, sizeof(user_move));

	mask = 0;
	if(tilt != 0)
		{
		mask |= 0x01;
		move_buf[2].tilt = tilt;
		}
	move_buf[2].yaw = yaw;
	if(roll != 0)
		{
		mask |= 0x02;
		move_buf[2].roll = roll;
		}
	if(front != 0)
		{
		mask |= 0x04;
		move_buf[2].front = front;
		}
	if(right != 0)
		{
		mask |= 0x08;
		move_buf[2].right = right;
		}
	if(up != 0)
		{
		mask |= 0x10;
		move_buf[2].up = up;
		}
	if(flag != 0)
		{
		mask |= 0x20;
		move_buf[2].flag = flag;
		}
	if(impulse != 0)
		{
		mask |= 0x40;
		move_buf[2].impulse = impulse;
		}
	mask |= 0x80;
	move_buf[2].load = load;

	move_buf[2].mask = mask;

	qp_out->put_byte(0x03);
	for(i = 0; i < 3; i++)
		{
		mask = move_buf[i].mask;
		qp_out->put_byte(mask);

		if(mask & 0x01) qp_out->put_angle16(move_buf[i].tilt);
		qp_out->put_angle16(move_buf[i].yaw);
		if(mask & 0x02) qp_out->put_angle16(move_buf[i].roll);
		if(mask & 0x04) qp_out->put_byte((char)move_buf[i].front);
		if(mask & 0x08) qp_out->put_byte((char)move_buf[i].right);
		if(mask & 0x10) qp_out->put_byte((char)move_buf[i].up);
		if(mask & 0x20) qp_out->put_byte((char)move_buf[i].flag);
		if(mask & 0x40) qp_out->put_byte((char)move_buf[i].impulse);
		if(mask & 0x80) qp_out->put_byte(move_buf[i].load);
		}

	impulse = 0;
}


/* ------------------------------------------------------------------------- */
void qbot::send_con_command(char *msg, int id, int h1)
{
char buf[80];

	if(id < 1) strcpy(buf, msg);
	else sprintf(buf, msg, id);

	qp_out->start_game_packet(seq_num++, last_rec_seq, h1, hid_bit);
	qp_out->put_byte(0x04);
	qp_out->put_string(buf);
	add_movement();
	qp_out->send(qrem);
}


/* ------------------------------------------------------------------------- */
int qbot::wait_packet(int ti, int rtry)
{
int rlen;
struct timeval tv;
fd_set a;

	while(rtry > 0)
		{
		if(con_state >= CS_CONNECTED)
			{
			qp_out->start_game_packet(seq_num++, last_rec_seq, 0, hid_bit);
			add_movement();
			if(con_state == CS_PLAY)
				{
				qp_out->put_byte(0x05);
				qp_out->put_byte((char)(last_rec_seq & 0xff));
				}
			qp_out->send(qrem);
			}

		FD_ZERO(&a);
		FD_SET(qrem->getFD(), &a);
		tv.tv_sec = ti;
		tv.tv_usec = 0;
		if((select(100, &a, 0, 0, &tv)) < 0) perror("Select");

		if(FD_ISSET(qrem->getFD(), &a))
			{
			qp_in->reset();
			rlen = qrem->receive(qp_in->get_buffer(), qp_in->get_max_size());
			decode_packet(rlen);
			return(1);
			}

		rtry--;
		}

	return(0);
}


/* ------------------------------------------------------------------------- */
int qbot::download_file(char *fname)
{
static char buf[900];

	sprintf(buf, "./qw/%s", fname);
	if((dl_file = fopen(buf, "wb")) == NULL)
		{
		printf("Error creating `%s'\n", buf);
		return 0;
		}

	sprintf(buf, "download %s", fname);
	send_con_command(buf, -1, 1);
	while(dl_file != NULL) wait_packet(1, 5);
	return 1;
}


/* ------------------------------------------------------------------------- */
void qbot::connect_server(char *sname, long port)
{
QFILE *qpf;
static char buf[200];
int i;

	if(qrem == NULL) qrem = new qsock(sname, port);
	if(qp_in == NULL) qp_in = new qpack(10000);
	if(qp_out == NULL) qp_out = new qpack(10000);

	while(con_state <= CS_NCON)
		{
		printf("Trying server...\n");
		sprintf(buf, "connect \"\\noaim\\0\\msg\\1\\rate\\6000\\bottomcolor\\0\\topcolor\\0\\skin\\base\\name\\%s\\spectator\\%d\"\n", bname, spectator);
		send_special(buf);
		wait_packet(5, 1);
		}

	printf("CONNECTED.\n");

	while(con_state <= CS_CONNECTED)
		{
		send_con_command("new", -1, 1);
		wait_packet(1, 5);
		}

	printf("CHECKING SOUNDS...\n");
	while(con_state <= CS_SERVERD)
		{
		send_con_command("soundlist %d", client_id, 1);
		wait_packet(1, 5);
		}

	printf("CHECKING MODELS...\n");
	while(con_state <= CS_SOUND)
		{
		send_con_command("modellist %d", client_id, 1);
		wait_packet(1, 5);
		}

	for(i = 0; i < 2; i++)
		{
		printf("\nLoad map file: `%s'\n", precache_models[1].file);
		if((qpf = qdir.qpopen(precache_models[1].file)) != NULL)
			{
			if(bsp != NULL) delete bsp;
			bsp = new bsp_file(qpf);
			bsp->print_info();
			delete qpf;
			break;
			}
		else
			{
			printf("`%s' not found.  Downloading...\n", precache_models[1].file);
			download_file(precache_models[1].file);
			qdir.add_dir("qw");
			}
		}

	update_table_types();

	while(con_state <= CS_MODEL)
		{
		send_con_command("prespawn %d", client_id, 1);
		if(wait_packet(1, 5))
			{
			while(con_state == CS_MODEL)
				wait_packet(1, 5);
			}
		}

	send_con_command("begin %d", client_id, 1);
	con_state = CS_PLAY;
}


/* ------------------------------------------------------------------------- */
void qbot::bot_talk(char *str)
{
static char buff[300];
char *name, *message, *command = NULL;
int i;

	strcpy(buff, str);
	name = strtok( buff, ":" );
	message = strtok(NULL, " \t\n\0" );

	i = 0;
	while(message && message[i])
		{
		if(!strncmp(message + i, "tb-", 3))
			command = strtok(message + i + 3, " \t\n\0");
		i++;
		}

	if(command)
		{
		if(!strcmp("author", command))
			send_con_command("say \"Author: Tim Ferguson\"", -1, 1);
		else if(!strcmp("fire", command))
			{
			if(bot_flags & 0x01)
				{
				bot_flags &= (~0x01);
				send_con_command("say \"fire off\"", -1, 1);
				}
			else
				{
				bot_flags |= 0x01;
				send_con_command("say \"fire on\"", -1, 1);
				}
			}
		else if(!strcmp("move", command))
			{
			if(bot_flags & 0x02)
				{
				bot_flags &= (~0x02);
				send_con_command("say \"move off\"", -1, 1);
				}
			else
				{
				bot_flags |= 0x02;
				send_con_command("say \"move on\"", -1, 1);
				}
			}
		}
}


/* ------------------------------------------------------------------------- */
void qbot::decode_packet(int len)
{
qplayer *pl;
qentity *ent;
vector tv;
int opcode, eval = 1, i, j, usr, v1, v2, num;
long seq1, seq2, mask1, mask2;
char *str;

	seq1 = qp_in->get_long();
	if(seq1 == -1)		/* special message */
		{
		str = qp_in->get_string();
		if(strcmp(str, "j") == 0)
			{
			con_state = CS_CONNECTED;
			last_rec_seq = 0;
			hid_bit = 0;
			}
		else if(str[0] == 'n')
			{
			printf("%s\n", str+1);
			if(strncmp(str+2, "server is full", 14) == 0) exit(0);
			}
		}
	else
		{
		last_rec_seq = seq2 = qp_in->get_long();
		if((seq1 >> 31) & 0x01) hid_bit = !hid_bit;

		while(eval)
			{
			if(qp_in->get_read_pos() >= len) return;

			opcode = qp_in->get_byte();
			/* printf("<0x%02x>, ", opcode); */

			switch(opcode)
				{
				case 0x02:		/* leave the game */
					printf("<Remote Quit>\n");
					con_state = CS_NCON;
					exit(0);
					break;

				case 0x03:		/* update stat */
					i = qp_in->get_byte();
					player_stats[i] = qp_in->get_byte();
					break;

				case 0x06:		/* Sound */
					mask1 = qp_in->get_short();
					if(mask1 & 0x8000) qp_in->get_byte();	/* volume */
					if(mask1 & 0x4000) qp_in->get_byte();		/* attn */
						/* mask1 & 0x07;	 chan */
						/* (int)((mask1 >> 3) & 0x03ff)); entity */
					qp_in->get_byte();	/* sound num */
					for(i = 0; i < 3; i++) qp_in->get_coord(); /* coords */
					break;

				case 0x08:		/* print */
					printf("[%d]", qp_in->get_byte());
					str = qp_in->get_string();
					bot_talk(str);
					printf("%s", trans_qstr(str));
					break;

				case 0x09:		/* stufftext */
					str = qp_in->get_string();
					if(strncmp("cmd", str, 3) == 0)
						send_con_command(str+4, -1, 1);
					else if(strncmp("fullserverinfo", str, 14) == 0) printf("Server info.\n");
					else if(strcmp("skins\n", str) == 0) con_state = CS_SKINS;
					else if(strcmp("changing\n", str) == 0) printf("Changing Map...\n");
					else if(strcmp("bf\n", str) == 0) printf("FLASH\n");
					else if(strcmp("reconnect\n", str) == 0)
						{
						printf("Reconnecting...\n");
						con_state = CS_CONNECTED;
						connect_server(NULL, 0);
						return;
						}
					else printf("Stufftext: `%s'", str);
					break;

				case 0x0a:		/* set angle */
					qp_in->get_angle(); qp_in->get_angle(); qp_in->get_angle();
					break;

				case 0x0b:		/* server data */
					if(qp_in->get_long() != 25) printf("Warning: WRONG VERSION\n");
					client_id = qp_in->get_long();
					str = qp_in->get_string();		/* DIR */
					user_id = qp_in->get_byte();
					printf("%s\n", qp_in->get_string());
					for(i = 0; i < 42; i++) qp_in->get_byte();
					con_state = CS_SERVERD;
					break;

				case 0x0c:		/* light style */
					qp_in->get_byte(); qp_in->get_string();
					break;

				case 0x0e:		/* update frags */
					usr = qp_in->get_byte();
					players[usr].frags = qp_in->get_short();
					break;

				case 0x10:		/* stop sound */
					qp_in->get_short();
					break;

				case 0x13:		/* damage */
					qp_in->get_byte(); qp_in->get_byte();	/* armor sub, health sub: */
					for(i = 0; i < 3; i++) qp_in->get_coord(); /* from coord */
					break;

				case 0x14:		/* spawn static */
						/* Model index, Frame,  Colormap, Skin */
					qp_in->get_byte(); qp_in->get_byte(); qp_in->get_byte(); qp_in->get_byte();
						/* org(x,y,z), ang(1,2,3) */
					for(i = 0; i < 3; i++)
						{
						qp_in->get_coord();
						qp_in->get_angle();
						}
					break;

				case 0x16:		/* spawn base line */
					v1 = qp_in->get_entity();		/* Entity */
					if(v1 > 449) printf("Error: Invalid entity number: %d.\n", v1);
					ent = &entities[v1];
					ent->spawned = 1;
					ent->visible = 0;

						/* default model index, frame,  colormap,   skin */
					ent->default_index = qp_in->get_byte();
					ent->frame = qp_in->get_byte();
					qp_in->get_byte();
					ent->skin = qp_in->get_byte();
					ent->origin.setx(qp_in->get_coord());
					ent->facing.set_pitch(qp_in->get_angle());
					ent->origin.sety(qp_in->get_coord());
					ent->facing.set_yaw(qp_in->get_angle());
					ent->origin.setz(qp_in->get_coord());
					ent->facing.set_roll(qp_in->get_angle());
					break;

				case 0x17:
					v1 = qp_in->get_byte();		/* entity type */
					switch(v1)
						{
						case 0:
						case 1:
						case 3:
						case 4:
						case 7:
						case 8:
						case 10:
						case 11:
						case 13:
							for(i = 0; i < 3; i++) qp_in->get_coord();	/* origin */
							break;
						case 5:
						case 6:
						case 9:
							qp_in->get_entity();		/* entity that created from */
							for(i = 0; i < 3; i++) qp_in->get_coord();	/* origin */
							for(i = 0; i < 3; i++) qp_in->get_coord();	/* trace endpos */
							break;
						case 2:
						case 12:
							qp_in->get_byte();		/* count */
							for(i = 0; i < 3; i++) qp_in->get_coord();	/* origin */
							break;
						}
					break;

				case 0x1a:		/* center print */
					printf(">>> %s", qp_in->get_string());
					break;

				case 0x1b:		/* killed monster */
					break;

				case 0x1c:		/* found secret */
					break;

				case 0x1d:		/* span static sound */
					for(i = 0; i < 3; i++) qp_in->get_coord();	/* position */
					qp_in->get_byte(); qp_in->get_byte(); qp_in->get_byte();	/* Num, Vol, Attn */
					break;

				case 0x1e:		/* intermission */
					for(i = 0; i < 3; i++) qp_in->get_coord();	/* position */
					for(i = 0; i < 3; i++) qp_in->get_angle();	/* angle */

					printf("\n----------------------------------------------------------\n");
					printf("Intermission: Rankings.\n");
					printf("----------------------------------------------------------\n");
					for(pl = players, i = 0; i < 32; i++, pl++)
						{
						if(pl->text != (char *)0 && pl->text[0] != '\0')
							{
							printf("%2d: %-20s  %3d    [ %3d ]\n",
								i, trans_qstr(pl->name), pl->frags, pl->ping);
							}
						}
					printf("----------------------------------------------------------\n\n");
					break;

				case 0x1f:		/* finale */
					printf(">>> %s", qp_in->get_string());
					break;

				case 0x20:		/* CD track */
					qp_in->get_byte();	/* track number */
					break;

				case 0x21:		/* sell screen */
					break;

				case 0x22:		/* small kick */
					break;

				case 0x23:		/* big kick */
					break;

				case 0x24:		/* update ping */
					usr = qp_in->get_byte();
					players[usr].ping = qp_in->get_short();
					break;

				case 0x25:		/* update enter time */
					usr = qp_in->get_byte();
					players[usr].enter_time = qp_in->get_float();
					break;

				case 0x26:		/* update stat long */
					i = qp_in->get_byte();
					player_stats[i] = qp_in->get_long();
					break;

				case 0x27:		/* muzzle flash */
					qp_in->get_entity();
					break;

				case 0x28:		/* update user info */
					usr = qp_in->get_byte();
					pl = &players[usr];
					if(pl->text != (char *)0) delete pl->text;
					pl->user = qp_in->get_long();
					pl->text = qp_in->get_nstring();
					pl->name = strstr(pl->text, "name\\");
					if(pl->name != NULL)
						{
						pl->name += 5;
						for(i = 0; pl->name[i] != '\\' && pl->name[i] != '\0'; i++);
						pl->name[i] = '\0';
						}
					break;

				case 0x29:		/* download */
					v1 = qp_in->get_ushort();
					v2 = qp_in->get_byte();
					if(v1 == 0xffff && v2 == 0x00)
						{
						printf("Error: File not available for download.\n");
						if(dl_file)
							{
							fclose(dl_file);
							dl_file = NULL;
							}
						}
					else
						{
						for(i = 0; i < v1; i++)
							{
							if(dl_file != NULL) fputc(qp_in->get_byte(), dl_file);
							else qp_in->get_byte();
							}

						printf("Download at %%%d    \r", v2);
						if(v2 != 100)
							{
							send_con_command("nextdl", -1, 1);
							}
						else
							{
							printf("\nDone.\n");
							fclose(dl_file);
							dl_file = NULL;
							}
						fflush(stdout);
						}
					break;

				case 0x2a:		/* player info */
					usr = qp_in->get_byte();
					pl = &players[usr];
					mask1 = qp_in->get_short();
					pl->origin.set(qp_in->get_coord(), qp_in->get_coord(), qp_in->get_coord());
					pl->frame = qp_in->get_byte();
					if(mask1 & 0x0001) /* pl->ping = */ qp_in->get_byte();
					if(mask1 & 0x0002)
						{
						mask2 = qp_in->get_byte();
						if(mask2 & 0x01) pl->pangle.set_pitch(qp_in->get_angle16());
						pl->pangle.set_yaw(qp_in->get_angle16());
						if(mask2 & 0x02) pl->pangle.set_roll(qp_in->get_angle16());
						pl->speed[0] = (mask2 & 0x04 ? qp_in->get_sbyte() : 0);
						pl->speed[1] = (mask2 & 0x08 ? qp_in->get_sbyte() : 0);
						pl->speed[2] = (mask2 & 0x10 ? qp_in->get_sbyte() : 0);
						if(mask2 & 0x20) pl->flags = qp_in->get_byte();
						if(mask2 & 0x40) pl->impulse = qp_in->get_byte();
						if(mask2 & 0x80) pl->load = qp_in->get_byte();
						}
					if(mask1 & 0x0004) pl->cspeed.setx(qp_in->get_coord());
					if(mask1 & 0x0008) pl->cspeed.sety(qp_in->get_coord());
					if(mask1 & 0x0010) pl->cspeed.setz(qp_in->get_coord());
					if(mask1 & 0x0020) pl->model = qp_in->get_byte();
					if(mask1 & 0x0040) qp_in->get_byte();	/* UNK */
					if(mask1 & 0x0080) pl->weapon = qp_in->get_byte();
					if(mask1 & 0x0100) pl->weapon_frame = qp_in->get_byte();
					break;

				case 0x2b:		/* nails */
					v1 = qp_in->get_byte();
					for(i = 0; i < v1; i++)
						{
						for(j = 0; j < 5; j++) qp_in->get_byte();
						qp_in->get_angle();
						}
					break;

				case 0x2c:		/* choke */
#if 0
					printf("Choke: %d\n", qp_in->get_byte());
#else
					qp_in->get_byte();
#endif
					break;

				case 0x2d:		/* model list */
					con_state = CS_MODEL;
					num = 0;
					do {
						if(++num > 255) printf("Error: too many models.\n");
						precache_models[num].file = qp_in->get_nstring();
						} while(*precache_models[num].file != '\0');
					break;

				case 0x2e:		/* sound list */
					con_state = CS_SOUND;
					num = 0;
					do {
						if(++num > 255) printf("Error: too many sounds.\n");
						precache_sounds[num].file = qp_in->get_nstring();
						} while(*precache_sounds[num].file != '\0');
					break;

				case 0x2f:		/* packet entities */
					while((mask1 = qp_in->get_short()))
						{
						ent = &entities[mask1 & 0x01ff];
						ent->spawned = 1;
						mask1 &= 0xfe00;
						if(mask1 & 0x8000) mask1 |= qp_in->get_byte();
						ent->visible = (mask1 & 0x4000 ? 0 : 1);
						if(!ent->visible)
							{
							ent->facing.set(0.0, 0.0, 0.0);
							ent->origin.set(0.0, 0.0, 0.0);
							ent->velocity.set(0.0, 0.0, 0.0);
							}

						tv = ent->origin;
						if(mask1 & 0x0004) ent->default_index = qp_in->get_byte();	/* Model index */
						if(mask1 & 0x2000) ent->frame = qp_in->get_byte();	/* Frame */
						if(mask1 & 0x0008) qp_in->get_byte();	/* Colormap */
						if(mask1 & 0x0010) ent->skin = qp_in->get_byte();	/* Skin */
						if(mask1 & 0x0020) ent->effects = qp_in->get_byte();	/* Effects */
						if(mask1 & 0x0200) tv.setx(qp_in->get_coord());	/* Origin1 */
						if(mask1 & 0x0001) ent->facing.set_pitch(qp_in->get_angle());	/* Angle1 */
						if(mask1 & 0x0400) tv.sety(qp_in->get_coord());	/* Origin2 */
						if(mask1 & 0x1000) ent->facing.set_yaw(qp_in->get_angle());	/* Angle2 */
						if(mask1 & 0x0800) tv.setz(qp_in->get_coord());	/* Origin3 */
						if(mask1 & 0x0002) ent->facing.set_roll(qp_in->get_angle());	/* Angle3 */
						ent->update_origin(tv);
						}
					break;

				case 0x30:		/* delta packets */
					i = qp_in->get_byte();	/* index ?? */
					v2 = 0;
					while((mask1 = qp_in->get_short()))
						{
						v1 = mask1 & 0x01ff;
						ent = &entities[mask1 & 0x01ff];
						ent->spawned = 1;
						mask1 &= 0xfe00;
						if(mask1 & 0x8000) mask1 |= qp_in->get_byte();
						ent->visible = (mask1 & 0x4000 ? 0 : 1);
						if(!ent->visible)
							{
							ent->facing.set(0.0, 0.0, 0.0);
							ent->origin.set(0.0, 0.0, 0.0);
							ent->velocity.set(0.0, 0.0, 0.0);
							}

						tv = ent->origin;
						if(mask1 & 0x0004) ent->default_index = qp_in->get_byte();	/* Model index */
						if(mask1 & 0x2000) ent->frame = qp_in->get_byte();	/* Frame */
						if(mask1 & 0x0008) qp_in->get_byte();	/* Colormap */
						if(mask1 & 0x0010) ent->skin = qp_in->get_byte();	/* Skin */
						if(mask1 & 0x0020) ent->effects = qp_in->get_byte();	/* Effects */
						if(mask1 & 0x0200) tv.setx(qp_in->get_coord());	/* Origin1 */
						if(mask1 & 0x0001) ent->facing.set_pitch(qp_in->get_angle());	/* Angle1 */
						if(mask1 & 0x0400) tv.sety(qp_in->get_coord());	/* Origin2 */
						if(mask1 & 0x1000) ent->facing.set_yaw(qp_in->get_angle());	/* Angle2 */
						if(mask1 & 0x0800) tv.setz(qp_in->get_coord());	/* Origin3 */
						if(mask1 & 0x0002) ent->facing.set_roll(qp_in->get_angle());	/* Angle3 */
						ent->update_origin(tv);

						if(v1 < 32)
							{
							printf("Entity: %d (%s)  ", v1, precache_models[ent->default_index].file);
							v2++;
							}
						}
					if(v2) printf("\n");
					break;

				default:
					printf(">>> 0x%02x\n", opcode);
					eval = 0;
				}
			}
			printf("\n");
		}
}


/* ------------------------------------------------------------------------- */
float qbot::danger_range(qentity *ent)
{
	if(ent == NULL) return 0.0;
	switch(precache_models[ent->default_index].type)
		{
		case ET_P_MISSILE: return 300.0;
		case ET_P_GRENADE: return 200.0;
		case ET_P_NG_NAIL:
		case ET_P_SNG_NAIL: return 80.0;
		}

	return 0.0;
}


/* ------------------------------------------------------------------------- */
void qbot::update_table_types(void)
{
int i;
precache *pc;

	for(i = 1; i < 256; i++)
		{
		pc = &precache_models[i];
		if(*(pc->file) == '\0') break;

		if(!strncmp(pc->file, "progs/g_", 8 ))
			{
			pc->m_type = ET_WEAPON;
			if(!strcmp(pc->file, "progs/g_shot.mdl")) pc->type = ET_W_SSG;
			else if(!strcmp(pc->file, "progs/g_rock.mdl")) pc->type = ET_W_GL;
			else if(!strcmp(pc->file, "progs/g_rock2.mdl")) pc->type = ET_W_RL;
			else if(!strcmp(pc->file, "progs/g_nail.mdl")) pc->type = ET_W_NG;
			else if(!strcmp(pc->file, "progs/g_nail2.mdl")) pc->type = ET_W_SNG;
			else if(!strcmp(pc->file, "progs/g_light.mdl")) pc->type = ET_W_LG;
			}
		else if(!strcmp(pc->file, "progs/missile.mdl"))
			{
			pc->type = ET_P_MISSILE;
			pc->m_type = ET_PROJECTILE;
			}
		else if(!strcmp(pc->file, "progs/grenade.mdl"))
			{
			pc->type = ET_P_GRENADE;
			pc->m_type = ET_PROJECTILE;
			}
		else if(!strcmp( pc->file, "progs/s_spike.mdl"))
			{
			pc->type = ET_P_SNG_NAIL;
			pc->m_type = ET_PROJECTILE;
			}
		else if(!strcmp(pc->file, "progs/spike.mdl"))
			{
			pc->type = ET_P_NG_NAIL;
			pc->m_type = ET_PROJECTILE;
			}
		else if(!strncmp(pc->file, "maps/b_bh", 9))
			{
			pc->m_type = ET_HEALTH;
			if(!strcmp(pc->file, "maps/b_bh100.bsp")) pc->type = ET_H_100;
			else if(!strcmp(pc->file, "maps/b_bh25.bsp")) pc->type = ET_H_25;
			else if(!strcmp(pc->file, "maps/b_bh10.bsp")) pc->type = ET_H_15;
			}
		else if(!strcmp(pc->file, "progs/armor.mdl"))
			{
			pc->m_type = ET_ARMOR;
			pc->type= ET_A_GREEN;
			}
		else if(!strncmp( pc->file, "maps/b", 6 ))
			{
			pc->m_type = ET_AMMO;
			if(!strncmp( pc->file, "maps/b_shell", 12)) pc->type = ET_A_SHELLS;
			else if(!strncmp( pc->file, "maps/b_batt", 11)) pc->type = ET_A_CELLS;
			else if(!strncmp( pc->file, "maps/b_rock", 11)) pc->type = ET_A_ROCKETS;
			else if(!strncmp( pc->file, "maps/b_nail", 11)) pc->type = ET_A_NAILS;
			}
		else if(!strncmp(pc->file, "progs/v_", 8))
			{
			pc->m_type = ET_VIEWMODEL;
			if(!strcmp(pc->file, "progs/v_shot.mdl")) pc->type = ET_V_SG;
			if(!strcmp(pc->file, "progs/v_shot2.mdl")) pc->type = ET_V_SSG;
			if(!strcmp(pc->file, "progs/v_nail.mdl")) pc->type = ET_V_NG;
			if(!strcmp(pc->file, "progs/v_nail2.mdl")) pc->type = ET_V_SNG;
			if(!strcmp(pc->file, "progs/v_light.mdl")) pc->type = ET_V_LG;
			if(!strcmp(pc->file, "progs/v_rock.mdl")) pc->type = ET_V_GL;
			if(!strcmp(pc->file, "progs/v_rock2.mdl")) pc->type = ET_V_RL;
			if(!strcmp(pc->file, "progs/v_axe.mdl")) pc->type = ET_V_AXE;
			}
		else 
			{
			pc->m_type = ET_MISC;
			if(!strncmp(pc->file, "progs/gib", 9)) pc->type = ET_M_BODY;
			else if(!strcmp(pc->file, "progs/h_player.mdl")) pc->type = ET_M_BODY;
			else if(*pc->file=='*') pc->type = ET_M_ENTITY;

			else if(!strcmp(pc->file, "progs/backpack.mdl"))
				{
				pc->type = ET_I_BACKPACK;
				pc->m_type = ET_ITEM;
				}
			else if(!strcmp( pc->file, "progs/quaddama.mdl"))
				{
				pc->type = ET_I_QUAD;
				pc->m_type = ET_ITEM;
				}
			else if(!strcmp(pc->file, "progs/invisibl.mdl"))
				{
				pc->type = ET_I_RING;
				pc->m_type = ET_ITEM;
				}
			else if( !strcmp( pc->file, "progs/invulner.mdl" ))
				{
				pc->type = ET_I_POP;
				pc->m_type = ET_ITEM;
				}
			else if(!strcmp( pc->file, "progs/suit.mdl"))
				{
				pc->type = ET_I_BIOSUIT;
				pc->m_type = ET_ITEM;
				}
			else
				{
				/* printf(" `%s' is unknown\n", pc->file); */
				pc->m_type = 0;
				pc->type = 0;
				}
			}
		}
}

