/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *
 *  Routines to handle angle values.
 * ------------------------------------------------------------------------ */
#include <math.h>
#include <stdio.h>

#include "angle.h"

/* -------------------------------------------------------------------------
 *
 */
vector angle::get_vector(void)
{
float cos_p, y, p;
vector vect;

	y = yaw * (_PI/180);
	p = pitch * (_PI/180);
	cos_p = cos(p);

	vect.setx(cos(y) * cos_p);
	vect.sety(sin(y) * cos_p);
	vect.setz(sin(p));

	return vect;
}


/* -------------------------------------------------------------------------
 *
 */
void angle::get_orientation(vector &front, vector &right, vector &up)
{
float cos_p, sin_p, cos_y, sin_y, cos_r, sin_r;

	cos_p = cos(pitch *  (_PI/180));
	sin_p = sin(pitch *  (_PI/180));
	cos_y = cos(yaw * (_PI/180));
	sin_y = sin(yaw * (_PI/180));
	cos_r = cos(roll * (_PI/180));
	sin_r = sin(roll * (_PI/180));

	front.setx(cos_y * cos_p);
	front.sety(sin_y * cos_p);
	front.setz(sin_p);

	right.setx(sin_y  * cos_r);
	right.sety(-cos_y * cos_r);
	right.setz(sin_r);

	up = right.X(front);
}

