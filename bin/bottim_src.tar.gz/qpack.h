/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _QPACK_H_
#define _QPACK_H_

#include <stdio.h>
#include <memory.h>
#include <string.h>
#include "qsock.h"


#define QP_MAX_PACKET_DATA     4096

class qpack
{
	int size;		/* size of data */
	int max_size;	/* total size of allocated memory in data */
	int read_pos;	/* read pos in data */
	int write_pos;	/* write pos in data */
	char *data;		/* packet data */

	public:
		qpack(int x=QP_MAX_PACKET_DATA);
		~qpack() { delete[] data; }
		unsigned char get_byte(void) { return (unsigned char)data[read_pos++]; }
		char get_sbyte(void) { return (char)data[read_pos++]; }
		short get_short(void);
		unsigned short get_ushort(void);
		long get_long(void);
		float get_angle(void);
		float get_angle16(void);
		float get_coord(void);
		long get_entity(void);
		float get_float(void);
		char *get_nstring(void);
		char *get_string(void);
		void reset() { size = 0; read_pos = write_pos = 0; }

		int get_size() { return size; }
		int get_read_pos() { return read_pos; }
		int get_write_pos() { return write_pos; }
		int get_max_size() { return max_size; }
		char *get_buffer() { return data; }

		void put_byte(unsigned char ch) { data[write_pos++] = ch; size++; }
		void put_short(short val);
		void put_long(long val);
		void put_string(char *str);
		void put_coord(float val);
		void put_angle(float val);
		void put_angle16(float val);
		void start_special(void);
		void start_game_packet(long seq1, long seq2, long h1, long h2);
		int send(qsock * s);
};

#endif

