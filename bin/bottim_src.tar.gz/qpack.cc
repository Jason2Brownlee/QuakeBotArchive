/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  Standard routines for creating a QuakeWorld packet.
 * ------------------------------------------------------------------------ */
#include "qwb.h"
#include "qsock.h"
#include "qpack.h"

/* ------------------------------------------------------------------------- */
qpack::qpack(int x)
{
	data = new char[x];
	size = 0;
	read_pos = write_pos = 0;
	max_size = x;
}


/* ------------------------------------------------------------------------- */
short qpack::get_short(void)
{
short ret;

	ret = get_byte() & 0xff;
	ret |= ((short)get_sbyte() << 8);

	return ret;
}


/* ------------------------------------------------------------------------- */
unsigned short qpack::get_ushort(void)
{
unsigned short ret;

	ret = get_byte() & 0xff;
	ret |= ((get_byte() & 0xff) << 8);

	return ret;
}


/* ------------------------------------------------------------------------- */
long qpack::get_long(void)
{
long ret;

	ret = get_byte();
	ret |= get_byte() << 8;
	ret |= get_byte() << 16;
	ret |= get_byte() << 24;

	return ret;
}


/* ------------------------------------------------------------------------- */
float qpack::get_angle(void)
{
	return (float)get_byte() / 256.0 * 360.0;
}


/* ------------------------------------------------------------------------- */
float qpack::get_angle16(void)
{
	return (float)get_ushort() / 65536.0 * 360.0;
}


/* ------------------------------------------------------------------------- */
float qpack::get_coord(void)
{
	return (float)get_short() * 0.125;
}


/* ------------------------------------------------------------------------- */
long qpack::get_entity(void)
{
	return (long)get_short();
}


/* ------------------------------------------------------------------------- */
float qpack::get_float(void)
{
freorder fr;

#if i80x86
	fr.uc[0] = get_byte();
	fr.uc[1] = get_byte();
	fr.uc[2] = get_byte();
	fr.uc[3] = get_byte();
#else
	fr.uc[3] = get_byte();
	fr.uc[2] = get_byte();
	fr.uc[1] = get_byte();
	fr.uc[0] = get_byte();
#endif

	return fr.fl;
}


/* ------------------------------------------------------------------------- */
char *qpack::get_nstring(void)
{
char *s = new char[1024];
	   
	for(int i = 0; i < 1024-1; i++ )
		if((s[i] = get_byte()) == '\0') break;
	s[1024-1] = '\0';

	return s;
}


/* ------------------------------------------------------------------------- */
char *qpack::get_string(void)
{
static char s[1024];

	for(int i = 0; i < 1024-1; i++ )
		if((s[i] = get_byte()) == '\0') break;
	s[1024-1] = '\0';

	return s;
}


/* ------------------------------------------------------------------------- */
void qpack::put_short(short val)
{
	put_byte(val & 0xFF);
	put_byte((val >> 8) & 0xFF);
}


/* ------------------------------------------------------------------------- */
void qpack::put_long(long val)
{
	put_byte(val & 0xFF);
	put_byte((val >> 8) & 0xFF);
	put_byte((val >> 16) & 0xFF);
	put_byte((val >> 24) & 0xFF);
}


/* ------------------------------------------------------------------------- */
void qpack::put_string(char *str)
{
int i=0;

	do
		{
		put_byte(str[i]);
		} while(str[i++]);
}


/* ------------------------------------------------------------------------- */
void qpack::put_coord(float val)
{
	put_short((int)(val/0.125));
}


/* ------------------------------------------------------------------------- */
void qpack::put_angle(float val)
{
int a;

	a = (int)(val * 256.0 / 360.0);
	a = a % 256;
	put_byte((char)a);
}


/* ------------------------------------------------------------------------- */
void qpack::put_angle16(float val)
{
long a;

	a = (long)(val * 65536.0 / 360.0);
	a = a % 65536;
	put_short((int)(a));
}


/* ------------------------------------------------------------------------- */
void qpack::start_special(void)
{
	reset();
	put_long(-1);
}


/* ------------------------------------------------------------------------- */
void qpack::start_game_packet(long seq1, long seq2, long h1, long h2)
{
	reset();
	put_long((seq1 & 0x7FFFFFFF) | (h1 << 31));
	put_long((seq2 & 0x7FFFFFFF) | (h2 << 31));
}


/* ------------------------------------------------------------------------- */
int qpack::send(qsock * s)
{
	return s->send(data, size);
}

