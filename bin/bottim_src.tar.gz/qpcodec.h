/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  See the .cc file.  This is perhaps the main contribution from this bot.
 * ------------------------------------------------------------------------ */
#ifndef _QPCODEC_H_
#define _QPCODEC_H_

#include "qfile.h"
#include "bspfile.h"
#include "qentity.h"
#include "qplayer.h"
#include "proxy.h"

enum type_cst { CS_NCON, CS_CONNECTED, CS_SERVERD, CS_SOUND, CS_MODEL, CS_SKINS, CS_PLAY };
static int enc_name[] = { 163, 162, 97, 76, 87, 247, 202, 206, 162, 161, 0 };

struct user_move
{
	int mask;
	float roll, tilt, yaw;
	int front, right, up;
	int impulse, flag, load;
};

class qbot
{
	user_move move_buf[3];
	long client_id, user_id;

	public:
		long bot_flags;
		char bname[50];
		int spectator;
		precache precache_models[256], precache_sounds[256];
		qplayer players[32];
		qentity entities[450];
		long player_stats[40];
		qsock *qrem;
		qpack *qp_in, *qp_out;
		proxy *prox;
		qdirectory qdir;
		bsp_file *bsp;

		float tilt, yaw, roll;
		int front, right, up;
		int impulse, flag, load;
		long seq_num, last_rec_seq, hid_bit;
		type_cst con_state;

		qbot()	{ int i;
			for(i = 0; i < 3; i++) move_buf[i].mask = 0;
			tilt = yaw = roll = 0;
			front = right = up = impulse = flag = load = 0;
			seq_num = last_rec_seq = hid_bit = 0;
			con_state = CS_NCON; qrem = NULL; qp_in = qp_out = NULL; bsp = NULL;
			for(i = 0; i < enc_name[i] != 0; i++) bname[i] = enc_name[i] ^ 0x23;
			bname[i] = '\0';
			spectator = 0;
			for(i = 0; i < 40; i++) player_stats[i] = 0;
			bot_flags = 0xff;
			}

		int uid() { return user_id; }

		void send_special(char *msg);
		void add_movement(void);
		void send_con_command(char *msg, int id, int h1);
		int wait_packet(int ti, int rtry);
		void connect_server(char *sname, long port);
		void fd_set_rem(fd_set *set) { FD_SET(qrem->getFD(), set); }
		int fd_isset_rem(fd_set *set) { return(FD_ISSET(qrem->getFD(), set)); }
		void bot_talk(char *str);
		int download_file(char *fname);
		void decode_packet(int len);
		float danger_range(qentity *ent);
		void update_table_types(void);
		int is_dead(qplayer *pls) { return(precache_models[pls->model].type == ET_M_BODY ||
					(pls->frame >= 48 && pls->frame < 103)); }
		int is_player(qplayer *pls) { return(pls->text != (char *)0 &&
			pls->text[0] != '\0'); }
		int player_in_range(qplayer *pls) { return(pls->origin.getx() != 0.0
			&& pls->origin.gety() != 0.0 && pls->origin.getz() != 0.0); }
};

#endif

