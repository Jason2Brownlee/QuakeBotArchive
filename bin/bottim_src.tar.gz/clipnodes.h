/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _CLIPNODE_H_
#define _CLIPBODE_H_

#include "qfile.h"
#include "vector.h"

class bsp_clipnode
{
	long plane_id;
	short front, back;

	public:
		bsp_clipnode(QFILE *qf) { read(qf); }
		void read(QFILE *qf) { plane_id = qf->get_long();
			front = qf->get_short(); back = qf->get_short(); }
		void write(QFILE *qf) { qf->put_long(plane_id);
			qf->put_short(front); qf->put_short(back); }
		int get_plane_id(void) { return plane_id; }
		short get_front(void) { return front; }
		short get_back(void) { return back; }
		void print() { printf("%ld %d %d\n", plane_id, front, back); }
};


class bsp_clipnodes
{
	bsp_clipnode ** clipnodes;
	int loaded_clipnodes;
	
	public:
		bsp_clipnodes(QFILE *qf, int n) { clipnodes = new bsp_clipnode* [ n ];
			for(int i = 0; i < n; i++) clipnodes[i] = 0; loaded_clipnodes=0;
			read(qf, n); }
		~bsp_clipnodes(void) { for(int i = 0; i < loaded_clipnodes; i++)
			delete clipnodes[i]; delete clipnodes; }
	
		void read(QFILE *qf, int n) { for(int i = 0; i < n; i++)
			clipnodes[i] = new bsp_clipnode(qf); loaded_clipnodes = n; }
		void write(QFILE *qf) { for(int i = 0; i < loaded_clipnodes; i++) clipnodes[i]->write(qf); }
		bsp_clipnode *get_clipnode(int x) { return(x >= 0 && x < loaded_clipnodes ? clipnodes[x] : (bsp_clipnode *)NULL); }
		int get_num() { return loaded_clipnodes; }
		void print(void) { for(int i = 0; i < loaded_clipnodes; i++) { printf("%d : ", i); clipnodes[i]->print(); } }
};



#endif
