/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------
 *  A set of routines for handling quake pak files, and all other files
 *  placed in a directory.  Builds a directory tree for use by read/write
 *  routines.  Probably over complicates the routines, bit it was fun doing
 *  it :)
 * ------------------------------------------------------------------------ */
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <dirent.h>
#include <stdlib.h>
#include <ctype.h>

#include "qwb.h"
#include "qfile.h"

/* ------------------------------------------------------------------------ */
unsigned int read_word(FILE *fp)
{
unsigned int ret;

	ret  = (unsigned int)(fgetc(fp) & 0xff);
	ret |= (unsigned int)(fgetc(fp) & 0xff) << 8;
	return(ret);
}


/* ------------------------------------------------------------------------ */
unsigned long read_long(FILE *fp)
{
unsigned long ret;

	ret  = (unsigned long)(fgetc(fp) & 0xff);
	ret |= (unsigned long)(fgetc(fp) & 0xff) << 8;
	ret |= (unsigned long)(fgetc(fp) & 0xff) << 16;
	ret |= (unsigned long)(fgetc(fp) & 0xff) << 24;
	return(ret);
}


/* ------------------------------------------------------------------------- */
long QFILE::read(void *ptr, long rd_size, long n)
{
long len;

	len = min(size - file_pos, rd_size * n);
	if(len > 0)
		{
		len = fread(ptr, 1, len, fp);
		file_pos += len;
		}

	return(len);
}


/* ------------------------------------------------------------------------- */
int QFILE::seek(long sk_offset, int whence)
{
	switch(whence)
		{
		case SEEK_SET: file_pos = sk_offset; break;
		case SEEK_CUR: file_pos += sk_offset; break;
		case SEEK_END: file_pos = size - sk_offset; break;
		}

	return(fseek(fp, start + file_pos, SEEK_SET));
}


/* ------------------------------------------------------------------------- */
int QFILE::get_byte(void)
{
int val = EOF;

	if(file_pos < size)
		{
		val = getc(fp);
		file_pos++;
		}

	return(val);
}


/* ------------------------------------------------------------------------- */
short QFILE::get_short(void)
{
short ret;

	ret = get_byte();
	ret |= get_byte() << 8;

	return ret;
}


/* ------------------------------------------------------------------------- */
unsigned short QFILE::get_ushort(void)
{
unsigned short ret;

	ret = (unsigned char)get_byte();
	ret |= (unsigned char)get_byte() << 8;

	return ret;
}


/* ------------------------------------------------------------------------- */
long QFILE::get_long(void)
{
long ret;

	ret = get_byte();
	ret |= get_byte() << 8;
	ret |= get_byte() << 16;
	ret |= get_byte() << 24;

	return ret;
}


/* ------------------------------------------------------------------------- */
unsigned long QFILE::get_ulong(void)
{
unsigned long ret;

	ret = (unsigned char)get_byte();
	ret |= (unsigned char)get_byte() << 8;
	ret |= (unsigned char)get_byte() << 16;
	ret |= (unsigned char)get_byte() << 24;

	return ret;
}


/* ------------------------------------------------------------------------- */
float QFILE::get_float(void)
{
freorder fr;

#if i80x86
	fr.uc[0] = get_byte();
	fr.uc[1] = get_byte();
	fr.uc[2] = get_byte();
	fr.uc[3] = get_byte();
#else
	fr.uc[3] = get_byte();
	fr.uc[2] = get_byte();
	fr.uc[1] = get_byte();
	fr.uc[0] = get_byte();
#endif

	return fr.fl;
}


/* ------------------------------------------------------------------------- */
void QFILE::write(void *ptr, long wr_size, long n)
{
	fwrite(ptr, wr_size, n, fp);
	file_pos += wr_size * n;
}


/* ------------------------------------------------------------------------- */
void QFILE::put_byte(int val)
{
	putc(val, fp);
	file_pos++;
}


/* ------------------------------------------------------------------------- */
void QFILE::put_short(short val)
{
	put_byte(val & 0xFF);
	put_byte((val >> 8) & 0xFF);

}


/* ------------------------------------------------------------------------- */
void QFILE::put_long(long val)
{
	put_byte(val & 0xFF);
	put_byte((val >> 8) & 0xFF);
	put_byte((val >> 16) & 0xFF);
	put_byte((val >> 24) & 0xFF);
}


/* ------------------------------------------------------------------------- */
void QFILE::put_float(float val)
{
freorder fr;

	fr.fl = val;

#if i80x86
	put_byte(fr.uc[0]);
	put_byte(fr.uc[1]);
	put_byte(fr.uc[2]);
	put_byte(fr.uc[3]);
#else
	put_byte(fr.uc[3]);
	put_byte(fr.uc[2]);
	put_byte(fr.uc[1]);
	put_byte(fr.uc[0]);
#endif
}


/* ------------------------------------------------------------------------- */
QFILE *qdirectory::qpopen(char *fname)
{
qdirent *td;
QFILE *qpf;

	if((td = find_file(fname, cwd)) == NULL) return NULL;
	if((qpf = new QFILE(td->get_offset(), td->get_size(), td->get_root_file())) == NULL) return NULL;
	if(qpf->get_fp() == NULL)
		{
		printf("Error opening `%s'\n", td->get_root_file());
		return NULL;
		}

	qpf->rewind();
	return qpf;
}


/* ------------------------------------------------------------------------- */
qdirent *qdirectory::find_file(char *fname, qdirent *dir)
{
static char buf[20];
int i;

	for(i = 0; fname[i] != '/' && fname[i] != '\0'; i++) buf[i] = tolower(fname[i]);
	buf[i] = '\0';

	if(buf[0] == '\0') dir = &root;
	else if(!strcmp(buf, "..")) dir = dir->get_parent();
	else
		{
		if((dir = find_ent(buf, dir->get_dir())) == NULL) return NULL;
		if(dir->get_type() != QDT_DIR) return dir;
		}

	if(fname[i] == '/') return find_file(fname + i + 1, dir);
	return dir;
}


/* ------------------------------------------------------------------------- */
int qdirectory::mknode(char *fname, long size, long offset, qfile_ent *qf, qdirent *dir)
{
qdirent *td;
static char buf[200];
int i;

	for(i = 0; fname[i] != '/' && fname[i] != '\0'; i++) buf[i] = tolower(fname[i]);
	buf[i] = '\0';

	if(fname[i] == '/')		/* directory */
		{
		if(buf[0] == '\0') td = &root;
		else if((td = find_ent(buf, dir->get_dir())) == NULL)
			{
			td = new qdirent(buf, dir);	/* add a directory */
			td->add(dir);
			}
		mknode(fname + i + 1, size, offset, qf, td);
		}
	else
		{
		if((td = find_ent(buf, dir->get_dir())) == NULL)
			(new qdirent(buf, offset, size, qf))->add(dir);		/* add a file */
		else
			td->change(buf, offset, size, qf);
		}

	return 1;
}


/* ------------------------------------------------------------------------- */
int qdirectory::chdir(char *fname)
{
qdirent *td;

	if((td = find_file(fname, cwd)) == NULL || td->get_type() != QDT_DIR)
		return 0;

	cwd = td;
	return 1;
}


/* ------------------------------------------------------------------------- */
void qdirectory::rdir(qdirent *qd, int depth)
{
int i;

	qd = qd->get_dir();
	while(qd != NULL)
		{
		for(i = 0; i < depth; i++) printf("  ");
		qd->print();
		if(qd->get_type() == QDT_DIR) rdir(qd, depth + 1);
		qd = qd->get_next();
		}
}


/* ------------------------------------------------------------------------- */
int qdirectory::add_qpack_dir(char *fname, qfile_ent *qf)
{
unsigned long diroffset, offset, size;
int num_dirent, fname_len = 56;
char buf[150];
FILE *fp;
int i;

	if((fp = fopen(fname, "rb")) == NULL)
		{
		printf("Error opening pack file `%s'\n", fname);
		return 0;
		}

	fread(buf, sizeof(char), 4, fp);
	if(strncmp(buf, "PACK", 4) != 0)
		{
		if(strncmp(buf, "SPAK", 4) != 0)
			{
			printf("Error: `%s' is not a pack or spak file.\n", fname);
			return 0;
			}
		else fname_len = 120;
		}

	diroffset = read_long(fp);
	num_dirent = read_long(fp)/(fname_len + 8);

	fseek(fp, diroffset, SEEK_SET);
	for(i = 0; i < num_dirent; i++)
		{
		fread(buf, sizeof(char), fname_len, fp);
		offset = read_long(fp);
		size = read_long(fp);
		mknode(buf, size, offset, qf, &root);
		}

	fclose(fp);
	return(1);
}


/* ------------------------------------------------------------------------- */
int qdirectory::recurse_disk_dir(char *dir_name)
{
static char fname_buf[200];
static struct stat st;
DIR *dirp;
struct dirent *dp;
char *nfname;

	if((dirp = opendir(dir_name)) == NULL) return 0;
	while((dp = readdir(dirp)) != NULL)
		{
		if(strcmp(dp->d_name, ".") == 0 || strcmp(dp->d_name, "..") == 0)
			continue;

		if(dir_name[strlen(dir_name)-1] != '/')
			sprintf(fname_buf, "%s/%s", dir_name, dp->d_name);		/* insert a / */
		else
			sprintf(fname_buf, "%s%s", dir_name, dp->d_name);
		lstat(fname_buf, &st);
		if(!(st.st_mode & S_IFDIR)) add_disk_file(fname_buf, st.st_size);
		else
			{
			nfname = strdup(fname_buf);
			recurse_disk_dir(nfname);
			free(nfname);
			}
		}

	closedir(dirp);
	return 1;
}


/* ------------------------------------------------------------------------- */
int qdirectory::add_dir(char *dir_name)
{
qfile_ent *qf_bottom, *qf;
char *tp;

	qf_bottom = disk_files;
	if(!recurse_disk_dir(dir_name)) return 0;

		/* read all pack files directories first */
	for(qf = disk_files; qf != qf_bottom; qf = qf->get_next())
		{
		if((tp = strrchr(qf->get_fname(), '.')) != NULL)
			if(strcasecmp(tp + 1, "pak") == 0 || strcasecmp(tp + 1, "sin") == 0)
				add_qpack_dir(qf->get_fname(), qf);
		}

		/* overlay real files */
	for(qf = disk_files; qf != qf_bottom; qf = qf->get_next())
		{
		if((tp = strrchr(qf->get_fname(), '.')) != NULL)
			if(strcasecmp(tp + 1, "pak") == 0 || strcasecmp(tp + 1, "sin") == 0)
				continue;
		mknode(qf->get_fname() + strlen(dir_name), qf->get_size(), 0, qf, &root);
		}

	return 1;
}

