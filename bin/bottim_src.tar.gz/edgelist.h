/* ------------------------------------------------------------------------
 *  This file is part of the BotTim project (c) Tim Ferguson, 1997-99.
 *  It is a client side bot for use on Id Software's QuakeWorld servers.
 *
 *  The code is based on, or a modified version of source by Mike Warren of
 *  the mikeBot project: http://www.planetquake.com/mikebot
 *
 *    This code is copyright 1997 Tim Ferguson. You may not distribute it,
 *  sell it or in any way make money off it without the written consent of
 *  the author.
 * 
 *  Web    http://www.dgs.monash.edu.au/~timf/bottim/
 *  Email  timf@dgs.monash.edu.au
 * ------------------------------------------------------------------------ */
#ifndef _EDGELIST_H_
#define _EDGELIST_H_


#include "qfile.h"


class bsp_edgelists
{
	long *edgelists;
	int loaded_edgelists;

	public:
		bsp_edgelists(QFILE *qf, int n) { edgelists = new long[n];
			loaded_edgelists = 0; read(qf, n); }
		~bsp_edgelists(){ delete edgelists; }

		void read(QFILE *qf, int n) { for(int i = 0; i < n; i++)
			edgelists[i] = qf->get_long(); loaded_edgelists = n; }
		void write(QFILE *qf) { for(int i = 0; i < loaded_edgelists; i++) qf->put_long(edgelists[i]); }
		int get_edge_list(int x) { return(x >= 0 && x < loaded_edgelists ? edgelists[x] : 0); }
		int get_num() { return loaded_edgelists; }
		void print() { for(int i = 0; i < loaded_edgelists; i++) printf("%d : %ld\n", i, edgelists[i]); }
};

#endif

