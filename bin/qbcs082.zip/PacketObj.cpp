#include "PacketObj.h"


void PacketObj::Reset() {

	OutputOffset = 8;
	OutputLength = 8;
	InputPacket = InputBuffer;
	OutputPacket = OutputBuffer;

}
	
void PacketObj::ResetPacket() {

	InputOffset = 8;
	OutputOffset = 8;
	InputLength = 8;
	OutputLength = 8;
	
	for(i=0; i <= SEQUENCE_MAX; i++) {
		OutgoingPacketSequence[i] = 0;
		IncomingPacketSequence[i] = 0;
	}

	IncomingRejected = 0;

	InputBuffer = Socket.InputBuffer;
	OutputBuffer = Socket.OutputBuffer;
	InputPacket = InputBuffer;
	OutputPacket = OutputBuffer;

}

PacketObj::PacketObj() {

	ResetPacket();

}

int PacketObj::GetMessage(){

	int PacketType;
	InputPacket = InputBuffer; // Reset start of buffer
	InputLength = Socket.GetPacket();
	if(InputLength <= 0)
		return 0;
	PacketType = GetInputHeader();
	switch(PacketType){
	case MESSAGE_TYPE_CONTROL: // If a control packet, no sequence
	case MESSAGE_TYPE_CLIENT: // If a client packet, no sequence
		InputOffset = 4;
		return InputLength;
		break;
	case MESSAGE_TYPE_ACK: // Don't care about sequence 
		InputOffset = 4;
		return InputLength;
		break;
	case MESSAGE_TYPE_UPDATE:
		PacketType = SEQUENCE_UPDATE;
//		printf("*************************** Sequence %d\n", GetPacketSequence());
		break;
	case MESSAGE_TYPE_FINAL:
	case MESSAGE_TYPE_PARTIAL:
		PacketType = SEQUENCE_FINAL;
		OutgoingPacketSequence[SEQUENCE_ACK] = GetPacketSequence();
		SendAck();
		break;
	default:
		printf("*****************Unknown Packet Type!!!!!!\n");
		SendAck();
		break;
	}
	if(GetPacketSequence() < IncomingPacketSequence[PacketType]) {
		printf("Old Sequence!!! Type %d, Got %d, Expected %d\n", PacketType, GetPacketSequence(), IncomingPacketSequence[PacketType]);
		IncomingRejected++;
		InputLength = 0;
	} else
		IncomingPacketSequence[PacketType]++;

	InputOffset = 8;
	return InputLength;
}

void PacketObj::SendMessage(){
	
	int i;

	int MessageType = GetOutputHeader();

	switch(MessageType) {
	case MESSAGE_TYPE_CONTROL:
	case MESSAGE_TYPE_CLIENT:

		OutputLength -= 4;
		SetOutputLength(OutputLength);
		for(i=0;i<=3;i++)
			OutputBuffer[i+4] = OutputBuffer[i];
		Socket.SendPacket(&OutputBuffer[4], OutputLength);
		OutputPacket = &OutputBuffer[4];
		break;

	case MESSAGE_TYPE_UPDATE: // Runtime Packets
		SetOutputLength(OutputLength);
		SetPacketSequence(OutgoingPacketSequence[SEQUENCE_UPDATE]++);
		Socket.SendPacket(OutputBuffer, OutputLength);
		OutputPacket = OutputBuffer;
		break;
	
	case MESSAGE_TYPE_FINAL:
	case MESSAGE_TYPE_PARTIAL:
		SetOutputLength(OutputLength);
		SetPacketSequence(OutgoingPacketSequence[SEQUENCE_FINAL]++);
		Socket.SendPacket(OutputBuffer, OutputLength);
		OutputPacket = OutputBuffer;
		break;
		
	case MESSAGE_TYPE_ACK:
		SetOutputLength(OutputLength);
//		printf("\n*************************Ack Sequence is %d\n", OutgoingPacketSequence[SEQUENCE_ACK]); 
		SetPacketSequence(OutgoingPacketSequence[SEQUENCE_ACK]++);
		Socket.SendPacket(OutputBuffer, OutputLength);
		OutputPacket = OutputBuffer;
		break;
	
	default:
		printf("Message Type Not Defined!!!!! Aborting Send\n");
		return;
	}
	

}

long PacketObj::NLong(long Data) {  // reverses byte order of long

	long Temp;
	char *Source, *Dest;

	Source = (char *)&Data;
	Dest = (char *)&Temp;

	Dest[0] = Source[3];
	Dest[1] = Source[2];
	Dest[2] = Source[1];
	Dest[3] = Source[0];

	return Temp;
	
}

short PacketObj::NShort(short Data) {  // reverses byte order of short

	short Temp;
	char *Source, *Dest;

	Source = (char *)&Data;
	Dest = (char *)&Temp;

	Dest[0] = Source[1];
	Dest[1] = Source[0];

	return Temp;
	
}

void PacketObj::HexDump(int Buffer, int DisplayLength){

	int i;
	int Length, CheckSum = 0;
	char *Packet;
	
	if (Buffer == HEXDUMP_INPUT_BUFFER){
		printf("***** Dumping Input Buffer...");
		Packet = InputPacket;
		Length = InputLength;
	} else if (Buffer == HEXDUMP_OUTPUT_BUFFER) {
		printf("***** Dumping Output Buffer...");
		Packet = OutputPacket;
		Length = OutputLength;
	} else {
		printf("******Invalid Buffer Option***********\n");
		return;
	}
	
	for(i=0; i<Length;i++)
		CheckSum += (unsigned char)Packet[i];

	printf("Length: 0x%lx, CheckSum = 0x%lx\n", Length, CheckSum);
	

	if(DisplayLength >= Length) {
		DisplayLength = Length;
	}

	for(i=0; i<DisplayLength;i++) {
		if((i % 16) == 0)
			printf("\n%04X: ", i);
		printf("%02X ", (unsigned char)Packet[i]);
	}

	printf("\n");

}


void PacketObj::HexDump(int Buffer){
	int Length;
	
	if (Buffer == HEXDUMP_INPUT_BUFFER){
		Length = InputLength;
	} else if (Buffer == HEXDUMP_OUTPUT_BUFFER) {
		Length = OutputLength;
	}
	
	HexDump(Buffer, Length);
}

// ******************************
//
//    Sends an acknowledgement.  Sequence number are automatically
//		Take care of.
//
// ******************************

void PacketObj::SendAck() {
		
	Reset();
	SetHeader(MESSAGE_TYPE_ACK);
	SendMessage();

}

unsigned char PacketObj::End() {
	int MessageType;
	if(InputOffset >= InputLength) {
		if(GetInputHeader() == MESSAGE_TYPE_PARTIAL) {
//				printf("Partial Message, getting more....\n");
			do {
				GetMessage();
				MessageType = GetInputHeader();
			} while(MessageType != MESSAGE_TYPE_FINAL && MessageType != MESSAGE_TYPE_PARTIAL);
			return 0;
		} else
			return 1;
	} else
		return 0;
}

// Primary Read routine. Does packet appending to form complete packets

unsigned char PacketObj::ReadByte(){

	unsigned char Temp = 0;
	
	if(!End()) {  // This will check for end of packet and read in another
					// if neccessary
		Temp = (unsigned char)InputBuffer[InputOffset]; 
		InputOffset += 1;
		return Temp;

	} else {
		printf("No data to read. Exiting\n");
		exit(2);

		return Temp; // This is cause the compiler is stupid
	}

}

char PacketObj::ReadChar(){

	return (char) ReadByte();
}

float PacketObj::ReadAngle() {

	unsigned char TempData;
	
	TempData = ReadByte();
 

	if(TempData != 0 && TempData != 64 && TempData != 128 && TempData != 192 ){
		if(TempData < 128)
			TempData++;
		else
			TempData--;
	}

//	return (float)TempData;	
	return (float) ((TempData / 256.0f) * 360.0f);
}

float PacketObj::ReadCoord() {

	return (float) ReadShort() * (float)0.125;
}


short PacketObj::ReadShort(){

	unsigned char Temp[2];
	short *Value;
	int i;

	Value = (short *)Temp;
	for(i = 0; i < 2; i++){
		Temp[i] = ReadByte(); 
	}

	return *Value;

}

short PacketObj::ReadNShort(){

	return NShort(ReadShort());

}

long PacketObj::ReadLong() {

	int i;
	unsigned char Temp[4];
	long *Value;

	Value = (long *)Temp;
	
	for(i = 0; i < 4; i++){
		Temp[i] = ReadByte(); 
	}

	return (long) *Value;

}


long PacketObj::ReadNLong() {

	return NLong(ReadLong());
}


float PacketObj::ReadNFloat() {
	
	unsigned char *Temp;
	float Data;
	int x;

	Temp = (unsigned char *)&Data; 
	for(x = 3; x >= 0; x--)
		Temp[x] = ReadByte();

	return Data;
}

float PacketObj::ReadFloat() {
	
	unsigned char *Temp;
	float Data;
	int x;

	Temp = (unsigned char *)&Data; 
	for(x = 0; x < 4; x++)
		Temp[x] = ReadByte();

	return Data;
}

char *PacketObj::ReadString() { // This routine reads chars upto quake max of 0x0800
	
	int i;
	for(i=0; i<0x7ff; i++) {
		StringBuffer[i] = ReadChar();
		if(StringBuffer[i] == '\0')
			break;
	}

	StringBuffer[i] = '\0';  // stirng at max, terminate result

	return StringBuffer;
}


// These routines save to the output packet buffer

void PacketObj::SaveString(char *Data) {

	int TempInt;
	
	if(Data == NULL)
		printf("SaveString: Argument is a NULL!!!\n");
	
	TempInt = 0;
	while(Data[TempInt] != '\0')
		SaveChar(Data[TempInt++]);

	SaveChar('\0');

}

void PacketObj::SaveChar(char Data){

	SaveByte((unsigned char)Data);

}

void PacketObj::SaveByte(unsigned char Data){
	
	int TempHeader;

	if(OutputLength >= MaxOutputData){
//		printf("---------------- Sending Partial Packet----------\n");
		TempHeader = GetOutputHeader();
		SetHeader(MESSAGE_TYPE_PARTIAL);
		SendMessage();
		Reset();
		SetHeader(TempHeader);
	}
	
	OutputBuffer[OutputLength++] = (char) Data; 
}

void PacketObj::SaveAngle(float Data){
	
//	SaveByte((unsigned char) Data);
	if(Data != 0)
		SaveByte((unsigned char) (((Data/ 360.0f) * 254.0f) + 1.0f));
	else
		SaveByte(1);
}

void PacketObj::SaveCoord(float Data) {

	SaveShort((short)(Data/(float)0.125));

}

void PacketObj::SaveShort(short Data){

	unsigned char *Temp;
	int x;

	
	Temp = (unsigned char *)&Data; 
	for(x = 0; x < 2; x++)
		SaveByte(Temp[x]);

}

void PacketObj::SaveLong(long Data) {

	unsigned char *Temp;
	int x;

	Temp = (unsigned char *)&Data; 
	for(x = 0; x < 4; x++)
		SaveByte(Temp[x]);

}


void PacketObj::SaveNLong(long Data) {

	SaveLong(NLong(Data));
}

void PacketObj::SaveFloat(float Data) {

	unsigned char *Temp;
	int x;

	Temp = (unsigned char *)&Data; 
	for(x = 0; x < 4; x++)
		SaveByte(Temp[x]);

}

void PacketObj::SaveNFloat(float Data) {

	unsigned char *Temp;
	int x;

	Temp = (unsigned char *)&Data; 
	for(x = 3; x >= 0; x--)
		SaveByte(Temp[x]);

}

void PacketObj::SetHeader(int Type) {

	switch(Type){
	case MESSAGE_TYPE_ACK:
		OutputBuffer[0] = 0x00;
		OutputBuffer[1] = 0x02;
		break;
	case MESSAGE_TYPE_CONTROL:
		OutputBuffer[0] = (char)0x80;
		OutputBuffer[1] = 0x00;
		break;
	case MESSAGE_TYPE_UPDATE:
		OutputBuffer[0] = 0x00;
		OutputBuffer[1] = 0x10;
		break;
	case MESSAGE_TYPE_PARTIAL:
		OutputBuffer[0] = 0x00;
		OutputBuffer[1] = 0x01;
		break;
	case MESSAGE_TYPE_FINAL:
		OutputBuffer[0] = 0x00;
		OutputBuffer[1] = 0x09;
		break;
	case MESSAGE_TYPE_CLIENT:
		OutputBuffer[0] = (char)0xC0;
		OutputBuffer[1] = 0x00;
		break;
	default:
		printf("Invalid Type!!!\n");
	}
}

int PacketObj::GetInputHeader() {

	return GetHeader((unsigned char *)InputBuffer);

}

int PacketObj::GetOutputHeader() {

	return GetHeader((unsigned char *)OutputBuffer);

}

int PacketObj::GetHeader(unsigned char *LocalBuffer) {


	if(LocalBuffer[0] == 0x00 && LocalBuffer[1] == 0x02)
		return	MESSAGE_TYPE_ACK;
	else
		if(LocalBuffer[0] == (unsigned char)0x80 && LocalBuffer[1] == 0x00)
			return MESSAGE_TYPE_CONTROL;
		else
			if(LocalBuffer[0] == 0x00 && LocalBuffer[1] == 0x10)
				return MESSAGE_TYPE_UPDATE;
			else
				if(LocalBuffer[0] == 0x00 && LocalBuffer[1] == 0x01)
					return MESSAGE_TYPE_PARTIAL;
				else
					if(LocalBuffer[0] == 0x00 && LocalBuffer[1] == 0x09)
						return MESSAGE_TYPE_FINAL;
					else
						if(LocalBuffer[0] == 0xC0 && LocalBuffer[1] == 0x00)
							return MESSAGE_TYPE_CLIENT;
						else
							return MESSAGE_TYPE_UNDEFINED;

}


void PacketObj::SetOutputLength(short Data) {
	int Temp;
	Temp = OutputLength; // Save the length for offset change
	OutputLength = 2;
	SaveShort(NShort(Data));
	OutputLength = Temp; // Restore Proper Length
}

void PacketObj::SetPacketSequence(long Data) {
	int Temp;
	Temp = OutputLength;
	OutputLength = 4;
	SaveNLong(Data);
	OutputLength = Temp;
}

long PacketObj::GetPacketSequence() {
	int Temp, Sequence;

	Temp = InputOffset;
	InputOffset = 4;
	Sequence = ReadNLong();
	InputOffset = Temp;

	return Sequence;

}
