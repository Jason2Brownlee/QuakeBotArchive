#include "ServerObj.h"

// ***********************************************************
// *
// *  Decodes the server Connection Accepted Packet
// *
// ***********************************************************


void ServerObj::DecodeAccept() {

	//struct ServerConnect Response {
    //    struct Header;                        // { 0x80, 0x00, 0x00, 0x09 }
    //    char OP_Code;							// 0x81 This is CCREP_ACCEPT 
    //    int Port								// This is your port assigned
    //											// by the server
    //    char Unknown[ 2] = {0x00, 0x00 };		// The packet header shows these two byte
                                                // to be valid data, I dunno what, tho.
	//};

	// if connection is successfull, server will return a new port for
	// init and runtime.  This takes care of that.

	EventTable->Print("Connection Accepted\n");
//	time(&ClientStartTime); // Record start of game
	GetServerStartTime = True;
	ServerPacket.Socket.RemotePort = ServerPacket.ReadShort();
	Connected = True;

	GameMode = 0;
	ServerMode = smGameInit;
	Data->ResetGameVariables();


}

// ***********************************************************
// *
// *  Decodes the server Connection Rejected Packet
// *
// ***********************************************************

void ServerObj::DecodeReject() {

	EventTable->Print("Connection Rejected: %s\n", ServerPacket.ReadString());
	Connected = False;

	// Delete old callback
	EventTable->DeleteCallback(SocketEventID);

	ServerPacket.Socket.ResetSocket();
	ServerPacket.ResetPacket();
	
	SocketMode = skIdle;
	ServerMode = smIdle;
}

// ***********************************************************
// *
// *  Decodes the server Query Response Packet
// *
// ***********************************************************


void ServerObj::DecodeQuery() {

	// printf out various specs

	Data->SetServerIP(ServerPacket.ReadString());
	Data->SetServerName(ServerPacket.ReadString());
	Data->SetMapName(ServerPacket.ReadString());

	Data->NumberOfPlayers = ServerPacket.ReadChar();
	Data->MaxPlayers = ServerPacket.ReadChar(); 

	Data->ProtocolVersion = ServerPacket.ReadChar();
	if(Data->ProtocolVersion != 0x03){
		EventTable->Print("Unknown protocol version(%H)!!!!!\n",(int) Data->ProtocolVersion);
		exit(1);
	}

	EventTable->Print("Address: %s, Name: %s, Map: %s\n", Data->ServerIP, Data->ServerName, Data->MapName);
	EventTable->Print("Players: %u, Max: %u\n", Data->NumberOfPlayers, Data->MaxPlayers);
	ServerMode = smGetRules;
}

// ***********************************************************
// *
// *  Decodes the server Rule Response Packet
// *
// ***********************************************************

void ServerObj::DecodeRule() {

	char Rule[0x7f], Value[0x7f];

	if(!ServerPacket.End()){ // When a 5 byte packet comes, no more data

		strcpy(Rule, ServerPacket.ReadString());
		strcpy(Value, ServerPacket.ReadString());
		
//		EventTable->Print("%s = %s\n",Rule, Value);

		if(stricmp(Rule, "sv_gravity") == 0)
			Data->sv_gravity = atoi(Value);
		else if (stricmp(Rule, "sv_friction") == 0)
			Data->sv_friction = atoi(Value);
		else if (stricmp(Rule, "sv_maxspeed") == 0)
			Data->sv_maxspeed = atoi(Value);
		else if (stricmp(Rule, "noexit") == 0)
			Data->noexit = atoi(Value);
		else if (stricmp(Rule, "teamplay") == 0)
			Data->teamplay = atoi(Value);
		else if (stricmp(Rule, "timelimit") == 0)
			Data->timelimit = atoi(Value);
		else if (stricmp(Rule, "fraglimit") == 0)
			Data->timelimit = atoi(Value);
		else
			EventTable->Print("Error: Unknown Rule - %s\n", Rule);

		// Get next rule
		ServerPacket.Reset();
		ServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);
		ServerPacket.SaveChar(CCREQ_RULE_INFO);
		ServerPacket.SaveString(Rule);
		ServerPacket.SendMessage();

	} else { // All rules receive, go to next stage
		if((Data->sv_gravity % 2) == 0) {
			ServerMode = smConnect;
			SocketMode = skIdle;  // Received Data
		} else {
			EventTable->Print("Gravity is an odd value.  Connection Terminated\n");
			ServerMode = smIdle;
			SocketMode = skIdle;  // Received Data
		}	

	}
}
// *********************************
// *
// * Sends a Say message to the server
// *
// *********************************

void ServerObj::SendBroadcastMessage(char *Message) {
	
	char Buffer[0x7F];
	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ServerPacket.SaveChar(0x04); 

	sprintf(Buffer, "say \"%s\"", Message);
	ServerPacket.SaveString(Buffer); 

	ServerPacket.SendMessage();

	#ifdef DEBUG	
		EventTable->Print("Message Sent\n");
	#endif

}

// ***********************************************************
// *
// *  Sends a console command to the server
// *
// ***********************************************************


void ServerObj::SendCommand(char *Message) {
	
	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ServerPacket.SaveChar(0x04); 
	ServerPacket.SaveString(Message); 
	ServerPacket.SendMessage();

	#ifdef DEBUG	
		EventTable->Print("Message Sent\n");
	#endif

}

// *********************************
// *
// * Logs off from Quake server
// *
// *********************************

void ServerObj::SendGoodbye() {
	
	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_UPDATE);

	ServerPacket.SaveChar(0x02); 

	ServerPacket.SendMessage();

	#ifdef DEBUG	
		EventTable->Print("Logoff completed\n");
	#endif

}


//***************************
//
//  Sends the name, color etc....
//
//***************************


void ServerObj::SendClientParms() {

//	struct ClientPlayerData {
//        struct Header; // { 0x00, 0x09, 0x00, 0x31}
//        struct Sequence; { 0x00, 0x00, 0x00, 0x02 }
//        char Data = 0x04;      // Could this be something to do with the rule stuff?
//        const char tag1[5] = "name ";
//        char Name[] // ASCII name
//        const char tail1[3] = { 0x0a, 0x00, 0x04};
//        const char tag2[6] = "color ";
//        char fgcolor[] = // ASCII color number
//        const char tag3 = " ";
//        char bgcolor[] = // ASCII color number
//        char tail3[] = {0x0a, 0x00, 0x04, "spawn ", 0x00};
//	};

	
	// For some reason, the strings have 0x0A append in them (linefeed).
	// Mistake?

	char Buffer[0x7f];

	ServerPacket.Reset();
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ServerPacket.SaveChar(0x04);
	sprintf(Buffer, "name %s\x0a", Data->BotName);
	ServerPacket.SaveString(Buffer);
	
	ServerPacket.SaveChar(0x04); 
	sprintf(Buffer, "color %d %d\x0a", Data->BotShirtColor, Data->BotPantColor);
	ServerPacket.SaveString(Buffer);
	
	ServerPacket.SaveChar(0x04); 
	ServerPacket.SaveString("spawn ");
	
	ServerPacket.SendMessage();

}

//*************************
//
//  Sends the begin command
//
//*************************

void ServerObj::SendBegin() {

	// struct ClientBegin {
    //    struct Header; // { 0x00, 0x09, 0x00, 0x0f }
    //    struct Sequence; // {0x00, 0x00, 0x00, 0x03 };
    //    char Data[7] = { 0x04, "begin", 0x00 };
	// };

	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ServerPacket.SaveChar(0x04); 
	ServerPacket.SaveString("begin");

	ServerPacket.SendMessage();

}

//*************************
//
//  Send a NOOP ?
//
//*************************
void ServerObj::SendNoOp() {

	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);
	ServerPacket.SaveChar(0x01);
	ServerPacket.SendMessage();
}

//*************************
//
//  Tell sever that prespawn has finished (psyche!)
//
//*************************
void ServerObj::SendPrespawn() {

	ServerPacket.Reset();	
	ServerPacket.SetHeader(MESSAGE_TYPE_FINAL);
	ServerPacket.SaveChar(0x04);
	ServerPacket.SaveString("prespawn");
	ServerPacket.SendMessage();

}

//*****************************
//
//  This routine performs the handshake for the server
//  Not fully tested on every server type, so could be buggy
//
//*****************************

void ServerObj::GameInit() {
	
	switch(GameMode) {
		//  ASCII Game Parameters
	case 0:

//		EventTable->Print("Receiving ASCII Game Parameters\n");
		break;

	case GAME_STATE_PRESPAWN:

		SendNoOp();
		// Prespawn Packet
		SendPrespawn();
	
		EventTable->Print("Receiving Binary Game Parameters\n");
		break;

	case GAME_STATE_LIGHTING:

		//	Client Parameter Transfer
		SendClientParms();
		break;

	case GAME_STATE_RENDER:

		//	Begin Game Packet
		SendBegin();

		EventTable->Print("Handshake completed\n");
		EventTable->SendMessage(edAI, oeAIOn, (void *)NULL); // Turn on AI
		EventTable->SendMessage(edBroadcast, oeServerOnline, (void *)NULL); // Turn on AI
		SocketMode = skIdle;
		ServerMode = smRuntime;
		break;
	}
}

// ***********************************************************
// *
// *  Determines server packet type
// *
// ***********************************************************

void ServerObj::DecodePacket() {
	
	unsigned char PacketData = ServerPacket.GetInputHeader();
	switch(PacketData) {
	case MESSAGE_TYPE_CONTROL:
		
		PacketData = ServerPacket.ReadChar();
		switch(PacketData) {
		case CCREP_RULE_INFO: // Rule Response
			DecodeRule();
			break;		
		case CCREP_SERVER_INFO: // Query Response
			DecodeQuery();
			SocketMode = skIdle;  // Received Data
			break;
		case CCREP_ACCEPT: // Connect Response
			DecodeAccept();
			SocketMode = skIdle;  // Received Data
			break;
		case CCREP_REJECT: // Reject Response
			DecodeReject();
			SocketMode = skIdle;  // Received Data
			break;		
		}
		break;
	case MESSAGE_TYPE_CLIENT:
		//		EventTable->Print("Not Decoded: Control Received\n");
		break;
	case MESSAGE_TYPE_ACK:
		//		EventTable->Print("Not Decoded: Ack Received\n");
		break;
	default:
		DecodeServerPacket();
	}

}

//**************************************
//
//  This routine is #$*#^&$#& UGLY. It parses the DEM messages.
//
//**************************************
//#define DECODE

void ServerObj::DecodeServerPacket() {

	int i, Misses, EndOfString;
	int EntityIndex;
	char *ConsoleString;
	int ConsoleStringLength;
	float TempFloatX, TempFloatY, TempFloatZ;
	long BitMask;
	unsigned char IDByte = 0, LastIDByte;
	EntityObj *TempEntity;

	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];  // Short for the Bot
	Misses = 0;
	while(!ServerPacket.End()){

#ifdef DEBUG
		IsMemNuked();
#endif
		
		LastIDByte = IDByte;
		IDByte = ServerPacket.ReadChar();

		switch(IDByte) {
		case 0x00:
			IsMemNuked();
			BombOut("Something Died in Here. Bad Data. Go Away.");
			break;
		
		case 0x01:
#ifdef DECODE
			EventTable->Print("Command: NOOP\n");
			IsMemNuked();
#endif
			break;
		
		case 0x02:
			DEMServerShutdown();
			return;
			break;
		
		case 0x03:
			DEMUpdatePlayerState(ServerPacket.ReadByte());
			break;

		case 0x04:
			ServerPacket.ReadLong();
#ifdef DECODE
			EventTable->Print("Command: Version\n");
			IsMemNuked();
#endif
			break;

		case 0x05:
			DEMSetView(ServerPacket.ReadShort());
			break;

		case 0x06:
			DEMSound();
			break;

		case 0x07:
			Data->ServerTimeStamp = ServerPacket.ReadFloat();
			_ftime(&(Data->ServerTime));
			Data->LastUpdatedEntity = -1;

#ifdef DECODE
			EventTable->Print("Command: Time\n");
			EventTable->Print("Server time: %f\n", Data->ServerTimeStamp);
			IsMemNuked();
#endif
			
			break;
		case 0x08: // DEM Command: Console Print
			ConsoleString = ServerPacket.ReadString();
			ConsoleStringLength = strlen(ConsoleString);
			EndOfString = 0;

			for(i=0; i < ConsoleStringLength; i++) {
				if((ConsoleString[i] == 0x0a))
					EndOfString = 1;

				if(iscntrl(ConsoleString[i]))
					ConsoleString[i] = ' ';
			}

			EventTable->Print("%s", ConsoleString);
			EventTable->SendMessage(edProxyServer, oeProxyPrint, ConsoleString);

			if(EndOfString)
				EventTable->Print("\n");

//			if(strnicmp(ConsoleString, QuitString, sizeof(QuitString)-1) == 0)
//				BombOut("WAH!! Someone doesn't love me!!!");

//			EventTable->Print("comparing %s, length %d\n", QuitString, sizeof(QuitString)-1);
			for(i = 0; i < ConsoleStringLength; i++) {
				if(strnicmp(&ConsoleString[i], QuitString, sizeof(QuitString)-1) == 0)
					BombOut("WAH!! Someone doesn't love me!!!");
			
			}


#ifdef DECODE
			EventTable->Print("Command: print\n");
			IsMemNuked();
#endif
			break;
		case 0x09:
			ConsoleString = strdup(ServerPacket.ReadString());
			if(strncmp(ConsoleString, "reconnect", 9) == 0){
				free(ConsoleString);

				GameMode = 0;
				ServerMode = smGameInit;
				Data->ResetGameVariables();

				EventTable->Print("Level Changing...\n");
				return;
			}
			EventTable->SendMessage(edConsole, oeConsoleParse, (void *)ConsoleString);
			free(ConsoleString);

#ifdef DECODE
			EventTable->Print("Stuff Text: %s\n", ConsoleString);
			IsMemNuked();
#endif

			break;

		case 0x0A:

			Bot->Angle[0] = ServerPacket.ReadAngle();
			Bot->Angle[1] = ServerPacket.ReadAngle();
			Bot->Angle[2] = ServerPacket.ReadAngle();
#ifdef DECODE
			EventTable->Print("Command: Set Angle\n");
			EventTable->Print("New angle is (%f, %f, %f)\n", Bot->Angle[0],
			Bot->Angle[1], Bot->Angle[2]);
			IsMemNuked();
#endif
			break;

		case 0x0B: // Server Info - Converted
			DEMServerInfo();
			break;

		case 0x0C: // DEM Command - Light Style
			DEMLightStyle(ServerPacket.ReadByte());
			break;

		case 0x0D:

			DEMUpdatePlayerName(ServerPacket.ReadByte());
			break;

		case 0x0E:
			DEMUpdatePlayerFrags(ServerPacket.ReadByte());
			break;

		case 0x0F:

			DEMUpdateClientData();
			break;

		case 0x10:
			ServerPacket.ReadShort();
#ifdef DECODE
			EventTable->Print("Command: Stop Sound\n");
			IsMemNuked();
#endif
			break;

		case 0x11:

			DEMUpdatePlayerColor(ServerPacket.ReadByte());
			break;
	
		case 0x12:
			{
				float Origin[3], Velocity[3];
				int i;
				for(i=0; i<3; i++)
					Origin[i] = ServerPacket.ReadCoord();
				for(i=0; i<3; i++)
					Velocity[i] = (float) ServerPacket.ReadChar() * (float)0.0625;
			
				int Color = ServerPacket.ReadByte();
				int Count = ServerPacket.ReadByte();
			}
#ifdef DECODE
			EventTable->Print("Command: Particle\n");
			IsMemNuked();
#endif
			break;
		
		case 0x13:
			Bot->ArmorValue -= ServerPacket.ReadChar();
			Bot->Health -= ServerPacket.ReadChar();
			TempFloatX = ServerPacket.ReadCoord();
			TempFloatY = ServerPacket.ReadCoord();
			TempFloatZ = ServerPacket.ReadCoord();

			Bot->Attacker = Data->WhatIsAt(TempFloatX, TempFloatY, TempFloatZ);
#ifdef DECODE
			EventTable->Print("Damage Origin: (%f,%f,%f)\n", TempFloatX, TempFloatY, TempFloatZ);
			IsMemNuked();
#endif
			break;

		case 0x14: // Command: Spawn Static
			DEMSpawnStatic();
			break;

		case 0x15:
#ifdef DECODE
			EventTable->Print("Command: Spawn Binary\n");
			IsMemNuked();
#endif
			BombOut("Bad Mojo Command: Spawn Binary");
			break;

		case 0x16: // Spawn Baseline
			DEMSpawnBaseline(ServerPacket.ReadShort());
			break;

		case 0x17:
			DEMTempEntity(ServerPacket.ReadByte());
			break;

		case 0x18:
			{
				int PauseState = ServerPacket.ReadByte();
				if(PauseState)
					EventTable->Print("Pause is on\n");
				else
					EventTable->Print("Pause is off\n");
			}
#ifdef DECODE
			EventTable->Print("Command: setpause\n");
			IsMemNuked();
#endif
			break;
		case 0x19: // Command: Game state

			GameMode = ServerPacket.ReadByte();
			SocketMode = skIdle;
#ifdef DECODE
			EventTable->Print("Game Mode: %d\n", GameMode);
			IsMemNuked();
#endif
			break;

		case 0x1A:
			EventTable->Print("String = %s\n", ServerPacket.ReadString());
#ifdef DECODE
			EventTable->Print("Command: Centerprint\n");
			IsMemNuked();
#endif
			break;

		case 0x1B:
#ifdef DECODE
			EventTable->Print("Command: Death of Monster\n");
			IsMemNuked();
#endif
			break;

		case 0x1C:
#ifdef DECODE
			EventTable->Print("Command: Found Secret\n");
			IsMemNuked();
#endif
			break;

		case 0x1D:
			{
				float Origin[3];

				for(i = 0; i<3; i++)
					Origin[i] = ServerPacket.ReadCoord();
				int SoundNum = ServerPacket.ReadByte();
				float Volume = (float)ServerPacket.ReadByte() / (float)255.0;
				float Attenuation = (float)ServerPacket.ReadByte() / (float)64.0;
			}
#ifdef DECODE
			EventTable->Print("Command: Spawn Static Sound\n");
			IsMemNuked();
#endif
			break;

		case 0x1E:
			Respawn(); // unpause
#ifdef DECODE
			EventTable->Print("Command: Intermission\n");
			IsMemNuked();
#endif
			break;

		case 0x1F:
			ConsoleString = ServerPacket.ReadString();
#ifdef DECODE
			EventTable->Print("Command: Final\n");
			IsMemNuked();
#endif
			break;

		case 0x20:
			DEMCDTrack();
			break;

		case 0x21:
#ifdef DECODE
			EventTable->Print("Command: Sell Screen\n");
			IsMemNuked();
#endif
			break;

		default:
			if(IDByte<0x80){
				EventTable->Print("ERROR!!!!!  Invalid ID Byte 0x%x\n", IDByte);
				ServerPacket.HexDump(HEXDUMP_INPUT_BUFFER, ServerPacket.InputOffset);
				BombOut("Bad Command");
			} else {


				BitMask = IDByte & 0x07F;

				if (BitMask & 0x0001) 
					BitMask |= ServerPacket.ReadByte() << 8;
				EntityIndex = BitMask & 0x4000 ?  ServerPacket.ReadShort() : (short) ServerPacket.ReadByte();

#ifdef DECODE
				EventTable->Print("Command: Update Entity (%d)\n", EntityIndex);
				IsMemNuked();
#endif

				Data->LastUpdatedEntity++;
				Data->UpdatedEntity[Data->LastUpdatedEntity] = EntityIndex;
				
				if(Data->BaselineEntity[EntityIndex] == NULL) {
					// EventTable->Print("Attempted to update NULL Entity!!!! Inserting Entry...\n");
					Data->BaselineEntity[EntityIndex] = new EntityObj;					
				}
				TempEntity = Data->BaselineEntity[EntityIndex];

				TempEntity->SaveOldValues(); // This saves the old state for

				if(BitMask & 0x0400)
					TempEntity->ModelIndex = ServerPacket.ReadByte();
				if(BitMask & 0x0040)
					TempEntity->Frame = ServerPacket.ReadByte();
				if(BitMask & 0x0800)
					TempEntity->ColorMap = ServerPacket.ReadByte();
				if(BitMask & 0x1000)
					TempEntity->Skin = ServerPacket.ReadByte();
				if(BitMask & 0x2000)
					TempEntity->AttackState = ServerPacket.ReadByte();
				if(BitMask & 0x0002)
					TempEntity->Location[0] = ServerPacket.ReadCoord();
				if(BitMask & 0x0100)
					TempEntity->Angle[0] = ServerPacket.ReadAngle();
				if(BitMask & 0x0004)
					TempEntity->Location[1] = ServerPacket.ReadCoord();
				if(BitMask & 0x0010)
					TempEntity->Angle[1] = ServerPacket.ReadAngle();
				if(BitMask & 0x0008)
					TempEntity->Location[2] =  ServerPacket.ReadCoord();
				if(BitMask & 0x0200)
					TempEntity->Angle[2] = ServerPacket.ReadAngle();
				
				if(BitMask & 0x0020)
					EventTable->Print("Really new stuff received for Entity[%d]\n", EntityIndex); 
			}	
			break;
		}

	}
}

// ***********************************************************
// *
// *  Parses the Client View Message
// *
// ***********************************************************


void ServerObj::DEMSetView(int EntityID){

	Data->BotID = EntityID - 1;
	Data->BotEntityIndex = EntityID;


#ifdef DECODE
	EventTable->Print("Command: Set View to Player %d\n", Data->BotID);
	IsMemNuked();
#endif

}

// ***********************************************************
// *
// * Parses the lightstyle Message 
// *
// ***********************************************************

void ServerObj::DEMLightStyle(int Index){

	char *String;
	String = ServerPacket.ReadString();

	Data->SetLightStyle(Index, String);
#ifdef DECODE
	EventTable->Print("Command: LightStyle[%d] = %s\n", Index, String);
	IsMemNuked();
#endif
}

// ***********************************************************
// *
// * Parses the sound Message 
// *
// ***********************************************************

void ServerObj::DEMSound(){

	float Origin[3];
	long EntityChannel;
	int Entity;
	int BitMask = ServerPacket.ReadByte();
	float Volume = BitMask & 0x01 ? (float) ServerPacket.ReadByte()/ (float)255.0 : (float)1.0;
	float Attenuation = BitMask & 0x02 ? (float) ServerPacket.ReadByte()/ (float)64.0 : (float)1.0;
	EntityChannel = ServerPacket.ReadShort();
	int Channel = EntityChannel & 0x07;
	Entity = (EntityChannel >> 3) & 0x1fff;
	int SoundNumber = ServerPacket.ReadByte();
	for(int i =0; i<3;i++)
		Origin[i] = ServerPacket.ReadCoord();

#ifdef DECODE
	EventTable->Print("Command: sound\n");
	IsMemNuked();
#endif

}

// ***********************************************************
// *
// * Deals with the server shutting down 
// *
// ***********************************************************

void ServerObj::DEMServerShutdown(){

	EventTable->Print("Server Shut Down\n");

	Data->ResetGameVariables(); // Clear Dyanmic data

	// Notifiy Console and turn off AI
	EventTable->SendMessage(edAI, oeAIOff, (void *)NULL); // Turn on AI
	EventTable->SendMessage(edBroadcast, oeServerOffline, (void *)NULL); // Turn on AI
	
	// Delete old callback
	EventTable->DeleteCallback(SocketEventID);

	ServerPacket.Socket.ResetSocket();
	ServerPacket.ResetPacket();
	
	SocketMode = skIdle;
	ServerMode = smIdle;
#ifdef DECODE
	EventTable->Print("Command: Disconnect\n");
	IsMemNuked();
#endif
}

// ***********************************************************
// *
// * Spawns a baseline(Dynamic) entity 
// *
// ***********************************************************

void ServerObj::DEMSpawnBaseline(int EntityIndex){

	EntityObj *Entity;
	int i;

#ifdef DECODE
	EventTable->Print("Spawned Baseline Entity #%d\n", EntityIndex);
	IsMemNuked();
#endif
	
	// This is record changes to the game entities
	Data->LastUpdatedEntity++;
	Data->UpdatedEntity[Data->LastUpdatedEntity] = EntityIndex;

	if(Data->BaselineEntity[EntityIndex] == NULL)
		Data->BaselineEntity[EntityIndex] = new EntityObj;

	Entity = Data->BaselineEntity[EntityIndex];
	if(EntityIndex >= MAX_BASELINE_ENTITIES)
		BombOut("CL_EntityNum: Invalid Number");
	
	Entity->SaveOldValues(); // This saves the old state for
							// for comparing changes

	Entity->ModelIndex = ServerPacket.ReadByte();
	Entity->Frame = ServerPacket.ReadByte();
	Entity->ColorMap = ServerPacket.ReadByte();
	Entity->Skin = ServerPacket.ReadByte();
	for(i = 0; i<3; i++){
		Entity->Location[i] = ServerPacket.ReadCoord();
		Entity->Angle[i] = ServerPacket.ReadAngle();
	}




}

// ***********************************************************
// *
// * Spawns a static entity 
// *
// ***********************************************************

void ServerObj::DEMSpawnStatic(){

	int EntityIndex, i;
	EntityObj *Entity;
	
	if(Data->StaticEntityCount >= MAX_STATIC_ENTITIES)
		BombOut("Too many static entries");

	(Data->StaticEntityCount)++;
	EntityIndex = (Data->StaticEntityCount) - 1;
	if(Data->StaticEntity[EntityIndex] == NULL)
		Data->StaticEntity[EntityIndex] = new EntityObj;

	Entity = Data->StaticEntity[EntityIndex];

	Entity->ModelIndex = ServerPacket.ReadByte();
	Entity->Frame = ServerPacket.ReadByte();
	Entity->ColorMap = ServerPacket.ReadByte();
	Entity->Skin = ServerPacket.ReadByte();
	for(i=0; i < 3; i++) {
		Entity->Location[i] = ServerPacket.ReadCoord();
		Entity->Angle[i] = ServerPacket.ReadAngle();
	}

#ifdef DECODE
	EventTable->Print("New Static Entity #%d\n", EntityIndex);
	IsMemNuked();
#endif


}

// ***********************************************************
// *
// * Spawns a temp entity 
// *
// ***********************************************************

void ServerObj::DEMTempEntity(int EntityType){

	float Origin[3], TraceEndPos[3];
	int i, Entity;
	if(EntityType > 11) {
		BombOut("CL_ParserTEnt: bad type");
	}
	switch(EntityType) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 7:
	case 8:
	case 10:
	case 11:

		for(i=0; i<3;i++)
			Origin[i] = ServerPacket.ReadCoord();
		break;
	case 5:
	case 6:
	case 9:
		Entity = ServerPacket.ReadShort();
		for(i=0; i<3;i++)
			Origin[i] = ServerPacket.ReadCoord();
		for(i=0; i<3;i++)
			TraceEndPos[i] = ServerPacket.ReadCoord();

		break;
	}

#ifdef DECODE
	EventTable->Print("Command: Temp Entity\n");
	IsMemNuked();
#endif

}

// ***********************************************************
// *
// * Changes the CD track, NOT!!!! 
// *
// ***********************************************************

void ServerObj::DEMCDTrack(){
	int Start, End;
	Start = ServerPacket.ReadByte();
	End = ServerPacket.ReadByte();

#ifdef DECODE
	EventTable->Print("Command: CD Track\n");
	EventTable->Print("Range %d - %d\n", Start, End);
	IsMemNuked();
#endif
}

// ***********************************************************
// *
// * Parses the server info Message.  This sets up the game 
// *
// ***********************************************************


void ServerObj::DEMServerInfo(){

	Data->ServerVersion = ServerPacket.ReadLong();
	if(Data->ServerVersion != 0x0F)
		EventTable->Print("Bad Server Version, V%x\n", Data->ServerVersion);

	Data->MaxClients = ServerPacket.ReadByte();
	Data->Multi = ServerPacket.ReadByte();

	Data->SetMapName(ServerPacket.ReadString());

	Data->ResetGameVariables();

	Data->NumModels = 1; // This is to align the models
	do {
		Data->PrecacheModel[Data->NumModels] = strdup(ServerPacket.ReadString());
		if (++(Data->NumModels) > MAX_MODELS)
			BombOut("Server sent too much model precache");
	//				EventTable->Print("Getting Model #%d\n", Data->NumModels);
	} while (*Data->PrecacheModel[Data->NumModels-1]);

	Data->NumSounds = 1; // This is to align the models
	do {
		Data->PrecacheSound[Data->NumSounds] = strdup(ServerPacket.ReadString());
		if (++(Data->NumSounds) > MAX_SOUNDS)
			BombOut("Server sent too much sound precache");
	//				EventTable->Print("Getting Sound #%d\n", Data->NumSounds);
	} while (*Data->PrecacheSound[Data->NumSounds-1]);

	/*
	for(TempInt = 0; TempInt < Data->NumSounds; TempInt++)
		printf("PrecacheSound[%d] = %s\n", TempInt, Data->PrecacheSound[TempInt]);

	printf("NumModels = %d, NumSounds = %d\n", Data->NumModels, Data->NumSounds);
	*/

#ifdef DECODE
	EventTable->Print("DEM Command: Server Info\n");
	IsMemNuked();
#endif

}

// ***********************************************************
// *
// * Parses Client Data message. This is the normal runtime message 
// *
// ***********************************************************

void ServerObj::DEMUpdateClientData(){

#ifdef DECODE
	EventTable->Print("Command: Update Client Data\n");
	IsMemNuked();
#endif

	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex]; 

	long BitMask = ServerPacket.ReadShort();
	if(BitMask & 0x0001)
		Bot->ViewOffset = (float) ServerPacket.ReadChar();

	if(BitMask & 0x0002)
		Bot->AngleOffset =  (float) ServerPacket.ReadAngle();
	if(BitMask & 0x0004)
		Bot->ClientAngle[0] =  ServerPacket.ReadAngle();
	if(BitMask & 0x0020)
		Bot->Velocity[0] = (float)ServerPacket.ReadChar();
	if(BitMask & 0x0008)
		Bot->ClientAngle[1] =  ServerPacket.ReadAngle();
	if(BitMask & 0x0040)
		Bot->Velocity[1] = (float)ServerPacket.ReadChar();
	if(BitMask & 0x0010)
		Bot->ClientAngle[2] = ServerPacket.ReadAngle();
	if(BitMask & 0x0080)
		Bot->Velocity[2] = (float)ServerPacket.ReadChar();
	if(BitMask & 0x0200)
		Bot->Items = ServerPacket.ReadLong();
	if(BitMask & 0x1000)
		Bot->WeaponFrame = ServerPacket.ReadChar();
	if(BitMask & 0x2000)
		Bot->ArmorValue = ServerPacket.ReadChar();
	if(BitMask & 0x4000)
		Bot->WeaponModel = ServerPacket.ReadChar();
	
	Bot->Health = ServerPacket.ReadShort();
	Bot->CurrentAmmo = ServerPacket.ReadChar();
	Bot->AmmoShells = ServerPacket.ReadChar();
	Bot->AmmoNails = ServerPacket.ReadChar();
	Bot->AmmoRockets = ServerPacket.ReadChar();
	Bot->AmmoCells = ServerPacket.ReadChar();
	Bot->Weapon = ServerPacket.ReadChar();


}

// ***********************************************************
// *
// * Updates frags 
// *
// ***********************************************************

void ServerObj::DEMUpdatePlayerFrags(int PlayerID){

	PlayerObj *Player;
	
	Player = (PlayerObj *)Data->BaselineEntity[PlayerID + 1];
	
	if (PlayerID < 0 || PlayerID >= Data->MaxPlayers) {
		EventTable->Print("ERROR: Update Frags - Invalid Entity Index = #%d\n", PlayerID);
		Player->Frags = ServerPacket.ReadShort();
	}
	else
		Player->Frags = ServerPacket.ReadShort();

#ifdef DECODE
	EventTable->Print("Command: Update Frags\n");
	IsMemNuked();
#endif

}
// ***********************************************************
// *
// * Updates player color 
// *
// ***********************************************************

void ServerObj::DEMUpdatePlayerColor(int PlayerID){

	PlayerObj *Player;
	int Color;

	if (PlayerID < 0 || PlayerID >= Data->MaxPlayers) {
		EventTable->Print("ERROR: Update Color - Invalid Entity Index = #%d\n", PlayerID);
		ServerPacket.ReadByte();			
	}
	
	Player = (PlayerObj *)Data->BaselineEntity[PlayerID + 1]; 

	Color = ServerPacket.ReadByte();
	Player->ShirtColor = (Color >> 4) & 0x0f;
	Player->PantColor = Color & 0x0f;

#ifdef DECODE
	EventTable->Print("Command: Update Color - Player #%d\n", PlayerID);
	IsMemNuked();
#endif

}

// ***********************************************************
// *
// * Updates player state 
// *
// ***********************************************************

void ServerObj::DEMUpdatePlayerState(int Index){

	if (Index < 0 || Index > 31) {
		EventTable->Print("ERROR: Update Player State - Invalid Index = #%d\n", Index);
//		ServerPacket.HexDump(HEXDUMP_INPUT_BUFFER, ServerPacket.InputOffset);
		ServerPacket.ReadLong();
//		BombOut("\n\n\nBad Command");
	
	} else

		Bot->PlayerState[Index] = ServerPacket.ReadLong();

#ifdef DECODE
	EventTable->Print("Command: Update Stat\n");
	IsMemNuked();
#endif


}

// ***********************************************************
// *
// * Update player name 
// *
// ***********************************************************

void ServerObj::DEMUpdatePlayerName(int PlayerID){

	PlayerObj *Player;
	char *TempPChar;
	
	Player = (PlayerObj *)Data->BaselineEntity[PlayerID + 1]; 
	TempPChar = ServerPacket.ReadString();
	if (PlayerID < 0 || PlayerID >= Data->MaxPlayers) {
		EventTable->Print("ERROR: UpdateName - Invalid Entity Index = #%d\n", PlayerID);
	} else {
		if(TempPChar != NULL)
			Player->SetName(TempPChar);
		else
			EventTable->Print("I Got a NULL Player Name for #%d!!!\n", PlayerID);
	}
#ifdef DECODE
	EventTable->Print("Command: Update Name #%d\n", PlayerID);
	IsMemNuked();
#endif
}



// *************************
// *
// * Debug Exit Routine.
// *
// *************************

void ServerObj::BombOut(char *String){
	EventTable->Print("BOOM!: %s\n", String);
	SendGoodbye();
//	EventTable->Exit(2);	
	exit(2);
}

// *****************************
// *
// * Routine to send the client runtime parameters.
// * This now deals with respawn keypresses
// *
// *****************************

void ServerObj::SendRuntimePacket(PlayerObj *Player) {

	static Boolean RespawnToggle = False; 
		
	_timeb CurrentTime;

	_ftime(&CurrentTime);

	ServerPacket.Reset();

	ServerPacket.SetHeader(MESSAGE_TYPE_UPDATE);

	ServerPacket.SaveByte(0x03);  // Movement Command


	Data->ClientTimeStamp = (float)(CurrentTime.time - Data->ServerTime.time);
	Data->ClientTimeStamp += (float)(CurrentTime.millitm - Data->ServerTime.millitm)/(float)1000.0; // elapsed time
	Data->ClientTimeStamp += Data->ServerTimeStamp; // elapsed time

	ServerPacket.SaveFloat(Data->ServerTimeStamp);
	ServerPacket.SaveAngle(Player->CommandViewAngle);
	ServerPacket.SaveAngle(Player->CommandRotation);
	ServerPacket.SaveAngle(Player->CommandRollAngle);	// Rollangle???
	ServerPacket.SaveShort(Player->CommandInlineSpeed);
	ServerPacket.SaveShort(Player->CommandLateralSpeed);
	ServerPacket.SaveShort(Player->CommandVerticalSpeed);
//	EventTable->Print("Runtime Packet\n");

	if(Data->RespawnMode){
		if(RespawnToggle) {
			ServerPacket.SaveByte(KEY_ACTION_NONE);
			EventTable->Print("None\n");
			RespawnToggle = False;
		} else {
			ServerPacket.SaveByte(KEY_ACTION_JUMP);
			EventTable->Print("Space\n");
			RespawnToggle = True;
		}

		if(((PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex])->Health > 0)
			Data->RespawnMode = False;
	} else
		ServerPacket.SaveByte(Player->CommandActions);	

	ServerPacket.SaveByte(Player->CommandImpulse);	// Impulse Command
	
	ServerPacket.SendMessage();

}


// ***************************************************************
// *
// * Respawn the player.  This routine is needed because it appears
// * That the server is slow to pick up on space bar presses.
// *
// ***************************************************************

void ServerObj::Respawn() {

	Data->RespawnMode = True;

/*
	
	int PacketLength, Count = 5;

	EventTable->Print("Respawning.....\n");

	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];  // Short for the Bot

	Bot->CommandActions = KEY_ACTION_JUMP;
	while(Count-- > 0) {
		if((PacketLength = ServerPacket.GetMessage()) > 0 )
			DecodePacket();
			
		SendRuntimePacket(Bot);
	}

	Bot->CommandActions = KEY_ACTION_NONE;

	if((PacketLength = ServerPacket.GetMessage()) > 0 )
		DecodePacket();
		
	SendRuntimePacket(Bot);
	EventTable->Print("Respawn Complete\n");

*/


}

// ***************************************************************
// *
// * Called once per event cycle. Takes care of all transmissions
// * to the server
// *
// ***************************************************************

void ServerObj::CycleEvent(void *Dummy) {

	if(SocketMode == skIdle) { // Not waiting for response
		SocketMode = skWaiting;  // go ahead and set flag
								// Decode packet flips it back
		switch(ServerMode) {
		case smQuery:
//			EventTable->Print("Query Mode\n");
			QueryServer();
			break;
		case smGetRules:
//			EventTable->Print("Get Rules Mode\n");
			GetRules();
			break;
		case smConnect:
//			EventTable->Print("Connect Mode\n");
			ConnectServer();
			break;
		case smGameInit:
//			EventTable->Print("GameInit Mode\n");
			GameInit();

			break;
		case smIdle:
			SocketMode = skIdle;
//			EventTable->Print("Idle Mode\n");
			break;
		case smRuntime:
			SocketMode = skIdle;
			SendRuntimePacket((PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex]);
			break;
		}

	}
}


ServerObj::ServerObj(EventTableObj *Event, DataObj *ServerData){		

	long Timeout;

	Connected = False;
	EventTable = Event;
	GetServerStartTime = False;
	ServerMode = smIdle;
	SocketMode = skIdle;
	OwnerID = edServer;

	Data = ServerData;

	// After socket is init'ed, register the callbacks
	EventTable->RegisterCallback((EventHandlerObj *)this, (void *)NULL, etCycleEvent);
	EventTable->RegisterCallback((EventHandlerObj *)this, (void *)NULL, etMessageEvent);
	ServerMode = smIdle; // Go to start mode

	CheckPointer = NULL;

	Timeout = 1;
	ShortTimeout.tv_sec = Timeout/1000;  // convert timeout to timeval struct
	ShortTimeout.tv_usec = (Timeout - (ShortTimeout.tv_sec * 1000)) * 1000;

}
	

void ServerObj::SetServer(char *ServerAddress, int InitPort){
	
	ServerPacket.Socket.SetDestination(ServerAddress);

	ServerPacket.Socket.RemotePort = InitPort;
	ServerPacket.Socket.Init();

	ServerPacket.Socket.SetTimeoutHandler(3000, ServerTimeoutHandler);
	SocketEventID = EventTable->RegisterCallback((EventHandlerObj *)this, (void *)&(ServerPacket.Socket), etRecvEvent);

	ServerMode = smQuery; // Go to next mode

}

// *********************
//
// This function queries the server for its name IP, etc.
//
// *********************

void ServerObj::QueryServer() {

	EventTable->Print("Performing Query on %s:%d\n", ServerPacket.Socket.RemoteIP, ServerPacket.Socket.RemotePort);
	EventTable->SetSocketPolling(True); // Turn on Socket Polling
	
	ServerPacket.Reset();

	ServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ServerPacket.SaveChar(CCREQ_SERVER_INFO);
	ServerPacket.SaveString("QUAKE");
	ServerPacket.SaveChar((char) 0x03);
	ServerPacket.SendMessage();

}

void ServerObj::GetRules() {

	ServerPacket.Reset();
	ServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ServerPacket.SaveChar(CCREQ_RULE_INFO);
	ServerPacket.SaveString("");
	ServerPacket.SendMessage();

}

// ***********************************
//
// Establishes a connection to server.
//
// ***********************************

void ServerObj::ConnectServer() {


	// Build the packet.
	ServerPacket.Reset();

	ServerPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ServerPacket.SaveChar(CCREQ_CONNECT);
	ServerPacket.SaveString("QUAKE");
	ServerPacket.SaveChar((char) 0x03);
	ServerPacket.SendMessage();
	
	EventTable->Print("Connecting\n");

}

void ServerObj::MessageEvent(ObjectEvent Event, void *Data) {

	Address *ConnectAddress;

	switch(Event) {
	case oeServerConnect: // Connect to a QuakeServer
		ConnectAddress = (Address *)Data;
		SetServer(ConnectAddress->IPAddress, ConnectAddress->Port);
		break;
	case oeServerDisconnect: // Disconnect from a QuakeServer
		SendGoodbye();
		break;
	case oeSendRuntimePacket: // Send client update packet
		SendRuntimePacket((PlayerObj *)Data);
		break;
	case oeSendSay: // sned a say command
		SendBroadcastMessage((char *)Data);
		break;
	case oeSendRaw: // Send a raw command
		SendCommand((char *)Data);
		break;
	case oeRespawn: // Disconnect from a QuakeServer
		Respawn();
		break;
	case oeServerOnline: // These are my events during broadcast
	case oeServerOffline: 
		break;
	default:
		EventTable->Print("Unknown Server Message Event!!!!\n");
	}

}

// *********************
// *
// * Called on exit of the EventTable
// * Disconnects from server
// *
// *********************

void ServerObj::ExitEvent(void *Dummy) {

	if(Connected) {
		SendBroadcastMessage("Terminating");
		SendGoodbye();
	}
}

// *********************
// *
// * DEBUG: Check for trounced Memory
// *
// *********************
void ServerObj::IsMemNuked() {

//	if(((PlayerObj *)Data->BaselineEntity[1])->Name != NULL){

//		EventTable->Print("Player Data Area Overwritten!!!\n");
//		BombOut("Getting the hell out of Dodge\n");
//	}
#ifndef __unix__

	if(!_CrtCheckMemory()){
		EventTable->Print("Memory has been most egregiously trounced!!!\n");
		BombOut("Getting the hell out of Dodge\n");
	}

#endif



}

// *********************
// *
// * Called by the presence of data on a socket
// *
// *********************
void ServerObj::RecvEvent(void *Dummy) {

//	EventTable->Print("Receiving Data\n");
	ServerPacket.GetMessage();
	DecodePacket();

//	while(ServerPacket.Socket.IsData(ShortTimeout))
//		DecodePacket(); // Check for extra data


}