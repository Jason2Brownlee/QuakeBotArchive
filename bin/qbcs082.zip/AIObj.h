#ifndef AIOBJ_H
#define AIOBJ_H

#include <stdio.h>


#include "QuakeBot.h"
#include "DataObj.h"
//#include "NavObj.h"
#include "EventTableObj.h"

enum AIMode_t	{INIT, DEAD, MAPPING, IDLE};
//enum MsgType_t	{STATUS, ERROR, REQUESTED};

class AIObj : virtual public EventHandlerObj
{
private:

	//int Health;

	Boolean Enabled; // AI on.off switch
	
	EventTableObj *EventTable;
	DataObj *Data;

	AIMode_t	AIMode;
	GameCoord BotCoord, StartCoord, LastCoord;
	float Rotation;
	float LastTimeStamp;	
	short Speed;
	float Delay;
	Boolean Msg;

/*	int AttackPlayer(int);
	void Chatter(int);
	void DisplayMode(int);*/
	void ProcessImpulse();
	void ProcessCommand(char*);
	void Print(char *,...);

public:

	AIObj(EventTableObj *Event, DataObj *ServerData);
	virtual void CycleEvent(void *);  // AI method
	virtual void MessageEvent(ObjectEvent Event, void *Data); 
};

#endif
