#include "ProxyServerObj.h"

#ifdef __unix__
char *itoa(int Data, char *Buffer, int Radix) {

	sprintf(Buffer, "%d", Data);

	return Buffer;
}
#endif

// ***********************************
// *
// * Sets up Proxy Server.
// *
// ***********************************

ProxyServerObj::ProxyServerObj(EventTableObj *Event, DataObj *ServerData, int LocalServerPort){		

	EventTable = Event;
	Data = ServerData;
	OwnerID = edProxyServer;
	ProxyInitPacket.Socket.LocalPort = LocalServerPort;
	ClientPacket.Socket.LocalPort = 0;

	ServerConnected = False;
	ClientConnected = False;
	WatchdogCounter = 0;
	ProxyMode = pmIdle;
	SocketMode = skIdle;
	SocketEventID = EventTable->RegisterCallback((EventHandlerObj *)this, (void *)NULL, etCycleEvent);
	SocketEventID = EventTable->RegisterCallback((EventHandlerObj *)this, (void *)NULL, etMessageEvent);


}


void ProxyServerObj::InitServerPort(){		

	EventTable->Print("Binding to Local Socket %d\n", ProxyInitPacket.Socket.LocalPort);

	ProxyInitPacket.Socket.Init();

	EventTable->Print("Proxy Server Bound\n");
	SocketEventID = EventTable->RegisterCallback((EventHandlerObj *)this, (void *)&(ProxyInitPacket.Socket), etRecvEvent);
	EventTable->SetSocketPolling(True);
}

int ProxyServerObj::InitClientPort(){		

	ClientPacket.Socket.Init();

	// Copy the init port's data to the client port
	strcpy(ClientPacket.Socket.RemoteIP, ProxyInitPacket.Socket.RemoteIP);
	ClientPacket.Socket.RemotePort = ProxyInitPacket.Socket.RemotePort;
	
//	EventTable->Print("Client Accepted.  Routed to Local Socket %d\n", ClientPacket.Socket.LocalPort);
	SocketEventID = EventTable->RegisterCallback((EventHandlerObj *)this, (void *)&(ClientPacket.Socket), etRecvEvent);

	return ClientPacket.Socket.LocalPort;
}

/*
void ProxyServerObj::CloseClientPort(){		

	ProxyInitPacket.Socket.Init();

	EventTable->Print("Client Accepted.  Routed to Local Socket %d\n", ClientPacket.Socket.LocalPort);
	SocketEventID = EventTable->RegisterCallback((EventHandlerObj *)this, (void *)&(ClientPacket.Socket), etRecvEvent);
}
*/
void ProxyServerObj::DecodeInitPacket() {

	int PacketData = ProxyInitPacket.GetInputHeader();

	switch(PacketData) {
	case MESSAGE_TYPE_CONTROL:
//		EventTable->Print("Control Received\n");
		PacketData = ProxyInitPacket.ReadChar();
		switch(PacketData) {
		case CCREQ_RULE_INFO: // Rule Request
			RespondRule();
			break;		
		case CCREQ_SERVER_INFO: // Query Request
			RespondQuery();
			break;
		case CCREQ_CONNECT: // Connect Request
			RespondConnect();
			break;
		}
		break;
	case MESSAGE_TYPE_CLIENT:
		EventTable->Print("Client Received on init port\n");
		break;
	case MESSAGE_TYPE_ACK:
		EventTable->Print("Ack Received on init port\n");
		break;
	case MESSAGE_TYPE_UPDATE:
		EventTable->Print("Update Received on init port\n");
		break;
	default:
		EventTable->Print("Default Received on init port\n");
		break;
	}

}

void ProxyServerObj::DecodeFinal() {

	int PacketData;
	char Buffer[0x7f];

	PlayerObj *Bot;

	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];

	while(!ClientPacket.End()){
		PacketData = ClientPacket.ReadByte();
		switch(PacketData) {
		case 0x00:
			EventTable->Print("ERROR: Proxy received a 0x00 Message\n");
			ClientPacket.HexDump(HEXDUMP_INPUT_BUFFER, ClientPacket.InputOffset);
			EventTable->Print("\n\n\n///");
			break;
		case 0x01:
			EventTable->Print("ProxyServer: Client->Server Keep Alive\n");
			break;
/*		case 0x02:
			EventTable->Print("Disconnect\n");
			ProxyMode = pmIdle;
			ClientConnected = False;
			break;
		case 0x03:
			EventTable->Print("Movement\n");
			ClientPacket.ReadFloat(); // Game time
			Bot->CommandRollAngle = ClientPacket.ReadAngle();
			Bot->CommandRotation = ClientPacket.ReadAngle();
			Bot->CommandViewAngle = ClientPacket.ReadAngle();
			Bot->CommandInlineSpeed = ClientPacket.ReadShort();
			Bot->CommandLateralSpeed = ClientPacket.ReadShort();
			Bot->CommandVerticalSpeed = ClientPacket.ReadShort();
			Bot->CommandActions = ClientPacket.ReadByte();
			Bot->CommandImpulse = ClientPacket.ReadByte();

			if(Bot->CommandImpulse > 50)
				EventTable->Print("Impulse Command Received\n");

			break;
*/		case 0x04:
//			EventTable->Print("Console Order\n");
			strcpy(Buffer, ClientPacket.ReadString());
			if(strnicmp(Buffer, "prespawn", 8) == 0){
				ProxyMode = pmBinaryPacket;
				SocketMode = skIdle;
//				EventTable->Print("Prespawn command\n");

			} else if(strnicmp(Buffer, "spawn", 5) == 0) {
				ProxyMode = pmLightingPacket;
				SocketMode = skIdle;
//				EventTable->Print("Spawn command\n");
			} else if(strnicmp(Buffer, "begin", 5) == 0) {
				ProxyMode = pmRuntimePacket;
				SocketMode = skIdle;
				EventTable->Print("ProxyServer: Client Online\n");
			} else if(strnicmp(Buffer, "name", 4) == 0)
				EventTable->Print("ProxyServer: Client 'Name' command ignored\n");
			 else if(strnicmp(Buffer, "color", 5) == 0)
				EventTable->Print("ProxyServer: Client 'Color' command ignored\n");
			 else
				 EventTable->Print("ProxyServer: ERROR - Unknown console order!!!\n");
			break;
		default:
			EventTable->Print("Unknown command!!!!\n");
			break;

		}

	}
}

void ProxyServerObj::DecodeUpdate() {

	int PacketData;
//	char Buffer[0x7f];

	PlayerObj *Bot;

	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];

	while(!ClientPacket.End()){
		PacketData = ClientPacket.ReadByte();
		switch(PacketData) {
		case 0x00:
			EventTable->Print("ERROR: Proxy received a 0x00 Message\n");
			ClientPacket.HexDump(HEXDUMP_INPUT_BUFFER, ClientPacket.InputOffset);
			EventTable->Print("\n\n\n///");
			break;
		case 0x01:
			EventTable->Print("ProxyServer: Client->Server Keep Alive\n");
			break;
		case 0x02:
			EventTable->Print("ProxyServer: Client Disconnected\n");
			ClientShutdown();
			break;
		case 0x03:
			ClientPacket.ReadFloat(); // Game time
			Bot->CommandRollAngle = ClientPacket.ReadAngle();
			Bot->CommandRotation = ClientPacket.ReadAngle();
			Bot->CommandViewAngle = ClientPacket.ReadAngle();
			Bot->CommandInlineSpeed = ClientPacket.ReadShort();
			Bot->CommandLateralSpeed = ClientPacket.ReadShort();
			Bot->CommandVerticalSpeed = ClientPacket.ReadShort();
			Bot->CommandActions = ClientPacket.ReadByte();
			Bot->CommandImpulse = ClientPacket.ReadByte();

			if(Bot->CommandImpulse > 0) {
				EventTable->Print("Impulse Command Received\n");
				EventTable->SendMessage(edAI, oeImpulseReceived, NULL);
			}

			break;
/*		case 0x04:
//			EventTable->Print("Console Order\n");
			strcpy(Buffer, ClientPacket.ReadString());
			if(strnicmp(Buffer, "prespawn", 8) == 0){
				ProxyMode = pmBinaryPacket;
				SocketMode = skIdle;
//				EventTable->Print("Prespawn command\n");

			} else if(strnicmp(Buffer, "spawn", 5) == 0) {
				ProxyMode = pmLightingPacket;
				SocketMode = skIdle;
//				EventTable->Print("Spawn command\n");
			} else if(strnicmp(Buffer, "begin", 5) == 0) {
				ProxyMode = pmRuntimePacket;
				SocketMode = skIdle;
				EventTable->Print("Handshake Completed. Client Online\n");
			} else if(strnicmp(Buffer, "name", 4) == 0)
				EventTable->Print("name command\n");
			 else if(strnicmp(Buffer, "color", 5) == 0)
				EventTable->Print("color command\n");
			 else
				EventTable->Print("ERROR: Unknown console order!!!\n");
			break;
*/		default:
			EventTable->Print("ProxyServer: Unknown Update command!!!!\n");
			break;

		}

	}
}

void ProxyServerObj::DecodeClientPacket() {

	int PacketData = ClientPacket.GetInputHeader();

	switch(PacketData) {
	case MESSAGE_TYPE_CONTROL:
		PacketData = ClientPacket.ReadChar();
		switch(PacketData) {
		case CCREQ_RULE_INFO: // Rule Request
			EventTable->Print("Rule packet received on proxy runtime port. Ignoring...\n");
			break;		
		case CCREQ_SERVER_INFO: // Query Request
			EventTable->Print("Query packet received on proxy runtime port. Ignoring...\n");
			break;
		case CCREQ_CONNECT: // Connect Request
			EventTable->Print("Connect packet received on proxy runtime port. Ignoring...\n");
			break;
		}
		break;
	case MESSAGE_TYPE_CLIENT:
		EventTable->Print("Peer client packet received on proxy runtime port. Ignoring...\n");
		break;
	case MESSAGE_TYPE_ACK:
//		EventTable->Print("Ack Received\n");
		break;
	case MESSAGE_TYPE_UPDATE:
//		EventTable->Print("Update Received\n");
		DecodeUpdate();
		break;
	case MESSAGE_TYPE_FINAL:
//		EventTable->Print("Final Received\n");
		DecodeFinal();
		break;
	default:
		EventTable->Print("Received %d\n", PacketData);
		break;
	}

}

void ProxyServerObj::RespondQuery() {

	EventTable->Print("ProxyServer: Query Received\n");
	char Buffer[0x40];

	// This long named function makes sure that I transmit
	// to the same person that sent to me.
	// I will need to change this later so that only
	// One connection will be supported.

	ProxyInitPacket.Socket.SetDestinationToPacketSource();


	ProxyInitPacket.Reset();	
	ProxyInitPacket.SetHeader(MESSAGE_TYPE_CONTROL);

	ProxyInitPacket.SaveChar(CCREP_SERVER_INFO); // Response
	sprintf(Buffer, "%s:%d", 	ProxyInitPacket.Socket.LocalIP,
		ProxyInitPacket.Socket.LocalPort);

	ProxyInitPacket.SaveString(Buffer); // IP:Port
	ProxyInitPacket.SaveString("BotProxy"); // Server name
	
	ProxyInitPacket.SaveString(Data->MapName);// Map Name
	ProxyInitPacket.SaveChar(Data->NumberOfPlayers); // Number of players
	ProxyInitPacket.SaveChar(Data->MaxPlayers); // Max Players

	ProxyInitPacket.SaveChar(NET_PROTOCOL_VERSION); // Net Protocol Version
	ProxyInitPacket.SendMessage();
}

void ProxyServerObj::RespondRule() {

//	EventTable->Print("Responding to Rule Request\n");
	char Buffer[0x40];

	// This long named function makes sure that I transmit
	// to the same person that sent to me.
	// I will need to change this later so that only
	// One connection will be supported.

	// Get the rule argument sent to server
	strcpy(Buffer, ProxyInitPacket.ReadString());

	ProxyInitPacket.Socket.SetDestinationToPacketSource();
	ProxyInitPacket.Reset();	
	ProxyInitPacket.SetHeader(MESSAGE_TYPE_CONTROL);
	ProxyInitPacket.SaveChar(CCREP_RULE_INFO); // Response
	if(stricmp(Buffer, "") == 0) {
		ProxyInitPacket.SaveString("sv_gravity"); // Rule
		ProxyInitPacket.SaveString(itoa(Data->sv_gravity, Buffer, 10)); // Value

	} else if(stricmp(Buffer, "sv_gravity") == 0) {
		ProxyInitPacket.SaveString("sv_friction"); // Rule
		ProxyInitPacket.SaveString(itoa(Data->sv_friction, Buffer, 10)); // Value

	} else if(stricmp(Buffer, "sv_friction") == 0) {
		ProxyInitPacket.SaveString("sv_maxspeed"); // Rule
		ProxyInitPacket.SaveString(itoa(Data->sv_maxspeed, Buffer, 10)); // Value

	} else if(stricmp(Buffer, "sv_maxspeed") == 0) {
		ProxyInitPacket.SaveString("fraglimit"); // Rule
		ProxyInitPacket.SaveString(itoa(Data->fraglimit, Buffer, 10)); // Value
	
	} else if(stricmp(Buffer, "fraglimit") == 0) {
		ProxyInitPacket.SaveString("timelimit"); // Rule
		ProxyInitPacket.SaveString(itoa(Data->timelimit, Buffer, 10)); // Value
	
	} else if(stricmp(Buffer, "timelimit") == 0) {
		ProxyInitPacket.SaveString("teamplay"); // Rule
		ProxyInitPacket.SaveString(itoa(Data->teamplay, Buffer, 10)); // Value
	
	} else if(stricmp(Buffer, "teamplay") == 0) {
		ProxyInitPacket.SaveString("noexit"); // Rule
		ProxyInitPacket.SaveString(itoa(Data->noexit, Buffer, 10)); // Value

	} else if(stricmp(Buffer, "noexit") == 0); // Do nothing
	ProxyInitPacket.SendMessage();
}

void ProxyServerObj::RespondConnect() {

	int NewPort;

	// This long named function makes sure that I transmit
	// to the same person that sent to me.
	// I will need to change this later so that only
	// One connection will be supported.

	ProxyInitPacket.Socket.SetDestinationToPacketSource();

	ProxyInitPacket.Reset();	
	ProxyInitPacket.SetHeader(MESSAGE_TYPE_CONTROL);

	if(ServerConnected) {
		if(ClientConnected) {
			EventTable->Print("ProxyServer: Rejecting Connection\n");
			ProxyInitPacket.SaveChar(CCREP_REJECT); // Response
			ProxyInitPacket.SaveString("Only one client connection per proxy currently supported"); // Server name
			ProxyInitPacket.SendMessage();
		} else {
			EventTable->Print("ProxyServer: Accepting Connection\n");

			ProxyInitPacket.SaveChar(CCREP_ACCEPT); // Response
			NewPort = InitClientPort();
			ProxyInitPacket.SaveShort(NewPort); // Response	
			ProxyInitPacket.SaveByte(0x00); // I don't know
			ProxyInitPacket.SaveByte(0x00); // ditto
			ClientConnected = True;
			ProxyInitPacket.SendMessage();
			ProxyMode = pmASCIIPacket;
		}
		
	} else {
		EventTable->Print("ProxyServer: Rejecting Connection\n");
		ProxyInitPacket.SaveChar(CCREP_REJECT); // Response
		ProxyInitPacket.SaveString("Bot not connected to a server"); // Server name
		ProxyInitPacket.SendMessage();
	}

}

void ProxyServerObj::SendASCIIPacket(){		

	int i;
//	EventTable->Print("Sending ASCII Packet\n");

	ClientPacket.Reset();	
	ClientPacket.SetHeader(MESSAGE_TYPE_FINAL);

	DEMPrintString("\002\nVERSION 1.03 SERVER (51103 CRC)");

	ClientPacket.SaveChar(0x0b); // DEM server info
	ClientPacket.SaveLong(Data->ServerVersion);
	ClientPacket.SaveByte(Data->MaxClients);
	ClientPacket.SaveByte(Data->Multi);
	ClientPacket.SaveString(Data->MapName);
	for(i = 1; i < Data->NumModels - 1; i++)
		ClientPacket.SaveString(Data->PrecacheModel[i]);
	ClientPacket.SaveByte(0x0);	
	for(i = 1; i < Data->NumSounds - 1; i++)
		ClientPacket.SaveString(Data->PrecacheSound[i]);
	ClientPacket.SaveByte(0x0);
	//	printf("NumModels = %d, NumSounds = %d\n", Data->NumModels, Data->NumSounds);

	// Camera view is based on entity #, player 0's entity
	// is #1, etc.....
	ClientPacket.SaveChar(0x05); // Set view
	ClientPacket.SaveShort(Data->BotEntityIndex); 
	
	ClientPacket.SaveByte(0x19);
	ClientPacket.SaveByte(GAME_STATE_PRESPAWN);

	ClientPacket.SendMessage();

}

void ProxyServerObj::SendNoOp() {

	ClientPacket.Reset();	
	ClientPacket.SetHeader(MESSAGE_TYPE_UPDATE);
	ClientPacket.SaveChar(0x01);
	ClientPacket.SendMessage();

}

void ProxyServerObj::SendBinaryPacket(){		

	int i,x;
	EntityObj *TempEntity;

	ClientPacket.Reset();	
	ClientPacket.SetHeader(MESSAGE_TYPE_FINAL);

//	DEMPrintString("Binary Packet Received\n");
	for(x = 0; x < MAX_BASELINE_ENTITIES; x++){
		
		if(Data->BaselineEntity[x] != NULL){
			ClientPacket.SaveChar(0x16); // DEM Spawn Baseline
			ClientPacket.SaveShort(x);
	
			TempEntity = Data->BaselineEntity[x];
			ClientPacket.SaveByte(TempEntity->ModelIndex);
			ClientPacket.SaveByte(TempEntity->Frame);
			ClientPacket.SaveByte(TempEntity->ColorMap);
			ClientPacket.SaveByte(TempEntity->Skin);
			for(i = 0; i<3; i++){
				ClientPacket.SaveCoord(TempEntity->Location[i]);
				ClientPacket.SaveAngle(TempEntity->Angle[i]);
			}
		}
	}

	ClientPacket.SaveByte(0x19);
	ClientPacket.SaveByte(GAME_STATE_LIGHTING);

//	DEMPrintString("Binary Packet Decoded\n");
	ClientPacket.SendMessage();


}

void ProxyServerObj::SendLightingPacket() {

	int i;

	PlayerObj *TempPlayer;
//	EventTable->Print("Sending Lighting Packet\n");

	ClientPacket.Reset();	
	ClientPacket.SetHeader(MESSAGE_TYPE_FINAL);
	
	DEMPrintString("Lighting Packet Received\n");


	ClientPacket.SaveChar(0x07); // Time
	ClientPacket.SaveFloat(Data->ServerTimeStamp);

	// Send Names & Frags
	for(i = 1; i <= Data->MaxPlayers; i++) {
		TempPlayer = (PlayerObj *)Data->BaselineEntity[i]; 

		ClientPacket.SaveChar(0x0D);
		ClientPacket.SaveByte(i-1);
		ClientPacket.SaveString(TempPlayer->Name);

		ClientPacket.SaveChar(0x0E);
		ClientPacket.SaveByte(i-1);
		ClientPacket.SaveShort(TempPlayer->Frags);

		ClientPacket.SaveChar(0x11);
		ClientPacket.SaveByte(i-1);
		ClientPacket.SaveByte((TempPlayer->ShirtColor << 4) + TempPlayer->PantColor);
	}


	TempPlayer = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex]; 
	
//	ClientPacket.SaveChar(0x05); // Set view to entity #
//	ClientPacket.SaveShort(Data->BotEntityIndex);

	ClientPacket.SaveChar(0x0A); // Set angle

	for(i = 0; i < 3; i++)
		ClientPacket.SaveAngle(TempPlayer->Angle[i]);

	for(i = 0; i < MAX_STATIC_ENTITIES; i++) {
		if(Data->LightStyle[i] != NULL){
			ClientPacket.SaveChar(0x0C); // String
			ClientPacket.SaveByte(i); // String
			ClientPacket.SaveString(Data->LightStyle[i]); // String
		}
	}
	ClientPacket.SaveByte(0x19);
	ClientPacket.SaveByte(GAME_STATE_RENDER);

	DEMPrintString("Lighting Packet Decoded\n");

	ClientPacket.SendMessage();

}

void ProxyServerObj::DEMPrintString(char *String) {

	ClientPacket.SaveChar(0x08); // String
	ClientPacket.SaveString(String);
}

void ProxyServerObj::DEMSendEntityUpdate(int Index) {

	long BitMask;
	int HighByte;

	EntityObj *Entity;
	
	BitMask = 0;

	Entity = Data->BaselineEntity[Index];

//	if(Entity->ModelIndex != Entity->OldModelIndex)
		BitMask |= 0x0400;

//	if(Entity->Frame != Entity->OldFrame)
		BitMask |= 0x0040;
	
//	if(Entity->ColorMap != Entity->OldColorMap)
		BitMask |= 0x0800;

//	if(Entity->Skin != Entity->OldSkin)
		BitMask |= 0x1000;

//	if(Entity->AttackState != Entity->OldAttackState)
		BitMask |= 0x2000;

//	if(Entity->Location[0] != Entity->OldLocation[0])
		BitMask |= 0x0002;
	
//	if(Entity->Angle[0] != Entity->OldAngle[0])
		BitMask |= 0x0100;

//	if(Entity->Location[1] != Entity->OldLocation[1])
		BitMask |= 0x0004;

//	if(Entity->Angle[1] != Entity->OldAngle[1])
		BitMask |= 0x0010;
		
//	if(Entity->Location[2] != Entity->OldLocation[2])
		BitMask |= 0x0008;

//	if(Entity->Angle[2] != Entity->OldAngle[2])
		BitMask |= 0x0200;

	BitMask |= 0x80;

	if(Index > 255)
		BitMask |= 0x4000;

	HighByte = (unsigned char)((BitMask >> 8) & 0xff);

	if(HighByte != 0) {
		BitMask |= 0x0001;
		ClientPacket.SaveByte((unsigned char)(BitMask & 0xff));
		ClientPacket.SaveByte((unsigned char)(HighByte & 0xff));
	} else
		ClientPacket.SaveByte((unsigned char)(BitMask & 0xff));


	BitMask = BitMask & 0x07F;

	if(BitMask & 0x0001)
		BitMask |= HighByte << 8;

	if(BitMask & 0x4000)
		ClientPacket.SaveShort(Index);
	else
		ClientPacket.SaveByte(Index);

	if(BitMask & 0x0400)
		ClientPacket.SaveByte(Entity->ModelIndex);
	if(BitMask & 0x0040)
		ClientPacket.SaveByte(Entity->Frame);
	if(BitMask & 0x0800)
		ClientPacket.SaveByte(Entity->ColorMap);
	if(BitMask & 0x1000)
		ClientPacket.SaveByte(Entity->Skin);
	if(BitMask & 0x2000)
		ClientPacket.SaveByte(Entity->AttackState);
	if(BitMask & 0x0002)
		ClientPacket.SaveCoord(Entity->Location[0]);
	if(BitMask & 0x0100)
		ClientPacket.SaveAngle(Entity->Angle[0]);
	if(BitMask & 0x0004)
		ClientPacket.SaveCoord(Entity->Location[1]);
	if(BitMask & 0x0010)
		ClientPacket.SaveAngle(Entity->Angle[1]);
	if(BitMask & 0x0008)
		ClientPacket.SaveCoord(Entity->Location[2]);
	if(BitMask & 0x0200)
		ClientPacket.SaveAngle(Entity->Angle[2]);
}

void ProxyServerObj::CycleEvent(void *Dummy) {


	if(SocketMode == skIdle) { // Not waiting for response
		SocketMode = skWaiting;  // go ahead and set flag
								// Decode packet flips it back
		switch(ProxyMode) {
		case pmASCIIPacket:
//			EventTable->Print("Sending ASCII Packet\n");
			SendASCIIPacket();
			break;
		case pmBinaryPacket:
//			EventTable->Print("Sending Binary Packet\n");
			SendBinaryPacket();
			break;
		case pmLightingPacket:
//			EventTable->Print("Sending Lighting Packet\n");
			SendLightingPacket();
			break;
		case pmRuntimePacket:
//			EventTable->Print("Runtime Packet\n");
			SendRuntimePacket();
			SocketMode = skIdle;
			break;
		case pmIdle:
			SocketMode = skIdle;
			break;
		default:
			EventTable->Print("ERROR: Unknown proxy mode!!!\n");
		}
	}
}

// *************************************************
// *
// * Sends runtime server packet ot proxy port
// *
// *************************************************

void ProxyServerObj::SendRuntimePacket() {
	
	PlayerObj *Bot;
	int i;

	Bot = (PlayerObj *)Data->BaselineEntity[Data->BotEntityIndex];
	
	if(WatchdogCounter > WatchdogCounterMax) {
		// Delete old callback
		EventTable->Print("Client port timed out.  Resetting.....\n");
		ClientShutdown();
	} else {
	
		WatchdogCounter++;
	
		ClientPacket.Reset();	
		ClientPacket.SetHeader(MESSAGE_TYPE_UPDATE);

		ClientPacket.SaveChar(0x07); // Time
		ClientPacket.SaveFloat(Data->ServerTimeStamp);

		ClientPacket.SaveChar(0x0A); // Set angle

		for(i = 0; i < 3; i++){
			ClientPacket.SaveAngle(Bot->Angle[i]);
		}
//		EventTable->Print("Angle[0] = %f, Angle[1] = %f, Angle[2] = %f\n", Bot->Angle[0], Bot->Angle[1], Bot->Angle[2]); 
		ClientPacket.SaveChar(0x0F); // Update Client Data
		ClientPacket.SaveShort((short)0xfffC);
//		ClientPacket.SaveShort((short)0xffff);

//		ClientPacket.SaveChar((char)Bot->ViewOffset);
//		ClientPacket.SaveAngle((char)Bot->AngleOffset);

		ClientPacket.SaveAngle(Bot->ClientAngle[0]);
		ClientPacket.SaveChar((char)Bot->Velocity[0]);
		ClientPacket.SaveAngle(Bot->ClientAngle[1]);
		ClientPacket.SaveChar((char)Bot->Velocity[1]);
		ClientPacket.SaveAngle(Bot->ClientAngle[2]);
		ClientPacket.SaveChar((char)Bot->Velocity[2]);
		ClientPacket.SaveLong(Bot->Items);

		ClientPacket.SaveChar(Bot->WeaponFrame);
		ClientPacket.SaveChar(Bot->ArmorValue);
		ClientPacket.SaveChar(Bot->WeaponModel);

		ClientPacket.SaveShort(Bot->Health);
		ClientPacket.SaveChar(Bot->CurrentAmmo);
		ClientPacket.SaveChar(Bot->AmmoShells);
		ClientPacket.SaveChar(Bot->AmmoNails);
		ClientPacket.SaveChar(Bot->AmmoRockets);
		ClientPacket.SaveChar(Bot->AmmoCells);
		ClientPacket.SaveChar(Bot->Weapon);

		for(i = 0; i <= Data->LastUpdatedEntity; i++){
//			EventTable->Print("Updating Entity %d\n", Data->UpdatedEntity[i]);
			DEMSendEntityUpdate(Data->UpdatedEntity[i]);
		}
	
		ClientPacket.SendMessage();
	}

}

// *******************************
// *
// * Sends a string to the proxy port
// *
// *******************************

void ProxyServerObj::SendBroadcastMessage(char *String) {
		
	ClientPacket.Reset();	
	ClientPacket.SetHeader(MESSAGE_TYPE_FINAL);

	ClientPacket.SaveChar(0x07); // Time
	ClientPacket.SaveFloat(Data->ServerTimeStamp);

	ClientPacket.SaveChar(0x08); // Console Print
	ClientPacket.SaveString(String); // Data
	
	ClientPacket.SendMessage();

}


// *******************************
// *
// * This closes the Client runtime
// * port and gets ready for another connection
// *
// *******************************

void ProxyServerObj::ClientShutdown() {

	EventTable->DeleteCallback(SocketEventID);
	ClientPacket.Socket.ResetSocket();
	ClientPacket.ResetPacket();
	WatchdogCounter = 0;
	ClientConnected = False;
	ProxyMode = pmIdle;
	SocketMode = skIdle;
}

// *******************************
// *
// * This tells teh client that the 
// * server has shutdown
// *
// *******************************

void ProxyServerObj::SendGoodbye() {
	
	ClientPacket.Reset();	
	ClientPacket.SetHeader(MESSAGE_TYPE_UPDATE);

	ClientPacket.SaveChar(0x02); 

	ClientPacket.SendMessage();

}

/*void ProxyServerObj::GameInit() {

	SendASCIIPacket();
	SendNoOp();
	SendBinaryPacket();
	SendLightingPacket();
}
*/
void ProxyServerObj::RecvEvent(void * Dummy) {

	SocketObj *DataSocket;

	DataSocket = (SocketObj *)Dummy;
	
	// This is kinda gross
	if(DataSocket == &(ProxyInitPacket.Socket)){
//		EventTable->Print("Init Port Message\n");
		ProxyInitPacket.GetMessage();
		DecodeInitPacket();
	}
	else {
		WatchdogCounter = 0;
		ClientPacket.GetMessage();
		DecodeClientPacket();
	}

}

// *********************
// *
// * Called on exit of the EventTable
// * Disconnects from server
// *
// *********************

void ProxyServerObj::ExitEvent(void *Dummy) {

	if(ClientConnected) {
		SendBroadcastMessage("Bot Terminating\n");
		SendGoodbye();
	}
}


void ProxyServerObj::MessageEvent(ObjectEvent Event, void *Data) {

	switch(Event) {
	case oeServerOnline: // Bot connected to a Quakeserver
		ServerConnected = True;
		EventTable->Print("ProxyServer: Server Online\n");
		break;
	case oeServerOffline: // Bot disconnected from a QuakeServer
		ServerConnected = False;
		EventTable->Print("ProxyServer: Server Offline\n");
		SendGoodbye();
		ClientShutdown();
		break;
	case oeProxyPrint: // Print to proxy port
		if(ClientConnected) {
//			EventTable->Print("ProxyServer: Proxy Print\n");
			SendBroadcastMessage((char *)Data);
		}
		break;
	default:
		EventTable->Print("ProxyServer: Unknown SendMessage() Event!!!!\n");
	}

}

