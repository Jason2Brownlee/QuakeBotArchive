// Public
//#define QUAKE
#define TALK
#define ARENA // Asdf

// Private
#ifndef QUAKE
#endif
