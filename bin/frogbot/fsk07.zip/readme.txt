Frogbot Startup Kit v0.6
------------------------

For more info, go to: http://www.acc.umu.se/~khol/fsk/

Or read the index.html included in this archive

// Khol