GENEBOT QUAKEWORLD SERVER MODIFICATION
--------------------------------------
AUTHOR:            Rich Whitehouse
CONTACT:           thefatal@telefragged.com
HOMEPAGE:          http://www.telefragged.com/thefatal/
RELEASE NUMBER:    1

The source code for this binary distribution is available
from my homepage.

Usage of this program is fairly simple. Extract it to your
main Quake folder (you should already have the QuakeWorld
server executable, which is qwsv.exe in most cases). After
that, you'll have a file called botinfo.txt and a file
called qwsv_bot.exe in your main Quake folder. Just run
qwsv_bot instead of qwsv to run your server (see
http://www.quakeworld.net for info on running a QW server),
and then type addbot in the console to add a bot into the
game no matter what mod you're using. You can then use
rembot to remove bots as well. After you add a bot, it will
continue to be carried across level changes and such as
well, so you don't have to worry about that. If you want
to make the bots more custom to fit your needs, just edit
the botinfo.txt file (it's somewhat self-explanitory).

Also make sure you extracted with directory structure, so
that the skins included in the zip will extract to the
correct place (they are used by a couple bots by default
in the botinfo.txt file).

After you get the server set up, run priority.exe (which
is included in the priority.zip file which was in the zip
this file was in). I didn't write the program, but you'll
need to use it with the server or the bots will seem to
float around and lag badly.

Priority was written by Alan 'Strider' Kivlin, and all the
files from his original distribution are included in the
priority.zip file. Note that if you're running on an OS
which allows you to set program priority levels that you
won't need to run priority.exe, and you can just force
qwsv_bot.exe's priority level up manually to avoid any
problems.

Note that there are probably bugs and such in this because
I haven't had much time to tweak it out myself. If there's
something you don't like, go download the source code and
fix it yourself.

The AI for the existing bots is fairly simple as well, but
I'm looking forward to seeing if anyone changes that.
Although, the existing bots do play a very good game of
Rocket Arena. Especially on arenax.

Happy murdering.

-Rich
