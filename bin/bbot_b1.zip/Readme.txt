                   ---------------------------------------------
                   BETA1      B U D D Y     B O T          BETA1
                   ---------------------------------------------
                      Artificial Deathmatch/Teamplay Opponent


Introduction
------------

Hello all. Welcome to the BuddyBot readme file. BuddyBot is, unlike the name might 
suggest, not only a DM bot to play against, it is also a complete MOD filled with 
new game modes, weapons, items and such. This MOD allows you to play offline (saving 
a lot of money if you're a modem user), and of course, to HAVE FUN!

This Bot is different from the other bots, like the Reaperbot or the QBot. It doesn't 
use the bog standard Quake weapons, either, it uses the new weapons and spells included 
in this MOD. Hell, if it's your teammate, he'll even heal you... might even bail you 
out of trouble from time to time. Also included in the MOD are different classes to choose
from, ranging from the Hightech Marine to the Medieval Wizard, all with their own weapons,
skills and spells. Enjoy reading this file, and enjoy playing the MOD!

Also, don't forget BuddyBot has been under development for months now, and this is the 
first beta to be released on the internet. So, we expect you to enjoy this beta, but also
to send us feedback, with bug reports. We also would love to hear your opinion on the mod!

For now, though, just sit back and enjoy the readme, and then give the MOD a shot. Play a 
offline game though, because you are very unlikely to find a buddybot server already. The 
MOD is too unknown for that right now. But with some luck, some buddybot servers should begin
to emerge.

The Features
------------

- 6 classes to choose from, including Marine, Wizard, Barbarian, Healer, Specialist and Builder.

- 9 creative, imaginative and easy to use spells.

- 3 teams to join (Blue, Red and Yellow).

- 300 (!) different bot names. Thanks a lot to kewl_dude for his support on this (and other issues)!

- 5 different game modes to play in (so far), being Deathmatch, Teamplay DM, HardCoded,
  ClanWar and Domination.
  
- Skins for every class, in every color (including neutral DM color).

- Waypoints that the bots use, to nagivate their way through a level.

- Different weapon modes for some weapons, like the Shotgun.

- Introduction of the Sniper Rifle (replaces thunderbolt), which uses AP ammo.

- Full, easy to use, spell casting system (with mana).

- it's very much possible to kill someone stronger than yourself, just by using
  the right tactics, and by taking advantage of their disadvantages.

- Balanced classes.

- Advanced bot orders system (order follow, lead, guard, roam, with distances).

- Fully functional "thinking" deathmatch opponent.

- Excellent teamplay bot.

- Sometimes (like, random) bots are part of a certain clan, and will ask you to join!

- Bot makes use of spell system too!

- This bot will insult you like never seen before (kewl_dude says the Q3A bots insult you more, but we
  all know he likes talking out of his bum :)

- Easy to change, individual bot skill levels (0 = pieca, 4 = kinda tough)

- Full understanding of all weapons and items.

- Random positioning of armor and ammo, so that no game will ever be the same. 

- INDIVIDUAL bot thinking, each bots gets stats stating his accuracy, combat skills and reflexes.

- A money system, you now get money for killing, and you can use that money
  to buy stuff, like weapons, ammo and items.

- Some degree of intelligence.

- unique bot-squad forming! Bots look for friends nearby, form a squad, and 
  vote for a squad leader who then leads the squad into enemy territory!

- This is also a cooperative bot! You can now replay singleplayer levels, with
  the help of these loyal bots! They follow you around anywhere, killing monsters
  and helping you on the way! Try playing a level on nightmare skill with a bot
  by your side... that rocks!

- extensive help. Just type helpme in the console for a list of all commands

The Classes
-----------

- Marine:

 Being the high tech kinda space marine, this chap starts out with 120 health, and
 an axe, a submachinegun and a super shotgun, Grenade Launcher, AND Rocket Launcher. 
 His MAJOR advantage is having heavy weaponry right from the start... but without ammo 
 for the heavier firepower (no rockets). This is the most all-round class in the mod.
 It is best used by beginners, to get the hang of things. He can take some serious
 punishment, and all damage taken is HALVED! This makes for a powerful soldier.
 His major drawback is that he doesn't have any mana at all, but he does have a 
 floating tripmine that detonates on collision! This may sound like the best class
 in the game, but remember this : this guy HATES nails (hint hint)

- Wizard:

 This one starts with a nailgun and an axe, and has 100 health. He has, however, the
 highest mana regenerating rate of any class, and can store up to 500 mana! He also
 has possession of some very deadly attack spells. He is easily killed though, so blast
 your opponent with fireballs before he gets a shot at you. This class is great for 
 entering a room with spells blazing, and can quickly escape if needed by using his 
 Teleport spells!

- Barbarian:

 This dude can withstand MAJOR punishment. He starts out with nothing more than an axe,
 but he boasts up to 150 Health, and takes only 1/3 damage! He can also store up to 60
 mana, making for a VERY powerful class. His major drawback is that he starts with a 
 stupid axe, and is easily outgunned by other classes.

- Healer:

 Being the virtuos healer type he is, the Healer has the best healing qualities in the
 game (really?). He can restore 3 times as much health with a single spell than other 
 classes, and he's the fastest class around, too. He has only 80 health, however, and 
 start with a shotgun and an axe. He is best placed at the back of the team, healing the 
 others and casting some Ice Shards now and then.

- Specialist:

 Created to directly oppose the Marine, this is obviously the "coolest" class to play as.
 He is the only class that can use the dreaded Sniper Rifle, so watch you back when fighting
 a Specialist. He start out with an axe, a shotgun and some handgrenades to throw. He has
 a maximum of 120 health, and is very uneffective against Barbarians (hint);

- Builder:

 This guy is obviously designed to build a lot of things. He can build walls to seal off an 
 area, or he can build a Sentinel, much like a guard robot that sits there and fires and enemies.
 Building things cost money though, so think before you build.
 He has pretty good protection, and a rapid-firing Submachinegun for starters. He also has 
 a Grenade Launcher with three firing modes. An excellent defense class. Great for protecting 
 flags in Domination.
 
The Weapons
-----------

- Shotgun:

 Pretty much the same as ever, but now has an alternate firing method, which means a
 larger spread at the cost of firepower. NOTE: the Specialist has an upgraded shotgun which
 fires more pellets.

- Submachinegun:

 Only owned by the Marine and the Builder, this weapon spits out shells at a ludicrous rate. 
 It does good damage, and is best used against a bunch of enemies. It has a second, faster 
 firing mode which is less accurate. Use this weapon to kick ass in style.
 
- Super Shotgun:

 Also, has the same alternate firing mode as the normal shotgun, but now also has a cool
 new sound... i think it's a LOT better than the old one.

- Nailgun & Supernailgun:

 These remain identical, but are slightly different for the Wizard and Healer, as they fire 
 respectively fire and ice nails. The fire nails are slightly weaker than the latter, but 
 they are practically not hearable. Ice nails are stronger than normal nails.
 
- Rocket Launcher:
 
 The Rocket Launcher has seen no changes (so far);

- Grenade Launcher:

 This is the stuff! Three firing modes make up for three times as much death! There is the
 normal, 2.5 second explosion delay grenade, the 1 second delay and the ravage mode! This
 fires three grenades in quick succession, making for a very deadly weapon indeed.
 NOTE: the Specialist can throw (hand)grenades without a launcher.

- Sniper Rifle:

 Blam! Armor piercing bullets ahoy! Fire one of these babies towards an enemy head for almost
 always instant death! Takes the place of the thunderbolt. For now, it's got the looks of an 
 ordinary shotgun, but i'll make a decent model sometime. It is very powerful, however, 
 as shot is deadly (unless you got some armor). Its got some major drawbacks though, 
 like it's insanely long reload rate and the scarce supply of ammo. A headshot is almost
 always an instant kill, a barbarian has a VERY small chance of surviving one. No-one can
 possible survive two headshots, though. Also, a headshot has a different sound than normal 
 damage, it's got the most disgusting sound of brains flying all over the place :p
 It's got a cool firing sound too (and a discharing "flick" afterwards).

The Spells, Skills and Items
----------------------------

- Firebolt Spell 

 Pretty weak, but very fast and cheap in mana, so this one's good if used a lot (say around
 5 firebolts at once). It can be quite frightening for an enemy to see 5 bolts coming at him 
 at once :)

- Heal Spell

 This obviously restores health, and it does so at the cost of a lot of mana. It will fully heal
 you, provided you have enough mana. If not, it heals as much HP as possible.

- Heal Other Spell

 Exactly the same as the Heal spell, but now used to heal other individuals (ie. teammates). Point 
 it at them and cast it. They will receive a message stating you healed them, so they will probably 
 thank you for it :p
 
- Mass Heal Spell

 Only the Healer can use this powerful spell, which restores 30 HP to EVERYONE on your team,
 so use this a lot! Your teammates will be eternally in your debt (they get a message if you
 heal them).

- Ice Shards Spell

 These deep-frozen shards penetrate a target in no time, and if all shards connect, this is
 a very powerful spell. Use it freely and devastatingly.

- Fireball Spell

 Much more powerful than the firebolt spell, this one is rather expensive, and travels slower
 too. If you hit them, however, they are in a world of pain...

- Chaos Teleport Spell

 If cast, this spell will teleport you to a random location on the map. A warning though : you
 can end up *anywhere*, so also above a pool of lava! So watch it :)

- Teleport Spell
 
 This will teleport you to wherever you are pointing, so don't point this at a pool of 
 lava and cast :p

- Mine Skill

 The marine can drop a tripmine that homes in on enemies and does some damage. Great for shaking of 
 chasers. Oh yeah...

- Handgrenade Skill

 The specialist can throw grenades without a launcher, making for an handy skill.

- Wall building Skill

 This can place walls of varying strengths, ranging from a stupid weak wall to a fortress-like one.
 
- Sentinel building Skill

 This will build a sentinel, a guard droid, which costs 5000 $.
 
New features in this version
----------------------------

- Damage is now based on a type (like, shells, nails, magic, explosion) and every class reacts differently to 
  them. Check out damages.txt for more info on damage.
  
- Marine now has a submachinegun instead of a shotgun. I think it's very cool, and so should you!

- The money system is now *finally* usefull, you can now buy artifacts also, and buying stuff like shells is 
  a lot easier. Also, you can bind keys to auto-buy stuff. Example for buying 25 shells fast : 
  bind h "impulse 56;wait;impulse 2"

- You can now also buy a StatViewer. This will let you see the stats of EVERYONE by just looking at them.

- Multiple bugfixes and things i'm forgetting.

Coming Features
---------------

- Bot FACTORIES! (this is coming soon i hope)
  Imagine you can build a small army of tiny little bots that can attack the enemy!
  This is gonna be huge! (actually, they will be quite small :)

- The specialist may get a chaingun

- Manual reloading (maybe)

- following 'demo' camera (a la Duke3D demo cam, if possible)

- builder class; will be able to build walls (i hope)

- a special helmet that deflects a headshot

- "sniper" game mode

- strafing bots

- no more perfect headshot bots

- more spells

- more weapons

- more models/skins

- more levels (kewl_dude?)

- more bot quotes (kewl?)

- more options

- more powerups

- more cool stuff

- more bot names

- more bot clans

- more... 

Notes
-----

Yes, I am fully aware of the bugs this bot shows. Also, the bot seems to be rather
idiotic at times, but this is rather rare, even on the lower skill levels.

The bot will hunt your ass down, however, so don't think you can run away to
refuel, the bot *will* follow you. I will make a routine that makes the bot
run away if he is low on health.

Credits
-------

Thanks a lot to kewl_dude for his lots of help, and for his occasional bug reports, 
helping me to clean out a lot of bugs. Also thanks to him for the lots of names he supported,
as well as a lot of good ideas for the mod.

This bot is written by Parsec. You may *not*, i repeat, you may *NOT* use
this bot in your own mod, and you may not disassemble, modify or change it.
You may, however, put the bot on a CD, and distribute it, AS LONG AS YOU HAVE
MY PERMISSION. To get my permission, mail me (parsec666@hotmail.com).

Any suggestions are also welcome at the same e-mail address.
Hope you love the MOD (and bot).

Cyaz,

Parsec
