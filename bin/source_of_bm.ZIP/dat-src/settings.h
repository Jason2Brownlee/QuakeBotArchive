// Public
// #define DEBUG_
  // #define TEST1
  // #define TEST
#define CREEPCAM
#define KASCAM
#define CONSOLE
#define LETTERCODES
#define TALK
#define ARCADE
#define ARENA // Asdf
#define MANUAL




