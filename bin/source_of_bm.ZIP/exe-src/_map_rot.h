#define MAX_LIST 256

typedef struct 
{
	char *map;
} map_entry_t;

extern map_entry_t	mapentry[MAX_LIST];

void Map_List_Init(void);
void Map_List_Shutdown(void);
int Map_List_Set(int i,char *name);
int Map_List_Reset(int i);
void Map_List_Switch(int a,int b);
int Map_List_Len(void);
int Map_List_Load(FILE *f);
int Map_List_Save(FILE *f);
char *gettokstart (char *str, int req, char delim);
char *Map_GetRandomFromList(void);
int gettoklen(char *str, int req, char delim);
