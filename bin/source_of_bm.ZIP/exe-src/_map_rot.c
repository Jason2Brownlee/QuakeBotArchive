#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "quakedef.h"
//#include "common.h"
//#include "console.h"
#include "_map_rot.h"


// MAP Rotation

map_entry_t	mapentry[MAX_LIST];

void Map_List_Init(void) 
{
	int i;
	for(i=0; i < MAX_LIST; i++) 
	{
		mapentry[i].map = '\0';
	}
}


void Map_List_Shutdown(void)
{  
	int i;
	FILE *f;

	// FIXME: if the list was deleted, the changes will not be saved
	for (i=0; i < MAX_LIST; i++) 
	{
		if (mapentry[i].map)
			break;
	}
	if (i < MAX_LIST)	// the list is not empty
	{
		if (!(f = fopen(va("%s/server.ini", com_gamedir),"w"))) 
	{
			Con_Printf("Couldn't open server.ini.\n");
			return;
		}
		Map_List_Save(f);
		fclose(f);
	}
	for(i=0;i < MAX_LIST;i++) 
{
		if (mapentry[i].map)
			free(mapentry[i].map);
	}
}
			

int Map_List_Set(int i,char *name) 
{

	if (i < MAX_LIST && i >= 0) 
	{
		if (mapentry[i].map)	// (Re)allocate memory first
			free(mapentry[i].map);
		mapentry[i].map = malloc(strlen(name) + 1);
		strcpy(mapentry[i].map,name);
		return 0;  // Yay, we haven't segfaulted yet.
	}
	return 1; // Out of range
}



int Map_List_Reset (int i) 
{
	if (i < MAX_LIST && i >= 0) 
	{
		if (mapentry[i].map)
			free(mapentry[i].map);
		mapentry[i].map = '\0';
		return 0;
	}
	return 1;
}

void Map_List_Switch(int a,int b) 
{
	map_entry_t temp;
	memcpy(&temp,&mapentry[a],sizeof(temp));
	memcpy(&mapentry[a],&mapentry[b],sizeof(temp));
	memcpy(&mapentry[b],&temp,sizeof(temp));
}





int Map_List_Len (void) 
{
	int i;
	for (i = 0; i < MAX_LIST && mapentry[i].map;i++)
		;
	return i;
}



int Map_List_Load (FILE *f)
 { 
// This could get messy
	int serv = 0;
	char line[256]; /* Long lines get truncated. */
	int c = ' ';    /* int so it can be compared to EOF properly*/
	int len;
	int i;
	char *map;

	// Init again to clear the list
	while (serv < MAX_LIST)
	 {
		//First, get a line
		i = 0;
		c = ' ';
		while (c != '\n' && c != EOF) 
		{
			c = fgetc(f);
			if (i < 255) 
			{
				line[i] = c;
				i++;
			}
		}
		line[i - 1] = '\0'; // Now we can parse it
		len = gettoklen(line,1,' ');
		map = malloc(len + 1);
		strncpy(map,&line[0],len);
			map[len] = '\0';
			Map_List_Set(serv,map);
			serv++;
		} 


		if (c == EOF)  // We're done
			return 0;
      return 0;
}

int rnd_ (int n)
{
	int k = 0;
	k = rand ()%n;
	if (k > n) k = n;
	return k;
}




char *Map_GetRandomFromList(void)
{
int line1 = 0;
char line[256]; /* Long lines get truncated. */
int c = ' ';    /* int so it can be compared to EOF properly*/
int len,i,k;
char *map,*name_r;
FILE *f;
int j = 0;
int l1 = 0;
Map_List_Init();
if ((f = fopen(va("%s/server.ini", com_gamedir),"r")) != NULL) 	
	{
	while (line1 < MAX_LIST)
	 {
		//First, get a line
		i = 0;
		c = ' ';
		while (c != '\n' && c != EOF) 
		{
			c = fgetc(f);
			if (i < 255) 
			{
				line[i] = c;
				i++;
			}
		}
		line[i - 1] = '\0'; // Now we can parse it
		len = gettoklen(line,1,' ');
		map = malloc(len + 1);
		strncpy(map,&line[0],len);
		map[len] = '\0';
		Map_List_Set(line1,map);
		line1++;
		} 
	    
	}
	
while (j < MAX_LIST && mapentry[j].map[0])
 j++;

  l1 = rnd_(j);

		strncpy(mapentry[l1].map,&line[0],len);
		name_r = malloc(len + 1);
		strcpy(name_r,mapentry[l1].map);
		fclose(f);
		return name_r;

}







int Map_List_Save(FILE *f) 
	{
	int i;
	for(i=0;i < MAX_LIST;i++) 
	{
		if (mapentry[i].map)
			fprintf(f,"%s\n",
				mapentry[i].map);
	}
	return 0;
}

char *gettokstart (char *str, int req, char delim) 
{
	char *start = str;
	
	int tok = 1;

	while (*start == delim) {
		start++;
	}
	if (*start == '\0')
		return '\0';
	while (tok < req) { //Stop when we get to the requested token
		if (*++start == delim) { //Increment pointer and test
			while (*start == delim) { //Get to next token
				start++;
			}
			tok++;
		}
		if (*start == '\0') {
			return '\0';
		}
	}
	return start;
}

int gettoklen (char *str, int req, char delim) {
	char *start = 0;
	
	int len = 0;
	
	start = gettokstart(str,req,delim);
	if (start == '\0') {
		return 0;
	}
	while (*start != delim && *start != '\0') {
		start++;
		len++;
	}
	return len;
}
