#include "frogbot.h"
#include "quakedef.h"
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

FILE *logfp;
FILE *motd_file;


#define MAX_TOTAL_MOTD_LINES    100
char motd_lines[MAX_TOTAL_MOTD_LINES][90];
int motd_num_lines;
#define MAX_STR_LEN             1020
char *_logfilename;
int		fragsort[MAX_SCOREBOARD];
int		 teamsort[MAX_SCOREBOARD];
int scoreboardteams;
team_t teams[MAX_SCOREBOARD];

char	name[1024];
char	filename[100];
char tmp[1024];
qboolean doweaponupdate;
qboolean locisloaded;

char locname_buf [128];








void PF_findteammember (void)
{
	edict_t	*ent, *chain, *self;
	float	rad;
	float	*org;
	vec3_t	eorg;
	int		i, j;

	chain = (edict_t *)sv.edicts;
	self = PROG_TO_EDICT(pr_global_struct->self);
	
	org = G_VECTOR(OFS_PARM0);
	rad = G_FLOAT(OFS_PARM1);

	ent = NEXT_EDICT(sv.edicts);
	rad *= 4 * rad;

	for (i=1 ; i<sv.num_edicts ; i++, ent = NEXT_EDICT(ent))
	{
		if (ent->free)
			continue;
		if (ent->v.solid == SOLID_NOT)
			continue;

		if (strcmp(pr_strings + ent->v.classname,"frogbot"))
			continue;

		if (ent->v.realteam == self->v.realteam)
			continue;					

		for (j=0 ; j<3 ; j++)

eorg[j] = org[j] - 2 * ent->v.origin[j] - ent->v.mins[j] - ent->v.maxs[j];
		

//	eorg[j] = org[j] - (ent->v.origin[j] + (ent->v.mins[j] + ent->v.maxs[j])*0.5);		if (DotProduct (eorg, eorg) > rad)
//		if (Length(eorg) > rad)
			continue;
			
		ent->v.chain = EDICT_TO_PROG(chain);
		chain = ent;
	}

	RETURN_EDICT(chain);
}





edict_t *ED_ClientAlloc (void)
{
	int			i;
	edict_t		*e;
	int clients = 0;
	client_t *cl;

	for (i=MAX_SCOREBOARD,(cl=svs.clients+svs.maxclients) ; i>0 ; i--,cl--)
	{
		if (cl->active)
			clients++;
		//if (cl->state != cs_free && cl->isabot != 1)
		//	return NULL;

	}
	clients++;

	//for ( i=clients ; i<MAX_CLIENTS ; i++)
	for ( i=svs.maxclients ; i>clients ; i--)
	{
		e = EDICT_NUM(i);
		// the first couple seconds of server time can involve a lot of
		// freeing and allocating, so relax the replacement policy
		if (!((int)e->v.flags & FL_CLIENT) /*&& e->free && ( e->freetime < 2 || sv.time - e->freetime > 0.5 )*/ )
		{
			ED_ClearEdict (e);
			// gbl_cl_num = i;
			return e;
		}
	}
	
	// gbl_cl_num = 0;
	return NULL;
	if (i == svs.maxclients+1)
	{
		//Con_Printf ("WARNING: ED_Alloc: no free edicts\n");
		//i--;	// step on whatever is the last edict
		//e = EDICT_NUM(i);
		//SV_UnlinkEdict(e);
		// gbl_cl_num = 0;
		return NULL;
	}
	else
		sv.num_edicts++;
	e = EDICT_NUM(i);
	ED_ClearEdict (e);
	// gbl_cl_num = i;

	return e;
}












void PF_pow_(void)
{
float a,b;
a = G_FLOAT(OFS_PARM0);
b = G_FLOAT(OFS_PARM1);
G_FLOAT(OFS_RETURN) = pow(a,b);
}


void PF_botlocation(void)                  
{
char *s2;
memset(locname_buf, 0, 127);
s2 = BotLocation();
sprintf(locname_buf,"%c%c %2s",136,137,s2); // yellow,blue boxes
G_INT(OFS_RETURN) = locname_buf - pr_strings;
}

char locname_buf2 [128];
void PF_botlocation2(void)                  // just locations
{
char *s2;
memset(locname_buf2, 0, 127);
s2 = BotLocation();
sprintf(locname_buf2,"%2s",s2);
G_INT(OFS_RETURN) = locname_buf2 - pr_strings;
}


char HAPBwP_buf [128];
char tmp_buf [128];
char tmp2_buf [128];
char tmp3_buf [128];
char _buf1[128];

void PF_BotRepHABwP(void) // health,armor,best weapon,best ammo and powerups
{
char *s1,*s2,*s3,*s4,*s5,*s6;
memset(HAPBwP_buf, 0, 127);
memset(tmp_buf, 0, 127);
memset(tmp2_buf, 0, 127);
memset(tmp3_buf, 0, 127);
s1 = BotHealth();
s2 = BotArmorType();
s3= BotArmorValue();
s4 = BotBestWeapon();
s5= BotBestAmmo();
s6= BotPowerups();
sprintf(tmp_buf,"%c ",136); // yellow
strcpy(HAPBwP_buf,s1);
strcat(HAPBwP_buf,s2);
strcat(HAPBwP_buf,s3);
strcat(HAPBwP_buf,s4);
strcat(HAPBwP_buf,s5);
if (s6[0])
{
sprintf(tmp2_buf,"%c",16); // "["
sprintf(tmp3_buf,"%c",17); // "]"
strcat(HAPBwP_buf," @ ");
strcat(HAPBwP_buf,tmp2_buf);
strcat(HAPBwP_buf,s6);
strcat(HAPBwP_buf,tmp3_buf);
}
strcat(tmp_buf,HAPBwP_buf);
G_INT(OFS_RETURN) = tmp_buf - pr_strings;
}


char LocBWP_buf [128]; // loc & bestweapon
void PF_BotRepLocBWP(void) // bot will report location,best weapon and powerups
{
char *s1,*s2,*s3,*s4;
memset(LocBWP_buf, 0, 127);
memset(tmp2_buf, 0, 127);
memset(tmp3_buf, 0, 127);
s1 = BotLocation();
s2 = BotBestWeapon();
s3= BotBestAmmo();
s4 = BotPowerups();
strcpy(LocBWP_buf,s1);
strcat(LocBWP_buf,"   (" );
strcat(LocBWP_buf,s2);
strcat(LocBWP_buf,s3);
if (s4[0])
{
sprintf(tmp2_buf,"%c",16); // "["
sprintf(tmp3_buf,"%c",17); // "]"
strcat(LocBWP_buf," @ ");
strcat(LocBWP_buf,tmp2_buf);
strcat(LocBWP_buf,s4);
strcat(LocBWP_buf,tmp3_buf);
}

strcat(LocBWP_buf,")");
G_INT(OFS_RETURN) = LocBWP_buf - pr_strings;
}

char bw_buf[128];
void PF_BotBestWeapon(void) // bot will report their locations,best weapon and powerups
{
char *s1,*s2,*s3,*s4;
memset(bw_buf, 0, 127);
s1 = BotBestWeapon();
s2= BotBestAmmo();
strcpy(bw_buf,"   (");
strcat(bw_buf,s1 );
strcat(bw_buf,s2);
strcat(bw_buf,")");
G_INT(OFS_RETURN) = bw_buf - pr_strings;
}

char LHBWLoc_buf[128];
void PF_BotLHBWLoc(void) // bot will report low health,best weap.,locations
{
char *s2,*s3,*s4;
edict_t *self;
self = PROG_TO_EDICT(pr_global_struct->self);
memset(LHBWLoc_buf, 0, 127);
memset(_buf1,0,127);
s2 = BotBestWeapon();
s3= BotBestAmmo();
s4 = BotLocation();
strcpy(LHBWLoc_buf," ");
if ((int)self->v.health < 35)
{
sprintf(_buf1,"%c%c low health",135,135); // red,red
strcat(LHBWLoc_buf,_buf1);
strcat(LHBWLoc_buf,"<-> ");
strcat(LHBWLoc_buf,s4);
strcat(LHBWLoc_buf," /");
strcat(LHBWLoc_buf,s2);
strcat(LHBWLoc_buf,s3);
}
G_INT(OFS_RETURN) = LHBWLoc_buf - pr_strings;
}


char talk_buf1_ [128];
char talk_buf2_ [128];
char talk_buf3_ [128];
char talk_buf4_ [128];
char talk_buf5_ [128];
char talk_buf6_ [128];
char talk_buf7_ [128];     // ... maybe I was drunk... :)

void PF_writetime_ (void)
{
float r,writetime;
writetime = 0;
r = (rand ()&0x7fff) / ((float)0x7fff);
if (r > 0 && r < 0.05)
writetime = 3.2 + r*6;
if (r > 0.05 &&  r < 0.1)
writetime = 4.5 + r*21;
if (r > 0.1 && r < 0.15)
writetime = 2 + r*13;
if (r > 0.15 && r < 0.2)
writetime = 6 + r*8;
if (r > 0.2 && r < 0.25)
writetime = 10 + r*3;
if (r > 0.25 && r < 0.3)
writetime = 11 + r*4;
if (r > 0.3 && r < 0.35)
writetime = 9 + r*7;
if (r > 0.35 && r < 0.4)
writetime = 3 + r*19;
if (r > 0.4 && r < 0.45)
writetime = r*23 + r*15;
if (r > 0.45 && r < 0.5)
writetime = 3/(r+0.1);
if (r > 0.5 && r < 0.55)
writetime = 7 + r*2;
if (r > 0.55 && r < 0.6)
writetime = 15 + r*9;
if (r > 0.6 && r < 0.65)
writetime = 13.5 + r + r*6;
if (r > 0.65 && r < 0.7)
writetime = (3 + r*6)/(r+0.1);
if (r > 0.7 && r < 0.75)
writetime = 4 + 2*r/(0.5*r) +  r*6;
if (r > 0.75 && r < 0.8)
writetime = 7 + 2*r*6;
if (r > 0.8 && r < 0.85)
writetime = 12 + 1.3*r*6;
if (r > 0.85 && r < 0.9)
writetime = 13 + r*6;
if (r > 0.9 && r < 0.95)
writetime = 11 + r*8;
else
writetime = 5+r*5;
G_FLOAT(OFS_RETURN) = writetime;
}



void PF_TalkKillTeamMate(void)                  
{
char *s1;
memset(talk_buf1_, 0, 127);
s1 = TalkKill_TeamMate();
sprintf(talk_buf1_,"%2s",s1); 
G_INT(OFS_RETURN) = talk_buf1_ - pr_strings;
}


void PF_TalkKill(void)                  
{
char *s1;
memset(talk_buf2_, 0, 127);
s1 = TalkKill();
sprintf(talk_buf2_,"%2s",s1); 
G_INT(OFS_RETURN) = talk_buf2_ - pr_strings;
}


void PF_TalkDie(void)                  
{
char *s1;
memset(talk_buf3_, 0, 127);
s1 = TalkDie();
sprintf(talk_buf3_,"%2s",s1); 
G_INT(OFS_RETURN) = talk_buf3_ - pr_strings;
}



void PF_TalkHi(void)                  
{
char *s1;
memset(talk_buf4_, 0, 127);
s1 = TalkHi();
sprintf(talk_buf4_,"%2s",s1); 
G_INT(OFS_RETURN) = talk_buf4_ - pr_strings;
}


void PF_TalkBye(void)                  
{
char *s1;
memset(talk_buf5_, 0, 127);
s1 = TalkBye();
sprintf(talk_buf5_,"%2s",s1); 
G_INT(OFS_RETURN) = talk_buf5_ - pr_strings;
}


void PF_TalkGG(void)                  
{
char *s1;
memset(talk_buf6_, 0, 127);
s1 = TalkGG();
sprintf(talk_buf6_,"%2s",s1); 
G_INT(OFS_RETURN) = talk_buf6_ - pr_strings;
}

void PF_TalkGL(void)                  
{
char *s1;
memset(talk_buf7_, 0, 127);
s1 = TalkGL();
sprintf(talk_buf7_,"%2s",s1); 
G_INT(OFS_RETURN) = talk_buf7_ - pr_strings;
}



char _buf[MAX_OSPATH];
void PF_logfilename(void)
{
memset(_buf,0,19);
strcpy(_buf,"\\logs\\");
if (_buf[0] == 0)
{strcpy(_buf,sv.name);}
strcat(_buf,sv.name);
strcat(_buf,".log");
G_INT(OFS_RETURN) = _buf - pr_strings;
}


void PF_numteams (void)
{	
 int numb;
 Sbar_SortTeams();
 numb = scoreboardteams;
 G_FLOAT(OFS_RETURN) = numb;
}


void PF_CheckLocfile (void)
{
G_FLOAT(OFS_RETURN) = (locisloaded == true);
}

void PF_CheckWinQuake (void)   // true if winquake..
{
float n;
n = 0;
#ifdef GLQUAKE
n = 0;
#else
n = 1;
#endif
G_FLOAT(OFS_RETURN) = n;
}


void PF_manualfilename (void)
{
memset(_buf,0,MAX_OSPATH);
_buf[0] = 0;
strcpy(_buf,"map_");
strcat(_buf,sv.name);
strcat(_buf,".qc");
G_INT(OFS_RETURN) = _buf - pr_strings;
}



char _t[128];
void PF_teamname_(void)       // teamname with highest frag count..
{
scoreboard_t *s;
int i,j,k;
char buf[5];

memset(_t,0,127);
  Sbar_SortTeams();
	for (i = 0; i < scoreboardteams - 1; i++)
              {
                 	for (j = i + 1; j < scoreboardteams; j++)
                      {
          	  if (teams[teamsort[i]].frags < teams[teamsort[j]].frags) 
                                {
                      _t[0] = 0;
                      buf[4] = 0;
                      strncpy(buf,teams[teamsort[j]].team,4);
                      sprintf(_t," team %c%s%c ",16,buf,17);
	  	            }
                 else   if (teams[teamsort[i]].frags > teams[teamsort[j]].frags) 
                                {
                      _t[0] = 0;
                      buf[4] = 0;
                     strncpy(buf,teams[teamsort[i]].team,4);
                      sprintf(_t," team %c%s%c ",16,buf,17);
	  	            }
                          }
                     }

      G_INT(OFS_RETURN) = _t - pr_strings;
}


void PF_teamdiff(void)       // difference by frags between 2 teams on scoreboard
{
scoreboard_t *s;
int i,j,k;
float tfrags;

Sbar_SortTeams();
	for (i = 0; i < scoreboardteams - 1; i++)
           {
             	for (j = i + 1; j < scoreboardteams; j++)
                {
             	if (teams[teamsort[i]].frags < teams[teamsort[j]].frags) 
                      {
                        tfrags = 0;
                        tfrags =  teams[teamsort[j]].frags - teams[teamsort[i]].frags;
                      }
             else if  (teams[teamsort[i]].frags > teams[teamsort[j]].frags) 
                     {
                           tfrags = 0;
                           tfrags =  teams[teamsort[i]].frags - teams[teamsort[j]].frags;
                     }
                else
                     {
                           tfrags = 0;
                     }

                 }
             }
        
G_FLOAT(OFS_RETURN) = tfrags;
}

void PF_checkovertime(void)     // returns TRUE if overtime..
{
scoreboard_t *s;
int i,j,k;
char t[16+1];
float overtime;
overtime = 0;

if (teamplay.value != 0)
{
Sbar_SortTeams();
   if (scoreboardteams == 2)
   {
	for (i = 0; i < scoreboardteams - 1; i++)
             {
             	for (j = i + 1; j < scoreboardteams; j++)
                {
             	if (teams[teamsort[i]].frags == teams[teamsort[j]].frags) 
                      {
                       overtime = 1;
                      }
                   else
                     {
                      overtime = 0;
                     }
                 }
              }

          }
    else goto NO_TEAM_NAMES;

     
}

else if (teamplay.value == 0)
{

NO_TEAM_NAMES:

Sbar_SortFrags(true);           
  // if (scoreboardlines == 2)

  for (i=0 ; i<scoreboardlines ; i++)
      {
  		for (j=0 ; j<scoreboardlines-1-i ; j++)
                   {
         		if (cl.scores[fragsort[j]].frags == cl.scores[fragsort[j+1]].frags)
                         {
				overtime = 1;
                         }
		          else
                       {
                      overtime = 0;
                        }
	  	       }
        }

 }
G_FLOAT(OFS_RETURN) = overtime;
}

char path_[MAX_OSPATH - 1];

char *FFaLogfileName (void)
{
   
	int		i;
	unsigned char	*p;
 
          i = CL_CountPlayers();
         if ((i >= 3) && (teamplay.value == 0)) 
{
  sprintf (filename, "%s_ffa_%s",CL_PlayerName(),CL_MapName());

// Make sure the filename doesn't contain illegal characters
	for (p=filename ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"' || c=='.')
			*p = '_';
	}
sprintf(path_,"%s/stats/%s(%u)",com_gamedir,hostname.string,net_hostport);
	Sys_mkdir(path_);
	strncpy (name, va("%s/%s",path_, filename), MAX_OSPATH-1);
   COM_DefaultExtension (name, ".log");
   return name;
	
}

  return "";
}



char *DuelLogfileName (void)
{
     
	int		i;
	unsigned char	*p;
        //         Sbar_SortFrags ();

          i = CL_CountPlayers();
         if ((i == 2) && (teamplay.value == 0)) 
{
sprintf (filename, "%s_vs_%s_duel_%s",
					CL_PlayerName(),
					CL_EnemyName(),
					CL_MapName());

// Make sure the filename doesn't contain illegal characters
	for (p=filename ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"' || c=='.')
			*p = '_';
	}

	sprintf(path_,"%s/stats/%s(%u)",com_gamedir,hostname.string,net_hostport);
	
//		sprintf(path_,"%s/stats",com_gamedir);
	Sys_mkdir(path_);
	strncpy (name, va("%s/%s",path_, filename), MAX_OSPATH-1);
  COM_DefaultExtension (name, ".log");
   return name;
	
}

  return "";
}



char *TPLogfileName (void)
{
	int		i,j;
	unsigned char	*p;
i = CL_CountPlayers();

Sbar_SortTeams();
j = scoreboardteams;
 if ((i > 1) && (j == 2) && (i == 2)) 
sprintf (filename, "%s[%s]_vs_%s[%s]_teamplay_%s",
				CL_PlayerName(), // ==>
				CL_PlayerTeam(),
				CL_EnemyName(),
				CL_EnemyTeam(),
				CL_MapName());

else if ((i > 1) && (j == 2) && (i > 2)) 
sprintf (filename, "%s[%s]_vs_%s_teamplay_%s",
				CL_PlayerName(), // ==>
				CL_PlayerTeam(),
				CL_EnemyTeam(),
				CL_MapName());

else if (j != 2)
sprintf (filename, "%s_teamplay_%s",
				CL_PlayerName(), // ==>
				CL_MapName());

// Make sure the filename doesn't contain illegal characters
	for (p=filename ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"' || c=='.')
			*p = '_';
		}


sprintf(path_,"%s/stats/%s(%u)",com_gamedir,hostname.string,net_hostport);
//	sprintf(path_,"%s/stats",com_gamedir);
	Sys_mkdir(path_);
	strncpy (name, va("%s/%s",path_, filename), MAX_OSPATH-1);
   COM_DefaultExtension (name, ".log");
   return name;
	
}



char *_1LogfileName (void)
{
	int		i;
	unsigned char	*p;
          i = CL_CountPlayers();
         if (i == 1) 
{
sprintf (filename,"%s_%s",CL_PlayerName(),CL_MapName());
// Make sure the filename doesn't contain illegal characters
	for (p=filename ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"' || c=='.')
			*p = '_';
	}

sprintf(path_,"%s/stats/%s(%u)",com_gamedir,hostname.string,net_hostport);
	
//	sprintf(path_,"%s/stats",com_gamedir);
	Sys_mkdir(path_);
	strncpy (name, va("%s/%s",path_, filename), MAX_OSPATH-1);
   COM_DefaultExtension (name, ".log");
   return name;
	
}

  return "";
}




char *ArenaLogfileName (void)
{
	int		i;
	unsigned char	*p;
        //         Sbar_SortFrags ();
          i = CL_CountPlayers();
         if (i > 1) 
{
sprintf (filename, "%s_arena_%s",
					CL_PlayerName(),
					CL_MapName());
// Make sure the filename doesn't contain illegal characters
	for (p=filename ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"' || c=='.')
			*p = '_';
	}
//	sprintf(path_,"%s/stats",com_gamedir);
sprintf(path_,"%s/stats/%s(%u)",com_gamedir,hostname.string,net_hostport);
	Sys_mkdir(path_);
	strncpy (name, va("%s/%s",path_, filename), MAX_OSPATH-1);
   COM_DefaultExtension (name, ".log");
   return name;
	
}

  return "";
}


char *LastDeathLocation (void)
{
int i;
char *p;
 edict_t *self;
 self = PROG_TO_EDICT(pr_global_struct->self);
i = (int)self->v.lastdeath;
p = BotLocation();
if (i == 1)
{
 if ( (int)self->v.health > 0)
 {
strcpy(buf1," died at ");
strcat(buf1,p);
strcat(lastdeathloc,buf1);
return lastdeathloc;
  }
}
return "";
}
 

char lastdeath[MAX_LOC_NAME];
char *BotLocation (void)
{
	int		i;
	int		min_num;
	vec_t	min_dist;
	vec3_t	vec;
	vec3_t	org;
          edict_t *self;
  self = PROG_TO_EDICT(pr_global_struct->self);
  
	if (!loc_numentries)
	return "someplace";
 if (self->v.classname)
   VectorCopy(self->v.origin,org);

	for (i = 0; i < 3; i++)
		org[i] *= 8;

	min_num = 0;
	min_dist = 9999999;

	for (i = 0; i < loc_numentries; i++)
	{

//   	Con_DPrintf ("%f %f %f: %s\n", locdata[i].coord[0], locdata[i].coord[1], locdata[i].coord[2], locdata[i].name);

		VectorSubtract (org, locdata[i].coord, vec);
		if (Length(vec) < min_dist)
		{
			min_num = i;
			min_dist = Length(vec);
		}
	}
          
	return locdata[min_num].name; // name 
}


char bhealth[8];
char barmor[8];
char bshells[8];
char bnails[8];
char brockets[8];
char bcells[8];
static char bbestammo[25];

char *BotHealth (void)
{
    edict_t *self;
    self = PROG_TO_EDICT(pr_global_struct->self);
   if ( (int)self->v.health > 0)
   sprintf(buf1, "%i", (int)self->v.health);
   strcpy(bhealth,"h:");
   strcat(bhealth,buf1);
   strcat(bhealth," ");
    return bhealth;
}

char *BotArmorValue (void)
{
     edict_t *self;
        self = PROG_TO_EDICT(pr_global_struct->self);
     sprintf(buf1, "%i", (int)self->v.armorvalue);
    strcpy(barmor,buf1);
     strcat(barmor," ");
    return barmor;
}

char *BotShells (void)
{
          edict_t *self;
          self = PROG_TO_EDICT(pr_global_struct->self);
	sprintf(buf1, "%i", (int)self->v.ammo_shells);
          strcpy(bshells,buf1);
            strcat(bshells," ");
           return bshells;
}

char *BotNails (void)
{
    edict_t *self;
  self = PROG_TO_EDICT(pr_global_struct->self);
  sprintf(buf1, "%i", (int)self->v.ammo_nails);
 strcpy(bnails,buf1);
   strcat(bnails," ");
    return bnails;

}

char *BotRockets (void)
{
 edict_t *self;
    self = PROG_TO_EDICT(pr_global_struct->self);
sprintf(buf1, "%i", (int)self->v.ammo_rockets);
 strcpy(brockets,buf1);
 strcat(brockets," ");
  return brockets;

}

char *BotCells (void)
{
 edict_t *self;
    self = PROG_TO_EDICT(pr_global_struct->self);
sprintf(buf1, "%i", (int)self->v.ammo_cells);
 strcpy(bcells,buf1);
 strcat(bcells," ");
  return bcells;
}

char *BotWeapon (void)
{
   edict_t *self;
     self = PROG_TO_EDICT(pr_global_struct->self);
	if ((int)self->v.items & IT_AXE) return "axe";
	if ((int)self->v.items &  IT_SHOTGUN) return "sg:";
	if ((int)self->v.items &  IT_SUPER_SHOTGUN) return "ssg:";
	if ((int)self->v.items &  IT_NAILGUN) return "ng:";
	if ((int)self->v.items &  IT_SUPER_NAILGUN) return "sng:";
          if ((int)self->v.items &  IT_GRENADE_LAUNCHER) return "gl:";
          if ((int)self->v.items &  IT_ROCKET_LAUNCHER) return "rl:";
	if ((int)self->v.items &  IT_LIGHTNING) return "lg:";
        else return " ";
}

int	_BotBestWeapon (void)
{
      int best;
     edict_t *self;
     self = PROG_TO_EDICT(pr_global_struct->self);
      best = 0;
	if ((int)self->v.items & IT_AXE)
		best = IT_AXE;
	if ((int)self->v.items & IT_SHOTGUN && ((int)self->v.items & IT_SHELLS >= 1))
		best = IT_SHOTGUN;
	if ((int)self->v.items & IT_SUPER_SHOTGUN && ((int)self->v.items & IT_SHELLS >= 2))
		best = IT_SUPER_SHOTGUN;
	if ((int)self->v.items & IT_NAILGUN && ((int)self->v.items & IT_NAILS >= 2))
		best = IT_NAILGUN;
	if ((int)self->v.items & IT_SUPER_NAILGUN && ((int)self->v.items & IT_NAILS >= 2))
		best = IT_SUPER_NAILGUN;
	if ((int)self->v.items & IT_GRENADE_LAUNCHER && ((int)self->v.items & IT_ROCKETS >= 2))
		best = IT_GRENADE_LAUNCHER;
	if ((int)self->v.items & IT_LIGHTNING && ((int)self->v.items & IT_CELLS >= 2))
		best = IT_LIGHTNING;
	if ((int)self->v.items & IT_ROCKET_LAUNCHER && ((int)self->v.items & IT_ROCKETS >= 2))
		best = IT_ROCKET_LAUNCHER;
	return best;
}

char *BotBestWeapon (void)
{
	switch (_BotBestWeapon())
	{
	case IT_AXE: return "axe";
	case IT_SHOTGUN: return "sg:";
	case IT_SUPER_SHOTGUN: return "ssg:";
	case IT_NAILGUN: return "ng:";
	case IT_SUPER_NAILGUN: return "sng:";
	case IT_GRENADE_LAUNCHER: return "gl:";
	case IT_ROCKET_LAUNCHER: return "rl:";
	case IT_LIGHTNING: return "lg:";
	default:
		return " ";
	}
}

char *BotBestAmmo (void)
{
 edict_t *self;
     self = PROG_TO_EDICT(pr_global_struct->self);
	switch (_BotBestWeapon())
	{
	case IT_SHOTGUN: case IT_SUPER_SHOTGUN: 
		sprintf(buf1, "%i", (int)self->v.ammo_shells);
                  strcpy(bbestammo,buf1);
                    return bbestammo;
		case IT_NAILGUN: case IT_SUPER_NAILGUN:
		sprintf(buf1, "%i", (int)self->v.ammo_nails);
		 strcpy(bbestammo,buf1);
                     return bbestammo;
	case IT_GRENADE_LAUNCHER: case IT_ROCKET_LAUNCHER:
		sprintf(buf1, "%i", (int)self->v.ammo_rockets);
                   strcpy(bbestammo,buf1);
                   return bbestammo;		
	case IT_LIGHTNING:
		sprintf(buf1, "%i", (int)self->v.ammo_cells);
		 strcpy(bbestammo,buf1);
                    return bbestammo;
	default:
		return "0";
	}
}


char *BotArmorType (void)
{
    edict_t *self;
     self = PROG_TO_EDICT(pr_global_struct->self);
	if ((int)self->v.items & IT_ARMOR1)
		return "ga:";
	else if ((int)self->v.items & IT_ARMOR2)
		return "ya:";
	else if ((int)self->v.items & IT_ARMOR3)
		return "ra:";
	else
		return "a:";
}

char *BotPowerups (void)
{
      edict_t *self;
        self = PROG_TO_EDICT(pr_global_struct->self);

	buf1[0] = 0;
	if ((int)self->v.items & IT_QUAD)
                    strcat(buf1, "quad");
          if ((int)self->v.items & IT_INVULNERABILITY)
	{
		if (buf1[0])
		strcat(buf1, "/");
                    strcat(buf1, "pent");
	}

	if ((int)self->v.items & IT_INVISIBILITY)
	{
		if (buf1[0])
		strcat(buf1, "/");
		strcat(buf1, "ring");
	}
        return buf1;
}


char *entityname(void)
{
 edict_t *self;
entity_t *ent;
int i;
i = cl.num_statics;
ent = &cl_static_entities[i];
 self = PROG_TO_EDICT(pr_global_struct->self);


if (strstr(cl.model_precache[ent->baseline.modelindex]->name, "h_mega"))
return "megahealth";
if (strstr(cl.model_precache[ent->baseline.modelindex]->name, "backpack"))
return "backpack";

return "item";

}








//=====================================================
        
//           			TALKS

//======================================================


static char talk_buf[128];


char *TalkKill_TeamMate (void)
{
float msg;
int messages;
msg = (rand ()&0x7fff) / ((float)0x7fff);

messages = 20;
msg = ceil(msg*messages);
	if (msg == 1)
		{
			strcpy(talk_buf,"IDIOT BLYA......");
		     return talk_buf;
		}
		if (msg == 2)
		{
			strcpy(talk_buf,"TUPOE LAMO");
		    return talk_buf;
		}
		if (msg == 3)
		{
			strcpy(talk_buf,"KRETIN");
		     return talk_buf;
		}
		if (msg == 4)
		{
			strcpy(talk_buf,"BLYA,LOSHPED !!!!");
			  return talk_buf;
		}
		if (msg == 5)
		{
			strcpy(talk_buf,"LAMO TUPOE,BLYA......");
			return talk_buf;
		}

                 if (msg == 6)
		{
		     strcpy(talk_buf,"Nu ne debil, a ?");
		     return talk_buf;
		}
		if (msg == 7)
		{
			strcpy(talk_buf,"Pizdec.....");
		    return talk_buf;
		}
		if (msg == 8)
		{
			strcpy(talk_buf,"Sosat !!!!");
		     return talk_buf;
		}
		if (msg == 9)
		{
			strcpy(talk_buf,"Traxni menya,traxni menya :)))");
			  return talk_buf;
		}
		if (msg == 10)
		{
			strcpy(talk_buf,"   OOOOO");
			return talk_buf;
		}

              	if (msg == 11)
		{
			strcpy(talk_buf," Svoj JA !!!");
		     return talk_buf;
		}
		if (msg == 12)
		{
			strcpy(talk_buf,"Ne smeshno,debil..");
		    return talk_buf;
		}
		if (msg == 13)
		{
			strcpy(talk_buf,"Dyatel zadrochennij,MLIA..");
		     return talk_buf;
		}
		if (msg == 14)
		{
			strcpy(talk_buf,"     :(");
			  return talk_buf;
		}
		if (msg == 15)
		{
			strcpy(talk_buf,"Eto TEAMPLAY !!!");
			return talk_buf;
		}

                 if (msg == 16)
		{
		     strcpy(talk_buf," ...Ebat v ROT.. :((");
		     return talk_buf;
		}
		if (msg == 17)
		{
			strcpy(talk_buf," Mda..");
		    return talk_buf;
		}
		if (msg == 18)
		{
			strcpy(talk_buf," Ti pridurok ?");
		     return talk_buf;
		}
		if (msg == 19)
		{
			strcpy(talk_buf," .............");
			  return talk_buf;
		}
		if (msg == 20)
		{
			strcpy(talk_buf,"  U menya prosto net slov....");
			return talk_buf;
		}

		else return "IMBICIL BLIA TUPOJ...";
}


/*
char *TalkKill_TeamMate (void)
{
    char buf[1000];
    char filename[MAX_OSPATH];
    int lbuf,i;
    FILE *chat_file;

	strncpy (filename, va("%s/bottchat", com_gamedir), MAX_OSPATH-1);
	COM_DefaultExtension (filename, ".txt");
Con_DPrintf("CHAT: Reading from %s",filename);

     chat_file = fopen(filename, "rt");
        if (chat_file == NULL)
                return "Chat-file not found !!";
                
                

        motd_num_lines = 0;
        while (fgets(buf, 900, motd_file) != NULL)
        {
                lbuf = strlen(buf);
                while (buf[lbuf-1] == '\r' || buf[lbuf-1] == '\n')
                {
                        buf[lbuf-1] = 0;
                        lbuf--;
                }

                if (lbuf > 40)
                        buf[40] = 0;

                strcpy(motd_lines[motd_num_lines], buf);
                 motd_num_lines++;

                if (motd_num_lines >= MAX_TOTAL_MOTD_LINES)
                        break;
        }

        fclose(motd_file);
}
*/




















char *TalkDie (void)
{
float msg;
int messages;
msg = (rand ()&0x7fff) / ((float)0x7fff);

  messages = 40; // number of messages;
	msg = ceil(msg *messages);
		if (msg == 1)
		{
			strcpy(talk_buf,"Damn");
            return talk_buf;
		}
		if (msg == 2)
		{
			strcpy(talk_buf,":(((");
            return talk_buf;
		}
		if (msg == 3)
		{
			strcpy(talk_buf,"LoL,Razdvin teper nogi...");
            return talk_buf;
		}
		if (msg == 4)
		{
		       strcpy(talk_buf,"there is a good day to die");
              return talk_buf;
		}
		if (msg == 5)
		{
			strcpy(talk_buf,"luck");
            return talk_buf;
		}
		if (msg == 6)
		{
			strcpy(talk_buf,"lucky son of the bitch...");
            return talk_buf;
		}
		if (msg == 7)
		{
			strcpy(talk_buf,"ROTFL,Eptit...");
            return talk_buf;
		}
		if (msg == 8)
		{
			strcpy(talk_buf,"sosat moj chlen.. ;-( ]");
            return talk_buf;
		}
		if (msg == 9)
		{
			strcpy(talk_buf,"fuck....");
             return talk_buf;
		}
		if (msg == 10)
		{
			strcpy(talk_buf,"MUDAk");
           return talk_buf;
		}
	if (msg == 11)
		{
	strcpy(talk_buf," Suck my...");
            return talk_buf;
		}
		if (msg == 12)
		{
			strcpy(talk_buf," Lost QUAD at %l....");
            return talk_buf;
		}
		if (msg == 13)
		{
			strcpy(talk_buf," Lost PENT at %l..");
            return talk_buf;
		}
		if (msg == 14)
		{
		       strcpy(talk_buf," AAAAAAAA");
              return talk_buf;
		}
		if (msg == 15)
		{
			strcpy(talk_buf," EBTIT.......");
            return talk_buf;
		}
		if (msg == 16)
		{
			strcpy(talk_buf," POSOSO ?");
            return talk_buf;
		}
		if (msg == 17)
		{
			strcpy(talk_buf," SUKA !!!!!!!!!");
            return talk_buf;
		}
		if (msg == 18)
		{
			strcpy(talk_buf," ..;-(~~]");
            return talk_buf;
		}
		if (msg == 19)
		{
			strcpy(talk_buf," Bury me in the hole..");
             return talk_buf;
		}
		if (msg == 20)
		{
			strcpy(talk_buf," Vot osel...");
           return talk_buf;
		}

	if (msg == 21)
		{
			strcpy(talk_buf," Cool... net slov..");
            return talk_buf;
		}
		if (msg == 22)
		{
			strcpy(talk_buf,":()");
            return talk_buf;
		}
		if (msg == 23)
		{
			strcpy(talk_buf,"Razdvin nogi..");
            return talk_buf;
		}
		if (msg == 24)
		{
		       strcpy(talk_buf," Nagnis teper ..");
              return talk_buf;
		}
		if (msg == 25)
		{
          	strcpy(talk_buf,"luck&fuck");
            return talk_buf;
		}
		if (msg == 26)
		{
			strcpy(talk_buf," ROFL ....");
            return talk_buf;
		}
		if (msg == 27)
		{
			strcpy(talk_buf," ne nado bolshe.. :)");
            return talk_buf;
		}
		if (msg == 28)
		{
			strcpy(talk_buf," shut up");
            return talk_buf;
		}
		if (msg == 29)
		{
			strcpy(talk_buf," nu ti i mudila !!!!");
             return talk_buf;
		}
		if (msg == 30)
		{
			strcpy(talk_buf," ~E");
           return talk_buf;
		}

                  if (msg == 31)
		{
			strcpy(talk_buf," Formu poteryal..");
            return talk_buf;
		}
		if (msg == 32)
		{
			strcpy(talk_buf,"MLIA");
            return talk_buf;
		}
		if (msg == 33)
		{
			strcpy(talk_buf," Nasha Udacha ne mozhet bit vechnoj...");
            return talk_buf;
		}
		if (msg == 34)
		{
		       strcpy(talk_buf,"...for Adun..");
              return talk_buf;
		}
		if (msg == 35)
		{
			strcpy(talk_buf," Ne pervij den sosem terranam..");
            return talk_buf;
		}
		if (msg == 36)
		{
			strcpy(talk_buf," blia on silnij..");
            return talk_buf;
		}
		if (msg == 37)
		{
			strcpy(talk_buf," daaa...");
            return talk_buf;
		}
		if (msg == 38)
		{
			strcpy(talk_buf," SKOTINA !!!!");
            return talk_buf;
		}
		if (msg == 39)
		{
			strcpy(talk_buf," L8rrrrrr...");
             return talk_buf;
		}
		if (msg == 40)
		{
			strcpy(talk_buf,"           Grr...");
           return talk_buf;
		}
   else   return " fuck";
}




char *TalkKill (void)
{
float msg;
int messages;
msg = (rand ()&0x7fff) / ((float)0x7fff);
messages = 40;
		msg = ceil(msg * messages);
		if (msg == 1)
		{
			strcpy(talk_buf,"hehe");
             return talk_buf;
		}
		if (msg == 2)
		{
			strcpy(talk_buf,":-)");
             return talk_buf;
		}
		if (msg == 3)
		{
			strcpy(talk_buf,"hah");
             return talk_buf;
		}
		if (msg == 4)
		{
			strcpy(talk_buf,"ROTFL");
            return talk_buf;
		}
		if (msg == 5)
		{
			strcpy(talk_buf,"gotcha");
            return talk_buf;
		}
          	if (msg == 6)
		{
	strcpy(talk_buf," Ne rasstraivajsya - vozmi VAZELIN");
            return talk_buf;
		}
		if (msg == 7)
		{
			strcpy(talk_buf,"Good guy - dead guy !!");
            return talk_buf;
		}
		if (msg == 8)
		{
			strcpy(talk_buf," Igrat nauchis,sosunok..");
            return talk_buf;
		}
		if (msg == 9)
		{
		       strcpy(talk_buf," mozgov ne xvataet ?");
              return talk_buf;
		}
		if (msg == 10)
		{
			strcpy(talk_buf," Imbecil tupoj..");
            return talk_buf;
		}
		if (msg == 11)
		{
			strcpy(talk_buf," :~))");
            return talk_buf;
		}
		if (msg == 12)
		{
			strcpy(talk_buf," <|>");
            return talk_buf;
		}
		if (msg == 13)
		{
			strcpy(talk_buf," Chitaj MANUAL po igre, idiot..");
            return talk_buf;
		}
		if (msg == 14)
		{
			strcpy(talk_buf," Weaker");
             return talk_buf;
		}
		if (msg == 15)
		{
			strcpy(talk_buf," LOL");
           return talk_buf;
		}


	if (msg == 16)
		{
			strcpy(talk_buf,"ROFL :~))");
            return talk_buf;
		}
		if (msg == 17)
		{
			strcpy(talk_buf,":<)))))))))");
            return talk_buf;
		}
		if (msg == 18)
		{
			strcpy(talk_buf," SOSOK !!");
            return talk_buf;
		}
		if (msg == 19)
		{
		       strcpy(talk_buf," Butchered at birth..");
              return talk_buf;
		}
		if (msg == 20)
		{
			strcpy(talk_buf,"I am GOD !!!");
            return talk_buf;
		}
		if (msg == 21)
		{
			strcpy(talk_buf," GOD SAVE THE QUEEN !!");
            return talk_buf;
		}
		if (msg == 22)
		{
			strcpy(talk_buf," Don't worry,just RELAX and do nothing");
            return talk_buf;
		}
		if (msg == 23)
		{
			strcpy(talk_buf," Kruto ti OTSOSAL,chuvak !!!");
            return talk_buf;
		}
		if (msg == 24)
		{
			strcpy(talk_buf,"~~~~VOT ETO BILO PIZDATO~~~~");
             return talk_buf;
		}
		if (msg == 25)
		{
			strcpy(talk_buf," DA DA DA !!!");
           return talk_buf;
		}
           if (msg == 26)
		{
			strcpy(talk_buf," (')_(')");
            return talk_buf;
		}
		if (msg == 27)
		{
			strcpy(talk_buf," RTFM,baby,RTFM..");
            return talk_buf;
		}
		if (msg == 28)
		{
			strcpy(talk_buf," Wanna suck my dick ? :)");
            return talk_buf;
		}
		if (msg == 29)
		{
			strcpy(talk_buf," O DA !!");
             return talk_buf;
		}
		if (msg == 30)
		{
			strcpy(talk_buf,";<~(,)");
           return talk_buf;
		}

	else	 return " :)";		
}


char *TalkHi (void)
{
float msg;
int messages;
msg = (rand ()&0x7fff) / ((float)0x7fff);

	messages = 15;
		msg = ceil(msg * messages);
		if (msg == 1)
		{
               strcpy(talk_buf,"hi!");
               return talk_buf;
		}
		if (msg == 2)
		{
                strcpy(talk_buf,"...KUDA ja popal... ;-{]");
               return talk_buf;
		}
		if (msg == 3)
		{
			strcpy(talk_buf,"PORVEM !!!!!!!!!");
            return talk_buf;
		}
		if (msg == 4)
		{
            	strcpy(talk_buf,"yeah");
                return talk_buf;
		}
		if (msg == 5)
		{
		
              	strcpy(talk_buf,"heheee");
               return talk_buf;
		}

                   if (msg == 6)
		{
               strcpy(talk_buf," ZDOROVA PANKI !");
               return talk_buf;
		}
		if (msg == 7)
		{
                strcpy(talk_buf," hi all");
               return talk_buf;
		}
		if (msg == 8)
		{
			strcpy(talk_buf," hi guyz");
            return talk_buf;
		}
		if (msg == 9)
		{
            	strcpy(talk_buf," SOSNEM ?");
                return talk_buf;
		}
		if (msg == 10)
		{
              	strcpy(talk_buf," Ja ne v nastroenii segodnya, idi naxuj..");
               return talk_buf;
		}
             if (msg == 11)
		{
               strcpy(talk_buf," Poshli vse naxuj,ja spat xochu !!");
               return talk_buf;
		}
		if (msg == 12)
		{
                strcpy(talk_buf," ZDAROV");
               return talk_buf;
		}
		if (msg == 13)
		{
			strcpy(talk_buf," SOSAT");
            return talk_buf;
		}
		if (msg == 14)
		{
            	strcpy(talk_buf,"VESELO,pizdec..");
                return talk_buf;
		}
		if (msg == 15)
		{
		
              	strcpy(talk_buf,"Otstoj..");
               return talk_buf;
		}
        else   return "hello,bitch";				
}




char *TalkBye (void)
{
float msg;
int messages;
msg = (rand ()&0x7fff) / ((float)0x7fff);
		messages = 5;
		msg = ceil(msg * messages);
		if (msg == 1)
		{
			strcpy(talk_buf,"bye!");
           return talk_buf;
		}
		if (msg == 2)
		{
			strcpy(talk_buf,"cya!");
              return talk_buf;
		}
		if (msg == 3)
		{
			strcpy(talk_buf,"l8r");
             return talk_buf;
		}
		if (msg == 4)
		{
			strcpy(talk_buf,"yeah");
            return talk_buf;
		}
		if (msg == 5)
		{
			strcpy(talk_buf,"well...next time... !");
            return talk_buf;
		}
 else return "shit..";
}
 


char *TalkGG (void)  // about good game..
{
float msg;
int messages;
msg = (rand ()&0x7fff) / ((float)0x7fff);
	messages = 20;
		msg = ceil(msg * messages);
		if (msg == 1)
		{
			strcpy(talk_buf," gg");
                           return talk_buf;
		}
		if (msg == 2)
		{
			strcpy(talk_buf," want some more ?");
              return talk_buf;
		}
		if (msg == 3)
		{
			strcpy(talk_buf,"good game..");
             return talk_buf;
		}
		if (msg == 4)
		{
			strcpy(talk_buf," suck my dick");
            return talk_buf;
		}
		if (msg == 5)
		{
			strcpy(talk_buf,"well...next time... !");
            return talk_buf;
		}
              	if (msg == 6)
		{
			strcpy(talk_buf,"I'll kill you next time,motherfucker...");
                           return talk_buf;
		}
		if (msg == 7)
		{
			strcpy(talk_buf,"this map rocks ");
              return talk_buf;
		}
		if (msg == 8)
		{
			strcpy(talk_buf,"heh :)");
             return talk_buf;
		}
		if (msg == 9)
		{
			strcpy(talk_buf,"no one steals our chicks, and lives..");
            return talk_buf;
		}
		if (msg == 10)
		{
			strcpy(talk_buf,"there's no end !!!");
            return talk_buf;
		}
          	if (msg == 11)
		{
			strcpy(talk_buf," that was good game");
                           return talk_buf;
		}
		if (msg == 12)
		{
			strcpy(talk_buf," I want some more !!!!");
              return talk_buf;
		}
		if (msg == 13)
		{
			strcpy(talk_buf," another game ?");
             return talk_buf;
		}
		if (msg == 14)
		{
			strcpy(talk_buf," that was funny");
            return talk_buf;
		}
		if (msg == 15)
		{
			strcpy(talk_buf," another one brick in the wall..");
            return talk_buf;
		}
	if (msg == 16)
		{
			strcpy(talk_buf," I see you blown, baby");
                           return talk_buf;
		}
		if (msg == 17)
		{
			strcpy(talk_buf," poor twisted me..");
              return talk_buf;
		}
		if (msg == 18)
		{
			strcpy(talk_buf,"I chew on sufer, I chew on agony..");
             return talk_buf;
		}
		if (msg == 19)
		{
			strcpy(talk_buf," and swallow whole the pain..");
            return talk_buf;
		}
		if (msg == 20)
		{
			strcpy(talk_buf," bleeding me... ");
            return talk_buf;
		}

 else return "SOSO";
} 


char *TalkGL (void)  // about good luck during countdown timer..
{
float msg;
int messages;
msg = (rand ()&0x7fff) / ((float)0x7fff);
		messages = 20;
		msg = ceil(msg * messages);
		if (msg == 1)
		{
			strcpy(talk_buf," gl");
                           return talk_buf;
		}
		if (msg == 2)
		{
			strcpy(talk_buf," gl,all..");
              return talk_buf;
		}
		if (msg == 3)
		{
			strcpy(talk_buf,"good lag !!");
             return talk_buf;
		}
		if (msg == 4)
		{
			strcpy(talk_buf," I wish you good lag,all :))");
            return talk_buf;
		}
		if (msg == 5)
		{
			strcpy(talk_buf," life is sucks,then you die..");
            return talk_buf;
		}
              	if (msg == 6)
		{
			strcpy(talk_buf," fuckin timer..");
                           return talk_buf;
		}
		if (msg == 7)
		{
			strcpy(talk_buf,"timer started !! ");
              return talk_buf;
		}
		if (msg == 8)
		{
			strcpy(talk_buf,"and what ?");
             return talk_buf;
		}
		if (msg == 9)
		{
			strcpy(talk_buf," catch my bleeding dick !");
            return talk_buf;
		}
		if (msg == 10)
		{
			strcpy(talk_buf,"i can't beleive in it......");
            return talk_buf;
		}
          	if (msg == 11)
		{
			strcpy(talk_buf," overtime ?");
                           return talk_buf;
		}
		if (msg == 12)
		{
                     if (overtime.value == 0 || overtime.value == 1)
             	strcpy(talk_buf," I *want* SUDDEN DEATH");
                    else
                    strcpy(talk_buf," Why overtime ? :)");
                    return talk_buf;
		}
		if (msg == 13)
		{
	strcpy(talk_buf," I am **the BEST**");
             return talk_buf;
		}
		if (msg == 14)
		{
	strcpy(talk_buf," my dick is thicker then yours :))");
            return talk_buf;
		}
		if (msg == 15)
		{
	strcpy(talk_buf," Aint gonna waste my hate..");
            return talk_buf;
		}
	if (msg == 16)
		{
			strcpy(talk_buf," sucker..");
                           return talk_buf;
		}
		if (msg == 17)
		{
			strcpy(talk_buf," what did you say ?");
              return talk_buf;
		}
		if (msg == 18)
		{
			strcpy(talk_buf," Hero of the day, eh ?");
             return talk_buf;
		}
		if (msg == 19)
		{
			strcpy(talk_buf," King nothing..");
            return talk_buf;
		}
		if (msg == 20)
		{
			strcpy(talk_buf," Bite me, bitch.. ");
            return talk_buf;
		}

 else return ":-()";
}
 


int	CL_CountPlayers ()
{
	int	i, count;
	count = 0;
	for (i = 0; i < cl.maxclients ; i++) 
         {
        if (cl.scores[i].name[0] && !cl.scores[i].spectator)
		count++;
	}

	return count;
}


int	CL_CountTeamMembers ()
{
      char *myteam;
	static char enemyteam[15];
	int	i, count;
	count = 0;
      myteam = CL_PlayerTeam();

	for (i = 0; i < cl.maxclients ; i++) 
         {
	strcpy (enemyteam, cl.scores[i].teamname);
        if (cl.scores[i].name[0] && cl.scores[i].teamname[0] && !cl.scores[i].spectator)
		if (strcmp(myteam, enemyteam) == 0) 
		count++;
	}

	return count;
}




int	CL_CountTeams ()
{
	int	i,k, count;
      team_t *tm; 
	count = 0;
Sbar_SortTeams();
	for (i = 0; i < scoreboardteams; i++)
      {
        k = teamsort[i];
         tm = teams + k;
         if (tm->team[0] && !cl.scores[i].spectator)
			count++;
	}
	return count;
}







char *CL_EnemyTeam ()
{
	int			i;
	char		*myteam;
	static char	enemyteam[15];
    
	myteam = CL_PlayerTeam();

	for (i = 0; i < cl.maxclients ; i++) 
          {
		if (cl.scores[i].teamname[0] && !cl.scores[i].spectator)
		{
			strcpy (enemyteam, cl.scores[i].teamname);
			if (strcmp(myteam, enemyteam) != 0)
				return enemyteam;
		}
	}
	return "";
}

char *CL_PlayerName ()
{
	static char	myname[32];
          int i,k;
          scoreboard_t *s;
          Sbar_SortFrags(true);
     for (i = 0; i < scoreboardlines; i++)
      {
        k = fragsort[i];
         s = &cl.scores[k];
        if (s->name[0] && !s->spectator)
        {
        strcpy (myname, s->name);
         return myname;
         }
      }
        	return "";
}


char *CL_PlayerTeam ()
{
	static char	myteam[15];
          team_t *tm;
          int i,k;
          Sbar_SortTeams();

  for (i = 0; i < scoreboardteams; i++)
    {
		k = teamsort[i];
		tm = teams + k;
                    strcpy (myteam, tm->team);
                    return myteam;
    }
     return "";
}

char *CL_EnemyName ()
{
	int			i;
	char		*myname;
	static char	enemyname[512];

	myname = CL_PlayerName ();

	for (i = 0; i < cl.maxclients ; i++) 
             {
		if (cl.scores[i].name[0] && !cl.scores[i].spectator)
		{
			strcpy (enemyname,cl.scores[i].name);
			if (strcmp(enemyname, myname) != 0)
				return enemyname;
		}
	}
	return "";
}


char *CL_MapName ()
{
	static char mapname[15];
	strcpy (mapname,sv.name);
	return mapname;
}





// Append log by writting players weapon effi..
void _appendLog(FILE *lfile)
{
char y[3] = "%";
static char _wtitle[40] = "# |  bul |  nls |  rox |  lg  | name ";
static char _wline[52] = "--+------+------+------+------+------------------";
char netname[32];
unsigned char *p;
int i,j,k,l;
float _bul,_lg,_nls,_rox;
scoreboard_t	*s;


if (!lfile)
{
SV_BroadcastPrintf("Error writting weapon efficiency\n");
return;
}

doweaponupdate = 0;

fprintf(lfile,"bul  - bullet efficiency\n");
fprintf(lfile,"nls  - nail efficiency\n");
fprintf(lfile,"rox  - rocket efficiency\n");
fprintf(lfile,"lg   - lightning gun efficiency\n");

fprintf(lfile,"\n%s\n",_wtitle);
fprintf(lfile,"%s\n",_wline);
Sbar_SortFrags(true);
l = scoreboardlines;
for (i=0 ; i<l ; i++)
{
	k = fragsort[i];
	s = &cl.scores[k];
	if (!s->name[0])
	continue;
		if (s->spectator)
			continue;

	_nls = s->nail_eff;
	_bul = s->bul_eff;
		_rox = s->rock_eff;
			_lg = s->lg_eff;

	if (_bul < 0)
	_bul = 0;
	 if (_rox < 0)
	_rox = 0;
	if (_lg < 0)
	_lg = 0;
	 if (_nls < 0)
	_nls = 0;

   if (k == cl.viewentity - 1)
    {
        strcpy(netname,"[");
        strcat(netname,s->name);
        strcat(netname,"]");
   }
 else
       strcpy(netname,s->name);
      for (p=netname ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"')
			*p = '_';
		}
if (netname[0])
    fprintf(lfile,"%2i|%5.1f%s|%5.1f%s|%5.1f%s|%5.1f%s| %s\n",i+1,_bul,y,_nls,y,_rox,y,_lg,y,netname);
   }
fprintf(lfile, "\n\n");
}









void _writelog(void)
{
char *mapname;
char y[3] = "%";
static char _title[70] = "# |Frags|Deaths|Suic|Rank| Effi |Time|Ping|Name";
static char _1title[15] = "Time|Ping|Name";
static char arenatitle[60] = "# |Frags|Deaths|Suic|Rank| Effi |Time|Ping|Name";
static char tptitle1[60] = "Low/Avg/High| Team |Total|Blunders|Players";
static char tptitle2[70] = "# |Frags|Deaths|Suic|Rank| Effi |Time| Team |Ping|Name";
static char _linetp2[89] = "--+-----+------+----+----+------+----+------+----+------------------"; // teamplay..
static char _line1[35] = "----+----+------------------"; // 1 player

static char _arenaline[75] = "--+-----+------+----+----+------+----+----+------------------";
static char _linetp[65] = "------------+------+-----+--------+-------"; //low/avg/h..
static char _lineffa[75] = "--+-----+------+----+----+------+----+----+------------------";
static char damage[24] = "(damage frags enabled)";
char netname[32];
char teamname1[16];
char teamname2[16];
unsigned char *p,*q;
int i,j,k,l,m,m1,o,rank,ping,ptotal,plow,pavg,phigh,sum,frags,deaths,suicides,tmfrags,ct,players,blunders,r_,r_max;
double _time;
float eff;
time_t  ltime;
team_t *tm;
scoreboard_t	*s;
time( &ltime );



mapname = CL_MapName();
m = 0;
m = CL_CountPlayers();

/*
if (teamplay.value != 0){
m1 = CL_CountTeams();}
*/


Sbar_SortFrags(true);
if (teamplay.value != 0)
Sbar_SortTeams();

if ((teamplay.value != 0) && (m > 1) && (!pr_global_struct->game_arena))
_logfilename = TPLogfileName ();

if ((m == 2) && (teamplay.value == 0) && (!pr_global_struct->game_arena))
_logfilename = DuelLogfileName ();

if (m == 1)
_logfilename = _1LogfileName ();

if ((m >= 3) && (teamplay.value == 0) && (!pr_global_struct->game_arena))
_logfilename = FFaLogfileName ();

if (pr_global_struct->game_arena)
_logfilename = ArenaLogfileName ();

// else _logfilename = _1LogfileName (); // ??

if (cls.state != ca_connected) 
	{
Con_Printf ("Can't 'writelog',not connected\n");
return;
	}

logfp = fopen(_logfilename, "ab"); // "wb"

if (!logfp)
	{
SV_BroadcastPrintf("Error writting log file %s\n", _logfilename);
return;
	}

SV_BroadcastPrintf("\nWritting log  %s..",_logfilename);

if ((strstr(_logfilename,"_ffa_")) || (strstr(_logfilename,"_duel_")) || (strstr(_logfilename,"_arena_")) || (strstr(_logfilename,"_teamplay_"))) 
{
// fprintf(logfp,"Detailed Stats for level %s (%s)\n",mapname,cl.levelname);
fprintf(logfp,"Date : %s",ctime( &ltime ));

if (pr_global_struct->game_damage)
fprintf(logfp,"Deathmatch : %i%3s\n",(int)deathmatch.value,damage);
else
fprintf(logfp,"Deathmatch : %i%\n",(int)deathmatch.value);

if (teamplay.value != 0)
fprintf(logfp,"Teamplay : %i\n",(int)teamplay.value);
if (timelimit.value != 0)
fprintf(logfp,"Timelimit : %i\n",(int)timelimit.value);
if (fraglimit.value != 0)
fprintf(logfp,"Fraglimit : %i\n",(int)fraglimit.value);
if (overtime.value != 0)
	{
if ((overtime.value == 1) && exttime.value)
fprintf(logfp,"Overtime : 1 (+%i min.)\n",(int)exttime.value);
else if (overtime.value == 2)
fprintf(logfp,"Overtime : SUDDEN DEATH\n");
	}
if (!pr_global_struct->game_disable_powerups && pr_global_struct->game_drop)
fprintf(logfp,"Powerups : ALL(DROP)\n");
else if (!pr_global_struct->game_disable_powerups)
fprintf(logfp,"Powerups : ALL\n");

if (pr_global_struct->game_enable_runes && pr_global_struct->game_not_rune_rj)
fprintf(logfp,"Runes : ALL\n");
else if (pr_global_struct->game_enable_runes)
fprintf(logfp,"Runes : ALL(RJ)\n");

}
else
fprintf(logfp,"Date : %s",ctime( &ltime ));


// =======> FFA
if ((strstr(_logfilename,"_ffa_")) || (strstr(_logfilename,"_duel_")))
{
fprintf(logfp,"\n%s\n",_title);
fprintf(logfp,"%s\n",_lineffa);



Sbar_SortFrags(true);
l = scoreboardlines;


for (i=0 ; i<l ; i++)
{
	k = fragsort[i];
	s = &cl.scores[k];
	if (!s->name[0])
	continue;
		if (s->spectator)
			continue;
         frags = s->frags;
         deaths = s->deaths;
         suicides = s->suicides;
         ping = s->ping;
         ct = s->connect_time;
         rank = frags - deaths;
         sum = frags + deaths;
          _time = (int)((realtime - ct)/60.0);
	if (sum == 0)
	sum = 1;
	eff = (float)((double)frags*100.0)/(double)(sum);
	 if (eff < 0)
	 eff = 0;
           if (frags < 0)
           eff = 0;

   if (k == cl.viewentity - 1)
    {
        strcpy(netname,"[");
        strcat(netname,s->name);
        strcat(netname,"]");
   }
 else
       strcpy(netname,s->name);
      for (p=netname ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"')
			*p = '_';
							}
if (netname[0])
    fprintf(logfp,"%2i|%5i|%6i|%4i|%4i|%5.1f%s|%4d|%4i| %s\n",i+1,frags,deaths,suicides,rank,(float)eff,y,(int)_time,ping,netname);
   }
// fprintf(logfp,"%s\n",_lineffa);
fprintf(logfp, "\n");
_appendLog(logfp);
goto flush;
}




  


// =================> ARENA

else if (strstr(_logfilename,"_arena_"))
{
   if (pr_global_struct->game_arena)
   {
r_ = pr_global_struct->round;
r_max = pr_global_struct->rounds;
fprintf(logfp,"Rounds played : %i (default = %i)\n",r_,r_max);
fprintf(logfp,"\n%s\n",arenatitle);
fprintf(logfp,"%s\n",_arenaline);

Sbar_SortFrags(true);
l = scoreboardlines;
for (j=0 ; j<l ; j++)
    {
          k = fragsort[j];
	s = &cl.scores[k];
	if (!s->name[0])
	continue;
		if (s->spectator)
			continue;
         frags = s->frags;
         deaths = s->deaths;
         suicides = s->suicides;
         ping = s->ping;
         ct = s->connect_time;
         rank = frags - deaths;
         sum = frags + deaths;
         _time = (int)((realtime - ct)/60.0);
	if (sum == 0)
	sum = 1;
	eff = (float)((double)frags*100.0)/(double)(sum);
	 if (eff < 0)
	 eff = 0;
           if (frags < 0)
           eff = 0;
 if (k == cl.viewentity - 1)
    {
        strcpy(netname,"[");
        strcat(netname,s->name);
        strcat(netname,"]");
   }
 else
       strcpy(netname,s->name);
      for (p=netname ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"')
			*p = '_';
	}
if (netname[0])
   fprintf(logfp,"%2i|%5i|%6i|%4i|%4i|%5.1f%s|%4d|%4i| %s\n",j+1,frags,deaths,suicides,rank,(float)eff,y,(int)_time,ping,netname);



     }
// fprintf(logfp,"%s\n",_arenaline);
 fprintf(logfp, "\n");
goto flush;
  }
}



  // ===========> TEAMPLAY

else if (strstr(_logfilename,"_teamplay_"))
{
 if (teamplay.value != 0)
  {
Sbar_SortTeams();
o = scoreboardteams;
	if (o > 0)
	{
fprintf(logfp,"\n%s\n",tptitle1);
fprintf(logfp,"%s\n",_linetp);
for (j=0 ; j<o ; j++)
		{
     k = teamsort[j];
     tm = teams  + k;
     if (!tm->team[0])
	continue;
     tmfrags = tm->frags;
     blunders = tm->blunders;
     plow = tm->plow;
if (plow < 0 || plow > 999)
      plow = 999;
     phigh = tm->phigh;
if (phigh < 0 || phigh > 999)
     phigh = 999;
     players = tm->players;
     ptotal = tm->ptotal;
     if (!players)	 pavg = 999;
else	 pavg = ptotal/players;
if (pavg < 0 || pavg > 999)
pavg = 999;

if (tm->team[0])
{
 if (k == cl.viewentity - 1)
    {
        strcpy(teamname2,"[");
        strcat(teamname2,tm->team);
        strcat(teamname2,"]");
   }
 else
  strcpy(teamname2,tm->team);
}
else strcpy(teamname2,"    ");

     for (p=teamname2 ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (/*c<=' ' ||*/c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"')
			*p = '_';
	 }


fprintf(logfp,"%3i/%3i/%4i|%6s|%5i|%8i|%7i\n",plow,pavg,phigh,teamname2,tmfrags,blunders,players);


// ---/---/----+------+-----+--------+-------
    }
}


// fprintf(logfp,"\n");
fprintf(logfp,"\n%s\n",tptitle2);
fprintf(logfp,"%s\n",_linetp2);

Sbar_SortFrags(true);
l = scoreboardlines;
for (j=0 ; j<l; j++)
     {
          k = fragsort[j];
	s = &cl.scores[k];
	if (!s->name[0])
	continue;
		if (s->spectator)
			continue;
         frags = s->frags;
         deaths = s->deaths;
         suicides = s->suicides;
         ping = s->ping;
         ct = s->connect_time;
           rank = frags - deaths;
         sum = frags + deaths;
         _time = (int)((realtime - ct)/60.0);
	if (sum == 0)
	sum = 1;
	eff = (float)((double)frags*100.0)/(double)(sum);
	 if (eff < 0)
	 eff = 0;
           if (frags < 0)
           eff = 0;

 if (k == cl.viewentity - 1)
    {
        strcpy(netname,"[");
        strcat(netname,s->name);
        strcat(netname,"]");
   }
 else
       strcpy(netname,s->name);
      for (p=netname ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"')
			*p = '_';
	}

if (s->teamname[0])
{
 if (k == cl.viewentity - 1)
    {
        strcpy(teamname1,"[");
        strcat(teamname1,s->teamname);
        strcat(teamname1,"]");
   }
	 else
	strcpy(teamname1,s->teamname);
}
else strcpy(teamname1,"    ");

      for (q=teamname1 ; *q ; q++)	
        {
		char c;
		*q &= 0x7F;		// strip high bit
		c = *q;
		if (/*c<=' ' ||*/c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"')
			*q = '_';
	}
if (netname[0])
fprintf(logfp,"%2i|%5i|%6i|%4i|%4i|%5.1f%s|%4d|%6s|%4i| %s\n",j+1,frags,deaths,suicides,rank,(float)eff,y,(int)_time,teamname1,ping,netname);

// --+-----+------+----+----+------+----+------+----+-------+------------------
  }
// fprintf(logfp,"%s\n",_linetp2);
fprintf(logfp, "\n");
// _appendLog(logfp);
_appendLog(logfp);
goto flush;
 }
}

else   // 1 player
{
fprintf(logfp,"\n%s\n",_1title);
fprintf(logfp,"%s\n",_line1);
Sbar_SortFrags(true);
l = scoreboardlines;
for (i=0 ; i<l ; i++)
{
	k = fragsort[i];
	s = &cl.scores[k];
	if (!s->name[0])
	continue;
		if (s->spectator)
			continue;
         ping = s->ping;
         ct = s->connect_time;
        _time = (int)((realtime - ct)/60.0);

if (k == cl.viewentity - 1)
    {
        strcpy(netname,"[");
        strcat(netname,s->name);
        strcat(netname,"]");
   }
 else
     strcpy(netname,s->name);
      for (p=netname ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"')
			*p = '_';
	}
    fprintf(logfp,"%4d|%4i| %s\n",(int)_time,ping,netname);
   }
// fprintf(logfp,"%s\n",_line1);
fprintf(logfp, "\n\n");
goto flush;
}


    flush:
fflush(logfp);
fclose(logfp);
SV_BroadcastPrintf("done\n");
}



void TeamStats (void)
{
char *mapname;
char t[12] = "�����"; // teams
char t1[14] = "����"; // team
char f[15] = "�����"; // frags
char p[24] = "�����������"; // percentages
char s1[6] = "�";
char s2[6] = "�";
char teamname[16];
char y[2] = "%";
int i,j,k,o,_sum,tmfrags,tmdeaths;
float _tmeff;
team_t *tm;
mapname = CL_MapName();
if (teamplay.value != 0)
 {
Sbar_SortTeams();
SV_BroadcastPrintf("\n  %s %s (%s[%s]):\n\n",mapname,t,f,p);
o = scoreboardteams;

for (j=0 ; j<o ; j++)
	{
     k = teamsort[j];
     tm = teams  + k;
     if (!tm->team[0])
	continue;
     tmfrags = tm->frags;
     tmdeaths = tm->deaths;
     _sum = tmfrags + tmdeaths;
     _tmeff = (float)((double)tmfrags*100.0)/(double)(_sum);
	 if (_tmeff < 0)
	 _tmeff = 0;
           if (tmfrags < 0)
           _tmeff = 0;
     strcpy(teamname,s1);
if (tm->team[0])
     strcat(teamname,tm->team);
     strcat(teamname,s2);
SV_BroadcastPrintf(" %s %s %5i    [%2.1f%s]\n",t1,teamname,tmfrags,(float)_tmeff,y);
     }
  }
}



qboolean IsPlaying (edict_t *p)
{
if ((int)p->v.connected && ((int)p->v.flags & FL_NOT_CREEPCAM) && ((int)p->v.flags & FL_NOT_KASCAM))
      return 1;
return 0;
}


/*
void DumpWeaponEffi (void)
{
edict_t *p,*w;
int bul1,bul2,nls1,nls2,rox1,rox2,lg1,lg2,total_fired,total_done;
double bul,nls,rox,lg,tot;
char name_[32];
memset(name_,0,31);
if (pr_global_struct->pre_game)
	{
SV_BroadcastPrintf("no game - no stats\n");
return;
	}
 if (autostats.value)
   {
SV_BroadcastPrintf("\nbul - ������ efficiency\n");
SV_BroadcastPrintf("nls - ���� efficiency\n");
SV_BroadcastPrintf("rox - ������ efficiency\n");
SV_BroadcastPrintf("lg  - ������������ efficiency\n");
SV_BroadcastPrintf("\n\n");
SV_BroadcastPrintf("bul��nls��rox��lg��tot��           name�\n"); // "name"
SV_BroadcastPrintf("����������������������������������������\n");

p = PROG_TO_EDICT(pr_global_struct->first_client);
w = PROG_TO_EDICT(pr_global_struct->world);
while (p != w)
{
if (IsPlaying(p) && p->v.classname)
	 {
if (p->v.netname)
  		{
bul1 = (int)p->v.hit_bullets;
bul2 = (int)p->v.bullets;
nls1 = (int)(p->v.hit_spikes+p->v.hit_sspikes);
nls2 = (int)p->v.spikes+p->v.sspikes;
rox1 = (int)p->v.hit_rockets;
rox2 = (int)p->v.rockets;
lg1 = (int)p->v.hit_lg; 
lg2 = (int)p->v.lg;
total_fired = bul2 + nls2 + lg2 + rox2; 
total_done = bul1 + nls1 + lg1 + rox1;

bul = bul1*100.0/(double)(bul1 + bul2);
nls = nls1*100.0/(double)(nls1 + nls2);
rox = rox1*100.0/(double)(rox1 + rox2);
lg = lg1*100.0/(double)(lg1 + lg2);
tot = total_done*100.0/(double)(total_fired+total_done);

// strcpy(name_,p->scores_.name);
strcpy(name_,(pr_strings + p->v.netname));
SV_BroadcastPrintf("%2d%5d%5d%5d%5d   %s\n",(int)bul,(int)nls,(int)rox,(int)lg,(int)tot,name_);
SV_BroadcastPrintf("����������������������������������������\n");
			}
		}
p = PROG_TO_EDICT(p->v.next);
	}
  }
}
*/



qboolean _OnSameTeam (edict_t *p,edict_t *e)
{
if (((int)p->v.realteam == (int)e->v.realteam)/* && (p->v.teamname == e->v.teamname)*/)
           return 1;
return 0;
}


void PF_OnSameTeam(void)
{
edict_t *p,*e;
int i;
p = G_EDICT(OFS_PARM0);
e = G_EDICT(OFS_PARM1);
i = 0;
if (_OnSameTeam (p,e))
i = 1;
else i = 0;
G_FLOAT(OFS_RETURN) = i;
}



// =========================================

// HIGHSCORES

// =========================================

/*
char *HSFileName(void)
{
char *mapname;
mapname = CL_MapName();
sprintf(path_,"%s/highscores",com_gamedir);
Sys_mkdir(path_);
strncpy (name, va("%s/%s",path_,mapname), MAX_OSPATH-1);
return name;
}

FILE *hs_file;
char	*hsfilename;

void ReadHSFile ()
{
	char _buf[1000];
	int lbuf,i;
	hsfilename = HSFileName(); 
	
	hs_file = fopen(hsfilename, "r");
        if (hs_file == NULL)
		{
	Con_Printf ("ReadHSFile: Could not load highscores\n");
            return;
		}

        hs_num_lines = 0;
        while (fgets(buf, 900, hs_file) != NULL)
        {
                lbuf = strlen(buf);
                while (buf[lbuf-1] == '\r' || buf[lbuf-1] == '\n')
                {
                        buf[lbuf-1] = 0;
                        lbuf--;
                }

                if (lbuf > 40)
                        buf[40] = 0;

                strcpy(hs_lines[hs_num_lines], buf);
                hs_num_lines++;

                if (hs_num_lines >= MAX_HS_ENTRIES)
                        break;
        }
        fclose(hs_file);
}


void _WriteHSLog(void)
{
int frags,ct;
double _time;
char netname[16];
unsigned char *p;
time_t  t;
team_t *tm;
scoreboard_t	*s;
time( &ltime );
static char title[11] = "highscores:";
char string2[40];

hsfilename = HSFileName(); 
hs_file = fopen(hsfilename, "wb");
        if (hs_file == NULL)
		{
	Con_Printf ("_WriteHSFile: Could not write highscores\n");
            return;
		}

fprintf(hs_file,"\n%s%s\n",cl.mapname,title);
fprintf(hs_file,"===========================\n");
fprintf(hs_file,"Name              Frags Date\n");
Sbar_SortFrags(true);
l = scoreboardlines;

   t = time(NULL);
    if( -1 != t )
    {
        struct tm  *ptm;

        ptm = localtime( &t );
        if( NULL != ptm )
        {
            char        date[MAX_DATE_STRLEN+1] = {0};

            strftime( &date[0],
                      (sizeof(date)/sizeof(date[0]))-1,
                      "%d %b %Y",
                      ptm );
         sprintf(string2, "%s\n",&date[0]);
	    }
	}

for (i=0 ; i<l ; i++)
{
	k = fragsort[i];
	s = &cl.scores[k];
	if (!s->name[0])
	continue;
		if (s->spectator)
			continue;
      frags = s->frags;
      ct = s->connect_time;
      _time = (int)((realtime - ct)/60.0);

if (k == cl.viewentity - 1)
    {
        strcpy(netname,"[");
        strcat(netname,s->name);
        strcat(netname,"]");
   }
 else
     strcpy(netname,s->name);
      for (p=netname ; *p ; p++)	
        {
		char c;
		*p &= 0x7F;		// strip high bit
		c = *p;
		if (c<=' ' || c=='?' || c=='*' || c=='\\' || c=='/' || c==':'
			|| c=='<' || c=='>' || c=='"')
			*p = '_';
	}
if (string2[0])
    fprintf(hs_file,"%-16s|%4i|%s\n",netname,frags,string2);
   }
fprintf(hs_file, "\n\n");
}
*/






void ReadMOTDFile(void)
{
    char buf[1000];
    char filename[MAX_OSPATH];
    int lbuf,i;

	strncpy (filename, va("%s/dm", com_gamedir), MAX_OSPATH-1);
	strcat(filename,"motd");
COM_DefaultExtension (filename, ".txt");
Con_DPrintf("MOTD: Reading from %s",filename);

     motd_file = fopen(filename, "r");
        if (motd_file == NULL)
                return;

        motd_num_lines = 0;
        while (fgets(buf, 900, motd_file) != NULL)
        {
                lbuf = strlen(buf);
                while (buf[lbuf-1] == '\r' || buf[lbuf-1] == '\n')
                {
                        buf[lbuf-1] = 0;
                        lbuf--;
                }

                if (lbuf > 40)
                        buf[40] = 0;

                strcpy(motd_lines[motd_num_lines], buf);
                 motd_num_lines++;

                if (motd_num_lines >= MAX_TOTAL_MOTD_LINES)
                        break;
        }

        fclose(motd_file);
}


void PrintMOTD(void)
{
        int i, lines = 0;
        int max_lines = MAX_TOTAL_MOTD_LINES;  
        char msg_buf[16384];  
  
        /* 
         * Insert /motd.txt contents (whole MOTD gets truncated after 30 lines)
         */
		msg_buf[0] = 0; // soul
        if (motd_num_lines)
        {
                if (lines < max_lines)
                {
                        for (i = 0; i < motd_num_lines; i++)
                        {
                                strcat(msg_buf, motd_lines[i]);
                                strcat(msg_buf, "\n");
                                lines++;
                                if (lines >= max_lines)
                                        break;
                        }
                }
        }

		SCR_MotDPrint(msg_buf);
}




void Draw_Match_RULES (void)
{
int x,y;
char *tpinfo;
char *dminfo;
char *arena;
char *rj;
char msg_buf[16384];
char msg_buf2[1024];
char msg_buf3[1024];
char msg_buf4[1024];
char msg_buf5[1024];
char msg_buf6[1024];
char msg_buf7[1024];
char msg_buf8[1024];
char msg_buf10[1024];
char msg_buf11[1024];
char msg_buf9[1024];
char countdown[1024];
float *i,*j,*cnt;

msg_buf[0] = 0;
msg_buf2[0] = 0;
msg_buf3[0] = 0;
msg_buf4[0] = 0;
msg_buf5[0] = 0;
msg_buf6[0] = 0;
msg_buf7[0] = 0;
msg_buf8[0] = 0;
msg_buf9[0] = 0;
msg_buf10[0] = 0;
msg_buf11[0] = 0;
countdown[0] = 0;
Sbar_SortFrags(true);

x = 108;
y = 110;

i = &pr_global_struct->real_time;
//cnt = 0 - i;
//j = floor(cnt/10.0);
sprintf(countdown,"Countdown : %i",(int)i);
	Draw_Alt_String2(x + 12,y - 24,countdown);
if (scoreboardlines)
{
y += 10;
sprintf(msg_buf2,"Number of connected clients : %i",scoreboardlines);
	Draw_Alt_String2(x,y,msg_buf2);
}

if (cl.levelname[0])
{
y += 10;
sprintf(msg_buf3,"Map :%6s (%s)\n",sv.name,cl.levelname);
	Draw_Alt_String2(x,y,msg_buf3);
}



if (deathmatch.value)
{
y += 10;
if ((int)deathmatch.value == 1)
dminfo = "(all items respawn)\n";
else if ((int)deathmatch.value == 2)
dminfo = "(only weapons stay)\n";
else if ((int)deathmatch.value == 3)
dminfo = "(weapons stay and other items respawn)\n";
else if ((int)deathmatch.value == 4)
dminfo = "(unlimitted ammo)\n";
else if ((int)deathmatch.value == 5)
dminfo = "(items besides weapons respawn)\n";
else // "6"
dminfo = "(no items)\n";

sprintf(msg_buf4,"Deathmatch : %i %s",(int)deathmatch.value,dminfo);
	Draw_Alt_String2(x,y,msg_buf4);
}
		


if (teamplay.value)
{
y += 10;
  if ((int)teamplay.value == 1)
tpinfo = "(total health protect)\n";
else if ((int)teamplay.value == 2)
tpinfo = "(team frag penalty)\n";
else if ((int)teamplay.value == 3)
tpinfo = "(team health protect)\n";
else if ((int)teamplay.value == 4)
tpinfo = "(team armor protect)\n";
else // "5"
tpinfo = "(team total health protect)\n";
sprintf(msg_buf5,"Teamplay :%3i %s",(int)teamplay.value,tpinfo);
	Draw_Alt_String2(x,y,msg_buf5);
}



if (timelimit.value)
{
y += 10;
sprintf(msg_buf6,"Timelimit : %i\n",(int)timelimit.value);
Draw_Alt_String2(x,y,msg_buf6);
}

            


if (fraglimit.value)
{
y += 10;
sprintf(msg_buf7,"Fraglimit : %i\n",(int)fraglimit.value);
Draw_Alt_String2(x,y,msg_buf7);
}


if (overtime.value && timelimit.value)
{
Sbar_SortFrags(true);
if (teamplay.value)
Sbar_SortTeams();
 if ((scoreboardteams == 2) || (scoreboardlines == 2))
	{
y += 10;
if ((int)overtime.value == 1)
sprintf(msg_buf8,"Overtime :%3i (%i minutes)\n",(int)overtime.value,(int)exttime.value);
else
sprintf(msg_buf8,"Overtime :%3i (Sudden Death)\n",(int)overtime.value);
Draw_Alt_String2(x,y,msg_buf8);
	}
 
}


if (pr_global_struct->game_enable_runes)
{
y += 10;
if (!pr_global_struct->game_not_rune_rj)
sprintf(msg_buf9,"Runes : ON(RJ)\n");
else
sprintf(msg_buf9,"Runes : ON\n");
Draw_Alt_String2(x,y,msg_buf9);
}



if (!pr_global_struct->game_disable_powerups)
{
y += 10;
sprintf(msg_buf10,"Powerups : ON\n");
Draw_Alt_String2(x,y,msg_buf10);
}
		

if (pr_global_struct->game_damage)
{
y += 10;
sprintf(msg_buf11,"Damage Frags : ON\n");
	Draw_Alt_String2(x,y,msg_buf11);
}
	
if (pr_global_struct->game_arena)
{
y += 10;
arena = "Arena : ENABLED\n";
	Draw_Alt_String2(x,y,arena);
}

}










// =================================== CTF.......

char *GetCTFTeamName (int myteam)
{
if (myteam == 5)
	return "red";
else if (myteam == 14)
return "blue";
else
   return "???";
};

void PF_GetTeamName(void)                  
{
int i,k;
scoreboard_t *s;
char *s2;
float myteam = G_FLOAT(OFS_PARM0);
char team[4];
team[4] = 0;
Sbar_SortFrags(true);

s2 = GetCTFTeamName(myteam);

     for (i = 0; i < scoreboardlines; i++)
      {
		 
        k = fragsort[i];
         s = &cl.scores[k];
		 strncpy(s->ctf_team,s2,4);
         strcpy (team, s->ctf_team);
       }
G_INT(OFS_RETURN) = team - pr_strings;
}


// ======== MANUAL ====================








