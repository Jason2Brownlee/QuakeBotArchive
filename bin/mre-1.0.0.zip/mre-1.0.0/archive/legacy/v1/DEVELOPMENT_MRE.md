# Development Guide - Modern Reaper Enhancements (MRE)

## QuakeC Development Best Practices

This guide documents common pitfalls, best practices, and important conventions for developing MRE.

---

## 🚨 Critical Issues to Avoid

### 1. System Globals Section (progdefs.h error)

**ISSUE:** Adding global variables before `void end_sys_globals;` in `defs.qc` causes runtime crash.

**Error Message:**
```
Host_Error: progs.dat system vars have been modified, progdefs.h is out of date
```

**Root Cause:**
The Quake engine expects system globals (defined before `end_sys_globals`) to match a fixed memory layout in `progdefs.h`. Adding, removing, or reordering these globals breaks the engine's memory expectations.

**What Happened (Historical):**
```c
// ❌ WRONG - Added bot_debug_enabled BEFORE end_sys_globals in defs.qc
.entity groundentity;
float bot_debug_enabled;  // This line broke the engine!
void end_sys_globals;
```

Build compiled successfully (458,974 bytes) but failed to load in Quake with progdefs.h error at line 46.

**The Fix:**
```c
// ✅ CORRECT - Add mod globals in botit_th.qc AFTER end_sys_globals
// In defs.qc - keep system globals untouched:
.entity groundentity;
void end_sys_globals;  // DO NOT ADD/REMOVE/REORDER ANYTHING ABOVE THIS LINE!

// In botit_th.qc - add mod-specific globals here:
float bot_debug_enabled;  // Safe location for new globals
```

**Safe Locations for New Globals:**
1. **`reaper_mre/botit_th.qc`** (lines 1-20) - Preferred for mod-specific globals
2. **After `end_sys_fields` marker in `defs.qc`** - For new entity fields (`.float` / `.entity` / `.vector`)

**How to Recognize System Globals Section:**
```c
// defs.qc structure:
entity self;              // System globals start here
entity other;
entity world;
// ... more system globals ...
void end_sys_globals;     // System globals END here - DO NOT MODIFY ABOVE!

// Safe area starts here - can add entity fields:
.float health;
.entity enemy;
// ... custom entity fields OK here ...
void end_sys_fields;      // Entity fields end here

// botit_th.qc - Safe for mod globals:
float bot_debug_enabled;
float SKINSMODE;
// ... custom globals OK here ...
```

**When You See This Error:**
1. Check recent changes to `defs.qc` before `end_sys_globals`
2. Move any new globals to `botit_th.qc` (lines 1-20)
3. Move any new entity fields to after `end_sys_fields` in `defs.qc`
4. Recompile with FTEQCC
5. Redeploy `progs.dat`

**Prevention:**
- Never touch `defs.qc` lines 1-47 (before `end_sys_globals`)
- Add forward declarations in `botit_th.qc` instead
- Comment any globals with their purpose and location

---

### 2. Impulse Command Scope (Player vs Bot Execution)

**ISSUE:** Impulse commands in `ImpulseCommands()` execute for ALL entities (players + bots), not just the human player.

**What Happened (Historical):**
```c
// ❌ WRONG - Bot AI can execute this during think cycle
if ((self.impulse == 95.000))
{
    bot_debug_enabled = !bot_debug_enabled;  // Global flag toggled by bots!
}
```

User entered `impulse 95` to enable debug logging (worked), then later tried to disable it. Between the two commands, a bot entity executed `impulse 95` during its think cycle (`PlayerPostThink()` → `W_WeaponFrame()` → `ImpulseCommands()`), toggling the global flag back. User appeared unable to disable logging.

**The Fix:**
```c
// ✅ CORRECT - Restrict to human player only
if ((self.impulse == 95.000) && (self.classname == "player"))
{
    bot_debug_enabled = !bot_debug_enabled;  // Only player can toggle
}
```

**Entity Classes:**
- `classname == "player"` → Human player
- `classname == "dmbot"` → Reaper bot
- `classname == "watcher"` → Spectator mode
- `classname == "KasCam"` → Camera spectator

**When to Use Player-Only Check:**
- Console commands (developer tools)
- Debug toggles
- Admin functions
- UI state changes (anything affecting global state)

**When Bots CAN Execute:**
- Weapon switching (impulse 1-8)

---

### 3. Bot Colormap Must Stay in Client Slot Range

**ISSUE:** Setting `self.colormap` to shirt/pants encodings (e.g., `fShirt * 16 + fPants`) breaks the client update path.

**Symptoms:**
- Windows error: `i >= cl.maxclients`
- Bot models render with the same colors even though the scoreboard shows different colors

**Root Cause:**
The engine expects `colormap` to be a **client slot index** (`clientnum + 1`). Values outside `1..maxclients` are invalid and can crash the client or force default coloring.

**The Fix:**
```c
// Correct: colormap always points at the client slot
self.colormap = (self.fClientNo + 1);

// Colors are communicated separately
msgUpdateColorsToAll (self.fClientNo, self.fShirt, self.fPants);
```

**Best Practice:**
- Set `colormap` for bots when they enter the server (in `PutBotInServer`).
- Never reuse `colormap` as a packed color value.
- Bot-specific commands (impulse 208 for addbot)
- Normal gameplay impulses

**Prevention:**
- Always ask: "Should bots be able to trigger this?"
- For global state changes, add `&& (self.classname == "player")`
- For per-entity state, ensure entity field usage (`.float` not `float`)
- Test with multiple bots to verify toggle behavior

---

### 3. Trace Globals Are Shared (trace_* clobbering)

**ISSUE:** `traceline()` writes into global `trace_*` variables. Any helper that calls `traceline()` will overwrite the caller's trace results.

**What Happened (Historical):**
- Navigation prediction and goal helpers ran `traceline()` internally.
- Parent movement/combat logic later read `trace_fraction` or `trace_endpos`, but got the helper results instead of its own trace data.
- This caused false "clear path" or phantom collisions.

**The Fix:**
Save and restore `trace_*` around helper traces, and use local copies for decisions:
```c
// Save globals
saved_trace_fraction = trace_fraction;
saved_trace_endpos = trace_endpos;

// Run helper trace
traceline(self.origin, predicted_pos, TRUE, self);
local_fraction = trace_fraction;
local_endpos = trace_endpos;

// Restore globals
trace_fraction = saved_trace_fraction;
trace_endpos = saved_trace_endpos;
```

**Prevention:**
- Cache `trace_*` immediately after your own `traceline()` if you need the values later.
- Avoid relying on `trace_*` across function calls unless you know no other trace ran.
- In helpers, treat trace globals as temporary and restore them before returning.

---

### 4. Bitmask Flag Clearing (self.lefty)

**ISSUE:** `self.lefty` is a bitmask. Clearing flags with raw subtraction can corrupt other bits if the flag is not set.

**Bad Pattern:**
```c
// Unsafe: may borrow across bits if STRAFE_DIR is not set
self.lefty = (self.lefty - STRAFE_DIR);
```

**Safe Pattern:**
```c
// Safe: only subtracts if the bit is present
self.lefty = (self.lefty - (self.lefty & STRAFE_DIR));
```

**Prevention:**
- Use masked subtraction for clears: `var = var - (var & FLAG)`.
- Avoid relying on subtraction without a mask, even inside a guard.

---

### 5. newmis Global (spawn) Safety

**ISSUE:** `spawn()` writes to the global `newmis`. If another spawn happens before you finish configuring the entity, the global can be overwritten.

**Bad Pattern:**
```c
newmis = spawn();
newmis.owner = self;
```

**Safe Pattern:**
```c
local entity missile;
missile = spawn();
missile.owner = self;
```

**Prevention:**
- Capture the spawned entity into a local variable immediately.
- Avoid using `newmis` for any configuration outside the same line as `spawn()`.

---

### 6. Frame-Rate Dependent Smoothing (Delta Time)

**ISSUE:** Fixed degrees-per-tick turning makes aim sluggish when server FPS drops.

**Bad Pattern:**
```c
turn_speed = (15.000 + (self.skil * 10.000)); // per tick
```

**Safe Pattern:**
```c
local float time_delta;
local float turn_dps;
time_delta = (time - self.last_aim_time);
turn_dps = (150.000 + (self.skil * 100.000));
turn_speed = (turn_dps * time_delta);
```

**Prevention:**
- Scale per-frame motion by elapsed time when possible.
- Clamp unusually large deltas to avoid big jumps after pauses.

---

### 7. Stale Goal Entities (Item Removal)

**ISSUE:** Items can be removed or hidden after selection (picked up or respawning), leaving bots chasing invalid entities.

**Safe Pattern:**
```c
if ((e.solid == SOLID_NOT) && (e.modelindex == 0.000))
{
    return DONT_WANT;
}
```

**Prevention:**
- Re-validate `solid` and `modelindex` when scoring or pursuing item goals.
- Reset goal state if a target becomes invalid mid‑pursuit.

---

### 8. Impulse Truncation (8-bit Limit)

**ISSUE:** Quake engine truncates impulse values to 8-bit range (0-255). Values >255 get reduced via modulo.

**What Happened (Historical):**
```c
// User entered: impulse 400
// Engine received: 400 % 256 = 144
// Result: Wrong impulse handler executed (or no handler)
```

Camera activation impulse 400 never worked because engine silently converted it to 144.

**The Fix:**
Use impulses in 0-255 range:
```c
// ✅ CORRECT - All camera controls remapped to safe range
impulse 50  = Flyby mode (was 300)
impulse 51  = Follow mode (was 301)
impulse 53  = Free-flight (was 303)
impulse 60  = Toggle info (was 310)
impulse 61  = Cycle player (was 317)
impulse 98  = EXIT camera (was 400)
impulse 99  = AI Director (was 400)
```

**Safe Impulse Ranges:**
- **1-8**: Weapon switching (reserved by Quake)
- **10-50**: Mod gameplay features
- **50-99**: Advanced features (camera, debug tools)
- **100-199**: Bot management
- **200-255**: Future expansion

**Prevention:**
- Always use impulses ≤255
- Document impulse assignments in code comments
- Test impulses in-game to verify they trigger correctly

---

### 9. Shared Timers (combat vs navigation)

**ISSUE:** `search_time` was used for both enemy persistence and goal patience, causing one system to clobber the other.

**Safe Pattern:**
```c
// Separate timers for different systems
self.combat_search_time = (time + 7.0);
self.nav_search_time = (time + 4.0);
```

**Prevention:**
- Use dedicated timers for combat and navigation.
- Avoid reusing shared fields for unrelated behaviors.

---

### 10. Bitmask Clears (self.items)

**ISSUE:** Clearing item flags with raw subtraction can corrupt the bitmask if the flag is already cleared elsewhere.

**Safe Pattern:**
```c
self.items = (self.items - (self.items & IT_QUAD));
```

**Prevention:**
- Use masked subtraction for clearing item flags.
- Avoid raw subtraction when multiple systems can update `self.items`.

---

### 11. Angle Interpolation (Pitch jitter)

**ISSUE:** Writing `angles_x` every frame can fight engine interpolation and cause visible pitch jitter in demos/spectators.

**Safe Pattern:**
```c
if ((abs_diff > 0.500))
{
    self.angles_x = current_pitch;
    self.fixangle = TRUE;
}
```

**Prevention:**
- Gate angle updates to meaningful deltas.
- Let engine interpolation handle micro changes.

---

### 12. Enemy Slot Reuse (phantom targets)

**ISSUE:** Entity slots get reused. `self.enemy` can point at a non-player entity after disconnects or spawns.

**Safe Pattern:**
```c
if (((self.enemy.classname != "player") && (self.enemy.classname != "dmbot")))
{
    self.enemy = world;
}
```

**Prevention:**
- Validate `self.enemy` each think before combat logic.
- Clear enemy if classname, health, or deadflag are invalid.

---

### 13. Duplicate Function Definitions (compile-order ambiguity)

**ISSUE:** Defining the same function body in multiple files creates ambiguous behavior. The compiler uses `progs.src` order, so later copies may shadow earlier ones or cause duplicate-definition errors.

**Safe Pattern:**
```c
// Define once in an early-compiled file (e.g., botmove.qc)
float () CheckWaterLevel =
{
    // ...
};

// Forward declare in files that need it (or in botit_th.qc)
float () CheckWaterLevel;
```

**Prevention:**
- Keep shared helpers in a single canonical file.
- Use forward declarations instead of copy-pasting function bodies.
- Prefer early-compiled files for core utilities to minimize dependency chains.

---

### 14. Jump Simulation Timestep Scaling (Bot_tryjump)

**ISSUE:** Per-step gravity in jump simulations must be scaled by the timestep. Applying full `GRAVITY` each 0.1s step simulates 10x gravity and makes bots misjudge jump feasibility.

**Safe Pattern:**
```c
sim_interval = 0.100;
tvel = (tvel - (GRAVITY * sim_interval));
newbottom = (bottom + (jumpv * sim_interval));
newbottom_z = (newbottom_z + (tvel * sim_interval));
```

**Prevention:**
- Always scale accelerations by the integration timestep.
- Keep simulation step size explicit and consistent.
- Add a safety break for out-of-bounds fall conditions.

---

### 15. Projectile Dodge Scan Scope (bot_dodge_stuff)

**ISSUE:** Scanning all entities every frame for projectiles is O(N) per bot and scales poorly.

**Safe Pattern:**
```c
head = findradius (self.origin, 500.000);
while (head)
{
    // filter for missiles/grenades and check approach direction
    head = head.chain;
}
```

**Prevention:**
- Use `findradius` to bound scan cost.
- Skip scans when idle and healthy unless under direct threat.
- Keep the dodge logic intact; only reduce the search space.

---

### 16. Shared Bot Prototypes (bot_defs.qc)

**ISSUE:** Scattered forward declarations drift and lead to duplicate-definition errors or missing prototypes across files.

**Safe Pattern:**
```c
// bot_defs.qc (included early in progs.src)
float () CheckWaterLevel;
float (entity target) Bot_IsAvoidedTarget;
void () CheckForHazards;
```

**Prevention:**
- Centralize shared prototypes in one file.
- Include the file immediately after `defs.qc` in `progs.src`.
- Keep function signatures aligned with their single definitions.

---

### 17. Train Prediction Traversal Caps (predict_train_pos)

**ISSUE:** Iterating long path_corner chains with `find()` is O(N) per call and can spike when multiple bots target trains in the same frame.

**Safe Pattern:**
```c
seg_count = 0;
dist_limit = (train_speed * t_future);
while (curr && seg_count < 10)
{
    // accumulate segment distance
    if (total_dist > dist_limit) break;
    curr = find (world, targetname, curr.target);
    seg_count = (seg_count + 1);
}
```

**Prevention:**
- Cap traversal depth (10 segments is usually enough for prediction).
- Break once the lookahead distance is satisfied.
- Only use modulo cycling when the chain is confirmed to loop.

---

### 18. Noise Fanout vs Global Queue (signalnoise)

**ISSUE:** A single global noise queue can be overwritten by multiple sound events in the same frame, causing bots to miss earlier sounds.

**Safe Pattern:**
```c
bot = find (world, classname, "dmbot");
while (bot)
{
    if (dist_sq < range_sq)
    {
        bot.noise_target = noisemaker;
    }
    bot = find (bot, classname, "dmbot");
}
```

**Prevention:**
- Push noise events directly to bots when they happen.
- Store the last noise source per bot to avoid race conditions.
- Prefer cheap distance checks (squared distance) in tight loops.

---

### 19. Team Help Scan Throttling (CallForHelp)

**ISSUE:** Running help scans for every bot every frame multiplies path checks and traces across the team.

**Safe Pattern:**
```c
if ((self.health >= 30.000) && (random () >= 0.100))
{
    return;
}
```

**Prevention:**
- Throttle help scans with a low probability when healthy.
- Allow immediate scans when the bot is low on health.
- Restore shared globals (e.g., `enemy_vis`) after `self` swaps.

---

### 20. Noise Queue Lifetime (NOISEQUEUE)

**ISSUE:** If NOISEQUEUE is created only during bot spawn, early match noises can be dropped before any bots exist.

**Safe Pattern:**
```c
// worldspawn
NOISEQUEUE = noisetarget();
```

**Prevention:**
- Initialize NOISEQUEUE in `worldspawn` so it's available from frame 0.
- Avoid bot-only init for shared world services.

## 🛠️ Build & Deploy Workflow

### Compilation
Prerequisite: `tools\fteqcc_win64\fteqcc64.exe` must exist (place the FTEQCC binary there).
```bash
# Option 1: Direct compile (manual)
cd c:\reaperai\reaper_mre
..\tools\fteqcc_win64\fteqcc64.exe -O3 progs.src

# Option 2: CI script (recommended - includes validation)
powershell -File c:\reaperai\ci\build_reaper_mre.ps1
```

### Deployment Locations
```bash
# Source build output:
c:\reaperai\reaper_mre\progs.dat

# Launch location (for testing):
c:\reaperai\launch\quake-spasm\reaper_mre\progs.dat

# CI artifact (for GitHub Actions):
c:\reaperai\ci\reaper_mre\progs.dat

# Deploy command:
copy c:\reaperai\ci\reaper_mre\progs.dat c:\reaperai\launch\quake-spasm\reaper_mre\progs.dat /Y
```

### Testing
```bash
# Launch with debug logging:
cd c:\reaperai\launch\quake-spasm
quakespasm.exe -basedir C:\reaperai\launch\quake-spasm -game reaper_mre -condebug +developer 1 +sv_gravity 800 -listen 8 +maxplayers 8 +deathmatch 1 +map dm4

# Or use batch script:
launch_reaper_mre.bat 8 dm4

# Check logs:
c:\reaperai\launch\quake-spasm\qconsole.log
```

---

## 📝 Code Conventions

### Forward Declarations
Always declare cross-file functions in `botit_th.qc`:
```c
// botit_th.qc
void () CamClientInit;   // Defined in kascam.qc
void () CamClientExit;   // Defined in kascam.qc
```

### Entity Fields vs Globals
```c
// Entity field (per-bot state) - prefix with dot
.float juggler_cooldown;   // Each bot has own cooldown timer

// Global variable (shared state) - no dot prefix
float bot_debug_enabled;   // One flag for entire game
```

### Commenting Style
```c
// ===== SECTION HEADER (Feature Name) =====
// Brief description of what this code does

void () MyFunction =
{
   // Implementation comments in sentence case
   local float my_var;

   // Explain non-obvious logic
   if (complex_condition)
   {
      // Why we do this...
   }
};
```

---

## 🐛 Debugging Tips

### Enable Console Logging
```bash
quakespasm.exe -condebug +developer 1
```

### Bot Debug Logging System

The MRE debug system provides hierarchical verbosity levels for analyzing bot behavior.

#### Quick Start
```bash
# In-game console:
impulse 95      # Toggle logging on/off
impulse 96      # Cycle through verbosity levels
```
Feeler exploration logs use a separate toggle:
```bash
impulse 97      # Feeler debug (exploration + breadcrumbs)
```
Note: FEELER/BREADCRUMB output only appears when bots enter exploration mode (no nearby waypoints).

### Structured Telemetry (per-tick traces)

Telemetry is a separate, low-overhead ring buffer for per-tick decisions and change events.

```bash
impulse 121     # Toggle telemetry on/off
impulse 122     # Dump trace ring buffer (per-tick snapshots)
impulse 123     # Dump event ring buffer (changes only)
```

Optional focus and dump sizing:
```
set bot_dbg_id 2        # Focus bot by client id (0 = crosshair or first bot)
set bot_dbg_n 120       # Trace entries to dump
set bot_dbg_event_n 20  # Event entries to dump
```

**ANGLES_OVERRIDE** events indicate something overwrote bot view angles after the apply phase.
Bots now sync `v_angle` and `fixangle` in `PlayerPreThink()` to keep PID aim authoritative; if overrides persist, another code path is still writing angles.

#### Verbosity Levels (impulse 96)

**LOG_OFF (0)** - No logging
- All debug output disabled
- Use for normal gameplay

**LOG_CRITICAL (1)** - Stuck, failures, suicides only
- Stuck detection and escape attempts
- AI failures and critical errors
- Use for diagnosing navigation issues

**LOG_NORMAL (2)** - Target/goal changes (default)
- Target selection changes
- Goal selection changes
- Use for basic behavior analysis

**LOG_TACTICAL (3)** - + Weapon switches, combos, dodges
- Weapon switching rationale (tactical, GL-suicide-prevent)
- Juggler combo executions (RL → LG shaft-combo, RL → SSG burst-combo)
- Use for combat effectiveness analysis

**LOG_VERBOSE (4)** - + Movement, routing, perception
- Simulated Perception (hearing) activations
- Movement decisions
- Route planning changes
- Use for full behavior analysis

**LOG_DEBUG (5)** - Everything (very spammy!)
- All debug information
- Frame-by-frame decisions
- Use for deep debugging only

#### Example Output

**Weapon Switches (LOG_TACTICAL):**
```
[Cheater] WEAPON: GL → SSG (GL-suicide-prevent)
[Assmunch] WEAPON: RL → LG (tactical)
```

**Juggler Combos (LOG_TACTICAL):**
```
[Drooly] COMBO: RL → LG (Juggler shaft-combo)
[Wanton] COMBO: RL → SSG (Juggler burst-combo)
```

**Opponent Profiling (LOG_TACTICAL):**
```
[Cheater] PROFILE: Assmunch is AGGRESSIVE (8.7) → Retreat & Trap
[Drooly] PROFILE: Wanton is PASSIVE (2.1) → Push Aggressively
```

**Hearing Events (LOG_VERBOSE):**
```
[Cheater] HEAR: Assmunch (weapon-fire)
[Drooly] HEAR: Wanton (door)
```

**Stuck Detection (LOG_CRITICAL):**
```
[Assmunch] STUCK: Desperate escape (count=6)
[Assmunch] UNSTUCK: Rocket jump escape
```

**Target/Goal Changes (LOG_NORMAL):**
```
[BotName] TARGET: EnemyName (score=X, HP=Y, dist=Zu)
[BotName] GOAL: item_name (score=X, dist=Yu)
```

#### Analyzing Logs

Use the Python analyzer to extract patterns:
```bash
python c:\reaperai\tools\analyze_bot_logs.py c:\reaperai\launch\quake-spasm\qconsole.log
```

Analyzer provides:
- Time-normalized switch rates
- Weapon switch rationale breakdown
- Juggler combo frequency
- Hearing activation patterns
- Stuck/unstuck method usage
- Suggestions for tuning improvements

### Common Warnings (Safe to Ignore)
```
- F314: Implicit cast from void() to void(entity attacker, float damage)
- Q302: Variable no references (unused locals)
- F210: Sound not directly precached (precached elsewhere)
- Q206: Not all control paths return a value (intentional in some AI functions)
```

### Critical Errors (Must Fix)
```
- Unknown field "X" in class "entity" → Field not defined in defs.qc
- Undefined function "X" → Missing forward declaration in botit_th.qc
- progdefs.h out of date → System globals modified (see Section 1 above)
```

---

## 📚 File Structure

```
reaper_mre/
├── defs.qc          # System globals, entity fields, constants (DO NOT MODIFY LINES 1-47!)
├── botit_th.qc      # Forward declarations, mod globals (SAFE for new globals)
├── weapons.qc       # Weapon logic, ImpulseCommands
├── kascam.qc        # Camera system
├── botmove.qc       # Movement AI
├── botgoal.qc       # Goal selection
├── bot_ai.qc        # Target selection, combat AI
├── botfight.qc      # Weapon selection, attack logic
├── botroute.qc      # A* pathfinding
└── progs.src        # Build manifest
```

---

## 🎯 Feature Development Checklist

Before submitting new features:

- [ ] Code compiles without errors (`FTEQCC -O3`)
- [ ] Tested in-game with 8 bots on dm4/dm6
- [ ] No system globals modified (defs.qc lines 1-47 untouched)
- [ ] Forward declarations added to botit_th.qc if needed
- [ ] Player-only check added to impulse commands if modifying global state
- [ ] Impulse values ≤255 if adding new impulse commands
- [ ] Documentation updated (README.md + CHANGELOG.md)
- [ ] Comments explain non-obvious logic
- [ ] Build size noted in CHANGELOG (check progs.dat bytes)
- [ ] Committed with clear message explaining "why" not just "what"

---

## 📊 Data-Driven Improvement Pipeline

MRE uses a scientific approach to bot tuning: measure behavior → analyze patterns → implement targeted fixes → validate improvements.

### The Pipeline

**Step 1: Instrument & Collect**
```bash
# Enable debug logging in-game
impulse 95

# Play test match (8 bots, 5 minutes)
cd c:\reaperai\launch\quake-spasm
launch_reaper_mre.bat 8 dm4

# Let bots play for 5 minutes, then exit Quake
# Debug logs saved to: qconsole.log
```

**Step 2: Analyze Patterns**
```bash
# Run log analyzer
python c:\reaperai\tools\analyze_bot_logs.py c:\reaperai\launch\quake-spasm\qconsole.log

# Example output:
# Combat engagement rate: 14.1% (bots idle 86% of time)
# Target switches: 109 per bot (EXCESSIVE)
# Goal diversity: 94% rockets/armor only
```

**Step 3: Identify Issues**

The analyzer suggests improvements based on thresholds:
- **Low engagement (<20%)**: Increase movement speed, improve vision range, add goal bias toward high-traffic areas
- **High switching (>20/bot)**: Increase target commitment time, add hysteresis to target scoring
- **Low switching (<3/bot)**: Decrease scan_time interval, lower selection thresholds
- **Low goal diversity (<5 unique)**: Increase weight for underutilized items, add randomization

**Step 4: Implement Targeted Fixes**

Example: High target switching (109/bot)
```c
// BEFORE (bot_ai.qc:1287)
self.scan_time = (time + 0.500); // Check twice a second

// AFTER
self.scan_time = (time + 1.500); // Check every 1.5s (3x reduction)

// ADD HYSTERESIS (bot_ai.qc:1286-1316)
// Only switch if new target has clear advantage:
// - Attacking us (self-defense)
// - 300+ units closer (proximity)
// - 30+ HP weaker (easy kill)
```

**Step 5: Validate Improvements**
```bash
# Compile changes
cd c:\reaperai\reaper_mre
..\tools\fteqcc_win64\fteqcc64.exe -O3 progs.src

# Deploy
copy progs.dat ..\launch\quake-spasm\reaper_mre\progs.dat /Y

# Play test match with impulse 95 enabled
# Re-run analyzer on new logs
python ..\tools\analyze_bot_logs.py ..\launch\quake-spasm\qconsole.log

# Compare metrics:
# OLD: 109 switches per bot, 14.1% engagement
# NEW: 64.8 switches per bot (40% reduction), 60.5% engagement (4.3× increase) ✓
```

**Step 6: Commit with Data**
```bash
git add reaper_mre/bot_ai.qc
git commit -m "Bot Behavior Tuning: Fix High Target Switching (Data-Driven)

Analyzed bot debug logs with Python analyzer tool and implemented
targeted fixes for performance issues identified through data analysis.

Log Analysis Results:
- Target switching: 109 switches per bot (excessive flip-flopping)

Fixes Implemented:
- Reduced scan_time from 0.5s to 1.5s (3x reduction)
- Added hysteresis (require clear advantage before switching)

Expected: 109 → ~36 switches per bot (67% reduction)
Build: 459,246 bytes"
```

### Real-World Example: Target Switching Fix (2026-01-05)

**Problem Identified:**
- Analyzer showed 109 target switches per bot (excessive)
- Bots flip-flopping between similar-score targets
- Combat effectiveness reduced by distraction

**Root Cause Analysis:**
- `scan_time = 0.5s` → bots re-evaluate targets twice per second
- No hysteresis → small score differences cause switches
- Result: Constant target changes, incomplete kills

**Data-Driven Fixes:**
1. **Reduced scan frequency**: 0.5s → 1.5s (3× longer commitment)
2. **Added hysteresis**: Require clear advantage (attacking, closer, weaker)

**Actual Results (Validated 2026-01-05):**
- Target switching: 109 → 64.8 per bot (40% reduction)
- Combat effectiveness: Significantly improved (bots complete more kills)
- Engagement rate: 14.1% → 60.5% (4.3× increase!) ⭐ **Key win**

**Validation Method:**
- Play test with impulse 95 enabled
- Re-run analyzer on new logs
- Compare switching metrics before/after
- **Outcome:** Pipeline validated - data-driven approach works!

### Debug Logging Reference

**Current Logging:**
- `[BotName] TARGET: EnemyName (score=X, HP=Y, dist=Zu)` - When target changes
- `[BotName] GOAL: item_name (score=X, dist=Yu)` - When goal changes

**Change-Only Logging:**
- Uses entity fields `.last_logged_enemy` and `.last_logged_goal`
- Only logs when target/goal CHANGES (reduces spam from 90% to ~5%)
- Implemented in bot_ai.qc:711-737 and botgoal.qc:1225-1251

**Adding New Debug Logging:**
```c
// In bot_ai.qc or botgoal.qc
if (bot_debug_enabled && (important_decision_made))
{
   bprint ("[");
   bprint (self.netname);
   bprint ("] EVENT: ");
   bprint (event_description);
   bprint ("\n");
}
```

### Analyzer Tool Features

**Pattern Extraction:**
- Target selection patterns (combat vs idle time)
- Goal selection patterns (item diversity)
- Switching frequency (per-bot and aggregate)
- Engagement rate (combat vs searching)

**Metrics Calculated:**
- Total decision events
- Combat engagement percentage
- Target/goal switch counts
- Average switches per bot
- Goal type distribution
- Target score statistics (avg/max/min)

**Threshold-Based Suggestions:**
- Engagement <20% → Speed/vision improvements
- Switching >20/bot → Commitment/hysteresis fixes
- Switching <3/bot → Scan interval/threshold adjustments
- Goal diversity <5 → Weight/randomization tuning

### Benefits of Data-Driven Approach

**Before:**
- ❌ Gut-feeling tuning ("this feels slow")
- ❌ Guessing at parameter values
- ❌ No validation of changes
- ❌ Regression risk

**After:**
- ✅ Quantified problems ("109 switches per bot")
- ✅ Root cause analysis (scan_time too short)
- ✅ Targeted fixes (increase to 1.5s, add hysteresis)
- ✅ Measurable validation (compare metrics)
- ✅ Confidence in improvements

---

## Open Issues

- Bot model colors appear identical in-world even though the scoreboard shows distinct colors.
- Tried: restored `colormap = fClientNo + 1`, removed shirt/pants colormap packing, enforced `FL_CLIENT` on bot spawn, and verified colors are sent via `msgUpdateColorsToAll`.
- Suspect: engine setting that disables model colors (`r_nocolors` / `r_noskins`) or a player model that lacks color ranges.
- Bots can still get stuck during navigation (observed in live test); needs investigation and reproduction steps.

---
## 📖 Additional Resources

- **FTEQCC Documentation**: https://fte.triptohell.info/moodles/qc/
- **Quake C Reference**: https://www.inside3d.com/qctut/
- **Reaper Bot History**: See original `Reaprb80.txt` in launch/quake-spasm/RPBOT/
- **MRE Changelog**: See `CHANGELOG.md` for full feature history

---

**Last Updated:** 2026-01-05
**Maintainer:** reaperai project
**License:** MIT
