
Title : SABIN Package 0.1 HOW-TO
Author: Terry 'DS' Hendrix II
Email : stu7440@westga.edu
Info  : This explains how to use and make SABIN Packages. 

---------------------------------------------------------------------------

0)  To get a copy of WinRaR goto http://www.tucows.com, if you need the 
   linux flavor I can give it to you via email or setup an FTP file. Also
   try searching for rar and linux to find a copy on the web.  Also you
   could get a rar RPM from ftp.redhat.com or a mirror.  

---------------------------------------------------------------------------

1)  sabinxxxxxx-src-???.rar
    These are source files where ??? is the directory name of the contents.

    Extract these directories into your SABIN directory where you compile
    your code... e.g.  /quake2/sabin/source

---------------------------------------------------------------------------

2)  sabinxxxxxx-makefile.rar
    These are the MSVC++ 5.0 and linux Makefiles.

    Extract these files into your SABIN directory where you compile
    your code... e.g.  /quake2/sabin/source

---------------------------------------------------------------------------

3)  sabinxxxxxx-testpak.rar
    These are the files you need to run SABIN in quake2.

    Extract these directories into your SABIN directory where you play 
    quake2 from...  e.g.  /quake2/sabin/

---------------------------------------------------------------------------

4)  sabinxxxxxx-notes.rar
    This is the documentation for SABIN coding and playing.

    Extract these where ever you like...

---------------------------------------------------------------------------

5) Only send the sabinxxxxxx-src-???.rar you updated back to me...
   
   With this new packaging system we can speed up development 20%.

---------------------------------------------------------------------------

Thank you for your time.


