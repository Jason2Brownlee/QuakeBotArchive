OrionBots Second Release

====================
QC files: yes
Sounds: replacements
Models: yes
====================


-------------------------------
Description of the modification
-------------------------------

This mod puts AI-controlled bots for multiplayer.
Type 'impulse 100' to add one.
The number of bots will be stored in "scratch1" cvar and in a level change, the bot will connect without impulses.


--------
Features
--------

*The bots will swim up more often;
*Improved bot aiming;
*That's all.


--------
Bugfixes
--------

*In long games the bots didn't respawn. That's now fixed (GibPlayer() bug);
*In deathmatch 3 mode ammo boxes will REALLY respawn every 15 seconds;
*Fixed "palette shift" bug in intermission too;
*That's all.


----------
Known Bugs
----------

*When you create a dedicated server with scratch1 above zero, and you connect to it, you'll be controlling a bot and you'll have his name;
*Sometimes when you're connected with wrong name in a dedicated server, will spawn a solid "hologram" that is at your last frame, and you get stuck in it. I've no idea why the hell that happens. 



-------------------------
Previous Release Features
-------------------------

*Colors in GLQuake;
*The bots are shown at the scoreboard;
*The bots will select the best weapon at a certain moment;
*The bots roam any level perfectly without needing waypoints;
*They follow their enemies;
*50 different names;
*Rocket jumping;
*Very fast thinking. 


-----------------------
Previous Release Tweaks
-----------------------

*Quad/Ring drop;
*Deathmatch 3 - weapons stay, and ammo boxes respawns every 15 seconds instead of 30;
*Powerup time adding - e.g. you find two quads side by side, when you get both, your quad will have 60 seconds of duration! This is so with the dropped ones;
*Multi grenade explosions - 2 grenades side by side will explode at the same time;
*Proper fall damage;
*Improved obituary;
*Improved gib velocities;
*Dinamycally-sized bodyque;
*Disconnecting will now gib. 


-------------------------
Previous Release Bugfixes
-------------------------

*Fixed incorrect settings of nextthink;
*Doors, buttons and boxes won't bleed when shooting'em;
*Corrected barrel explosion;
*Fixed all compile warnings;
*Fixed the bug that when you die with an active powerup, your palette is still shifted.



If you notice some bug, mail me or make a post on the Inside3D forums.

E-Mail: rfalcetti@gmail.com
Inside3D: www.inside3d.com