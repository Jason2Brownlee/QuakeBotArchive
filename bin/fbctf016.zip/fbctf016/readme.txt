Title    : Frogbot CTF Beta 0.16
Filename : fbctf016.zip
Version  : Beta 0.16
Date     : 10-12-99
Authors  : Robert "Frog" Field, Gerard "numb" Ryan,
           and Dave "Zoid" Kirsch
Email    : numb@macquakeinfinity.com
WWW      : http://numb.macquakeinfinity.com


INSTRUCTIONS:
-------------

Please read the original frogbot readme if you're unfamiliar with starting a 
game with the frogbot. To start a game of CTF, simply use the normal command 
line parameters for starting a frogbot server, drop the console, set teamplay 
to 1 (or greater) and type "ctf".  It's possible to make use of the Threewave 
pak0 and pak1 pak files by placing them into the fbctf folder and typing the 
"custom" command into the console. If you're not using customized CTF maps, 
you must be in the game to manually spawn the flags. To spawn flags on a 
non-custom CTF map:

- Type "red" to spawn a red flag
- Type "blue" to spawn a blue flag

* You may only spawn a flag of the team you are currently on
* Only Admins can spawn flags and change teams

Once you fire off the impulse, step back, because the flag will spawn exactly 
where you are standing. Be sure to place the flags at adequate distances apart--  
to ensure challenging gameplay. Also, be careful not to place them too deeply 
into corners (or underwater) because the bots will have difficulty getting to 
them. Auto teams is the default. Bots and players will auto-even the teams as
they enter the game.

***See the autoexec.cfg file for the [almost] full list of options.


QUAKEWORLD:
-----------

The QuakeWorld version of Frogbot CTF, similar to the normal Quake version, is
a work in progress. There are several features which either haven't been
implemented yet, or need refinement. 

Bots have ping time and packetloss. You can change their ping/pl by addding 
the line:

localinfo botping modem

to your server.cfg (if you're running a qw server), or, you can change bot ping
remotely, by using rcon. There's three possible values for ping/pl: LAN, modem, 
or digital. Digital is the default, and these values are purely cosmetic. However, 
I plan on adding skill and response time deficiencies as an effect of their 
determined ping and packetloss, sometime in the future.


NOTES:
------

This modification of the Frogbot is unsupported by its author, Robert Field.
Please  direct your suggestions, complaints, and praises to the above address.
Frogbot CTF is a simple hack to the frogbot which makes use of Robert Field's 
excellent goal evaluation code. Frogbot will assess the flags as goals based 
on various criteria: whether it's dropped, carried, or at base, what team it's 
on and what its current "plan" is: i.e., defend, roam, escort, or attack. 
The bots are entirely autonomous, however you can request an escort if a bot is 
nearby by typing "escort." The bot responding to your request will escort you 
for 2 minutes. Though the mod has almost full Threewave support, the Threewave 
maps can be problematic due to their size. Gameplay is very fast if you enable 
"simple" planning, playing with two or three man teams, on a medium sized map, 
with manually placed flags. Try ztndm3 with one flag in the corner stairs near
the yellow armor, and the other flag placed in the small L-shaped hallway, near 
the quad.

todo:

1.) Bot Grappling
2.) More map support


IMPULSES:
---------------

Game options        - impulse 47 (or type 'options' at the console)
CTF                 - impulse 67 (or type 'ctf' at the console)

Team-Score          - impulse 77 (or type 'score' at the console)
Spawn red flag      - impulse 78 (or type 'red' at the console)
Spawn blue flag     - impulse 79 (or type 'blue' at the console)
Order Escort        - impulse 80 (or type 'escort' at the console)
Identify Player     - impulse 81 (or type 'identify' at the console)
Simple planning     - impulse 82 (or type 'simple' at the console)
Detailed scores     - impulse 85 (or type 'myscore' at the console)
Status bar          - impulse 86 ("sbar" to toggle, impulses 87 - 96 to set resolution)
Multiwep            - impulse 97 (or type 'multiwep' at the console)
Drop Ring           - impulse 98 (or type 'dropring' at the console)
Drop Quad           - impulse 99 (or type 'dropquad' at the console)
Toss Weapon         - impulse 100 
Toss Backpack       - impulse 101 

READ: When using the multiwep and custom modes, the additional pak files must 
      be installed!! you can get the Threewave CTF pak0 and pak1 files here:
           
      ftp://ftp.cdrom.com/pub/quake/planetquake/threewave/ctf/client/3wctfc.zip
           
      You can get the pak2 file for Threewave CTF multiwep here:
      
      ftp://numb.macquakeinfinity.com/numb/ctf/pak2pak.zip
      

ADDITIONAL CREDITS:
-------------------

Hylken "gibbie" Beck (hylke_b@hotmail.com) for the ctf8, ctf5 and ctf2 waypoints 

The bot planning code is based on Anthony (*this) Distler's Ctfbot+,
(adistler@ace.cs.ohiou.edu) which is based on Drew "BZ" Davidson's 
Ctfbot 1.4. 

Ctfbot+ can be found at:
http://www.captured.com/ctfbot/


VERSION CHANGES:
----------------

Version Beta 0.16 / 10-12-99:

New ctf8 waypoints
Fixed bug in red base evaluation
MOTD altered

Version Beta 0.15 / 10-11-99:

Dug around inside the "team" fields:
- fixed the crash on MOST maps associated with adding bots
- fixed the NULL function associated with BestEnemy
Discovered that CTF maps have the following problems:
- the custom ctf maps have clipping issues
- cft5 is missing the "info_intermission" destination
Removed bot spawning from the observer menu =(
Improved overall program flow where ctf rules are concerned


Version Beta 0.14 / 10-7-99:

This version is much more stable than prior versions
Removed ztndm5 map until better lift support is available
Removed debug mode for planning and goal evaluation
Re-enabled planning modes in QW after optimizations
Added Matt 'asdf' McChesney's "hacks" ;) thanks Matt!
- Divide-by-zero error: "Got a NaN velocity on Frogbot"
- "if" statements added to eliminate "NULL function" fatalities
Finished bot and player QW skins for Threewave CTF 
- CTF skins procured from: http://www.telefragged.com/skins
Changed some of the desire values for goals
Made all ctf items share one search string

Version Beta 0.13 / 10-5-99:

Changed/fixed some team issues
Bots now have QW team names
Began adding custom QW skin support

Version Beta 0.12 / 10-4-99:

Changed manual flag placement:
- you can only spawn flags of the team you're presently on
- you can only switch teams if you have admin priveleges
- thus, eliminating team and flag spawning exploits...
Fixed the ThinkTime bug which caused a crash when loading bots
Team-Score doesn't include observer frags (-99) while summing scores
Detailed-Score doesn't include observer frags (-99) while summing scores
TeamCheckTeam doesn't include observers while summing team players
Replaced SUB_UseTargets with the original id code
Altered artifact goal evaluation
Added ztndm5 support

Version Beta 0.11 / 10-3-99:

Fixed the stupid mistakes from beta 0.10:
- Bots standing around doing nothing
- Team spawning
- Flag spawning
Changed sbar code to be more like the original threewave sbar


Version Beta 0.10 / 10-2-99:

Added team spawn code
Added vote exit code
Added Matt "asdf" McChesney's 'oldsolid' hack for 
recurring crash in "no assignment for world entity"
Changed sbar code

Version Beta 0.09 / 9-28-99:

Added a temporary fix for the disappearing flag. When a frogbot produces a 
"NaN velocity" and touches the flag, the flag "floats" away. Code has been 
added to prevent the flag from flying away when an owner with a NaN 
velocities attempts to capture.

Added e1m2 map support (big ups to gibbie!)
Revamped base goal evaluation
Added Toss Weapon and Toss Backpack (players only)
Fixed the detailed scores
Fixed bot talk (their chat text was the wrong color)

Version BETA 0.08 / 9-25-99: 

Status bar fully rewritten using WriteByte()
TeamPlayerUpdate rewritten but not implemented
Optimizations made to base goal spawning
 
Version BETA 0.07 / 9-24-99:
 
Not a public release
Updated to frogbot source release version 0.13 test
All the bells and whistles of v0.13 test are included
Enabled dropring, dropquad, and multiwep
Added dm3 map support
Added flag carrier goal evaluation for items
Special thanks to Mr. Elusive for providing me with the newest Meqcc
 
Version BETA 0.06 / 9-22-99:
 
Bot stategizing tweaked
Auto Teams fixed
Dropflag fixed-- the flag doesn't "disappear" anymore
Added the Threewave status bar and observer mode
Version BETA 0.05 / 9-17-99:
 
Added map ctf2 - thanx again to Gibbie
Added auto teams for CTF 
Added simple chat routine (greetings)
Fixed the flag and flag carrier's "glowing": it was switched
Consolidated some of the new qc modules into "ctfgame.qc"
Further Threewave implementation 
 
Version BETA 0.04 / 9-16-99:
 
Added detailed scoring from the Threewave and Ctfbot+ mods
Added XXX EXPERT CTF scoring to ClientObituary (scoring needs work!)
Added ctf skins - enabled with game options "custom" and "ctf" (NQ only)
Re-enabled "simple planning" for bots (use the "simple" command) 

Version ALPHA 0.03 / 9-14-99:
 
First public release
Added escort ordering
Added identify player
Fixed some of the goal workarounds 
Added stronger goal strategizing for defending
Added ctf8 support, thanks to Gibbie!  (not optimal yet)
Added QW logdeath
Added QW ping
 
Version ALPHA 0.02 / 9-13-99:
 
Internal only
Added modified bot planning and enemy base strategies from CTFBot+
Changed goals over from dynamic to fixed searches (performed individually)
Changed goal values to be more realistic
Tweaked flag spawning functions flags are now spawned if ctf maps are detected
TeamDropFlag now allows flag teleportation if anything bad happens to it 
TeamCaptureFlagThink now makes flag invisible if carrier has Ring of Shadows
Reduced the chance of NO FREE EDICTS warning/server crash
Added Team-Scoring (Complete Enhanced Teamplay/J. Spickes)
Added alternate gib sound
Added Drop weapon/ring/quad
Added MOTD
Made a QuakeWorld version with number of bots listed in server browsers
Changed this readme
 
Version ALPHA 0.01 / 9-11-99: 
 
first run, internal only; basic flag/base as goals
 


COPYRIGHTS & DISTRIBUTION:
--------------------------

The modifications included in this archive are Copyright 1998, Robert
Field, and Copyright 1999, Gerard Ryan. The original QuakeC source is 
Copyright 1996, id software.

You may distribute this Quake modification in any electronic format as
long as all the files in this archive remain intact and unmodified and
are distributed together.


DISCLAIMER:
----------

Software under this agreement is under no kind of warranty. Software
under this agreement is provided as is, and isn't guaranteed in any
way by the mod author. Use this software at your own risk.

