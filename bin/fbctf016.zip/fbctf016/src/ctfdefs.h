/****************************************************************************
 * ThreeWave Capture The Flag
 ****************************************************************************
 * Based on John Spikles Complete Enhanced Teamplay
 ****************************************************************************
 * Version 4.0 rewrite Mar 21, 1997
 ****************************************************************************/

void(entity e) remove_apply = #15;

// motd
.float writer_seconds;
string string_one;
.entity writer;
void() WriterStep;

.string stringname;
.float creepflags;

float yellowdot   = 143;
float exclamation = 33;
float apostrophe  = 39;

float redteam     = 68;
float blueteam    = 221;

.float laststattime;		// time of last status update
.float statstate;			// is the status bar on?
float teamscr1;			    // team 1's teamscr score
float teamscr2;			    // team 2's teamscr score
float lastteamscrtime;		// last time we calculated it
float TEAMSCRTIME = 1;

void(vector org, entity death_owner) spawn_tdeath;

void(entity who, string s) TeamPlayerUpdate;
void(float to, entity client) SetColorName;
void() ChangeTeam;
float (float myTeam) IsHumanOnTeam;
float (float myTeam) NumPlayersOnMyTeam;
void(vector org, entity e) spawn_tfog;
void() UpdateGoalEntity;
entity(vector org) LocateMarker;
void() DetailedScoresBroadcast;
void() TeamCaptureFlagThink;
void(entity e) UpdateFrags;
void() TeamCaptureRegenFlags;
float teamScorePrintTime;
void() TeamCaptureResetUpdate;
void() goal_flag_team1;
void() goal_flag_team2;
void() goal_base_1;
void() goal_base_2;
void(entity e) InitTouchMarker;
void(entity e) Flag_InitGoalBase;

float TEAM_PRINT_DELAY =	45;	
float BOT_ATTACK = 1;
float BOT_DEFEND = 2;
float BOT_ROAM   = 3;
float BOT_ESCORT = 4;
float ESCORT_TIME = 120;

float BASE_WEIGHT = 600;
float FLAG_WEIGHT = 600; 
  
float red_base_count = 0;
float blue_base_count = 0;

.float      motd;
.float		killed;			// have we been killed yet
.float      escort_time;
.entity     escort_entity;
.float      bot_plan;
.float      update_plan_time;

entity lastspawn;

void() goal_supershotgun1;
void() goal_nailgun1;
void() goal_supernailgun1;
void() goal_grenadelauncher1;
void() goal_rocketlauncher1;
void() goal_lightning1;
void() bf;
//void(entity item) InitDynamicItem;
void() bound_ammo;
void() W_SetCurrentAmmo;
void(float new) Deathmatch_Weapon;
void() ResquestEscort;
void() SetBotPlan;

void() MOTDChooseTeam;
void() not_supported;

entity redflag;
entity blueflag;

float item_flag1, item_flag2;
float bot_debug = 0;

.string oldmodel;
.string stringname;
.float last_returned_flag;
.float last_fragged_carrier;
.float last_hurt_carrier;
.float flag_check_invisible_finished;
.float ident_stat;
// *XXX* EXPERT CTF
.float flag_since;

// high chars

float _oA = 193;
float _oB = 194;
float _oC = 195;
float _oD = 196;
float _oE = 197;
float _oF = 198;
float _oG = 199;
float _oH = 200;
float _oI = 201;
float _oJ = 202;
float _oK = 203;
float _oL = 204;
float _oM = 205;
float _oN = 206;
float _oO = 207;
float _oP = 208;
float _oQ = 209;
float _oR = 210;
float _oS = 211;
float _oT = 212;
float _oU = 213;
float _oV = 214;
float _oW = 215;
float _oX = 216;
float _oY = 217;
float _oZ = 218;
float _oexclamation = 161;
