#define MAP_e1m2
#define MAP_dm3
#define MAP_dm4
#define MAP_dm6
#define MAP_ztndm3
#define MAP_ctf2
#define MAP_ctf5
#define MAP_ctf8