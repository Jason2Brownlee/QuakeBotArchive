Title    : FrikBot in Mision Pack 1: Scourge of Armagon
Filename : frikmp01.zip
Version  : 0.09
Date     : 2-26-00
Author   : Ryan "Frika C" Smith
Email    : frika-c@earthling.net
Credits  : Alan Kivlin for his rankings.qc and step movement
Frog for releasing the Frogbot code and giving me a good goal
to shoot for.

Additional thanks to Wazat, Asdf and MaNiAc who helped immensly with suggestions, code snipplets and ideas.

Type of Mod
-----------
Quake C  : yes
Sound    : no
MDL      : no
Level    : no

Format of QuakeC (if a Quake C Mod)
-----------------------------------
unified diff  : no (and yes I know what that is!)
context diff  : no (and yes I know what that is!)
.qc files     : no
progs.dat     : yes


Description of the Modification
-------------------------------

This is an update to the previous Frikbot + mission pack one, using the current version of the FrikBot.
                          
How to Install the Modification
-------------------------------

You must have the mission pack to use this file.

Copy all included files into your HIPNOTIC directory. DO NOT OVERWRITE ANY PAK FILES.

To run, start quake with -hipnotic -listen 8

Impulses
===========
100 Add a bot or add a bot to your team in a team game
101 Add a bot to an enemy team
102 Remove a bot
103 Bot Cam cycle. Cycles through the view of all bots & players currently on the server
104 Dump Waypoint data to console

Technical Details
-----------------

Known Bugs
==========
None are known for this particular mod

For general frikbot bugs, please finger frika-c@mdqnet.net or visit the FrikBot homepage.


Availability
------------

This modification is available from the following places:

FrikBot Homepage at http://www.mdqnet.net/frikbot/


