================================================================

OrionTF beta
by Orion (rfalcetti@gmail.com)

Editors used: QME, QCIDE, Sound Forge
Build time: About 3 months, including testing
Thanks to: Id for releasing Quake.
Id for some Quake2 models and sounds.
Valve for some Half-Life models and sounds.
TeamFortress Software for releasing TF, and for some QC codes.

================================================================

---------------------------------------------------
I. DESCRIPTION OF THE MODIFICATION + SOME FEATURES
II. CLASSES & WEAPONS
III. GRENADES
IV. BOTS
V. COMMANDS
VI. TECH POWERUPS
VII. WAYPOINT EDITING
VIII. KNOWN BUGS
---------------------------------------------------


I. DESCRIPTION OF THE MODIFICATION + SOME FEATURES

This is a TF-clone CTF(Capture the Flag) mod, adapted for both CTF and TF maps. But there are still some TF maps with different rules that are NOT supported, like canalzone(command points). Rock2 will work, but as a regular CTF map. Grab the flag located at the enemy's office, then bring it back to your office, NOT the enemy's gas chamber. It's a slight variation of TF mode. It also includes offline bots, and a simple waypoint system I made from scratch. It works kinda well, if you ask me.

The rules are simple, get the enemy flag located at the enemy team's base, then return it to your base at your flagroom, no matter if your team's flag is there or not. Unlike CTF, you *cannot* return your team's flag by running over it, it must wait 30 seconds and it will then return to base. The flag carrier who captured the flag gets 15 frags, and the rest of the team gets 10 frags. If the flag carrier gets fragged by an enemy, the enemy will get 2 frags instead of one.

NOTE: Waypointed maps are included in the package.

There are some different things as well, like:

*Quad and Ring drop
*Gibbable corpses
*New animation system for the players and bots
*Classes like in TF, but only 8 (there's no spy, but I'm thinking of implementing it)
*Visible Weapons (but there's a little problem, your visible weapon will be shown to you on a regular Quake engine, so better use DarkPlaces or FTE, but in FTE the bots will be invisible.)
*Single Barrel Shotgun and Nailgun no longer exist (the Super Nailgun is called Nailgun on this mod, because there's no point on calling it 'Super Nailgun' if there's no 'Normal Nailgun' here, but it uses the SNG models). The Shotgun was replaced by the Revolver. The regular Nailgun no longer exists.
*Armor is gone. It's all HP-based, like in Valve's TF2.


II. CLASSES & WEAPONS

The classes have its advantages and disadvantages. Each class carry a type of hand grenade, which can be selected by pressing the 'g' key.
Here are the profiles of each class:

1. Scout
Health: 90 (135 if buffed by a Medic or AutoDoc)
Speed: 450
Weapons: Axe, Revolver, Double Barrel Shotgun
Initial shells: 30
Initial cells: 15
Max shells: 75
Max cells: 50
Grenade type: Flash
Ability: Proximity Sensor (scans for enemies, show their classes and distance), defuse detpacks

Description: The scout is the fastest of all classes, but the most vulnerable of all. He can only carry a maximum of 75 shells. It's got a reasonable firepower, though. You can use your shotgun to try to kill someone from behind at point-blank range. Use your flash grenades to blind your enemies, but take care not to blind your teammates.

Weapon Profiles:

1. Axe: The good old axe.

2. Revolver: It fires a single pellet that does 40 damage. Headshots will do 80 damage. It's a rather precise weapon, but has a slow fire rate. Each shot uses 1 shell, and it fires 1 shot each 0.8 seconds.

3. Double Barrel Shotgun: It shoots 20 pellets doing 5 damage each. Will do 100 damage if all pellets connect. Useless on medium to long ranges. Use the Revolver instead. Each shot uses 2 shells, and it has a fire rate of 0.7 seconds. NOTE: If you fire this weapon off-ground, you'll have a kinda strong knockback. It is possible to 'boomstick-jump' with this weapon and with no health cost, as well as other tricks.

Special Ability(ies):

Proximity Sensor: By typing 'impulse 111' at your console, your sensor will be activated or deactivated, it's a toggle. It'll search for enemies within a range of 100 meters, making a noise and drawing a lightning beam pointing to where the enemy is. And don't worry; only YOU can see the sensor's lightning. The sensor scans for enemies every 2 seconds, for the cost of 1 cell. 

Defuse detpacks: To defuse an enemy detpack, simply step over it. You'll freeze, can't move, shoot, and if you were cooking a grenade it will explode in your face. It takes 3 seconds to defuse a detpack.


2. Sniper
Health: 105 (158 if buffed by a Medic or AutoDoc)
Speed: 300
Weapons: Axe, Revolver, Railgun, Crossbow
Initial shells: 30
Initial nails: 25
Initial cells: 10
Max shells: 50
Max nails: 75
Max cells: 50
Grenade type: Flare
Ability: Laser sight

Description: The sniper is a medium-speed, kinda vulnerable class but it's got powerful weapons. You can attack with this class, but it's meant to kill distant targets.

Weapon Profiles:

1. Axe
2. Revolver

9. Railgun: Shoots a blue or red beam, depending on your team. It can kill most classes with a single shot. Each shot does 150 damage, and headshots will do 450 damage. See how much foes will turn into chunky kibbles before the beam hits concrete. >:) Also, the weapon will draw an explosion at the end of the beam. This explosion will do 75 damage. So it's recommended to shoot on the ground if your target is moving fast, so he can at least take the blast damage. Each shot uses 1 cell, and the fire rate is 1.5 second. The sound is loud as hell, it can be heard more further away than most regular sounds. NOTE: This weapon also gives you a knockback when firing it in mid-air. But the railgun's knockback is MUCH stronger than the shotgun's. Also, when you fire it in mid-air, your precision is gone (the beam won't go exatcly where you're shooting). So better shoot it if you're on the ground, so you get 100% precision.

Crossbow: Select this weapon by pressing 9 twice. It fires black arrows that fly more than twice as a rocket's speed, doing 100 damage each. Headshots will do 300 damage. Use this weapon if you want to be silent. Because the railgun is more effective. Also, the arrows are ballistic. You'll see them going slightly downwards after being fired. Each shot uses 1 nail, and the fire rate is 0.8 seconds.

Special Ability(ies):

Laser sight: Impulse 113 activates or deactivates your laser sight. You can use it with whatever weapon you're holding. Really helpful when you're sniping.


3. Soldier
Health: 260 (390 if buffed by a Medic or AutoDoc)
Speed: 240
Weapons: Axe, Revolver, Double Barrel Shotgun, Rocket Launcher
Initial shells: 30
Initial rockets: 10
Max shells: 50
Max rockets: 50
Grenade type: High Explosive(HE)
Ability: Nothing

Description: The soldier can sustain heavy fire, but it's slow-moving, so a sniper can easily kill him. Always look around for snipers, and try to throw some rockets on them. The soldier is effective to be either a defensive or offensive class.

Weapon Profiles:

1. Axe
2. Revolver
3. Double Barrel Shotgun

7. Rocket Launcher: The rockets are slightly slower, and the damage was also lessened. A direct hit will inflict 102 damage. The blast damage is 92, with an area of effect of 112 units. Don't use it in close combat, and don't try to aim directly at your enemy, because the rocket can be easily dodged. Shoot at a nearby wall or the ground, so he can take good part of the blast damage and fly in mid-air, so you can then try a mid-air kill. If you keep aiming at an enemy without firing this weapon for half a second or more and the enemy is far away enough (>600 units), a 'Locked!' message will appear at the center of your screen, and you'll hear a computer noise, meaning that the rocket will track your target, but it's not as precise as a Voreball. Fire rate unchanged. TIP: If you see a rocket that is tracking you, strafe slightly side to side either stopped or while running, and the rocket will fly in circles around you until it explodes. It has a life time of 10 seconds, so it won't follow you for ages like a Voreball.


4. Demoman
Health: 162 (243 if buffed by a Medic or AutoDoc)
Speed: 280
Weapons: Axe, Revolver, Grenade/Pipebomb Launcher, Mortar Cannon
Initial shells: 30
Initial rockets: 20
Max shells: 50
Max rockets: 50
Grenade type: Cluster
Ability: Plant detpacks

Description: The demoman has got a reasonable health, and a medium-slow speed. Can also be both defensive or offensive. Use your mortars for long-range attacks. Throw some mortars on the snipers.

Weapon Profiles:

1. Axe
2. Revolver

6. Grenade/Pipebomb Launcher: The grenade launcher was unchanged. The pipebomb launcher can be selected by pressing 6 twice. It shoots yellow grenades that explodes on command from the owner, or after 2 minutes. There's a limit of 8 pipebombs per demoman, so if a 9th pipebomb is launched, one of the old pipeboms will explode.

9. Mortar Cannon: Shoots a devastatingly powerful ballistic rocket. Like the crossbow, the mortar will fly in the form of an arc, and it's a bit slower than a rocket. The mortar itself does 100 damage, and then it spawns 8 little bombs, doing 50 damage each. So it is possible for this gun to deliver up to 500 damage to some unlucky guy. If there are enemies within a certain distance from the mortar, its bombs will be tossed toward them to try to do as much damage as possible. Each shot uses 3 rockets, so you can only shoot it 16 times. Be careful. The fire rate is 1.5 second. Loud as hell, it's even louder than the railgun. It is currently the most powerful weapon in the mod. If you hit a mortar right at a hwguy's torso, he may be insta-gibbed. Works pretty much like fireworks.

Special Ability(ies):

Plant detpacks: By typing 'impulse 115(5 seconds), 116(20s), 117(50s) or 118(255s)' at the console, your weapon will disappear, and it takes 3 seconds to plant a detpack. While planting a detpack, you can't move, shoot, nor change your weapon. Also, if you were cooking a grenade before planting the detpack, you also can't throw it. It'll explode right in your face. So NEVER cook a grenade when you're gonna plant a detpack! Also, you can only carry one detpack. Plant it, then grab a backpack located at your team's respawn room so you get 1 more detpack.


5. Medic
Health: 150 (225 if buffed by a Medic or AutoDoc)
Speed: 320
Weapons: Medikit, Revolver, Double Barrel Shotgun, Nailgun
Initial shells: 30
Initail nails: 50
Max shells: 80
Max nails: 150
Grenade type: Poison
Ability: Self-regeneration

Description: The medic is the second fastest class of all. It's got a fairly low health but high firepower. Use the medikit to heal your teammates or infect your enemies. Use your nailgun to kill mid-range targets. The medic's regeneration is much slower than that of the AutoDoc.

Weapon Profiles:

1. Medikit: The medikit will heal your teammates if you hit them with this weapon. Each hit will add 5 health, and it can buff up to over 150% health. If you hit an enemy with this weapon, he will become infected, and will begin to lose health. Each hit does 10 damage, and the infection does 5 damage every 2 seconds. A single hit will make an enemy infected for 20 seconds, so the more hits, the more time the enemy will be infected, in 20-second increments. Only a friendly medic can heal your infection. Enemy medics won't get infected. If you touch an infected player, you'll also become infected, no matter if it's a teammate or not. Unless if you're a medic.

2. Revolver
3. Double Barrel Shotgun

5. Nailgun: It shoots nails that do 15 damage each. The fire rate is 0.1 second, and each shot uses 1 nail. These were the only changes to it.

Special Ability(ies):

Self-regeneration: WHen the medic is injured, he can regenerate himself 3 points of health each 3 seconds until he heaches his max health.


6. Heavy Weapons Guy
Health: 340 (510 if buffed by a Medic or AutoDoc)
Speed: 230
Weapons: Axe, Revolver, Shotgun, Chaingun
Initial shells: 50
Max shells: 250
Ability: Spin up/spin down the chaingun by command, but with a sacrifice on speed.

Description: The heavy weapons guy is the class that has the most health of all, but the slowest of all of them. It can only carry shells, because all his weapons use shells. It can spin up his chaingun by command, making it better as an offensive class, not just defensive. Always use this feature when you see lots of enemies and you don't want to waste ammo or be annoyed by the spin up/spindown delays.

Weapon Profiles:

1. Axe
2. Revolver
3. Double Barrel Shotgun

9. Chaingun: The chaingun is a weapon that does massive damage. Each pellet will do 20 damage. Its fire rate is 0.05 seconds, or 20 rounds per second, that's over 1200 rounds per minute! With 250 shells, you can fire it without releasing the button for only 12.5 seconds. Its damage per second is over 400, that means, you can kill another hwguy in less than a second! Its disadvantages are the spinup/spindown delay, and the bullets spread on distance, making it kinda ineffective on distant targets. You also can't fire it if you're not on ground, and your screen will shake while firing this gun. It's *strongly* recommended that you pick up backpacks from dead players or you'll run out of ammo in no time.

Special Ability(ies):

Spin up/spin down the chaingun: By typing 'impulse 112', your chaingun will spin up, and keep spinning, but with a sacrifice on speed. You will be running at half speed when you spin up your chaingun, as well as when you're firing it. This is useful when there are a lot of enemies in front of you and you don't want to waste your time spinning up/spinning down your chaingun.


7. Pyro
Health: 190 (285 if buffed by a Medic or AutoDoc)
Speed: 300
Weapons: Axe, Revolver, Flamethrower, Incendiary Cannon
Initial shells: 30
Initial rockets: 5
Initial cells: 120
Max shells: 50
Max rockets: 16
max cells: 200
Grenade type: Napalm
Ability: Nothing

Description: The pyro is a reasonable offensive class, with nice health. His only objective is set things on fire. So burn'em all!

Weapon Profiles:

1. Axe
2. Revolver

6. Flamethrower: The flamethrower is a short-range weapon that shoots flames. It doesn't work underwater. The more flames you hit an enemy, the more time he'll be on fire. The fire can only be extinguished if the time is up, or when entering on water, or healed by a medic. Other pyros won't get on fire. Each shot uses 1 cell, and the fire rate is 0.15 seconds.

7. Incendiary Cannon: It's a rocket launcher that shoots incendiary rockets. The rockets are slower that the rockets of the rocket launcher. The rocket itself does little damage, but it's got a nice area of effect that will set things on fire. Its area is 180 units. Uses 1 rocket, and the fire rate is 1.2 second.


8. Engineer
Health: 110 (165 if buffed by a Medic or AutoDoc)
Speed: 300
Weapons: Spanner, Revolver, Double Barrel Shotgun
Initial shells: 30
Initial rockets: 5
Initial cells: 100
Max shells: 50
Max rockets: 20
Max cells: 200
Grenade type: EMP
Ability: Build sentry gun

Description: The Engineer is a defensive-only class, with rather low health, and medium speed. Build a sentry gun on a strategic place, and take care of it.

Special Ability(ies):

Build sentry gun: Impulse 114 will build a sentry gun. It takes 5 seconds to build one. Within these 5 seconds, like the scout defusing a detpack, or a demoman planting a detpack, you can't move, shoot, and the grenade you were cooking will explode in your face.

Sentry Gun: An automated stationary turret. When you build one, its base is spawned then you can't move while building. After 3 seconds the sentry is finished. It costs 130 'metal' to build or upgrade one. The 'metal' are your cells. When the sentry gun is built, it comes with 25 shells. The sentry gun has 3 levels:

-Level 1-
Health: 150
Weapon: Semi-automatic rifle
Initial shells: 25
Max shells: 100
Damage per shot: 16
Fire rate: 0.2s

-Level 2-
Health: 180
Weapon: Machinegun
Max shells: 120
Damage per shot: 16
Fire rate: 0.1s

-Level 3-
Health: 216
Weapon: Machinegun, Rocket Launcher
Initial rockets: 5
Max shells: 144
Max rockets: 20
Damage per shot: 16 (bullet), 110 (rocket)
Fire rate(machinegun): 0.1s
Fire rate(rocket): 3s


9. Quake Guy (only available on read team, with scratch1 set to 1, because it's TF vs DM, not selectable)
Health: 184 (276 if buffed by an AutoDoc)
Speed: 320
Weapons: Axe, Revolver, Double Barrel Shotgun, Nailgun, Grenade Launcher, Rocket Launcher, Lightning Gun
Initial shells: 30
Initial nails: 30
Initial rockets: 5
Initial cells: 15
Max shells: 100
Max nails: 200
Max rockets: 25
Max cells: 20
Grenade type: HE
Ability: Nothing

Description: The Quake Guy is only available on TF vs DM mode, and only on red team. It uses the original player skin, hence the name. He is as fast as a Medic, and he's the only class that carries the Lightning Gun. But he can only fire his lightning gun for 2 seconds, he can only carry 20 cells, and also only 25 rockets. His grenade launcher does NOT launch pipebombs, only Demoman's. His rocket launcher is also a bit different from the Soldier's, the rockets are slightly faster, and does slightly more damage, but they don't have the Soldier's lock-on system. A direct hit will do 110 damage (the Soldier's RL does 102), and the blast radius will do 120 damage, with a radius of 120 units (the Soldier's RL's blast radius does 92 damage, and has a radius of 112 units).


III. GRENADES

Each class carry a type of hand grenade, which can be selected by pressing the 'g' key (or impulse 10). All classes start with 2, and can carry a maximum of 5, and also a box of rockets will give a grenade to you. A grenade will explode on contact with another player (or bot), minus the Flare and Napalm.

*Flash: Used by the Scout, it blinds enemies. Its explosion does 60 damage. The blindnes takes about 10 seconds to vanish.

*Flare: Not really a grenade, it's used by the Sniper, it simply illuminates some dark areas for 10 seconds.

*HE: Used by the Soldier and the Quake Guy, it merely explodes doing almost twice as much damage than a grenade from the grenade launcher. It does 180 damage.

*Cluster: Used by the Demoman and Heavy, it explodes turning into 12 smaller grenades. Each small grenade will do 120 damage, and the big grenade itself will do 100.

*Poison: Used by the Medic, this grenade does the same thing as hitting an enemy with the medikit. It'll infect all enemies within its area of effect. The grenade itself does 40 damage.

*Napalm: Used by the Pyro, it does pretty much the same thing as an incendiary rocket. But, the grenade must 'explode' 7 times before the last explosion, and then the grenade is gone. It will set things around it on fire.

*EMP: Used by the Engineer, this grenade will detonate ammo from other players, and will also detonate nearby ammo boxes, backpacks and detpacks, and depending on the quantity of ammo the enemy has, it can do massive damage. But if an enemy has no ammo, this grenade will not do any damage at all.


IV. BOTS

They are not as good as I expected to be, but it's kinda fun to play with them.
Of course they need waypoints, otherwise they won't know where the flag is. When they can't see a waypoint, they actually try coffee_move() until finding one. Their in-water behavior is very unrealistic, soon I'll be trying to improve that.
Unfortunately they don't have client physics emulation, so they're WinQuake-friendly. They support colors for GLQuake, and can be seen on the scoreboard.
Impulse 101 spawns a blue bot, and impulse 102 spawns a red bot.
The bots have a little trouble on well6/wellgl1.

So far, the supported maps are:

glide1
shank76
2on2fortb2
wall
well6/wellgl1
2fort5
crowns1
woodfort
xpress3
ctf1
ctf8


V. COMMANDS

Here's a list of console commands and what they do.

fraglimit: It now works as the capture limit. Frags are completely ignored.
scratch1: Set to '1' if you want to play TF vs DM mode. Default is '0'.
impulse 9: Selects '9' weapon.
impulse 10: Selects your grenade.
impulse 15: Prints your origin.
impulse 20-96: Spawn waypoints 1 to 77. More info on WAYPOINT EDITING.
impulse 97: Removes the nearest waypoint.
impulse 98: prints all waypoints (for waypointing new maps).
impulse 99: Change team. You die and respawn as the opposing team, as the same class. You don't lose a frag when doing this.
impulse 101: Spawns a blue bot.
impulse 102: Spawns a red bot.
impulse 103: Kicks a blue bot.
impulse 104: Kicks a red bot.
impulse 105: Kicks all bots at once.
impulse 110: Detonates your pipebombs.
impulse 111: Turn proximity sensor on or off.
impulse 112: Spin up/spin down your chaingun.
impulse 113: Toggle laser sight.
impulse 114: Build a sentry gun.
impulse 115: Set a detpack for 5 seconds.
impulse 116: Set a detpack for 20 seconds.
impulse 117: Set a detpack for 50 seconds.
impulse 118: Set a detpack for 255 seconds.
impulse 120: Respawn as a Scout.
impulse 121: Respawn as a Sniper.
impulse 122: Respawn as a Soldier.
impulse 123: Respawn as a Demoman.
impulse 124: Respawn as a Medic.
impulse 125: Respawn as a Heavy.
impulse 126: Respawn as a Pyro.
impulse 127: Respawn as an Engineer.
impulse 160: This merely toggles if you want your gl_polyblend be set to zero or not after your blindness caused by a flash grenade is healed.
impulse 200: Drops your current Tech powerup.
impulse 201: Drops the flag(if you're carrying it).


VI. TECH POWERUPS

The Tech powerups were greatly inspired from Quake2 ThreeWave CTF. They actually do exactly the same thing as the Q2 CTF's Tech powerups do. They spawn on the map's team spawn points. After 1 minute they change their positions.
There are 4 types of Tech powerups:

1. Disruptor Shield: You take half damage from everything.

2. Time Accelerator: All your weapons (except the axe) will shoot twice as fast. Just try using the Chaingun! >:)

3. AutoDoc: Regenerates health.

4. Power Amplifier: All your weapons will do 2x damage. If you use this powerup combined with quad damage, your weapons will do 8x damage!! >:)


VII. WAYPOINT EDITING

Spawn waypoints by typing the impulses shown above. A bubble will spawn inside you and stay there, just to indicate where you spawned it. In order to make an unwaypointed map load your waypoints, you'll need to run Quake with -condebug command, and after spawning all your waypoints, use impulse 98. Then, open your qconsole.log, fink all make_way() lines, and paste it to LoadWaypoints() located in world.qc, put at the very top. BUT, you'll need to put an "if" statement before.

Use this:

if (self.model == "maps/whatever.bsp")
{
	make_way (...);
	...
}

And there you go.

And an important thing, the waypoint number 1 MUST be on the flag. Doesn't matter if you start waypointing from the blue base or red base, the first waypoint SHOULD be in the flag. And then, you spawn the waypoints number 2, 3 and so on until the enemy flag, which also SHOULD be the last waypoint. You also MAY spawn two waypoints with the same number, for example you put 2 waypoints with the same number on corridors that lead to the same place.
You can set 'developer' to '1' and restart the map, so you can see the waypoints and you know their numbers by touching them.


VIII. KNOWN BUGS

None that I know of, but there might be some bugs I didn't figure out yet, because it's a beta. There's the floating weapon model bug I said above, though.